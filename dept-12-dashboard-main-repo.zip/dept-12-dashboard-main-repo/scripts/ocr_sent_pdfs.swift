// Local-only OCR of scanned PDF pages, using macOS Vision and PDFKit.
// Usage: compiled-tool inventory.json source-folder output.jsonl [file-limit]
import Foundation
import AppKit
import PDFKit
import Vision

let args = CommandLine.arguments
let records = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: args[1]))) as! [[String: Any]]
let source = URL(fileURLWithPath: args[2])
let output = URL(fileURLWithPath: args[3])
let limit = args.count > 4 ? Int(args[4])! : records.count
var completed = Set<String>()
if let prior = try? String(contentsOf: output, encoding: .utf8) {
    for line in prior.split(separator: "\n") {
        if let data = line.data(using: .utf8),
           let row = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           row["error"] == nil, let sha = row["sha256"] as? String, let page = row["page"] as? Int {
            completed.insert("\(sha):\(page)")
        }
    }
}
if !FileManager.default.fileExists(atPath: output.path) {
    FileManager.default.createFile(atPath: output.path, contents: nil)
}
let handle = try FileHandle(forWritingTo: output)
try handle.seekToEnd()
let lock = NSLock()
let queue = OperationQueue()
queue.maxConcurrentOperationCount = 3
var written = 0
let started = Date()
for record in records.prefix(limit) {
    queue.addOperation {
        let filename = record["filename"] as! String
        let sha = record["sha256"] as! String
        guard let pdf = PDFDocument(url: source.appendingPathComponent(filename)) else { return }
        for index in 0..<pdf.pageCount {
            if completed.contains("\(sha):\(index + 1)") { continue }
            autoreleasepool {
                var result: [String: Any] = ["filename": filename, "sha256": sha, "page": index + 1]
                do {
                    guard let page = pdf.page(at: index) else { throw NSError(domain: "PDFPage", code: 1) }
                    let size = page.bounds(for: .mediaBox).size
                    let thumb = page.thumbnail(of: CGSize(width: size.width * 3, height: size.height * 3), for: .mediaBox)
                    var rect = CGRect(origin: .zero, size: thumb.size)
                    guard let cg = thumb.cgImage(forProposedRect: &rect, context: nil, hints: nil) else { throw NSError(domain: "PDFRender", code: 1) }
                    let request = VNRecognizeTextRequest()
                    request.recognitionLevel = .accurate
                    request.usesLanguageCorrection = false
                    request.recognitionLanguages = ["en-US"]
                    try VNImageRequestHandler(cgImage: cg, options: [:]).perform([request])
                    let observations = request.results ?? []
                    let lines: [[String: Any]] = observations.compactMap { item in
                        guard let value = item.topCandidates(1).first else { return nil }
                        return ["text": value.string, "confidence": value.confidence,
                                "box": [item.boundingBox.minX, item.boundingBox.minY,
                                        item.boundingBox.width, item.boundingBox.height]]
                    }
                    result["lines"] = lines
                    result["text"] = lines.map { $0["text"] as! String }.joined(separator: "\n")
                } catch {
                    result["error"] = String(describing: error)
                }
                lock.lock()
                if let data = try? JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]) {
                    handle.write(data)
                    handle.write(Data([10]))
                }
                written += 1
                if written % 25 == 0 {
                    print("OCR pages: \(written); elapsed seconds: \(Int(Date().timeIntervalSince(started)))")
                    fflush(stdout)
                }
                lock.unlock()
            }
        }
    }
}
queue.waitUntilAllOperationsAreFinished()
try handle.close()
print("OCR complete: \(written) pages; \(Int(Date().timeIntervalSince(started))) seconds")
