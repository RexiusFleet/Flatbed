#!/usr/bin/env python3
"""Apply D221's reviewed Umatilla mapping; dry-run by default.

Preserves every trip, including repeated source numbers. Limited to the
confirmed 2025–26 season. --related-routes includes the separately confirmed
Umatilla returns and direct Valley AG deliveries. Does not infer multi-leg
routes, preparation notes, or other seasons. Requires a backup
before --commit. Writes its review under ignored output/import-review/.
"""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

BASE = Path(__file__).resolve().parents[1]
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")
RULE = "umatilla-season-2025-v1"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    ap.add_argument("--related-routes", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        rows = conn.execute("""
            select * from orders
            where custom->>'source' in ('sheet2025','sheet2026')
              and (notes ~* '^bag[[:space:]]*plant[[:space:]]+to[[:space:]]+umatilla'
                   or (%s and (
                       notes ~* '^umatilla([[:space:]]+yard)?[[:space:]]+to[[:space:]]+(the[[:space:]]+)?bag[[:space:]]+plant'
                       or notes ~* '^valley[[:space:]]+ag[[:space:]]+to[[:space:]]+umatilla'
                   )))
              and delivered_at between '2025-10-01' and '2026-09-14'
            order by delivered_at, custom->>'truck', id
            for update
        """, (args.related_routes,)).fetchall()
        if not rows:
            raise ValueError("No route records found")
        dept = conn.execute("select id from departments where name='Bagger - 07'").fetchone()
        if not dept:
            raise ValueError("Confirmed Bagger department not found")
        seen_numbers = {}
        for row in rows:
            match = re.search(r"#\s*(\d+)\b", row["notes"])
            if match:
                seen_numbers.setdefault(int(match[1]), []).append(str(row["id"]))
        next_number = max(seen_numbers, default=0) + 1
        changes = []
        for row in rows:
            if row["custom"].get("season_review", {}).get("rule") == RULE:
                if not row["is_transfer"] or row["transfer_season"] != 2025 or row["transfer_department_id"] != dept["id"]:
                    raise ValueError("Previously reviewed row changed; review manually")
                continue
            if row["customer_party_id"] or row["broker_party_id"] or row["solomon_order_no"]:
                raise ValueError("Unexpected customer/broker/order link; manual review required")
            loads = conn.execute("""
                select l.*, (select count(*) from load_orders x where x.load_id=l.id) as order_count
                from loads l join load_orders lo on lo.load_id=l.id
                where lo.order_id=%s for update of l
            """, (row["id"],)).fetchall()
            if len(loads) != 1 or loads[0]["order_count"] != 1:
                raise ValueError("Expected one standalone trip per imported row")
            match = re.search(r"#\s*(\d+)\b", row["notes"])
            number = int(match[1]) if match else next_number
            notes = row["notes"] if match else row["notes"].rstrip() + f" # {number}"
            if not match:
                next_number += 1
            review = {"rule": RULE, "season": 2025, "load_number": number,
                      "number_origin": "source" if match else "assigned_after_source_max",
                      "repeated_source_number": bool(match and len(seen_numbers[number]) > 1),
                      "original_notes": row["notes"]}
            change = {"order_before": row, "load_before": loads[0], "review": review,
                      "notes_after": notes}
            changes.append(change)
        report = {"mode": "apply-requested" if args.commit else "dry-run", "season": "2025–26",
                  "route_trip_count": len(rows), "changes": changes,
                  "repeated_source_numbers": {str(k): v for k, v in seen_numbers.items() if len(v) > 1}}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-umatilla.json")
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            for change in changes:
                row, load = change["order_before"], change["load_before"]
                conn.execute("""
                    update orders set kind='external', is_transfer=true,
                        transfer_department_id=%s, transfer_season=2025,
                        department='07', order_period=null, notes=%s,
                        custom=custom || jsonb_build_object('season_review',%s::jsonb)
                    where id=%s
                """, (dept["id"], change["notes_after"], Jsonb(change["review"]), row["id"]))
                conn.execute("update loads set kind='external', notes=%s where id=%s",
                             (change["notes_after"], load["id"]))
            conn.commit()
            report["mode"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"mode": report["mode"], "trips": len(rows), "changed": len(changes),
                          "assigned_numbers": [c["review"]["load_number"] for c in changes
                                               if c["review"]["number_origin"] != "source"],
                          "repeated_source_numbers": list(report["repeated_source_numbers"]),
                          "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
