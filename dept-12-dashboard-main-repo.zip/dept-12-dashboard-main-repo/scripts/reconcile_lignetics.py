#!/usr/bin/env python3
"""Lignetics rows are external freight for Bi-Mart, never a Bag Order, dry-run first.

Nate (2026-09-12): "take any 'lignetics' orders out of the 07 customers those
are for bi-mart but its external freight so its bi-mart as the customer/broker."
Two of the 27 imported Lignetics rows had been matched by
reconcile_internal_orders.py's brand+store-number pairing to a specific
Bi-Mart store (the store number happened to appear right after "Bi-Mart" in
the text, e.g. "Bi-Mart 607"), landing them as Bag Orders — wrong: Lignetics
is a pellet-fuel shipper delivering to Bi-Mart stores, not a bag customer.
All 27 get the same treatment: kind='external', broker_party_id = the
general "BI-MART" broker party (not a specific store), department external.
"""
import argparse
import datetime as dt
import json

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

RULE = "lignetics-external-bimart-v1"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        bimart = conn.execute("select id from parties where is_broker and lower(name)='bi-mart'").fetchone()
        if not bimart:
            raise ValueError("Expected general BI-MART broker party not found")
        rows = conn.execute("""select * from orders where notes ilike '%%lignetic%%'
            order by delivered_at for update""").fetchall()
        if not rows:
            raise ValueError("No Lignetics rows found")
        changes = []
        for row in rows:
            if row["is_transfer"] or row["solomon_order_no"]:
                raise ValueError(f"Order {row['id']} unexpectedly a transfer or already numbered")
            loads = conn.execute("""select l.*, (select count(*) from load_orders x where x.load_id=l.id) as n
                from loads l join load_orders lo on lo.load_id=l.id
                where lo.order_id=%s for update of l""", (row["id"],)).fetchall()
            if len(loads) != 1 or loads[0]["n"] != 1:
                raise ValueError(f"Order {row['id']} is not a standalone single-order trip")
            after = {"kind": "external", "customer_party_id": None,
                     "broker_party_id": row["broker_party_id"] or bimart["id"], "department": "12"}
            if all(row[k] == v for k, v in after.items()) and row["custom"].get("lignetics_review") == {"rule": RULE}:
                continue
            changes.append({"order": row, "load": loads[0], "after": after})
        report = {"status": "preview", "matched": len(rows), "changed": len(changes)}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-lignetics.json")
        path.write_text(json.dumps({**report, "changes": changes}, default=str, indent=2) + "\n")
        if args.commit:
            for c in changes:
                conn.execute("""update orders set kind='external', customer_party_id=null,
                    broker_party_id=%s, department='12',
                    custom=custom || jsonb_build_object('lignetics_review',%s::jsonb)
                    where id=%s""", (c["after"]["broker_party_id"], Jsonb({"rule": RULE}), c["order"]["id"]))
                conn.execute("update loads set kind='external' where id=%s", (c["load"]["id"],))
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps({**report, "changes": changes}, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({**report, "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
