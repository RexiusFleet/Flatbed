#!/usr/bin/env python3
"""Merge the two synthetic Bi-Mart seed rows into their imported real rows.

Dry-run by default. Pass --apply only after the exact IDs/names validate. All
reference moves and both deletes happen in one transaction.
"""

import argparse
import os

import psycopg
from psycopg.rows import dict_row


DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")

PAIRS = (
    {
        "duplicate_party": "11111111-1111-1111-1111-111111111103",
        "duplicate_name": "Bi-Mart 601",
        "canonical_party": "a33e5fe4-1c1c-49aa-8d01-5ad4c2c1c4ed",
        "canonical_name": "BI-MART #601",
        "duplicate_location": "22222222-2222-2222-2222-222222222202",
        "canonical_location": "74575e39-df91-491d-90ae-d6e33931429c",
    },
    {
        "duplicate_party": "11111111-1111-1111-1111-111111111104",
        "duplicate_name": "Bi-Mart 602",
        "canonical_party": "c286fc30-a6f5-4cd1-9fab-693d73663cc0",
        "canonical_name": "BI-MART #602",
        "duplicate_location": "22222222-2222-2222-2222-222222222203",
        "canonical_location": "efff7fa9-0033-42a3-a4d8-44fc1aa6c3e8",
    },
)


def validate_pair(cur, pair):
    cur.execute(
        "select id, name from parties where id in (%s, %s) order by id",
        (pair["duplicate_party"], pair["canonical_party"]),
    )
    names = {str(row["id"]): row["name"] for row in cur.fetchall()}
    expected = {
        pair["duplicate_party"]: pair["duplicate_name"],
        pair["canonical_party"]: pair["canonical_name"],
    }
    if names != expected:
        raise RuntimeError(f"Party identity check failed: expected {expected}, found {names}")

    cur.execute(
        "select id, party_id from locations where id in (%s, %s) order by id",
        (pair["duplicate_location"], pair["canonical_location"]),
    )
    owners = {str(row["id"]): str(row["party_id"]) for row in cur.fetchall()}
    expected_owners = {
        pair["duplicate_location"]: pair["duplicate_party"],
        pair["canonical_location"]: pair["canonical_party"],
    }
    if owners != expected_owners:
        raise RuntimeError(
            f"Location identity check failed: expected {expected_owners}, found {owners}"
        )

    cur.execute("select count(*) as n from locations where party_id=%s", (pair["duplicate_party"],))
    if cur.fetchone()["n"] != 1:
        raise RuntimeError(f"Duplicate party {pair['duplicate_name']} does not have exactly one location")


def move_refs(cur, pair):
    duplicate_party = pair["duplicate_party"]
    canonical_party = pair["canonical_party"]
    duplicate_location = pair["duplicate_location"]
    canonical_location = pair["canonical_location"]
    counts = {}

    statements = (
        ("orders.customer", "update orders set customer_party_id=%s where customer_party_id=%s",
         (canonical_party, duplicate_party)),
        ("orders.broker", "update orders set broker_party_id=%s where broker_party_id=%s",
         (canonical_party, duplicate_party)),
        ("loads.carrier", "update loads set carrier_party_id=%s where carrier_party_id=%s",
         (canonical_party, duplicate_party)),
        ("invoices.customer", "update invoices set customer_party_id=%s where customer_party_id=%s",
         (canonical_party, duplicate_party)),
        ("orders.pickup", "update orders set pickup_location_id=%s where pickup_location_id=%s",
         (canonical_location, duplicate_location)),
        ("orders.delivery", "update orders set delivery_location_id=%s where delivery_location_id=%s",
         (canonical_location, duplicate_location)),
        ("order_stops.location", "update order_stops set location_id=%s where location_id=%s",
         (canonical_location, duplicate_location)),
        ("load_stops.location", "update load_stops set location_id=%s where location_id=%s",
         (canonical_location, duplicate_location)),
        ("location_images.location", "update location_images set location_id=%s where location_id=%s",
         (canonical_location, duplicate_location)),
    )
    for label, statement, params in statements:
        cur.execute(statement, params)
        counts[label] = cur.rowcount

    for table_name, old_id, new_id in (
        ("parties", duplicate_party, canonical_party),
        ("locations", duplicate_location, canonical_location),
    ):
        cur.execute(
            """insert into grid_cell_fmt (table_name, row_id, field, fmt)
               select table_name, %s, field, fmt from grid_cell_fmt
               where table_name=%s and row_id=%s
               on conflict (table_name, row_id, field) do nothing""",
            (new_id, table_name, old_id),
        )
        counts[f"{table_name}.formatting_copied"] = cur.rowcount
        cur.execute("delete from grid_cell_fmt where table_name=%s and row_id=%s", (table_name, old_id))
        counts[f"{table_name}.formatting_removed"] = cur.rowcount

    cur.execute(
        "delete from grid_row_orders where row_id in (%s, %s)",
        (duplicate_party, duplicate_location),
    )
    counts["saved_row_positions"] = cur.rowcount
    cur.execute("delete from locations where id=%s", (duplicate_location,))
    counts["duplicate_location"] = cur.rowcount
    cur.execute("delete from parties where id=%s", (duplicate_party,))
    counts["duplicate_party"] = cur.rowcount
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="Commit the verified merge and deletes")
    args = parser.parse_args()

    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        totals = {}
        with conn.cursor() as cur:
            for pair in PAIRS:
                validate_pair(cur, pair)
                moved = move_refs(cur, pair)
                totals[pair["duplicate_name"]] = moved
        if args.apply:
            conn.commit()
        else:
            conn.rollback()

    print("Duplicate Bi-Mart merge " + ("applied" if args.apply else "validated (dry run rolled back)"))
    for name, counts in totals.items():
        changed = ", ".join(f"{key}={value}" for key, value in counts.items() if value)
        print(f"  {name}: {changed or 'no references'}")


if __name__ == "__main__":
    main()
