#!/usr/bin/env python3
"""Convert confirmed import reminders to schedule notes; preview by default.

Original records are saved under ignored output/import-review before any
mutation. Refuse shared placements, existing notes, paperwork, or billing.
Run only against the backed-up local import. Never matches Load as a substring
of another word or interprets arbitrary text inside a freight route as a note.
"""
import argparse
from collections import Counter, defaultdict
import datetime as dt
import json
import re

import psycopg
from psycopg.rows import dict_row

from reconcile_umatilla_season import BASE, DSN

INSTRUCTION = re.compile(r"^(?:\d+\s*)?(?:(?:\d{1,2}(?::\d{2})?\s*(?:AM|PM))\s*)?(?:load|deliver)\b", re.I)
ADMIN = re.compile(r"^grab\s+(?:fork\s*lift|lift)\b", re.I)
HOLIDAY = re.compile(r"^(?:labor\s+day|memorial\s+day|independence\s+day|christmas|thanksgiving)\b", re.I)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        rows = conn.execute("""select o.*, l.id as load_id, l.truck_id,
            l.scheduled_date, l.slot from orders o
            join load_orders lo on lo.order_id=o.id join loads l on l.id=lo.load_id
            where o.custom->>'source' in ('sheet2025','sheet2026') and not o.is_transfer
            order by l.scheduled_date,l.truck_id,l.slot for update of o,l""").fetchall()
        letters = defaultdict(list)
        for row in rows:
            if len(row["notes"].strip()) == 1:
                letters[(row["scheduled_date"], row["truck_id"])].append(row)
        holiday_ids = set()
        # Source spells LABOR and DAY vertically on two truck columns. Require
        # both words on the same date; do not infer dates from holiday calendars.
        words = defaultdict(dict)
        for (day, truck), group in letters.items():
            word = "".join(r["notes"].strip().upper() for r in group)
            if word in ("LABOR", "DAY"):
                words[day][word] = group
        for parts in words.values():
            if "LABOR" in parts and "DAY" in parts:
                holiday_ids.update(r["id"] for group in parts.values() for r in group)
        changes = []
        for row in rows:
            body = row["notes"].strip()
            reason = ("load_deliver_instruction" if INSTRUCTION.match(body) else
                      "forklift_reminder" if ADMIN.match(body) else
                      "holiday" if HOLIDAY.match(body) or row["id"] in holiday_ids else
                      "grid_marker" if body == "*" else None)
            if not reason:
                continue
            load = conn.execute("select * from loads where id=%s", (row["load_id"],)).fetchone()
            links = conn.execute("select * from load_orders where load_id=%s or order_id=%s",
                                 (row["load_id"], row["id"])).fetchall()
            if len(links) != 1:
                raise ValueError("Shared order/load needs review")
            protected = conn.execute("""select
                exists(select 1 from documents where order_id=%s or load_id=%s) or
                exists(select 1 from invoices where order_id=%s or load_id=%s) or
                exists(select 1 from order_stops where order_id=%s) or
                exists(select 1 from load_stops where load_id=%s) as found""",
                (row["id"], load["id"], row["id"], load["id"], row["id"], load["id"])).fetchone()
            if protected["found"] or row["solomon_order_no"] or row["billed_at"]:
                raise ValueError("Freight-linked reminder needs review")
            if not load["truck_id"] or conn.execute("""select 1 from schedule_notes
                where truck_id=%s and scheduled_date=%s and slot=%s""",
                (load["truck_id"], load["scheduled_date"], load["slot"])).fetchone():
                raise ValueError("Note placement unavailable")
            changes.append({"order_before": row, "load_before": load,
                            "link_before": links[0], "reason": reason})
        report = {"status": "preview", "changes": changes}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-notes.json")
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            order_ids = [c["order_before"]["id"] for c in changes]
            load_ids = [c["load_before"]["id"] for c in changes]
            def unchanged_fingerprint():
                return conn.execute("""select
                    (select md5(string_agg(row_to_json(o)::text,'' order by id))
                     from orders o where not(id=any(%s::uuid[]))) as orders,
                    (select md5(string_agg(row_to_json(l)::text,'' order by id))
                     from loads l where not(id=any(%s::uuid[]))) as loads""",
                     (order_ids, load_ids)).fetchone()
            before = unchanged_fingerprint()
            for change in changes:
                row, load = change["order_before"], change["load_before"]
                note = conn.execute("""insert into schedule_notes
                    (truck_id,scheduled_date,slot,body,fmt,category_id)
                    values (%s,%s,%s,%s,%s::jsonb,%s) returning id""",
                    (load["truck_id"], load["scheduled_date"], load["slot"], row["notes"],
                     json.dumps(load.get("fmt") or {}), load["category_id"])).fetchone()
                change["note_id"] = str(note["id"])
                conn.execute("delete from loads where id=%s", (load["id"],))
                conn.execute("delete from orders where id=%s", (row["id"],))
            if unchanged_fingerprint() != before:
                raise ValueError("Unrelated freight changed; rolling back")
            for change in changes:
                note = conn.execute("select * from schedule_notes where id=%s",
                                    (change["note_id"],)).fetchone()
                load = change["load_before"]
                if any(note[k] != load[k] for k in ("truck_id", "scheduled_date", "slot")) or note["body"] != change["order_before"]["notes"]:
                    raise ValueError("Note text or placement changed; rolling back")
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"status": report["status"], "count": len(changes),
                          "by_reason": dict(Counter(c["reason"] for c in changes)),
                          "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
