#!/usr/bin/env python3
"""End-to-end multi-stop smoke test; every database write is rolled back."""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "app"))

import server  # noqa: E402


class RollbackSmokeTest(Exception):
    pass


def main():
    created_id = None
    try:
        with server.db().transaction():
            locs = server.q("select id from locations order by name limit 4")
            truck = server.q("select id from trucks where active order by number limit 1", one=True)
            assert len(locs) == 4 and truck

            order = server.api_create_order({"kind": "external", "broker_load_no": "ROUTE-SMOKE"})
            created_id = order["id"]
            server.api_update_order(created_id, {
                "pickup_location_id": locs[0]["id"], "delivery_location_id": locs[3]["id"],
                "po_number": "PU-1", "delivery_number": "DEL-2",
            })
            simple = server.q("select * from order_stops where order_id=%s order by sequence", (created_id,))
            assert [s["stop_type"] for s in simple] == ["pickup", "delivery"]

            server.api_order_route_save({"order_id": created_id, "stops": [
                {"stop_type": "pickup", "location_id": str(locs[0]["id"]), "reference_number": "PU-1"},
                {"stop_type": "pickup", "location_id": str(locs[1]["id"]), "reference_number": "PU-2"},
                {"stop_type": "delivery", "location_id": str(locs[2]["id"]), "reference_number": "DEL-1"},
                {"stop_type": "delivery", "location_id": str(locs[3]["id"]), "reference_number": "DEL-2"},
            ]})
            route = server.q("select * from order_stops where order_id=%s order by sequence", (created_id,))
            assert [s["stop_type"] for s in route] == ["pickup", "pickup", "delivery", "delivery"]

            load = server.api_schedule({"order_id": created_id, "truck_id": truck["id"],
                                        "date": "2030-01-02", "slot": 1})
            scheduled = server.q("select * from load_stops where load_id=%s order by sequence", (load["id"],))
            assert [s["stop_type"] for s in scheduled] == ["pickup", "pickup", "delivery", "delivery"]
            assert all(s["order_stop_id"] for s in scheduled)

            # A scheduled, uninvoiced route remains editable and updates the
            # truck-run snapshot. Arbitrary pickup/drop interleaving is valid.
            server.api_order_route_save({"order_id": created_id, "stops": [
                {"stop_type": "pickup", "location_id": str(locs[0]["id"])},
                {"stop_type": "delivery", "location_id": str(locs[2]["id"])},
                {"stop_type": "pickup", "location_id": str(locs[1]["id"])},
                {"stop_type": "delivery", "location_id": str(locs[3]["id"])},
            ]})
            scheduled = server.q("select stop_type from load_stops where load_id=%s order by sequence", (load["id"],))
            assert [s["stop_type"] for s in scheduled] == ["pickup", "delivery", "pickup", "delivery"]

            # Returning to the no-extra-work path is allowed only as P then D.
            server.api_order_route_save({"order_id": created_id, "route_mode": "simple", "stops": [
                {"stop_type": "pickup", "location_id": str(locs[0]["id"]), "reference_number": "PU-1"},
                {"stop_type": "delivery", "location_id": str(locs[3]["id"]), "reference_number": "DEL-2"},
            ]})
            simple_again = server.q("select route_mode from orders where id=%s", (created_id,), one=True)
            assert simple_again["route_mode"] == "simple"
            raise RollbackSmokeTest()
    except RollbackSmokeTest:
        pass

    assert created_id and not server.q("select 1 from orders where id=%s", (created_id,), one=True)
    print("multi-stop smoke test passed: simple/custom routes, arbitrary sequencing, scheduled sync, rollback")


if __name__ == "__main__":
    main()
