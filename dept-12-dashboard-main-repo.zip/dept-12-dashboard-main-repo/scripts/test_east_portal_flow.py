#!/usr/bin/env python3
"""End-to-end smoke test for a running local Rexius Bag Orders app."""

import base64
import json
import os
from email import policy
from email.parser import BytesParser
from pathlib import Path
from urllib.request import Request, urlopen


BASE_URL = os.environ.get("EAST_PORTAL_TEST_URL", "http://127.0.0.1:8785")
OUTBOX = Path(os.environ.get("EAST_EMAIL_OUTBOX", "/private/tmp/dept12-east-email-outbox"))


def get_json(path):
    with urlopen(BASE_URL + path, timeout=15) as response:
        return json.load(response)


def main():
    initial = get_json("/api/bootstrap")
    order = next(item for item in initial["ready"] if item["solomon_order_no"] == "07-0926-9001")
    truck = initial["trucks"][0]

    with urlopen(BASE_URL + f"/api/order/{order['id']}/pdf", timeout=15) as response:
        pdf = response.read()
    assert pdf.startswith(b"%PDF-"), "Source receipt endpoint did not return a PDF"

    request = Request(
        BASE_URL + f"/api/order/{order['id']}/complete",
        method="POST",
        headers={"Content-Type": "application/json"},
        data=json.dumps(
            {
                "truck_number": truck["number"],
                "note": "Automated local workflow check - synthetic data only.",
                "pdf_b64": base64.b64encode(pdf).decode("ascii"),
            }
        ).encode(),
    )
    with urlopen(request, timeout=30) as response:
        result = json.load(response)
    assert result["ok"] and result["email"] == "captured"

    final = get_json("/api/bootstrap")
    assert not any(item["id"] == order["id"] for item in final["ready"])
    assert any(item["id"] == order["id"] for item in final["completed"])

    messages = sorted(OUTBOX.glob("*.eml"), key=lambda path: path.stat().st_mtime)
    assert messages, "No test email was captured"
    message = BytesParser(policy=policy.default).parsebytes(messages[-1].read_bytes())
    assert str(message["To"]) == "nathanl@rexius.com"
    attachments = list(message.iter_attachments())
    assert len(attachments) == 1 and attachments[0].get_content_type() == "application/pdf"

    print("East Side workflow OK")
    print(f"Completed order: {order['solomon_order_no']}")
    print(f"Truck: {truck['number']}")
    print(f"Email: {message['To']} ({result['email']})")
    print(f"Attachment: {attachments[0].get_filename()}")


if __name__ == "__main__":
    main()
