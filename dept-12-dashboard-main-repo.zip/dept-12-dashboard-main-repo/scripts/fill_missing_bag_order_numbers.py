#!/usr/bin/env python3
"""D224: fill blank imported Bag Order numbers using delivery-month rules.

Earlier deliveries sharing a month/short-number move back exactly one month.
Same-day ties and remaining occupied-number conflicts are reported, never
arbitrarily merged or shifted further. Existing full numbers are preserved.
Preview first; original rows and unresolved cases are saved under output/.
"""
import argparse
from collections import Counter, defaultdict
import datetime as dt
import json
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

PAIR = re.compile(r"(?<![\d/])(\d{1,4})\s*/\s*(\d{1,3})(?![\d/])")


def pair_from_notes(text, delivered):
    candidates = []
    matches = list(PAIR.finditer(text or ""))
    for m in matches:
        before, after = text[:m.start()], text[m.end():]
        if re.search(r"\b(?:rdy|ready|redy|date|dated|appt)\s*[:=-]?\s*$", before, re.I):
            continue
        if m[0].replace(" ", "") == "1/2" and re.match(r"\s*BT\b", after, re.I):
            continue  # half a back trailer, not order 1 / two pallets
        if len(matches) > 1 and delivered and (int(m[1]), int(m[2])) == (delivered.month, delivered.day):
            continue
        if int(m[1]) > 0 and int(m[2]) > 0:
            candidates.append((int(m[1]), int(m[2]), m[0]))
    return candidates[0] if len(candidates) == 1 else None


def previous_month(day):
    return (day.replace(day=1) - dt.timedelta(days=1)).replace(day=1)


def number_for(month, short):
    return f"07-{month:%m%y}-{short:04d}"


def build_plan(rows, occupied):
    peers = defaultdict(list)
    parsed = {}
    for row in rows:
        pair = pair_from_notes(row["notes"] or "", row["delivered_at"])
        parsed[row["id"]] = pair
        if pair and row["delivered_at"]:
            peers[(row["delivered_at"].replace(day=1), pair[0])].append(row)
    plans = []
    for row in rows:
        if (row["solomon_order_no"] or "").strip():
            continue
        pair = parsed[row["id"]]
        p = {"before": row, "issues": [], "number": None, "period": None,
             "pallet_count": pair[1] if pair else None, "pair": pair, "previous_month": False}
        plans.append(p)
        if not pair:
            p["issues"].append("no_unambiguous_order_pallet_pair")
            continue
        day = row["delivered_at"]
        if not day:
            p["issues"].append("missing_delivery_date")
            continue
        month = day.replace(day=1)
        group = peers[(month, pair[0])]
        latest = max(r["delivered_at"] for r in group)
        if day < latest:
            month = previous_month(day)
            p["previous_month"] = True
        elif sum(r["delivered_at"] == day for r in group) > 1:
            p["issues"].append("same_delivery_date_duplicate")
            continue
        p["period"] = month
        p["candidate"] = number_for(month, pair[0])
    targets = Counter(p["candidate"] for p in plans if p.get("candidate"))
    for p in plans:
        candidate = p.get("candidate")
        if not candidate:
            continue
        if candidate in occupied:
            p["issues"].append("number_already_assigned")
        elif targets[candidate] > 1:
            p["issues"].append("remaining_duplicate_after_previous_month_rule")
        else:
            p["number"] = candidate
    return plans


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        config = conn.execute("select internal_pattern,internal_department from order_number_settings where id=1").fetchone()
        if config != {"internal_pattern": "07-{MM}{YY}-{####}", "internal_department": "07"}:
            raise ValueError("Order-number settings changed; review format")
        rows = conn.execute("""select * from orders where kind='internal' and not is_transfer
            and custom->>'source' in ('sheet2025','sheet2026') order by delivered_at,id for update""").fetchall()
        occupied = {r["solomon_order_no"] for r in conn.execute(
            "select solomon_order_no from orders where solomon_order_no is not null").fetchall()}
        plans = build_plan(rows, occupied)
        changes = []
        for p in plans:
            row = p["before"]
            if not p["pair"]:
                continue
            meta = {"rule": "missing-bag-numbers-v1", "source_pair": p["pair"][2],
                    "short_order_number": str(p["pair"][0]), "issues": p["issues"],
                    "previous_month": p["previous_month"], "assigned_number": p["number"]}
            p["metadata"] = meta
            if p["number"] or row["pallet_count"] != p["pallet_count"] or row["custom"].get("bag_number_repair") != meta:
                changes.append(p)
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-missing-bag-numbers.json")
        summary = {"blank_orders_scanned": len(plans), "numbers_to_fill": sum(bool(p["number"]) for p in plans),
                   "previous_month_assignments": sum(bool(p["number"]) and p["previous_month"] for p in plans),
                   "pallet_values_to_change": sum(p["pallet_count"] is not None and p["pallet_count"] != p["before"]["pallet_count"] for p in plans),
                   "issues": dict(Counter(i for p in plans for i in p["issues"]))}
        report = {"status": "preview", "summary": summary, "plans": plans}
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            ids = [p["before"]["id"] for p in changes]
            def fingerprint():
                return conn.execute("""select
                    (select md5(string_agg(row_to_json(o)::text,'' order by id)) from orders o
                     where not(id=any(%s::uuid[]))) as other_orders,
                    (select md5(string_agg(row_to_json(l)::text,'' order by id)) from loads l) as loads""", (ids,)).fetchone()
            before = fingerprint()
            for p in changes:
                row = p["before"]
                custom = dict(row["custom"])
                custom["bag_number_repair"] = p["metadata"]
                if p["number"]:
                    for key in ("internal_import_review", "bag_import_review"):
                        if key in custom:
                            custom[key] = dict(custom[key], issues=[], order_month_status="delivery_month_rule",
                                               confirmed_order_month=p["period"].isoformat())
                conn.execute("""update orders set solomon_order_no=%s,pallet_count=%s,
                    order_period=%s,department='07',custom=%s where id=%s""",
                    (p["number"] or row["solomon_order_no"], p["pallet_count"],
                     p["period"] if p["number"] else row["order_period"], Jsonb(custom), row["id"]))
            if fingerprint() != before:
                raise ValueError("Unrelated orders or loads changed; rolling back")
            for p in changes:
                actual = conn.execute("select * from orders where id=%s", (p["before"]["id"],)).fetchone()
                if actual["pallet_count"] != p["pallet_count"] or (p["number"] and (actual["solomon_order_no"] != p["number"] or actual["order_period"] != p["period"])):
                    raise ValueError("Verification failed; rolling back")
                if any(actual[k] != p["before"][k] for k in ("notes", "customer_party_id", "delivered_at", "ordered_at")):
                    raise ValueError("Original customer, notes or dates changed; rolling back")
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"status": report["status"], **summary, "changed": len(changes), "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
