#!/usr/bin/env node
/*
 * Regression test for the live rate-con ingestion feature (ingestRateCon /
 * parseRateCon, app/web/js/02-chips-extract.js + 06-modals-grids.js).
 *
 * Ground truth: the 133 rate_con documents already matched to real orders by
 * the D225 scanned-batch pipeline (macOS Vision OCR + manual-confirmed
 * matching in plan_sent_documents.py). For each one we know, for certain,
 * which order it belongs to and that order's real broker/load#/solomon#/PO.
 * We feed the SAME OCR'd page text through the app's actual parseRateCon()
 * (loaded unmodified from the real file, not reimplemented) and check
 * whether it recovers the same broker/load#/solomon#/PO the real order has.
 * A mismatch here is a real bug in the everyday "upload a rate con" feature,
 * not a data problem — same fixture-driven approach as D27-D105.
 *
 * Ground truth (real business data — never written to a committed file, per
 * the seed.sql rule) is pulled live from Postgres via `psql` on every run,
 * not cached to disk:
 *   - one row per matched rate_con doc (doc_id, order_id, extracted_fields
 *     .sent2026_sha256/pages/source, real solomon_order_no/broker_load_no/
 *     po_number/broker_name)
 *   - the full `parties` table (name/is_broker/is_customer/archived_at),
 *     what brokerList()/findBroker() match against
 * output/sent-2026/ocr.jsonl (checked-in-adjacent, gitignored like the rest
 * of output/) supplies the per-(sha256,page) OCR text from the D225
 * pipeline's macOS Vision pass.
 *
 * Usage: node scripts/test_ratecon_extraction.js
 * Requires: psql reachable as `psql -d dept12 -h /tmp` (same as every other
 * script in this repo).
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { execFileSync } = require("child_process");

const ROOT = path.join(__dirname, "..");

function psqlJson(sql) {
  const out = execFileSync("psql", ["-d", "dept12", "-h", "/tmp", "-t", "-A", "-c", sql], { encoding: "utf8", maxBuffer: 1024 * 1024 * 64 });
  return JSON.parse(out.trim() || "[]");
}

const groundTruth = psqlJson(`
  select coalesce(json_agg(row_to_json(t)), '[]') from (
    select d.id as doc_id, d.order_id, d.extracted_fields, o.solomon_order_no, o.broker_load_no, o.po_number,
           p.name as broker_name
    from documents d
    join orders o on o.id = d.order_id
    left join parties p on p.id = o.broker_party_id
    where d.matched_by='document_text' and d.doc_type='rate_con'
  ) t;
`);
const parties = psqlJson(`
  select coalesce(json_agg(row_to_json(t)), '[]') from (
    select name, is_broker, is_customer, broker_archived_at, customer_archived_at from parties
  ) t;
`);

// Index ocr.jsonl by "sha256|page", preferring an entry that actually has text.
const ocrIndex = {};
fs.readFileSync(path.join(ROOT, "output/sent-2026/ocr.jsonl"), "utf8").split("\n").forEach(function (line) {
  if (!line.trim()) return;
  var rec;
  try { rec = JSON.parse(line); } catch (e) { return; }
  if (!rec.text) return; // skip error entries (first-pass nilError retries)
  var key = rec.sha256 + "|" + rec.page;
  if (!ocrIndex[key] || rec.text.length > ocrIndex[key].length) ocrIndex[key] = rec.text;
});

// Load the REAL app extraction code, unmodified, into a sandbox.
var src = fs.readFileSync(path.join(ROOT, "app/web/js/02-chips-extract.js"), "utf8");
var sandbox = {
  window: {}, document: {}, console: console,
  DB: { parties: parties },
  Object: Object, JSON: JSON, Array: Array, String: String, Number: Number,
  Math: Math, RegExp: RegExp, parseFloat: parseFloat, parseInt: parseInt, Promise: Promise
};
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: "02-chips-extract.js" });

function normName(s) { return (s || "").toUpperCase().replace(/[^A-Z0-9]/g, ""); }
function digitsOnly(s) { return (s || "").replace(/\D/g, ""); }

var results = [];
groundTruth.forEach(function (row) {
  var ef = row.extracted_fields || {};
  var sha = ef.sent2026_sha256;
  var pages = ef.sent2026_pages || [];
  var filename = ef.sent2026_source || "";
  if (!sha || !pages.length) { results.push(Object.assign({}, row, { skip: "no sha/pages" })); return; }
  var text = pages.map(function (p) { return ocrIndex[sha + "|" + p] || ""; }).join("\n");
  if (!text.trim()) { results.push(Object.assign({}, row, { skip: "no OCR text found" })); return; }

  var p = sandbox.parseRateCon(text, filename);

  var brokerOk = row.broker_name && p.broker && normName(p.broker) === normName(row.broker_name);
  var loadOk = row.broker_load_no && p.load_no && digitsOnly(p.load_no) === digitsOnly(row.broker_load_no);
  var solomonOk = row.solomon_order_no && p.solomon && p.solomon === row.solomon_order_no;
  var poOk = row.po_number && p.po && normName(p.po) === normName(row.po_number);

  results.push({
    doc_id: row.doc_id, order_id: row.order_id, filename: filename,
    real: { broker: row.broker_name, load_no: row.broker_load_no, solomon: row.solomon_order_no, po: row.po_number },
    parsed: { broker: p.broker, load_no: p.load_no, solomon: p.solomon, po: p.po, rate: p.rate, source: p.source },
    brokerOk: brokerOk, loadOk: loadOk, solomonOk: solomonOk, poOk: poOk,
    hasRealLoadNo: !!row.broker_load_no, hasRealSolomon: !!row.solomon_order_no, hasRealPo: !!row.po_number
  });
});

var tested = results.filter(function (r) { return !r.skip; });
var skipped = results.filter(function (r) { return r.skip; });

function pct(n, d) { return d ? (100 * n / d).toFixed(1) + "%" : "n/a"; }

var brokerTotal = tested.filter(function (r) { return r.real.broker; }).length;
var brokerHits = tested.filter(function (r) { return r.brokerOk; }).length;
var loadTotal = tested.filter(function (r) { return r.hasRealLoadNo; }).length;
var loadHits = tested.filter(function (r) { return r.loadOk; }).length;
var solomonTotal = tested.filter(function (r) { return r.hasRealSolomon; }).length;
var solomonHits = tested.filter(function (r) { return r.solomonOk; }).length;
var poTotal = tested.filter(function (r) { return r.hasRealPo; }).length;
var poHits = tested.filter(function (r) { return r.poOk; }).length;

console.log("=== Rate con extraction regression (real matched documents) ===");
console.log("Total ground-truth rate_con docs:", results.length, "  tested:", tested.length, "  skipped:", skipped.length);
console.log("Broker match:  " + brokerHits + "/" + brokerTotal + " (" + pct(brokerHits, brokerTotal) + ")");
console.log("Load #  match: " + loadHits + "/" + loadTotal + " (" + pct(loadHits, loadTotal) + ")");
console.log("Solomon match: " + solomonHits + "/" + solomonTotal + " (" + pct(solomonHits, solomonTotal) + ")");
console.log("PO match:      " + poHits + "/" + poTotal + " (" + pct(poHits, poTotal) + ")");

if (skipped.length) {
  console.log("\n--- Skipped ---");
  skipped.forEach(function (r) { console.log(r.doc_id, r.skip, r.extracted_fields && r.extracted_fields.sent2026_source); });
}

console.log("\n--- Broker mismatches ---");
tested.filter(function (r) { return r.real.broker && !r.brokerOk; }).forEach(function (r) {
  console.log(r.filename, "| real:", JSON.stringify(r.real.broker), "| parsed:", JSON.stringify(r.parsed.broker), "| source:", r.parsed.source.join(","));
});

console.log("\n--- Load# mismatches ---");
tested.filter(function (r) { return r.hasRealLoadNo && !r.loadOk; }).forEach(function (r) {
  console.log(r.filename, "| real:", r.real.load_no, "| parsed:", r.parsed.load_no);
});

console.log("\n--- Solomon mismatches ---");
tested.filter(function (r) { return r.hasRealSolomon && !r.solomonOk; }).forEach(function (r) {
  console.log(r.filename, "| real:", r.real.solomon, "| parsed:", r.parsed.solomon);
});

console.log("\n--- PO mismatches ---");
tested.filter(function (r) { return r.hasRealPo && !r.poOk; }).forEach(function (r) {
  console.log(r.filename, "| real:", r.real.po, "| parsed:", r.parsed.po);
});

var outPath = path.join(ROOT, "output/ratecon_test_results.json");
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(results, null, 2));
console.log("\nFull results written to output/ratecon_test_results.json");
