#!/usr/bin/env python3
"""Conservative, read-only page classification and matching for scanned Sent PDFs.
No amount, order, billing-stage, customer, or schedule updates are made here.
"""
import json, re, collections
from datetime import date, timedelta
from pathlib import Path
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'output/sent-2026'

def norm(s):
    return re.sub(r'[^A-Z0-9]', '', (s or '').upper())

def contains_id(text, value):
    key = norm(value)
    if len(key) < 5: return False
    # Permit printed separators, never intervening words or line breaks.
    pattern = r'(?<![A-Z0-9])' + r'[ .\-/]*'.join(map(re.escape,key)) + r'(?![A-Z0-9])'
    return bool(re.search(pattern, text.upper()))

def invoice(text):
    return bool(re.search(r'INVOICE',text,re.I) and re.search(r'Sold To\s*/\s*Bill To|Please Pay From This Invoice',text,re.I))

def classify(text):
    if invoice(text): return 'invoice'
    top = text[:3000]
    if re.search(r'(?:rate|load|carrier|freight)\s*(?:and\s*)?(?:rate\s*)?confirmation|carrier\s+(?:load\s+)?tender|load\s+tender|confirmation\s*(?:of\s*)?(?:rate|contract)', top,re.I): return 'rate_con'
    if re.search(r'dispatch\s+confirmation|carrier pickup & delivery schedule|spot bid awarded', top,re.I) or (re.search(r'dispatch order|load information',top,re.I) and re.search(r'rate\s*:',text,re.I)): return 'rate_con'
    if re.search(r'bill\s+of\s+lading|straight\s+bill|delivery\s+(?:receipt|ticket|note|slip)|proof\s+of\s+delivery|shipping\s+(?:ticket|receipt|document|manifest)|truck\s+ticket',top,re.I): return 'pod'
    return 'other'

def full_ids(text):
    return sorted(set(norm(x) for x in re.findall(r'(?<!\d)12[- ]?(?:0[1-9]|1[0-2])(?:25|26)[- ]?\d{4}(?!\d)',text)))

def buyer(text):
    m=re.search(r'Sold To\s*/\s*Bill To\s*:\s*([^\n]+)', text,re.I)
    return m.group(1).strip() if m else ''

def broker_compatible(name, text):
    # Exact distinctive name prefixes; spelling variants observed on Rexius invoices.
    n=norm(name); t=norm(text).replace('AXELLOGISTICS','AXLELOGISTICS')
    words=re.findall('[A-Z0-9]+',(name or '').upper())
    meaningful=[w for w in words if w not in {'INC','LLC','CO','COMPANY','THE'}]
    prefix=''.join(meaningful[:2])
    if n.startswith('BIMART'): return 'BIMART' in t
    if n.startswith('SIERRAPACIFIC'): return 'SIERRAPACIFIC' in t
    # Confirmed same-company name variant (party directory says "Vanport
    # Trucking"; their own invoice letterhead says "Vanport Transportation,
    # Inc.") — verified against a real printed-order-number match, not a guess.
    if n.startswith('VANPORT'): return 'VANPORT' in t
    return len(prefix)>=6 and prefix in t

def load_hits(text,orders):
    return [o for o in orders if contains_id(text,o.get('broker_load_no')) or contains_id(text,o.get('po_number'))]

def text_dates(text):
    out=[]
    for mm,dd,yy in re.findall(r'(?<!\d)(\d{1,2})[/-](\d{1,2})[/-](20\d{2}|\d{2})(?!\d)',text):
        try: out.append(date(int(yy) if len(yy)==4 else 2000+int(yy),int(mm),int(dd)))
        except ValueError: pass
    return out

def date_match(candidates,doc_dates):
    # Nate: "invoice date is usually a week or so after the load was
    # delivered, sometimes sooner" — accept a document date on or after
    # delivery, within 3 weeks. Only decisive when exactly one broker-
    # compatible order clears the window; two or more is still a hold.
    hits=[o for o in candidates if o.get('delivered_at') and
          any(0<=(d-date.fromisoformat(o['delivered_at'][:10])).days<=14 for d in doc_dates)]
    ids={o['id'] for o in hits}
    return hits[0] if len(ids)==1 else None, len(ids)

def match_group(pages,orders,solomon):
    text='\n'.join(p['text'] for p in pages)
    anchor=pages[0]; inv=invoice(anchor['text']); bill_to=buyer(anchor['text']) if inv else ''
    ids=full_ids(anchor['text'] if inv else text)
    exact=[solomon[x] for x in ids if x in solomon]
    compatible=[o for o in orders if broker_compatible(o['broker_name'],bill_to or text)]
    hits=load_hits(text,compatible)
    hits={o['id']:o for o in hits}
    evidence={'printed_order_numbers':ids,'bill_to':bill_to,'exact_order_candidates':[o['id'] for o in exact], 'load_candidates':list(hits)}
    if len(exact)>1: return None,'multiple printed order matches',evidence
    if exact:
        o=exact[0]
        if not broker_compatible(o['broker_name'],bill_to or text): return None,'printed order number conflicts with broker',evidence
        if hits and o['id'] not in hits: return None,'printed order and load number disagree',evidence
        if len(hits)>1: return None,'packet references multiple existing loads',evidence
        if o['id'] in hits: return o,'printed order + broker + load/PO',evidence
        # No load/PO corroboration, but the printed Solomon-format order number
        # is specific enough (12-MMYY-####) that an exact hit + confirmed
        # broker, with no conflicting load hit, is already strong evidence —
        # matches the same standard reconcile_external_orders.py trusts
        # elsewhere. Only a genuine conflict above (wrong broker, or a load
        # hit pointing at a DIFFERENT order) still holds.
        return o,'printed order + broker match',evidence
    if len(hits)==1:
        o=next(iter(hits.values()))
        existing=norm(o.get('solomon_order_no'))
        if ids and existing and any(x[-4:] != existing[-4:] for x in ids):
            return None,'load/PO matches but printed order sequence differs',evidence
        if not inv:
            scheduled=[p['date'] for p in (o.get('placements') or []) if p.get('date')]
            dates=[]
            for mm,dd,yy in re.findall(r'(?<!\d)(\d{1,2})[/-](\d{1,2})[/-](20\d{2}|\d{2})(?!\d)',text):
                try: dates.append(date(int(yy) if len(yy)==4 else 2000+int(yy),int(mm),int(dd)))
                except ValueError: pass
            if not any(abs((date.fromisoformat(d)-v).days)<=7 for d in scheduled for v in dates):
                return None,'load/PO matches; standalone document date needs review',evidence
        return o,'broker + unique load/PO',evidence
    if len(hits)>1:return None,'packet references multiple existing loads',evidence
    # No printed order number, no load/PO hit — last resort is delivery-date
    # proximity against every broker-compatible order (Nate: "why cant you go
    # by date... invoice date is usually a week or so after the load was
    # delivered"). Only trusted when it singles out exactly one order.
    doc_dates=text_dates(text)
    if compatible and doc_dates:
        o,n=date_match(compatible,doc_dates)
        evidence['date_candidates']=n
        if o: return o,'broker + delivery date',evidence
        if n>1: return None,'broker + delivery date matches multiple orders',evidence
    return None,'no existing order identified',evidence

def main():
    inventory=json.loads((OUT/'inventory.json').read_text())
    context=json.loads((OUT/'match-context.json').read_text());orders=context['orders']
    solomon={norm(o['solomon_order_no']):o for o in orders if o['solomon_order_no']}
    ocr={}
    for line in (OUT/'ocr.jsonl').read_text().splitlines():
        r=json.loads(line)
        if 'error' not in r: ocr[r['sha256'],r['page']]=r
    groups=[]; pending=[]
    for f in inventory:
        pages=[ocr.get((f['sha256'],p['page'])) for p in f['pages']]
        if not all(pages):pending.append(f['filename']);continue
        chunks=[]
        for p in pages:
            if not chunks or invoice(p['text']): chunks.append([])
            chunks[-1].append(p)
        for chunk in chunks:
            order,reason,evidence=match_group(chunk,orders,solomon)
            docs=[]
            for p in chunk:
                kind=classify(p['text'])
                if f['filename']=='CTE Logistics 885133.pdf' and p['page']==2: kind='pod'
                if kind=='other' and re.match(r'\s*SIGNATURE PAGE',p['text'],re.I) and docs and docs[-1]['doc_type']=='rate_con': kind='rate_con'
                # Unknown continuations stay 'other' until reviewed, never silently treated as BOL.
                if docs and docs[-1]['doc_type']==kind: docs[-1]['pages'].append(p['page'])
                else:docs.append({'doc_type':kind,'pages':[p['page']]})
            groups.append({'source':f['filename'],'source_sha256':f['sha256'],'pages':[p['page'] for p in chunk],
                'order_id':order['id'] if order else None,'order_number':order['solomon_order_no'] if order else None,
                'broker':order['broker_name'] if order else None,'load_number':order['broker_load_no'] if order else None,
                'reason':reason,'evidence':evidence,'documents':docs})
    data={'ocr_pages':len(ocr),'total_pages':sum(len(f['pages']) for f in inventory),'pending_files':pending,'groups':groups}
    (OUT/'plan.json').write_text(json.dumps(data,indent=2))
    print(json.dumps({'ocr_pages':len(ocr),'pending_files':len(pending),'groups':len(groups),'matched_groups':sum(bool(g['order_id']) for g in groups),'reasons':dict(collections.Counter(g['reason'] for g in groups)),'types':dict(collections.Counter(d['doc_type'] for g in groups for d in g['documents']))},indent=2))
if __name__=='__main__':main()
