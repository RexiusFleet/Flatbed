#!/usr/bin/env python3
"""Apply reviewed BM DC and Northend customer/pallet mappings, dry-run first.

Short order numbers and customer references remain separate from full ERP
identifiers. Existing provisional import periods are not treated as proof
of the real order month. Original rows are retained in the local audit.
"""
import argparse
import datetime as dt
import json
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    ap.add_argument("--northend-month", help="Confirmed YYYY-MM, otherwise keep month pending")
    args = ap.parse_args()
    month = dt.date.fromisoformat(args.northend_month + "-01") if args.northend_month else None
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        rows = conn.execute("""select * from orders where
            custom->>'source' in ('sheet2025','sheet2026') and
            (notes ~* '\\mBM[[:space:]]+DC\\M' or notes ~* '\\mnorth[[:space:]]*end\\M')
            order by delivered_at,id for update""").fetchall()
        dc = conn.execute("select * from parties where is_customer and name='BI-MART DC #700'").fetchone()
        if not dc:
            raise ValueError("Expected Bi-Mart DC customer not found")
        north = conn.execute("select * from parties where lower(name)='northend organics'").fetchall()
        if len(north) > 1 or north and not north[0]["is_customer"]:
            raise ValueError("Northend directory entry needs review")
        changes = []
        for row in rows:
            is_north = bool(re.search(r"\bnorth\s*end\b", row["notes"], re.I))
            short = re.search(r"\b(\d+)\s*/\s*(\d+)\b", row["notes"])
            if not short or row["is_transfer"]:
                raise ValueError("Unexpected notation or transfer")
            target = (north[0]["id"] if north else None) if is_north else dc["id"]
            if row["customer_party_id"] and row["customer_party_id"] != target or row["broker_party_id"]:
                raise ValueError("Conflicting customer or broker")
            pallet = int(short[2])
            if row["pallet_count"] is not None and row["pallet_count"] != pallet:
                raise ValueError("Existing pallet count conflicts with source")
            refs = re.findall(r"\b\d{6}\b", row["notes"]) if not is_north else []
            prior = row["custom"].get("bag_import_review", {})
            confirmed = month if is_north and month else (
                dt.date.fromisoformat(prior["confirmed_order_month"])
                if prior.get("confirmed_order_month") else None)
            metadata = {"rule": "confirmed-bag-customers-v1", "source_order_number": short[1],
                        "source_customer_references": refs,
                        "order_month_status": "confirmed" if confirmed else "pending",
                        "confirmed_order_month": confirmed.isoformat() if confirmed else None}
            period = confirmed or row["order_period"]
            if row["kind"] == "internal" and row["customer_party_id"] == target and row["pallet_count"] == pallet and row["custom"].get("bag_import_review") == metadata and row["order_period"] == period:
                continue
            loads = conn.execute("""select l.* from loads l join load_orders lo on lo.load_id=l.id
                where lo.order_id=%s for update of l""", (row["id"],)).fetchall()
            if len(loads) != 1 or conn.execute("select count(*) as n from load_orders where load_id=%s", (loads[0]["id"],)).fetchone()["n"] != 1:
                raise ValueError("Shared trip needs review")
            changes.append({"order_before": row, "load_before": loads[0], "customer_id": target,
                            "customer_name": "Northend Organics" if is_north else dc["name"],
                            "pallet_count": pallet, "order_period": period, "metadata": metadata})
        report = {"status": "preview", "changes": changes}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-bag-customers.json")
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            def fingerprint():
                return conn.execute("""select
                    (select md5(string_agg(row_to_json(o)::text,'' order by id)) from orders o
                     where not(id=any(%s::uuid[]))) as other_orders,
                    (select md5(string_agg(id::text || scheduled_date::text ||
                     coalesce(truck_id::text,'') || slot::text,'' order by id)) from loads) as placements""",
                    ([c["order_before"]["id"] for c in changes],)).fetchone()
            before = fingerprint()
            for change in changes:
                if change["customer_id"] is None:
                    if not north:
                        north = [conn.execute("""insert into parties (name,is_customer)
                            values ('Northend Organics',true) returning *""").fetchone()]
                        report["created_customer_id"] = str(north[0]["id"])
                    change["customer_id"] = north[0]["id"]
                conn.execute("""update orders set kind='internal',department='07',
                    customer_party_id=%s,pallet_count=%s,order_period=%s,
                    custom=custom || jsonb_build_object('bag_import_review',%s::jsonb)
                    where id=%s""", (change["customer_id"], change["pallet_count"],
                    change["order_period"], Jsonb(change["metadata"]), change["order_before"]["id"]))
                conn.execute("update loads set kind='internal' where id=%s", (change["load_before"]["id"],))
            if fingerprint() != before:
                raise ValueError("Unrelated orders or trip placements changed; rolling back")
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"status": report["status"], "changes": len(changes), "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
