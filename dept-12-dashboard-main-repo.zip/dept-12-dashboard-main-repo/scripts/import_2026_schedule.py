#!/usr/bin/env python3
"""
Backfill the "Master Schedule 2026" tab into the live orders/loads/scheduler
model — the year-2026 sibling of import_2025_schedule.py (D65). Same sheet
shape, same business rules; kept as a separate script (not a generalized
multi-tab rewrite) to match the project's one-script-per-source convention
(import_bagger_customers.py, import_outside_customers.py, etc.) and to avoid
touching the already-verified 2025 script's behavior.

Real historical + year-to-date dispatch data — runs straight into local
Postgres, never into seed.sql.

Layout: identical to the 2025 tab (see that script's docstring / D65) — nine
trucks down the rows, a 15-column day-block tiling left->right, bands stacked
newest-on-top. Only difference in practice: 2026's legend has grown several
new fill colors (new customers/lanes) that aren't in the 2025 HEX2CAT map —
those cells import as real orders/loads with no category color (cosmetic
only; ask Nate before inventing meaning for an unmapped color).

Scope: real calendar dates in 2026, up to and including --today (defaults to
the actual current date) — the stray tail of 2025 dates this tab also
contains (a duplicate of what the 2025 tab already covers) is skipped by the
year filter, and nothing beyond "today" is imported (this is a real backfill
of what already happened, not a preview of unscheduled future template rows).

Idempotent & reversible: every imported order carries
custom->>'source' = 'sheet2026'; --reset clears prior sheet2026 rows in scope
before inserting.

Usage:
    python3 scripts/import_2026_schedule.py                       # dry run, 2026 to today
    python3 scripts/import_2026_schedule.py --month 2026-03        # dry run, March only
    python3 scripts/import_2026_schedule.py --commit --reset       # write, replacing prior sheet2026 rows
"""

import argparse
import datetime
import os
import sys

import openpyxl
import psycopg
from psycopg.rows import dict_row

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from import_2025_schedule import (  # noqa: E402
    HEX2CAT, STORE_CATS, band_rows, block_starts, as_date, parse_label,
    fill_hex, build_cust_index, match_customer,
)
import re  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XLSX = os.environ.get("DEPT12_XLSX", os.path.join(BASE, "Flatbed Master Schedule.xlsx"))
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")
TAB = "Master Schedule 2026"
SOURCE = "sheet2026"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--commit", action="store_true", help="write to the DB (default: dry run)")
    ap.add_argument("--reset", action="store_true", help="delete prior sheet2026 rows in scope first")
    ap.add_argument("--month", help="limit to a YYYY-MM (e.g. 2026-03)")
    ap.add_argument("--today", help="cutoff date YYYY-MM-DD (default: actual today)")
    args = ap.parse_args()

    today = (datetime.date.fromisoformat(args.today) if args.today
             else datetime.date.today())

    want_month = None
    if args.month:
        y, m = args.month.split("-")
        want_month = (int(y), int(m))

    def in_scope(d):
        if not d or d.year != 2026 or d > today:
            return False
        if want_month and (d.year, d.month) != want_month:
            return False
        return True

    wb = openpyxl.load_workbook(XLSX)
    ws = wb[TAB]
    trs = band_rows(ws)

    conn = psycopg.connect(DSN, row_factory=dict_row, autocommit=False)
    cur = conn.cursor()

    cur.execute("select id, name, is_off from categories")
    cat_id = {r["name"]: r["id"] for r in cur.fetchall()}
    # "Off" (and other 2025-era flag categories) may no longer exist in the
    # live categories table — internal chip color moved to the Bagger
    # Customer designation model (D72/D94), and truck_off_days.category_id
    # is nullable app-wide (api_truck_off does the same .get()-style lookup
    # live). Never KeyError on a retired category name.
    off_cat = cat_id.get("Off")

    by_store, all_c = build_cust_index(cur)
    cur.execute("select internal_department, external_department from order_number_settings limit 1")
    dept_row = cur.fetchone()
    internal_dept = dept_row["internal_department"] if dept_row else "07"
    external_dept = dept_row["external_department"] if dept_row else "12"

    if args.reset:
        cur.execute("""
            delete from loads l using load_orders lo, orders o
            where lo.load_id = l.id and lo.order_id = o.id
              and o.custom->>'source' = %s
              and (%s::text is null or to_char(l.scheduled_date,'YYYY-MM') = %s)
        """, (SOURCE, args.month, args.month))
        cur.execute("""
            delete from orders o where o.custom->>'source' = %s
              and (%s::text is null or to_char(o.delivered_at,'YYYY-MM') = %s)
        """, (SOURCE, args.month, args.month))
        cur.execute("""
            delete from truck_off_days t where t.note like %s
              and (%s::text is null or to_char(t.off_date,'YYYY-MM') = %s)
        """, (SOURCE + ":%", args.month, args.month))

    truck_cache = {}

    def truck_id(num, eq):
        if num in truck_cache:
            return truck_cache[num]
        cur.execute("select id from trucks where lower(number)=lower(%s)", (num,))
        r = cur.fetchone()
        if not r:
            cur.execute("insert into trucks (number, equipment_type) values (%s,%s) returning id",
                        (num, eq or "F"))
            r = cur.fetchone()
        truck_cache[num] = r["id"]
        return r["id"]

    seen = set()
    stats = {"loads": 0, "internal": 0, "external": 0, "matched": 0,
             "unmatched_internal": 0, "off_days": 0, "trucks": set(),
             "cats": {}, "unmapped_colors": {}}
    samples = []
    unmapped_samples = {}

    for tr in trs:
        for sc in block_starts(ws, tr):
            d = as_date(ws.cell(tr - 1, sc).value)
            if not in_scope(d):
                continue
            for r in range(tr + 1, tr + 10):
                label = ws.cell(r, 1).value
                num, eq = parse_label(label)
                if not num:
                    continue
                off_notes, cells = [], []
                for c in range(sc, sc + 14):
                    v = ws.cell(r, c).value
                    if v in (None, ""):
                        continue
                    s = str(v).strip()
                    hx = fill_hex(ws.cell(r, c))
                    cat = HEX2CAT.get(hx)
                    if cat == "Off":
                        off_notes.append(s)
                    else:
                        cells.append((s, hx, cat))
                        if hx not in HEX2CAT and hx != "FFFFFFFF":
                            stats["unmapped_colors"][hx] = stats["unmapped_colors"].get(hx, 0) + 1
                            if hx not in unmapped_samples:
                                unmapped_samples[hx] = s[:50]
                if off_notes:
                    stats["off_days"] += 1
                    if args.commit:
                        note = SOURCE + ": " + " / ".join(dict.fromkeys(off_notes))[:240]
                        cur.execute("""
                            insert into truck_off_days (truck_id, off_date, note, category_id)
                            values (%s,%s,%s,%s) on conflict (truck_id, off_date)
                            do update set note = excluded.note, category_id = excluded.category_id
                        """, (truck_id(num, eq), d, note, off_cat))
                slot = 0
                for s, hx, cat in cells:
                    key = (num, d, re.sub(r"\s+", " ", s.upper()))
                    if key in seen:
                        continue
                    seen.add(key)
                    slot += 1
                    cust = match_customer(s, by_store, all_c)
                    # "Bag plant" cells are bagger loads regardless of customer
                    # match (Nate: "bag plant to umatilla is a bagger load") —
                    # not a dept-to-dept Internal Freight transfer, just an
                    # internal/dept-07 haul with no matched customer yet.
                    is_internal = bool(cust) or (cat in STORE_CATS) or (cat == "Bag plant")
                    kind = "internal" if is_internal else "external"
                    stats["loads"] += 1
                    stats[kind] += 1
                    stats["trucks"].add(num)
                    stats["cats"][cat or "(none)"] = stats["cats"].get(cat or "(none)", 0) + 1
                    if cust:
                        stats["matched"] += 1
                    elif is_internal:
                        stats["unmatched_internal"] += 1
                    if len(samples) < 14:
                        samples.append((d.isoformat(), num, kind, cat or "-",
                                        "cust" if cust else "?", s[:40]))
                    if args.commit:
                        # order_period (D217) is what the Bag Orders month-tab
                        # actually groups on now, not the order number — these
                        # rows have no solomon_order_no at all, so without this
                        # they're invisible in every month tab despite existing
                        # and showing fine on the Scheduler. department (D217)
                        # likewise moved off the number; use the live default
                        # for each kind rather than hardcoding '07'/'12'.
                        dept = internal_dept if kind == "internal" else external_dept
                        period = datetime.date(d.year, d.month, 1) if kind == "internal" else None
                        cur.execute("""
                            insert into orders (kind, solomon_order_no, customer_party_id,
                                stage, ordered_at, delivered_at, notes, custom, department, order_period)
                            values (%s, null, %s::uuid, 'delivered', %s, %s, %s,
                                    jsonb_build_object('source',%s::text,'raw',%s::text,
                                        'color',%s::text,'truck',%s::text,'date',%s::text),
                                    %s, %s)
                            returning id
                        """, (kind, cust, d, d, s, SOURCE, s, hx, num, d.isoformat(), dept, period))
                        oid = cur.fetchone()["id"]
                        # Sheet fill colors are not imported as categories (Nate:
                        # "we dont care about colors on import, we have our own
                        # color rules here"). Internal stays uncategorized —
                        # he'll assign each bagger customer's real designation
                        # by hand from the load text. External gets pushed_at
                        # set so it immediately follows the truck's current
                        # driver color, "just like our app would" (pushColorFor,
                        # 02-chips-extract.js) — no bespoke coloring logic here.
                        cur.execute("""
                            insert into loads (kind, status, scheduled_date, truck_id, slot,
                                category_id, notes, pushed_at)
                            values (%s,'delivered',%s,%s,%s,null,%s,
                                    case when %s = 'external' then now() else null end)
                            returning id
                        """, (kind, d, truck_id(num, eq), slot, s, kind))
                        lid = cur.fetchone()["id"]
                        cur.execute("insert into load_orders (load_id, order_id) values (%s,%s)",
                                    (lid, oid))

    if args.commit:
        conn.commit()
    conn.close()

    scope = args.month or f"2026-01-01 through {today.isoformat()}"
    print(f"\n{'COMMITTED' if args.commit else 'DRY RUN'} — scope: {scope}  (tab: {TAB})")
    print(f"  trucks touched : {len(stats['trucks'])}  {sorted(stats['trucks'], key=lambda x: int(x))}")
    print(f"  loads          : {stats['loads']}   (internal {stats['internal']} / external {stats['external']})")
    print(f"  customer-matched internal : {stats['matched']}   unmatched-but-internal : {stats['unmatched_internal']}")
    print(f"  truck off-days : {stats['off_days']}")
    print("  by category:")
    for k, v in sorted(stats["cats"].items(), key=lambda kv: -kv[1]):
        print(f"     {k:16s} {v}")
    if stats["unmapped_colors"]:
        print("  UNMAPPED fill colors (imported as no-category, cosmetic only):")
        for hx, n in sorted(stats["unmapped_colors"].items(), key=lambda kv: -kv[1]):
            print(f"     {hx}  {n:4d} cells   e.g. {unmapped_samples.get(hx, '')!r}")
    print("  sample rows (date | truck | kind | category | cust | text):")
    for s in samples:
        print("     " + " | ".join(str(x) for x in s))


if __name__ == "__main__":
    main()
