#!/usr/bin/env python3
"""Create a reversible current-week matrix for the Google driver-tab push."""

import datetime
import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))
import server  # noqa: E402

SOURCE = "driver_push_test_20260817"
START = datetime.date(2026, 8, 17)

CUSTOMERS = [
    "A-BOY GARDEN CENTER",       # early, no forklift
    "BASCO",                     # anytime, Spyder
    "BI-MART #619 - U",          # early east
    "BI-MART #605 - U",          # anytime east
    "BI-MART #602",              # anytime, forklift
    "ALASKA GARDEN & PET",       # anytime, no forklift
]
BROKERS = [
    "AMERICAN FREIGHT,INC.", "BOB MURRAY TRANSPORTATION", "AMOTH LOGISTICS LLC",
    "C. Ray Trucking", "CENTRAL OREGON TRUCKING", "EAGLE FOREST PRODUCTS",
    "EXPRESS TRANSPORT SERVICES, IN",
]
STOP_NAMES = [
    "BI-MART #601", "BI-MART #602", "BI-MART #603", "BI-MART #604",
    "BI-MART #605 - U", "BI-MART #606", "BI-MART #607", "BI-MART #608",
    "BI-MART #609", "BI-MART #610", "BI-MART #611", "BI-MART #612",
    "BI-MART #613", "BI-MART #614 - U", "BI-MART #615", "BI-MART #616",
    "BI-MART #617 - U", "BI-MART #618", "BI-MART #619 - U", "BI-MART #620",
    "BI-MART #621 - U", "BI-MART #622", "BI-MART #624",
]


def one(cur, sql, params=()):
    cur.execute(sql, params)
    row = cur.fetchone()
    if not row:
        raise RuntimeError(f"Required test fixture missing for query: {sql}")
    return row


def main():
    conn = server.db()
    created = []
    with conn.transaction():
        # Re-running is safe and affects only this clearly tagged matrix.
        server.q("delete from schedule_notes where body like %s", ("%[DRIVER PUSH TEST%",))
        server.q("""delete from loads l using load_orders lo, orders o
                    where lo.load_id=l.id and lo.order_id=o.id and o.custom->>'source'=%s""", (SOURCE,))
        server.q("delete from orders where custom->>'source'=%s", (SOURCE,))

        with conn.cursor() as cur:
            trucks = {}
            cur.execute("select id, number from trucks where active")
            for row in cur.fetchall():
                trucks[row["number"]] = row["id"]
            required = ["31", "33", "39", "62", "63", "72", "162", "80", "135"]
            if any(t not in trucks for t in required):
                raise RuntimeError("Expected fleet trucks are missing")

            customers = {name: one(cur, "select id from parties where is_customer and name=%s", (name,))["id"]
                         for name in CUSTOMERS}
            brokers = {name: one(cur, "select id from parties where is_broker and name=%s", (name,))["id"]
                       for name in BROKERS}
            locations = {name: one(cur, "select id from locations where name=%s order by created_at limit 1", (name,))["id"]
                         for name in STOP_NAMES}

        seq = 0

        def schedule(order_id, kind, truck_no, day, slot, load_note):
            nonlocal seq
            load = server.api_schedule({"order_id": order_id, "truck_id": trucks[truck_no],
                                        "date": day.isoformat(), "slot": slot})
            server.q("update loads set notes=%s where id=%s",
                     ("[DRIVER PUSH TEST] " + load_note, load["id"]))
            created.append({"date": day.isoformat(), "truck": truck_no, "slot": slot,
                            "kind": kind, "order_id": str(order_id), "label": load_note})

        def internal(customer, truck_no, day, slot, pallets, case):
            nonlocal seq
            seq += 1
            order_no = f"07-0826-{9200 + seq:04d}"
            row = server.q("""insert into orders
                (kind,solomon_order_no,customer_party_id,pallet_count,ordered_at,notes,custom)
                values ('internal',%s,%s,%s,%s,%s,jsonb_build_object('source',%s::text,'case',%s::text))
                returning id""", (order_no, customers[customer], pallets, day,
                                  "[DRIVER PUSH TEST] " + case, SOURCE, case), one=True)
            schedule(row["id"], "internal", truck_no, day, slot, case)

        def external(broker, truck_no, day, slot, stops, case, tarp=False,
                     missing_solomon=False, blank_refs=False):
            nonlocal seq
            seq += 1
            order_no = None if missing_solomon else f"12-0826-{9300 + seq:04d}"
            load_no = f"99{3100 + seq}"
            pick = next(s for s in stops if s[0] == "pickup")
            drop = next(s for s in reversed(stops) if s[0] == "delivery")
            row = server.q("""insert into orders
                (kind,solomon_order_no,broker_load_no,broker_party_id,po_number,delivery_number,
                 pickup_location_id,delivery_location_id,route_mode,tarp,ordered_at,notes,custom)
                values ('external',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                        jsonb_build_object('source',%s::text,'case',%s::text)) returning id""",
                (order_no, load_no, brokers[broker], None if blank_refs else pick[2],
                 None if blank_refs else drop[2], locations[pick[1]], locations[drop[1]],
                 "custom" if len(stops) > 2 else "simple", tarp, day,
                 "[DRIVER PUSH TEST] " + case, SOURCE, case), one=True)
            for i, (kind, location_name, reference) in enumerate(stops, 1):
                server.q("""insert into order_stops
                    (order_id,sequence,stop_type,location_id,reference_number,
                     appointment_required,pallet_count,notes)
                    values (%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (row["id"], i, kind, locations[location_name], None if blank_refs else reference,
                     "APPT" in case, i * 2 if len(stops) > 2 else None, case))
            schedule(row["id"], "external", truck_no, day, slot, case)

        assigned = ["31", "33", "63", "72", "39", "162", "62"]
        for day_index in range(5):
            day = START + datetime.timedelta(days=day_index)
            for truck_index, truck in enumerate(assigned):
                case_no = day_index * len(assigned) + truck_index
                # Put both unusual route shapes in slot 1 so the existing
                # one-row-per-driver/day export is forced to render them.
                if day_index == 2 and truck == "63":
                    external("CENTRAL OREGON TRUCKING", truck, day, 1,
                             [("pickup", "BI-MART #609", "PU-A"),
                              ("pickup", "BI-MART #610", "PU-B"),
                              ("delivery", "BI-MART #611", "DEL-A"),
                              ("delivery", "BI-MART #612", "DEL-B")],
                             f"CASE {case_no + 1:02d} · MULTI P/P/D/D · APPT 08:30")
                    continue
                if day_index == 3 and truck == "72":
                    external("EAGLE FOREST PRODUCTS", truck, day, 1,
                             [("pickup", "BI-MART #613", "PU-1"),
                              ("delivery", "BI-MART #614 - U", "DEL-1"),
                              ("pickup", "BI-MART #615", "PU-2"),
                              ("delivery", "BI-MART #616", "DEL-2")],
                             f"CASE {case_no + 1:02d} · INTERLEAVED P/D/P/D · TARP", tarp=True)
                    continue
                if (case_no + day_index) % 2 == 0:
                    cust = CUSTOMERS[case_no % len(CUSTOMERS)]
                    internal(cust, truck, day, 1, [1, 7, 12, 24, 48, 0][case_no % 6],
                             f"CASE {case_no + 1:02d} · {cust} · INTERNAL PRIMARY")
                else:
                    broker = BROKERS[case_no % len(BROKERS)]
                    a = STOP_NAMES[(case_no * 2) % len(STOP_NAMES)]
                    b = STOP_NAMES[(case_no * 2 + 1) % len(STOP_NAMES)]
                    external(broker, truck, day, 1,
                             [("pickup", a, f"PU-{case_no + 1:02d}"),
                              ("delivery", b, f"DEL-{case_no + 1:02d}")],
                             f"CASE {case_no + 1:02d} · STANDARD EXTERNAL",
                             tarp=case_no % 5 == 0, missing_solomon=case_no == 8,
                             blank_refs=case_no == 19)

        # Explicit break-the-system cases in second/third scheduler slots.
        external("CENTRAL OREGON TRUCKING", "63", START + datetime.timedelta(days=2), 2,
                 [("pickup", "BI-MART #620", "PU-EXTRA"),
                  ("delivery", "BI-MART #621 - U", "DEL-EXTRA")],
                 "CASE 36 · SECOND LOAD BEHIND MULTI-STOP PRIMARY")
        external("EAGLE FOREST PRODUCTS", "72", START + datetime.timedelta(days=3), 2,
                 [("pickup", "BI-MART #618", "PU-EXTRA"),
                  ("delivery", "BI-MART #619 - U", "DEL-EXTRA")],
                 "CASE 37 · SECOND LOAD BEHIND INTERLEAVED PRIMARY", tarp=True)
        internal("BI-MART #619 - U", "31", START, 2, 99,
                 "CASE 38 · SECOND LOAD SAME DRIVER/DAY · HIGH PALLETS")
        internal("BASCO", "31", START, 3, 3,
                 "CASE 39 · THIRD LOAD SAME DRIVER/DAY · SPYDER")
        external("EXPRESS TRANSPORT SERVICES, IN", "39", START + datetime.timedelta(days=4), 2,
                 [("pickup", "BI-MART #622", "PU-LONG"), ("delivery", "BI-MART #624", "DEL-LONG")],
                 "CASE 40 · LONG NOTE · GATE 2468 · CALL DISPATCH BEFORE DEPARTURE · CHECK IN AT RECEIVING")

        # Loads on trucks without current drivers should stay off driver tabs.
        internal("A-BOY GARDEN CENTER", "80", START + datetime.timedelta(days=2), 1, 5,
                 "CASE 41 · UNASSIGNED TRUCK 80")
        external("AMOTH LOGISTICS LLC", "135", START + datetime.timedelta(days=3), 1,
                 [("pickup", "BI-MART #617 - U", "PU-135"),
                  ("delivery", "BI-MART #618", "DEL-135")],
                 "CASE 42 · UNASSIGNED TRUCK 135")
        server.q("""insert into schedule_notes (truck_id,scheduled_date,slot,body)
                    values (%s,%s,3,%s)""",
                 (trucks["72"], START + datetime.timedelta(days=1),
                  "[DRIVER PUSH TEST] CASE 43 · PLAIN SCHEDULE NOTE, NOT A LOAD"))

    print(f"created {len(created)} test orders/loads plus one schedule note")
    for item in created:
        print("{date} | truck {truck} | slot {slot} | {kind} | {label}".format(**item))


if __name__ == "__main__":
    main()
