#!/usr/bin/env python3
"""
One-time backfill: the legacy "Flatbed Master Schedule" 2025 tab into the live
orders / loads / scheduler model (D65).

This is real historical dispatch data, so — like import_bagger_customers.py — it
runs straight into the local Postgres and never touches seed.sql.

Layout of the "Master Schedule 2025" tab (reverse-engineered, see docs/decisions
D65). Nine trucks down the rows; time-of-day across the columns (06:00–19:00);
each business day is a 15-column block, and ~26 day-blocks tile left→right per
"band"; bands stack newest-on-top down the sheet. Cells hold a load's lane text;
merges are just visual overflow, so a load lives in one cell. Fill color = a
category from Nate's own legend (mapped below).

Business rules confirmed with Nate:
  - Truck is the identity (drivers churn); driver is left null on history.
  - internal (dept 07) = the delivery customer is a Bagger Customer, OR the cell
    is a store category (anytime / early / Umatilla side). Everything else is
    external (dept 12). Color does not decide this — the customer match does.
  - red = truck off that day (OFF / FMLA / SICK / CDL phys), one "Off" per day,
    reason kept as the note. Not a load.
  - 2025 calendar dates only; the stray 2024 bands and the Jan-2026 tail are
    skipped, and the overlapping duplicate Dec band is de-duped by truck+date+text.
  - No hour-slots; a truck-day can hold any number of loads (slot = 1..N sequence).

Idempotent & reversible: every imported order carries
custom->>'source' = 'sheet2025'; --reset clears prior sheet2025 rows in scope
before inserting.

Usage:
    python3 scripts/import_2025_schedule.py                  # dry run, whole 2025
    python3 scripts/import_2025_schedule.py --month 2025-12  # dry run, Dec only
    python3 scripts/import_2025_schedule.py --month 2025-12 --commit --reset
"""

import argparse
import datetime
import os
import re
import sys

import openpyxl
import psycopg
from psycopg.rows import dict_row

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XLSX = os.environ.get("DEPT12_XLSX", os.path.join(BASE, "Flatbed Master Schedule.xlsx"))
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")
TAB = "Master Schedule 2025"

# xlsx ARGB fill -> category name (Nate's 2025 legend, D65). Driver-identity
# colors and the ignore/unknown colors are intentionally absent -> category None.
HEX2CAT = {
    "FFFFD966": "Anytime store",
    "FF92D050": "Early store",
    "FFBF8F00": "Umatilla side", "FFBF9000": "Umatilla side",
    "FFB6D7A8": "Bag plant", "FF6AA84F": "Bag plant", "FF93C47D": "Bag plant",
    "FFFFFF00": "Other dept",
    "FFFF00FF": "Don't miss",
    "FFFF0000": "Off",
}
STORE_CATS = {"Anytime store", "Early store", "Umatilla side"}


def is_six(v):
    return isinstance(v, datetime.time) and v.hour == 6 and v.minute == 0


def as_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    return v if isinstance(v, datetime.date) else None


def fill_hex(cell):
    f = cell.fill
    if not f or f.patternType is None:
        return "FFFFFFFF"
    rgb = f.fgColor.rgb if f.fgColor and isinstance(f.fgColor.rgb, str) else None
    return rgb or "FFFFFFFF"


def parse_label(lbl):
    """'31 Wayne BT' -> ('31','BT'); '80 Cameron' -> ('80', None)."""
    toks = str(lbl).split()
    if not toks or not toks[0].isdigit():
        return None, None
    eq = None
    for t in toks[1:]:
        tu = t.upper()
        if tu in ("BT", "CV", "F") or (t.isdigit() and len(t) <= 3):
            eq = tu
    return toks[0], eq


def band_rows(ws):
    """Return the time-header row of every band (row that has a 06:00 header)."""
    out = []
    for r in range(1, ws.max_row + 1):
        for c in range(1, 25):
            if is_six(ws.cell(r, c).value):
                out.append(r)
                break
    return out


def block_starts(ws, tr):
    return [c for c in range(1, ws.max_column + 1) if is_six(ws.cell(tr, c).value)]


# ── customer matching ──────────────────────────────────────────────────────
def build_cust_index(cur):
    cur.execute("select id, name from parties where is_customer")
    by_store, all_c = {}, []
    for row in cur.fetchall():
        up = row["name"].upper()
        if "BI-MART" in up or "BIMART" in up or "BI MART" in up:
            m = re.search(r"#\s*(\d{3})", up)
            if m:
                by_store[m.group(1)] = row["id"]
        all_c.append((up, row["id"]))
    all_c.sort(key=lambda x: -len(x[0]))  # longest name first for containment
    return by_store, all_c


def match_customer(text, by_store, all_c):
    up = text.upper()
    if re.search(r"\bB[-\s]?M\b|BI-?\s?MART", up):
        m = re.search(r"#?\s*(\d{3})\b", up)
        if m and m.group(1) in by_store:
            return by_store[m.group(1)]
    for cname, cid in all_c:
        if len(cname) >= 5 and cname in up:
            return cid
    return None


# ── main ────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--commit", action="store_true", help="write to the DB (default: dry run)")
    ap.add_argument("--reset", action="store_true", help="delete prior sheet2025 rows in scope first")
    ap.add_argument("--month", help="limit to a YYYY-MM (e.g. 2025-12)")
    args = ap.parse_args()

    want_month = None
    if args.month:
        y, m = args.month.split("-")
        want_month = (int(y), int(m))

    def in_scope(d):
        if not d or d.year != 2025:
            return False
        if want_month and (d.year, d.month) != want_month:
            return False
        return True

    wb = openpyxl.load_workbook(XLSX)
    ws = wb[TAB]
    trs = band_rows(ws)

    conn = psycopg.connect(DSN, row_factory=dict_row, autocommit=False)
    cur = conn.cursor()

    # category name -> id
    cur.execute("select id, name, is_off from categories")
    cat_id = {r["name"]: r["id"] for r in cur.fetchall()}
    # "Off" (and other 2025-era flag categories) may no longer exist in the
    # live categories table — internal chip color moved to the Bagger
    # Customer designation model (D72/D94), and truck_off_days.category_id
    # is nullable app-wide (api_truck_off does the same .get()-style lookup
    # live). Never KeyError on a retired category name.
    off_cat = cat_id.get("Off")

    by_store, all_c = build_cust_index(cur)
    cur.execute("select internal_department, external_department from order_number_settings limit 1")
    dept_row = cur.fetchone()
    internal_dept = dept_row["internal_department"] if dept_row else "07"
    external_dept = dept_row["external_department"] if dept_row else "12"

    if args.reset:
        # delete loads (cascades load_orders) then orders, then off-days, in scope.
        cur.execute("""
            delete from loads l using load_orders lo, orders o
            where lo.load_id = l.id and lo.order_id = o.id
              and o.custom->>'source' = 'sheet2025'
              and (%s::text is null or to_char(l.scheduled_date,'YYYY-MM') = %s)
        """, (args.month, args.month))
        cur.execute("""
            delete from orders o where o.custom->>'source' = 'sheet2025'
              and (%s::text is null or to_char(o.delivered_at,'YYYY-MM') = %s)
        """, (args.month, args.month))
        cur.execute("""
            delete from truck_off_days t where t.note like 'sheet2025:%%'
              and (%s::text is null or to_char(t.off_date,'YYYY-MM') = %s)
        """, (args.month, args.month))

    truck_cache = {}

    def truck_id(num, eq):
        if num in truck_cache:
            return truck_cache[num]
        cur.execute("select id from trucks where lower(number)=lower(%s)", (num,))
        r = cur.fetchone()
        if not r:
            cur.execute("insert into trucks (number, equipment_type) values (%s,%s) returning id",
                        (num, eq or "F"))
            r = cur.fetchone()
        truck_cache[num] = r["id"]
        return r["id"]

    seen = set()          # (truck_num, date, normtext) de-dupe across overlapping bands
    stats = {"loads": 0, "internal": 0, "external": 0, "matched": 0,
             "unmatched_internal": 0, "off_days": 0, "trucks": set(), "cats": {}}
    samples = []

    for tr in trs:
        for sc in block_starts(ws, tr):
            d = as_date(ws.cell(tr - 1, sc).value)
            if not in_scope(d):
                continue
            for r in range(tr + 1, tr + 10):
                label = ws.cell(r, 1).value
                num, eq = parse_label(label)
                if not num:
                    continue
                off_notes, cells = [], []
                for c in range(sc, sc + 14):
                    v = ws.cell(r, c).value
                    if v in (None, ""):
                        continue
                    s = str(v).strip()
                    hx = fill_hex(ws.cell(r, c))
                    cat = HEX2CAT.get(hx)
                    if cat == "Off":
                        off_notes.append(s)
                    else:
                        cells.append((s, hx, cat))
                # off day for this truck
                if off_notes:
                    stats["off_days"] += 1
                    if args.commit:
                        note = "sheet2025: " + " / ".join(dict.fromkeys(off_notes))[:240]
                        cur.execute("""
                            insert into truck_off_days (truck_id, off_date, note, category_id)
                            values (%s,%s,%s,%s) on conflict (truck_id, off_date)
                            do update set note = excluded.note, category_id = excluded.category_id
                        """, (truck_id(num, eq), d, note, off_cat))
                # loads for this truck-day, sequence 1..N
                slot = 0
                for s, hx, cat in cells:
                    key = (num, d, re.sub(r"\s+", " ", s.upper()))
                    if key in seen:
                        continue
                    seen.add(key)
                    slot += 1
                    cust = match_customer(s, by_store, all_c)
                    # "Bag plant" cells are bagger loads regardless of customer
                    # match (Nate: "bag plant to umatilla is a bagger load") —
                    # not a dept-to-dept Internal Freight transfer, just an
                    # internal/dept-07 haul with no matched customer yet.
                    is_internal = bool(cust) or (cat in STORE_CATS) or (cat == "Bag plant")
                    kind = "internal" if is_internal else "external"
                    stats["loads"] += 1
                    stats[kind] += 1
                    stats["trucks"].add(num)
                    stats["cats"][cat or "(none)"] = stats["cats"].get(cat or "(none)", 0) + 1
                    if cust:
                        stats["matched"] += 1
                    elif is_internal:
                        stats["unmatched_internal"] += 1
                    if len(samples) < 14:
                        samples.append((d.isoformat(), num, kind, cat or "-",
                                        "cust" if cust else "?", s[:40]))
                    if args.commit:
                        # order_period (D217) is what the Bag Orders month-tab
                        # actually groups on now, not the order number — these
                        # rows have no solomon_order_no at all, so without this
                        # they're invisible in every month tab despite existing
                        # and showing fine on the Scheduler. department (D217)
                        # likewise moved off the number; use the live default
                        # for each kind rather than hardcoding '07'/'12'.
                        dept = internal_dept if kind == "internal" else external_dept
                        period = datetime.date(d.year, d.month, 1) if kind == "internal" else None
                        cur.execute("""
                            insert into orders (kind, solomon_order_no, customer_party_id,
                                stage, ordered_at, delivered_at, notes, custom, department, order_period)
                            values (%s, null, %s::uuid, 'delivered', %s, %s, %s,
                                    jsonb_build_object('source','sheet2025','raw',%s::text,
                                        'color',%s::text,'truck',%s::text,'date',%s::text),
                                    %s, %s)
                            returning id
                        """, (kind, cust, d, d, s, s, hx, num, d.isoformat(), dept, period))
                        oid = cur.fetchone()["id"]
                        # Sheet fill colors are not imported as categories (Nate:
                        # "we dont care about colors on import, we have our own
                        # color rules here"). Internal stays uncategorized —
                        # he'll assign each bagger customer's real designation
                        # by hand from the load text. External gets pushed_at
                        # set so it immediately follows the truck's current
                        # driver color, "just like our app would" (pushColorFor,
                        # 02-chips-extract.js) — no bespoke coloring logic here.
                        cur.execute("""
                            insert into loads (kind, status, scheduled_date, truck_id, slot,
                                category_id, notes, pushed_at)
                            values (%s,'delivered',%s,%s,%s,null,%s,
                                    case when %s = 'external' then now() else null end)
                            returning id
                        """, (kind, d, truck_id(num, eq), slot, s, kind))
                        lid = cur.fetchone()["id"]
                        cur.execute("insert into load_orders (load_id, order_id) values (%s,%s)",
                                    (lid, oid))

    if args.commit:
        conn.commit()
    conn.close()

    scope = args.month or "all of 2025"
    print(f"\n{'COMMITTED' if args.commit else 'DRY RUN'} — scope: {scope}")
    print(f"  trucks touched : {len(stats['trucks'])}  {sorted(stats['trucks'], key=lambda x:int(x))}")
    print(f"  loads          : {stats['loads']}   (internal {stats['internal']} / external {stats['external']})")
    print(f"  customer-matched internal : {stats['matched']}   unmatched-but-internal : {stats['unmatched_internal']}")
    print(f"  truck off-days : {stats['off_days']}")
    print("  by category:")
    for k, v in sorted(stats["cats"].items(), key=lambda kv: -kv[1]):
        print(f"     {k:16s} {v}")
    print("  sample rows (date | truck | kind | category | cust | text):")
    for s in samples:
        print("     " + " | ".join(str(x) for x in s))


if __name__ == "__main__":
    main()
