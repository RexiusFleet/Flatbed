#!/usr/bin/env python3
"""Read-only local matching context for the scanned Sent document batch."""
import json
import psycopg
from psycopg.rows import dict_row
from reconcile_umatilla_season import BASE, DSN

with psycopg.connect(DSN, row_factory=dict_row) as conn:
    conn.execute("set transaction read only")
    orders = conn.execute("""select o.*, b.name as broker_name,
        (select jsonb_agg(jsonb_build_object('load_id',l.id,'date',l.scheduled_date,'truck',t.number))
         from load_orders lo join loads l on l.id=lo.load_id left join trucks t on t.id=l.truck_id
         where lo.order_id=o.id) as placements
        from orders o left join parties b on b.id=o.broker_party_id
        where o.kind='external' and not o.is_transfer""").fetchall()
    data = {"orders": orders,
            "parties": conn.execute("select id,name,is_broker from parties where is_broker").fetchall(),
            "notes": conn.execute("select id,truck_id,scheduled_date,slot,body from schedule_notes").fetchall(),
            "documents": conn.execute("select * from documents").fetchall()}
    target = BASE / "output" / "sent-2026" / "match-context.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, default=str, indent=2))
    print(json.dumps({key: len(value) for key, value in data.items()}))
