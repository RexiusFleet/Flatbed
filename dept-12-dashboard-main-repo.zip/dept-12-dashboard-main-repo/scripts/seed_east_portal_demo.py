#!/usr/bin/env python3
"""Load the synthetic East Side order into an isolated local database."""

import argparse
import os
import shutil
from pathlib import Path

import psycopg


ROOT = Path(__file__).resolve().parent.parent
SOURCE_PDF = ROOT / "output" / "pdf" / "east-side-demo-delivery-receipt-07-0926-9001.pdf"
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12_east_test host=127.0.0.1")
STORAGE_ROOT = Path(os.environ.get("DEPT12_STORAGE_ROOT", "/private/tmp/dept12-east-portal-storage"))

PARTY_ID = "99999999-9999-4999-8999-999999999901"
LOCATION_ID = "99999999-9999-4999-8999-999999999902"
ORDER_ID = "99999999-9999-4999-8999-999999999903"
DOCUMENT_ID = "99999999-9999-4999-8999-999999999904"
STORAGE_PATH = f"{ORDER_ID}/{DOCUMENT_ID}_East_Side_Demo_Receipt.pdf"


def reset_completion(conn):
    with conn.cursor() as cur:
        cur.execute(
            """
            select d.storage_path
            from driver_receipt_completions ec
            join documents d on d.id=ec.pod_document_id
            where ec.order_id=%s
            """,
            (ORDER_ID,),
        )
        row = cur.fetchone()
        cur.execute("delete from driver_receipt_completions where order_id=%s", (ORDER_ID,))
        cur.execute(
            "delete from documents where order_id=%s and doc_type='pod' and extracted_fields->>'driver_portal'='true'",
            (ORDER_ID,),
        )
        cur.execute(
            "update orders set stage='released', delivered_at=null where id=%s",
            (ORDER_ID,),
        )
    if row:
        completed_file = (STORAGE_ROOT / row[0]).resolve()
        root = STORAGE_ROOT.resolve()
        if completed_file.is_relative_to(root) and completed_file.is_file():
            completed_file.unlink()


def seed(reset=False):
    if not SOURCE_PDF.is_file():
        raise SystemExit(f"Generate the demo PDF first: {SOURCE_PDF}")
    STORAGE_ROOT.mkdir(parents=True, exist_ok=True)
    target = STORAGE_ROOT / STORAGE_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE_PDF, target)

    with psycopg.connect(DSN) as conn:
        if reset:
            reset_completion(conn)
        with conn.cursor() as cur:
            cur.execute(
                """
                insert into parties (id, name, is_customer, phone, manager_name, notes)
                values (%s, 'East Ridge Home & Garden - TEST', true, '(541) 555-0142',
                        'Demo Receiver', 'Synthetic local East Side portal test customer.')
                on conflict (id) do update set
                  name=excluded.name, is_customer=true, phone=excluded.phone,
                  manager_name=excluded.manager_name, notes=excluded.notes
                """,
                (PARTY_ID,),
            )
            cur.execute(
                """
                insert into locations
                  (id, party_id, name, address, city, state, postal_code, phone,
                   forklift, timing_window, is_umatilla, miles_from_umatilla, notes)
                values (%s, %s, 'East Ridge Home & Garden - TEST', '7420 Test Market Road',
                        'Umatilla', 'OR', '97882', '(541) 555-0142', 'spyder', 'anytime',
                        true, 7.5, 'Synthetic address. Not a real delivery location.')
                on conflict (id) do update set
                  party_id=excluded.party_id, name=excluded.name, address=excluded.address,
                  city=excluded.city, state=excluded.state, postal_code=excluded.postal_code,
                  phone=excluded.phone, forklift=excluded.forklift,
                  timing_window=excluded.timing_window, is_umatilla=true,
                  miles_from_umatilla=excluded.miles_from_umatilla, notes=excluded.notes
                """,
                (LOCATION_ID, PARTY_ID),
            )
            cur.execute(
                """
                insert into orders
                  (id, kind, solomon_order_no, customer_party_id, po_number, pallet_count,
                   stage, ordered_at, released_at, requested_delivery_date,
                   delivery_location_id, notes, driver_note)
                values (%s, 'internal', '07-0926-9001', %s, 'PO-TEST-1847', 21,
                        'released', '2026-09-10', now(), '2026-09-15', %s,
                        'Synthetic local portal test order.',
                        'Call receiving 30 minutes before arrival. Use east service gate.')
                on conflict (id) do update set
                  customer_party_id=excluded.customer_party_id,
                  po_number=excluded.po_number, pallet_count=excluded.pallet_count,
                  delivery_location_id=excluded.delivery_location_id,
                  requested_delivery_date=excluded.requested_delivery_date,
                  notes=excluded.notes, driver_note=excluded.driver_note
                """,
                (ORDER_ID, PARTY_ID, LOCATION_ID),
            )
            cur.execute(
                """
                insert into documents
                  (id, doc_type, order_id, storage_path, original_filename,
                   extracted_fields, matched_by, matched_at)
                values (%s, 'delivery_receipt', %s, %s,
                        'East Side Demo Delivery Receipt - 07-0926-9001.pdf',
                        '{"synthetic": true, "east_portal_demo": true}'::jsonb,
                        'manual', now())
                on conflict (id) do update set
                  order_id=excluded.order_id, storage_path=excluded.storage_path,
                  original_filename=excluded.original_filename,
                  extracted_fields=excluded.extracted_fields
                """,
                (DOCUMENT_ID, ORDER_ID, STORAGE_PATH),
            )
    print(f"Demo order 07-0926-9001 loaded into {DSN}")
    print(f"Receipt stored at {target}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--reset-completion",
        action="store_true",
        help="Remove the demo order's signed POD and put it back in the ready queue.",
    )
    args = parser.parse_args()
    seed(reset=args.reset_completion)


if __name__ == "__main__":
    main()
