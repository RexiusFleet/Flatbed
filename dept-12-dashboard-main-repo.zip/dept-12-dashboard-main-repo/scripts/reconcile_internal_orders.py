#!/usr/bin/env python3
"""Bag Order (internal) customer matching + full order numbering, preview first.

Same safety model as reconcile_external_orders.py: unambiguous matches only
(brand-name + store-number pairing, tolerant of punctuation and a short
descriptive word the sheet omits — e.g. "HI-SCHOOL #1164" matches "HI-SCHOOL
PHARMACY #1164"), every full-number collision held rather than guessed,
nothing already set is overwritten, and every change is written to a local
JSON report before (and after) commit.

Order/pallet notation ("23/12") — left is the order number, right is the
pallet count (Nate, D221/D222) — is parsed from the same raw `notes` text
the schedule import preserved. The full order number is
"07-{MM}{YY}-{####}" using the load's real delivered_at month, matching the
live order_number_settings pattern.
"""
import argparse
from collections import Counter, defaultdict
import datetime as dt
import json
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

# "BM DC"/"North End" abbreviations were already resolved by
# reconcile_bag_customers.py to specific customers. These are the other
# common shorthand forms seen across the rest of the sheet.
ALIAS_SUB = [
    (re.compile(r"\bBI-M\b", re.I), "BI-MART"),
    (re.compile(r"\bB/M\b", re.I), "BI-MART"),
]

NUM_RE = re.compile(r"\d{2,6}")
ORDER_PALLET_RE = re.compile(r"\b(\d{1,4})\s*/\s*(\d{1,3})\b")


def norm(value):
    return re.sub(r"[^A-Z0-9]", "", value.upper())


def brand_num(name):
    """('WILCO #503 McMinnville OR NF 2/12', ...) -> ('WILCO', '503') — the
    brand is everything before the FIRST number, so a customer name with an
    extra descriptive word ("HI-SCHOOL PHARMACY #1178") still pairs with the
    sheet's shorter form ("HI-SCHOOL #1178") via the containment check in
    match_customer, not exact brand equality."""
    m = NUM_RE.search(name)
    if not m:
        return None, None
    return norm(name[:m.start()]), m.group(0)


def match_customer(text, db_bn):
    sub = text
    for pat, repl in ALIAS_SUB:
        sub = pat.sub(repl, sub)
    brand, number = brand_num(sub)
    if not brand or len(brand) < 3:
        return None, None
    cands = [c for b, n, c in db_bn if n == number and (brand in b or b in brand)]
    ids = {c["id"] for c in cands}
    return (cands[0]["id"], cands[0]["name"]) if len(ids) == 1 else (None, None)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        customers = conn.execute(
            "select id, name from parties where is_customer and customer_archived_at is null").fetchall()
        db_bn = []
        for c in customers:
            b, n = brand_num(c["name"])
            if b and len(b) >= 3:
                db_bn.append((b, n, c))
        cfg = conn.execute(
            "select internal_pattern, internal_department from order_number_settings where id=1").fetchone()
        if cfg != {"internal_pattern": "07-{MM}{YY}-{####}", "internal_department": "07"}:
            raise ValueError("Number settings differ from the confirmed format")
        rows = conn.execute("""select * from orders where kind='internal'
            and custom->>'source' in ('sheet2025','sheet2026')
            order by delivered_at, id for update""").fetchall()
        existing = conn.execute("select id, solomon_order_no from orders").fetchall()
        existing_orders = {r["solomon_order_no"]: str(r["id"]) for r in existing if r["solomon_order_no"]}
        order_groups = defaultdict(list)
        plans = []
        for row in rows:
            text = row["notes"] or ""
            cust_id, cust_name = (row["customer_party_id"], None)
            if not cust_id:
                cust_id, cust_name = match_customer(text, db_bn)
            m = ORDER_PALLET_RE.search(text)
            short, pallet = (m.group(1), int(m.group(2))) if m else (None, None)
            day = row["delivered_at"]
            candidate = f"07-{day:%m%y}-{int(short):04d}" if day and short else None
            item = {"before": row, "matched_customer": cust_name, "customer_id": cust_id,
                    "short_order_number": short, "pallet_count": pallet,
                    "order_number_candidate": candidate, "issues": []}
            plans.append(item)
            if candidate:
                order_groups[candidate].append(str(row["id"]))
        changes = []
        for item in plans:
            row = item["before"]
            oid = str(row["id"])
            number = item["order_number_candidate"]
            issues = item["issues"]
            if not item["short_order_number"]:
                issues.append("short_order_number_missing")
            if number and (len(order_groups[number]) > 1 or existing_orders.get(number, oid) != oid):
                issues.append("repeated_full_order_number")
                number = None
            after = {
                "customer_party_id": row["customer_party_id"] or item["customer_id"],
                "pallet_count": row["pallet_count"] if row["pallet_count"] is not None else item["pallet_count"],
                "solomon_order_no": row["solomon_order_no"] or number,
            }
            metadata = {"rule": "internal-order-numbers-v1",
                        "short_order_number": item["short_order_number"],
                        "matched_customer": item["matched_customer"],
                        "order_number_candidate": item["order_number_candidate"],
                        "issues": issues}
            if all(row[k] == v for k, v in after.items()) and row["custom"].get("internal_import_review") == metadata:
                continue
            changes.append({"before": row, "after": after, "metadata": metadata})
        report = {"status": "preview", "issue_counts": dict(Counter(i for p in plans for i in p["issues"]))}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-internal.json")
        report["changes"] = changes
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            for c in changes:
                conn.execute("""update orders set customer_party_id=%s, pallet_count=%s,
                    solomon_order_no=%s, custom=custom || jsonb_build_object('internal_import_review',%s::jsonb)
                    where id=%s""", (c["after"]["customer_party_id"], c["after"]["pallet_count"],
                    c["after"]["solomon_order_no"], Jsonb(c["metadata"]), c["before"]["id"]))
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"status": report["status"], "changed": len(changes),
                          "customers_matched": sum(1 for p in plans if p["matched_customer"]),
                          "pallet_counts": sum(1 for c in changes if c["after"]["pallet_count"] is not None),
                          "full_order_numbers": sum(1 for c in changes if c["after"]["solomon_order_no"]),
                          "issues": report["issue_counts"], "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
