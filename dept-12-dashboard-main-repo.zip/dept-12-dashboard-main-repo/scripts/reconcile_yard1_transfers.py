#!/usr/bin/env python3
"""Apply Nate's reviewed Yard 1 / cleanup calls on the imported schedule, dry-run first.

Three fixed dispositions, confirmed by Nate directly (not inferred):
  - DELETE: "Cascade Valley Cannabis BK TLR SPYD" (2025-02-13) — no longer needed.
  - NOTE: the two bare "AM SULF" rows — not a real order, converted to a
    schedule_notes cell so the reminder text survives on the Scheduler.
  - TRANSFER: Stutzman/Marion AG "...to Yard #1...", Columbia Carb "...to Yard
    #1...", and every "Ultra Block Vancouver to the Rexius Yard #1" row —
    reclassified to an Internal Freight transfer against the Yard 1 - 03
    department, same shape as reconcile_umatilla_season.py's Bagger-07 move.
    No transfer_season is set (no season concept was confirmed for Yard 1,
    unlike the Bagger-Umatilla case) — sheet2025-sourced rows here stay
    historical/hidden from the live Internal Freight tracker like any other
    2025 import, sheet2026 ones show under their calendar year.

Every row is matched by literal id, not by re-deriving the pattern, so this
is not meant to be re-run against new data — it is a one-time cleanup of the
exact rows reviewed in this pass.
"""
import argparse
import datetime as dt
import json

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

DELETE_IDS = ["52c6f1a4-4462-45a4-aaee-d50b1932e2b0"]  # Cascade Valley Cannabis
NOTE_IDS = [
    "42630b21-46c9-4552-9a1a-ea871a714965",
    "f3270e9f-eae1-4cb1-b844-73f5a3ff6fe5",
]  # bare "AM SULF"
TRANSFER_IDS = [
    "b6e7da29-b057-450d-b7db-236730b15cce",  # Columbia Carb to Yard #1
    "3f4f24aa-d05f-430f-b0f6-2204a27bd3c6",
    "0401ffb9-bbcd-41f6-8c0c-b6df1b140293",
    "407d00b9-5a47-4d47-8656-a410a4ae315e",
    "6cb17742-66db-45a3-ab66-7d93f2082745",
    "c49b2551-0047-4eef-a036-76f9036b937a",
    "3256874c-905a-469a-a33f-821f442b89dc",
    "0d9b39ce-2cff-4a73-acf9-6e1ef94e6bc4",
    "28272ee9-d33b-4bd5-a312-df1b2caff3ad",  # Stutzman/Marion AG to Yard #1 (8)
    "8e7114f6-a153-440f-a7cf-ca896217bb46",
    "16a62521-51e3-4a0e-be95-75f497d1e066",
    "a4c33172-3a20-44d4-b7d6-caf8556cdd79",
    "078f1e09-8e3b-4e67-95cd-9864b31ff801",  # Ultra Block to Yard #1 (4)
]
RULE = "yard1-cleanup-2026-09-12-v1"


def one_load(conn, order_id):
    loads = conn.execute("""select l.*, (select count(*) from load_orders x where x.load_id=l.id) as n
        from loads l join load_orders lo on lo.load_id=l.id
        where lo.order_id=%s for update of l""", (order_id,)).fetchall()
    if len(loads) != 1 or loads[0]["n"] != 1:
        raise ValueError(f"Order {order_id} is not a standalone single-order trip")
    return loads[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        dept = conn.execute("select id from departments where name='Yard 1 - 03'").fetchone()
        if not dept:
            raise ValueError("Expected Yard 1 - 03 department not found")

        deletes, notes, transfers = [], [], []
        for oid in DELETE_IDS:
            row = conn.execute("select * from orders where id=%s for update", (oid,)).fetchone()
            if not row or row["stage"] not in ("delivered", "ordered", "scheduled"):
                raise ValueError(f"Order {oid} not found or in an unexpected stage")
            load = one_load(conn, oid)
            deletes.append({"order": row, "load": load})

        for oid in NOTE_IDS:
            row = conn.execute("select * from orders where id=%s for update", (oid,)).fetchone()
            if not row or row["notes"].strip().upper() != "AM SULF":
                raise ValueError(f"Order {oid} does not match expected AM SULF text")
            load = one_load(conn, oid)
            notes.append({"order": row, "load": load})

        for oid in TRANSFER_IDS:
            row = conn.execute("select * from orders where id=%s for update", (oid,)).fetchone()
            if not row:
                raise ValueError(f"Order {oid} not found")
            if row["customer_party_id"] or row["broker_party_id"] or row["solomon_order_no"]:
                raise ValueError(f"Order {oid} unexpectedly has customer/broker/order number set")
            load = one_load(conn, oid)
            transfers.append({"order": row, "load": load})

        report = {"mode": "apply-requested" if args.commit else "dry-run",
                  "delete_count": len(deletes), "note_count": len(notes),
                  "transfer_count": len(transfers)}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-yard1-cleanup.json")
        path.write_text(json.dumps({**report, "deletes": deletes, "notes": notes, "transfers": transfers},
                                    default=str, indent=2) + "\n")

        if args.commit:
            for d in deletes:
                oid, lid = d["order"]["id"], d["load"]["id"]
                conn.execute("delete from load_orders where load_id=%s", (lid,))
                conn.execute("delete from loads where id=%s", (lid,))
                conn.execute("delete from orders where id=%s", (oid,))
            for n in notes:
                order, load = n["order"], n["load"]
                conn.execute("""insert into schedule_notes (truck_id, scheduled_date, slot, body)
                    values (%s,%s,%s,%s)""",
                    (load["truck_id"], load["scheduled_date"], load["slot"], order["notes"]))
                conn.execute("delete from load_orders where load_id=%s", (load["id"],))
                conn.execute("delete from loads where id=%s", (load["id"],))
                conn.execute("delete from orders where id=%s", (order["id"],))
            for t in transfers:
                order, load = t["order"], t["load"]
                conn.execute("""update orders set kind='external', is_transfer=true,
                    transfer_department_id=%s, department=null, order_period=null,
                    customer_party_id=null, pallet_count=null,
                    custom=custom || jsonb_build_object('yard1_review',%s::jsonb)
                    where id=%s""", (dept["id"], Jsonb({"rule": RULE}), order["id"]))
                conn.execute("update loads set kind='external' where id=%s", (load["id"],))
            conn.commit()
            report["mode"] = "committed"
            path.write_text(json.dumps({**report, "deletes": deletes, "notes": notes, "transfers": transfers},
                                        default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({**report, "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
