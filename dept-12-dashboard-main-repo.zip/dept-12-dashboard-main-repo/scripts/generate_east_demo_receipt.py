#!/usr/bin/env python3
"""Generate the synthetic East Side delivery receipt used for portal testing."""

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "output" / "pdf" / "east-side-demo-delivery-receipt-07-0926-9001.pdf"
LOGO = ROOT / "app" / "web" / "rexius-logo.png"


def build_copy(story, label, styles):
    green = colors.HexColor("#2F6F3A")
    soft_green = colors.HexColor("#E5F0E4")
    warm = colors.HexColor("#F2F0E9")
    ink = colors.HexColor("#172019")
    muted = colors.HexColor("#697169")

    logo = Image(str(LOGO), width=1.55 * inch, height=0.65 * inch)
    heading = Paragraph("<b>DELIVERY RECEIPT</b><br/><font size='9'>TEST DOCUMENT - NOT A REAL ORDER</font>", styles["TitleRight"])
    story.append(Table([[logo, heading]], colWidths=[2.0 * inch, 5.05 * inch], style=[
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LINEBELOW", (0, 0), (-1, -1), 2, green),
    ]))
    story.append(Spacer(1, 12))

    story.append(Table([
        [Paragraph("<b>Order</b><br/>07-0926-9001", styles["Box"]),
         Paragraph("<b>Delivery date</b><br/>September 15, 2026", styles["Box"]),
         Paragraph(f"<b>Copy</b><br/>{label}", styles["Box"])],
    ], colWidths=[2.35 * inch] * 3, style=[
        ("BACKGROUND", (0, 0), (-1, -1), soft_green),
        ("BOX", (0, 0), (-1, -1), 0.75, green),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#B8C9B7")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(Spacer(1, 14))

    address = [
        [Paragraph("<b>SHIP TO</b>", styles["Section"]), Paragraph("<b>DELIVERY DETAILS</b>", styles["Section"])],
        [Paragraph("<b>East Ridge Home &amp; Garden</b><br/>7420 Test Market Road<br/>Umatilla, OR 97882<br/>(541) 555-0142", styles["Body"]),
         Paragraph("<b>Window:</b> Umatilla Anytime<br/><b>Purchase order:</b> PO-TEST-1847<br/><b>Pallets:</b> 21<br/><b>Forklift:</b> Spyder required", styles["Body"])],
    ]
    story.append(Table(address, colWidths=[3.52 * inch, 3.53 * inch], style=[
        ("BACKGROUND", (0, 0), (-1, 0), warm),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#C9C7BF")),
        ("INNERGRID", (0, 0), (-1, 0), 0.4, colors.HexColor("#C9C7BF")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(Spacer(1, 15))

    items = [
        ["QTY", "PRODUCT", "PACK", "LOT / NOTES"],
        ["12 pallets", "Premium Dark Bark", "60 bags per pallet", "Demo lot A-0915"],
        ["6 pallets", "Organic Garden Compost", "50 bags per pallet", "Demo lot B-0915"],
        ["3 pallets", "Playground Chips", "55 bags per pallet", "Demo lot C-0915"],
        ["21 pallets", "TOTAL", "1,185 bags", "Count before signing"],
    ]
    story.append(Table(items, colWidths=[0.9 * inch, 2.45 * inch, 1.7 * inch, 2.0 * inch], repeatRows=1, style=[
        ("BACKGROUND", (0, 0), (-1, 0), green),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), soft_green),
        ("GRID", (0, 0), (-1, -1), 0.45, colors.HexColor("#BFC2BB")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("TEXTCOLOR", (0, 1), (-1, -1), ink),
    ]))
    story.append(Spacer(1, 14))

    story.append(Table([
        [Paragraph("<b>DELIVERY INSTRUCTIONS</b>", styles["Section"])],
        [Paragraph("Call the receiving desk 30 minutes before arrival. Enter through the east service gate. Keep the fire lane clear and place all pallets in the marked garden-center staging area.", styles["Body"])],
    ], colWidths=[7.05 * inch], style=[
        ("BACKGROUND", (0, 0), (-1, 0), warm),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#C9C7BF")),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
    ]))
    story.append(Spacer(1, 17))

    story.append(Paragraph("<b>RECEIVING CONFIRMATION</b>", styles["SectionGreen"]))
    story.append(Spacer(1, 7))
    story.append(Paragraph("I acknowledge receipt of the products listed above in acceptable condition, except as noted below.", styles["Body"]))
    story.append(Spacer(1, 13))
    signature_rows = [
        ["RECEIVER SIGNATURE", "PRINTED NAME"],
        ["", ""],
        ["DATE / TIME", "DRIVER / TRUCK"],
        ["", ""],
    ]
    story.append(Table(signature_rows, colWidths=[3.52 * inch, 3.53 * inch], rowHeights=[0.22 * inch, 0.64 * inch, 0.22 * inch, 0.46 * inch], style=[
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TEXTCOLOR", (0, 0), (-1, -1), muted),
        ("LINEBELOW", (0, 1), (-1, 1), 0.7, ink),
        ("LINEBELOW", (0, 3), (-1, 3), 0.7, ink),
        ("VALIGN", (0, 0), (-1, -1), "BOTTOM"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 14),
    ]))
    story.append(Spacer(1, 11))
    story.append(Paragraph("Exceptions / damage notes: __________________________________________________________________________________", styles["Small"]))
    story.append(Spacer(1, 12))
    story.append(Paragraph("This synthetic receipt is for local Rexius Bag Orders testing only. It does not represent a real customer, address, order, shipment, or product lot.", styles["Footer"]))


def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleRight", parent=styles["Normal"], fontName="Helvetica", fontSize=18, leading=22, alignment=TA_RIGHT, textColor=colors.HexColor("#172019")))
    styles.add(ParagraphStyle(name="Box", parent=styles["Normal"], fontSize=10, leading=14, textColor=colors.HexColor("#172019")))
    styles.add(ParagraphStyle(name="Section", parent=styles["Normal"], fontSize=9, leading=11, textColor=colors.HexColor("#5E665E"), letterSpacing=0.6))
    styles.add(ParagraphStyle(name="SectionGreen", parent=styles["Normal"], fontSize=10, leading=12, textColor=colors.HexColor("#2F6F3A"), letterSpacing=0.5))
    styles.add(ParagraphStyle(name="Body", parent=styles["Normal"], fontSize=10, leading=15, textColor=colors.HexColor("#172019")))
    styles.add(ParagraphStyle(name="Small", parent=styles["Normal"], fontSize=8.5, leading=12, textColor=colors.HexColor("#172019")))
    styles.add(ParagraphStyle(name="Footer", parent=styles["Normal"], fontSize=7.5, leading=10, alignment=TA_CENTER, textColor=colors.HexColor("#697169")))

    doc = SimpleDocTemplate(str(OUTPUT), pagesize=letter, rightMargin=0.7 * inch, leftMargin=0.7 * inch, topMargin=0.55 * inch, bottomMargin=0.5 * inch, title="East Side Demo Delivery Receipt", author="Dept 12 Dashboard Test Fixture")
    story = []
    build_copy(story, "DRIVER COPY", styles)
    story.append(PageBreak())
    build_copy(story, "CUSTOMER COPY", styles)
    doc.build(story)
    print(OUTPUT)


if __name__ == "__main__":
    main()
