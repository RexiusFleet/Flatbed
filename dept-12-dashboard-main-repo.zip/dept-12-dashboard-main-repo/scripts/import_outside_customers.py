#!/usr/bin/env python3
"""Import the live ``outside customer list`` tab into local ``parties``.

Source columns (confirmed in the legacy contract):
  A Customer/Broker name  B Notes  C AP Email

The operation is idempotent by case-insensitive, normalized name. The legacy
``++`` suffix is stripped per schema decision D5. Existing party roles other
than ``is_broker`` are preserved; only the outside-list fields (AP email and
notes) are synchronized.

Usage:
  DEPT12_SHEETS_CREDS=secrets/dept-12-dash-....json \
    python3 scripts/import_outside_customers.py --dry-run

  DEPT12_SHEETS_CREDS=secrets/dept-12-dash-....json \
    python3 scripts/import_outside_customers.py --apply
"""

import argparse
import os
import re
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))

import psycopg
from psycopg.rows import dict_row
from adapters import GoogleSheetsSync


SHEET_ID = "1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4"
TAB = "outside customer list"
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")


def clean(value):
    value = str(value or "").strip()
    return value or None


def normalize_name(value):
    return re.sub(r"\s*\+\+.*$", "", str(value or "").strip()).strip()


def merge_distinct(left, right, separator):
    values = []
    for raw in (left, right):
        if not raw:
            continue
        parts = re.split(r"\s*[;,]\s*", raw) if separator == "; " else [raw]
        for part in parts:
            part = part.strip()
            if part and part.casefold() not in [v.casefold() for v in values]:
                values.append(part)
    return separator.join(values) or None


def read_source(sheets):
    values = sheets.read_range(f"'{TAB}'!A1:C500")
    if not values:
        raise RuntimeError(f"{TAB!r} returned no rows")
    header = (values[0] + [""] * 3)[:3]
    if "customer" not in str(header[0]).lower():
        raise RuntimeError(f"Unexpected {TAB!r} header: {header!r}")

    rows, duplicates = [], []
    seen = {}
    for sheet_row, raw in enumerate(values[1:], start=2):
        raw = (raw + [""] * 3)[:3]
        name = normalize_name(raw[0])
        if not name:
            continue
        item = {
            "sheet_row": sheet_row,
            "name": name,
            "raw_name": str(raw[0]).strip(),
            "notes": clean(raw[1]),
            "ap_email": clean(raw[2]),
        }
        key = name.casefold()
        if key in seen:
            duplicates.append((seen[key]["sheet_row"], sheet_row, name))
            # A duplicated broker row can represent a second AP recipient (the
            # current sheet does this for Oregon Canadian). Preserve both;
            # OutlookDraft/GraphDraft already accept semicolon-separated lists.
            seen[key]["ap_email"] = merge_distinct(seen[key]["ap_email"], item["ap_email"], "; ")
            seen[key]["notes"] = merge_distinct(seen[key]["notes"], item["notes"], " | ")
            seen[key]["raw_name"] += " / " + item["raw_name"]
            continue
        seen[key] = item
        rows.append(item)
    return header, rows, duplicates


def classify(conn, rows):
    with conn.cursor() as cur:
        cur.execute("select id, name, is_broker, ap_email, notes from parties")
        existing = {r["name"].casefold(): r for r in cur.fetchall()}
    inserts, updates, unchanged = [], [], []
    for row in rows:
        old = existing.get(row["name"].casefold())
        if not old:
            inserts.append(row)
        elif (not old["is_broker"] or (old["ap_email"] or None) != row["ap_email"] or
              (old["notes"] or None) != row["notes"]):
            updates.append((row, old))
        else:
            unchanged.append(row)
    return inserts, updates, unchanged


def apply(conn, inserts, updates):
    with conn.cursor() as cur:
        cur.execute("select coalesce(max(sort_order), 0) as n from parties")
        sort_order = cur.fetchone()["n"]
        for row in inserts:
            sort_order += 1
            cur.execute("""
                insert into parties (name, is_broker, ap_email, notes, sort_order, custom)
                values (%s, true, %s, %s, %s,
                        jsonb_build_object('outside_customer_list',
                          jsonb_build_object('sheet_row', %s::integer, 'source_name', %s::text)))
            """, (row["name"], row["ap_email"], row["notes"], sort_order,
                  row["sheet_row"], row["raw_name"]))
        for row, old in updates:
            cur.execute("""
                update parties
                set is_broker = true, ap_email = %s, notes = %s,
                    custom = coalesce(custom, '{}'::jsonb) ||
                      jsonb_build_object('outside_customer_list',
                        jsonb_build_object('sheet_row', %s::integer, 'source_name', %s::text))
                where id = %s
            """, (row["ap_email"], row["notes"], row["sheet_row"],
                  row["raw_name"], old["id"]))
    conn.commit()


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    creds = os.environ.get("DEPT12_SHEETS_CREDS")
    if not creds:
        sys.exit("Set DEPT12_SHEETS_CREDS to the service-account JSON path.")

    sheets = GoogleSheetsSync(creds, SHEET_ID)
    header, rows, duplicates = read_source(sheets)
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        inserts, updates, unchanged = classify(conn, rows)
        print(f"sheet={SHEET_ID} tab={TAB!r}")
        print(f"header={header!r}")
        print(f"source_rows={len(rows)} emails={sum(bool(r['ap_email']) for r in rows)} "
              f"insert={len(inserts)} update={len(updates)} unchanged={len(unchanged)}")
        if duplicates:
            print("duplicates=" + ", ".join(f"rows {a}/{b}: {name}" for a, b, name in duplicates))
        sample = rows[:5] + (rows[-5:] if len(rows) > 5 else [])
        print("sample=" + " | ".join(
            f"{r['sheet_row']}:{r['name']} ({'email' if r['ap_email'] else 'no email'})" for r in sample))
        if args.apply:
            apply(conn, inserts, updates)
            print("applied=true")
        else:
            conn.rollback()
            print("applied=false")


if __name__ == "__main__":
    main()
