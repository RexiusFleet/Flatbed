#!/usr/bin/env python3
"""Preview/apply reviewed external identifiers without merging real trips.

Exact names, unambiguous whole-word name prefixes and confirmed aliases only.
Number collisions are held on every affected row, not resolved by choosing
the first record or inventing suffixes. Early-month order numbers require
carryover review. Original records and all exceptions stay in the audit.
"""
import argparse
from collections import Counter, defaultdict
import datetime as dt
import json
import re

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from reconcile_umatilla_season import BASE, DSN

ALIASES = {
    "SPI": "SIERRA PACIFIC INDUSTRIES - SPI",
    "NW": "NATIONWIDE TRANSPORT SERVICES, INC. +",
    "PLAT": "PLATEAU FOREST PRODUCTS, INC",
    "AARON": "Aaron Wilson Logistics",
    "TRADE": "TRADEWINDS BROKERAGE,INC.",
    "IOSCO": "IOSCO TRANSPORTATION,INC.",
    "ROS": "Rosboro Lumber Co",
    "HAM": "HAMMER LUMBER CO.",
    "MTG": "MULINO TRADING LLC +",
    "KOF": "King of Freight",
    "HART": "HARTMAN STEEL",
    "COT": "CENTRAL OREGON TRUCKING",
    "EAGLE": "EAGLE FOREST PRODUCTS",
    "OR": "OPEN ROAD TRANSPORTATION,INC.",
    # Cross-checked 2026-09-12 against the live "outside customer list" sheet
    # tab (BROKER_SHEET_URL, legacy/invoicing-local/index.html) — every one of
    # these codes is a shortening of a company already named in the same raw
    # text (e.g. "Harmer Steel Portland ... (HARM)"), not a blind guess.
    # Genuinely ambiguous codes (UTAH, WG, CENTRAL O — two plausible sheet
    # matches each) and person-name/internal-looking codes (NATE, MIKE, KEV,
    # KEVIN, DAN, TOM, JR) are deliberately left out, not guessed.
    "WITH": "Witham Family Transportation",
    "TRAD": "TRADEWINDS BROKERAGE,INC.",
    "OB": "OREGON BLOCK",
    "WSFP": "West Shore Forest Products",
    "RED": "REDMOND INDUSTRIES LLC +",
    "VAN": "Vanport Trucking",
    "RAIN": "RAINIER VENEER, INC",
    "RV": "RAINIER VENEER, INC",
    "RAI": "RAINIER VENEER, INC",
    "HARM": "Harmer Steel",
    "CLARK": "Clarkes Sheet Metal",
    "CLARKS": "Clarkes Sheet Metal",
    "CLARKE": "Clarkes Sheet Metal",
    "AARONW": "Aaron Wilson Logistics",
    "AW": "Aaron Wilson Logistics",
    "BOBM": "BOB MURRAY TRANSPORTATION",
    "BOB": "BOB MURRAY TRANSPORTATION",
    "MURRY": "BOB MURRAY TRANSPORTATION",
    "ALL": "All City Fence",
    "WW": "Wildwood Trading Group, Inc.",
    "PAR": "Parrott's Metal",
    "PARRIOT": "Parrott's Metal",
    "PAROT": "Parrott's Metal",
    "PARR": "Parrott's Metal",
    "BM": "BI-MART",
    "ARM": "ARMSTRONG TRANSPORT GROUP",
    "ORRD": "OPEN ROAD TRANSPORTATION,INC.",
    "STAL": "Stalwart Freight",
    "SMOKEY": "Smokey Mountain Logistics",
    "WEATH": "WEATHERLY'S INC.",
    "WEAT": "WEATHERLY'S INC.",
    "ORBLOCK": "OREGON BLOCK",
    "ORB": "OREGON BLOCK",
    "PP": "Portland Plate & Steel",
    "HAMP": "HAMPTON LUMBER",
    "TQL": "TOTAL QUALITY LOGISTICS",
    "OC": "Oregon Canadian",
    "AMOUTH": "AMOTH LOGISTICS LLC",
    "ALLTR": "Alltran Logistics",
    "CRAY": "C. Ray Trucking",
    "BR": "B&R RELIABLE TRANSPORTATION",
    "CTE": "CTE Logistics",
    "TRINTY": "Trinity Logistics",
    "ALLIANCE": "Alliance Trucking",
    "SCONN": "Shipping Connections",
    "SHIPC": "Shipping Connections",
    "WP": "Western Pneumatics",
    "A1": "A-1 FREIGHT SYSTEMS",
    "B2B": "Business to Business",
    "C2C": "Coast to Coast Logistics",
    "DL": "D&L TRANSPORT",
    "GREEN": "Green Line Brokerage",
    "GULIK": "Gulick Freight Service",
    "HAMM": "HAMMER LUMBER CO.",
    "HIGHR": "HIGH RISE LOGISTICS",
    "IP": "INTERNATIONAL PAPER",
    "LST": "LST Group",
    "MOD": "MODE Transport",
    "MURPH": "MURPHY CO.",
    "NATION": "NATIONWIDE TRANSPORT SERVICES, INC. +",
    "PACW": "Pacific West Lumber",
    "RR": "R&R EXPRESS LOGISTICS",
    "STAGE": "AMERICAN STAGECOACH, INC.",
    "PROD": "Prodigee Logistics",
    "AXEL": "AXLE LOGISTICS",
}


def norm(value):
    return re.sub(r"[^A-Z0-9]", "", value.upper())


def parse(text):
    short = re.match(r"^(\d{1,4})\s*(?=[A-Za-z])", text)
    if re.match(r"^\d{1,2}\s*(?:AM|PM)\b", text, re.I):
        short = None
    groups = list(re.finditer(r"\(([^()]*)\)", text))
    code = groups[0][1].strip() if groups else None
    tail = text[groups[0].end():].strip() if groups else ""
    ignored_date = None
    date = re.search(r"\s+(\d{1,2}/\d{1,2}(?:/\d{2,4})?)\s*$", tail)
    if date:
        ignored_date, tail = date[1], tail[:date.start()].strip()
    load = None
    if code and norm(code) == "SPI":
        if re.fullmatch(r"\d+(?:\s+\d+)*", tail):
            load = " ".join(tail.split())  # keep printed groups and leading zeros
    elif re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]*", tail) and re.search(r"\d", tail) and not re.fullmatch(r"\d{1,2}/\d{1,2}(?:/\d{2,4})?", tail):
        load = tail
    return {"short_order_number": short[1] if short else None,
            "broker_code": code, "load_number_candidate": load,
            "following_text": tail, "ignored_trailing_date": ignored_date}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        rows = conn.execute("""select * from orders where kind='external' and not is_transfer
            and custom->>'source' in ('sheet2025','sheet2026') order by delivered_at,id
            for update""").fetchall()
        parties = conn.execute("select id,name from parties where is_broker").fetchall()
        cfg = conn.execute("select external_pattern,external_department from order_number_settings where id=1").fetchone()
        if cfg != {"external_pattern": "12-{MM}{YY}-{####}", "external_department": "12"}:
            raise ValueError("Number settings differ from the confirmed format")
        def broker(code):
            if not code:
                return None
            key = norm(code)
            if key in ALIASES:
                matches = [p for p in parties if p["name"].strip().casefold() == ALIASES[key].casefold()]
            else:
                matches = [p for p in parties if norm(p["name"]) == key]
                if not matches and len(key) >= 4:
                    # Whole first words only: e.g. JENKS -> Jenks Trucking.
                    # HAM must not become either Hampton or Hammer.
                    matches = [p for p in parties if norm(p["name"].split()[0]) == key]
            return matches[0] if len(matches) == 1 else None
        plans, load_groups, order_groups = [], defaultdict(list), defaultdict(list)
        for row in rows:
            parsed = parse(row["custom"].get("raw") or row["notes"])
            party = broker(parsed["broker_code"])
            day = row["delivered_at"]
            candidate = (f"12-{day:%m%y}-{int(parsed['short_order_number']):04d}"
                         if day and parsed["short_order_number"] else None)
            item = {"before": row, "parsed": parsed, "broker": party,
                    "order_number_candidate": candidate, "issues": []}
            plans.append(item)
            if party and parsed["load_number_candidate"]:
                load_groups[(str(party["id"]), norm(parsed["load_number_candidate"]))].append(str(row["id"]))
            if candidate:
                order_groups[candidate].append(str(row["id"]))
        existing = conn.execute("select id,solomon_order_no,broker_party_id,broker_load_no from orders").fetchall()
        existing_orders = {r["solomon_order_no"]: str(r["id"]) for r in existing if r["solomon_order_no"]}
        existing_loads = defaultdict(set)
        for r in existing:
            if r["broker_party_id"] and r["broker_load_no"]:
                existing_loads[(str(r["broker_party_id"]), norm(r["broker_load_no"]))].add(str(r["id"]))
        changes = []
        for item in plans:
            row, parsed, party = item["before"], item["parsed"], item["broker"]
            oid = str(row["id"])
            load, number = parsed["load_number_candidate"], item["order_number_candidate"]
            issues = item["issues"]
            if not party:
                issues.append("broker_missing_or_unresolved")
                load = number = None
            if party and not load:
                issues.append("load_number_missing_or_ambiguous")
            if party and load:
                key = (str(party["id"]), norm(load))
                if len(load_groups[key]) > 1 or existing_loads[key] - {oid}:
                    issues.append("repeated_broker_load_number")
                    load = None
            if number and (len(order_groups[number]) > 1 or existing_orders.get(number, oid) != oid):
                issues.append("repeated_full_order_number")
                number = None
            if not parsed["short_order_number"]:
                issues.append("short_order_number_missing")
            for field, proposed in (("broker_party_id", party["id"] if party else None),
                                    ("broker_load_no", load), ("solomon_order_no", number)):
                if row[field] is not None and row[field] != proposed:
                    issues.append("existing_" + field + "_preserved")
            item["after"] = {"broker_party_id": row["broker_party_id"] or (party["id"] if party else None),
                             "broker_load_no": row["broker_load_no"] or load,
                             "solomon_order_no": row["solomon_order_no"] or number}
            item["metadata"] = {"rule": "external-identifiers-v1", **parsed,
                                "order_number_candidate": item["order_number_candidate"],
                                "issues": issues}
            if all(row[k] == v for k, v in item["after"].items()) and row["custom"].get("external_import_review") == item["metadata"]:
                continue
            changes.append(item)
        report = {"status": "preview", "changes": changes,
                  "issue_counts": dict(Counter(issue for p in plans for issue in p["issues"]))}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-external.json")
        path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        if args.commit:
            for item in changes:
                values = item["after"]
                conn.execute("""update orders set broker_party_id=%s,broker_load_no=%s,
                    solomon_order_no=%s, custom=custom || jsonb_build_object('external_import_review',%s::jsonb)
                    where id=%s""", (values["broker_party_id"], values["broker_load_no"],
                    values["solomon_order_no"], Jsonb(item["metadata"]), item["before"]["id"]))
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps(report, default=str, indent=2) + "\n")
        print(json.dumps({"status": report["status"], "changed": len(changes),
                          "broker_links": sum(bool(p["after"]["broker_party_id"]) for p in plans),
                          "load_numbers": sum(bool(p["after"]["broker_load_no"]) for p in plans),
                          "full_order_numbers": sum(bool(p["after"]["solomon_order_no"]) for p in plans),
                          "issues": report["issue_counts"], "report": str(path)}, indent=2))
        if not args.commit:
            conn.rollback()


if __name__ == "__main__":
    main()
