#!/usr/bin/env python3
"""Replace the Pick/Drop List test data with the real list from the future
TMS Google Sheet's "Pick/Drop List" tab, preview first.

Nate: "grab the pick and drop list from that and import it into this app to
replace the current test pick and drop list in the app which is just a copy
of the bag customers." The Pick/Drop List page is the same `locations`
table as Bagger Customers, just unfiltered by party_id (CLAUDE.md) — with
no real standalone rows yet (party_id is null) it looked identical to
Bagger Customers by coincidence, not because it IS Bagger Customers. The
only existing party_id-null row is seed.sql's synthetic "Bag Plant" test
fixture (uuid 22222222-...-205, unreferenced by any order/stop) — deleted
and superseded by the sheet's own "Rexius Bag Plant" entry.

Source: dispatcher sheet 1KlPQ... (the "future"/working TMS sheet), tab
"Pick/Drop List", read via the authenticated Sheets API (D257), same
service-account path `import_outside_customers.py` uses — not the public
unauthenticated gviz CSV export `legacy/invoicing-local/index.html`'s
BROKER_SHEET_URL relies on (that endpoint requires the sheet be link-public;
this script no longer needs that).
Columns: App? | Company Name | Address | City | State | Phone Number |
Dropdown List (the last is a derived display string, not imported).

Usage:
  DEPT12_SHEETS_CREDS=secrets/dept-12-dash-....json \
    python3 scripts/import_pickdrop_list.py [--commit]
"""
import argparse
import json
import os
import sys

import psycopg
from psycopg.rows import dict_row

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))

from adapters import GoogleSheetsSync

from reconcile_umatilla_season import DSN

SHEET_ID = "1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4"
TAB = "Pick/Drop List"
TEST_ROW_ID = "22222222-2222-2222-2222-222222222205"  # seed.sql's placeholder "Bag Plant"


def fetch_rows(sheets):
    values = sheets.read_range(f"'{TAB}'!A:G")
    out = []
    for row in values[1:]:  # skip header
        name = (row[1] if len(row) > 1 else "").strip()
        if not name:
            continue
        out.append({
            "appointment_note": (row[0] if len(row) > 0 else "").strip() or None,
            "name": name,
            "address": (row[2] if len(row) > 2 else "").strip() or None,
            "city": (row[3] if len(row) > 3 else "").strip().rstrip(",").strip() or None,
            "state": (row[4] if len(row) > 4 else "").strip() or None,
            "phone": (row[5] if len(row) > 5 else "").strip() or None,
        })
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    creds = os.environ.get("DEPT12_SHEETS_CREDS")
    if not creds:
        sys.exit("Set DEPT12_SHEETS_CREDS to the service-account JSON path.")
    sheets = GoogleSheetsSync(creds, SHEET_ID)
    rows = fetch_rows(sheets)
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        test_row = conn.execute("select id, name from locations where id=%s and party_id is null",
                                 (TEST_ROW_ID,)).fetchone()
        refs = conn.execute("""
            select
                (select count(*) from orders where pickup_location_id=%s or delivery_location_id=%s) as orders,
                (select count(*) from order_stops where location_id=%s) as order_stops,
                (select count(*) from load_stops where location_id=%s) as load_stops
        """, (TEST_ROW_ID, TEST_ROW_ID, TEST_ROW_ID, TEST_ROW_ID)).fetchone()
        other_null = conn.execute("select count(*) as n from locations where party_id is null and id != %s",
                                   (TEST_ROW_ID,)).fetchone()["n"]

        report = {
            "status": "preview", "sheet_rows": len(rows),
            "test_row_found": bool(test_row), "test_row_referenced": any(refs.values()) if refs else False,
            "other_existing_pickdrop_rows": other_null,
            "sample": rows[:5],
        }
        if other_null:
            report["warning"] = ("Found other party_id-null rows besides the known test fixture — "
                                  "not deleting those automatically, review manually.")

        if args.commit:
            if refs and any(refs.values()):
                raise ValueError(f"Test 'Bag Plant' row is referenced ({dict(refs)}); not deleting")
            if test_row:
                conn.execute("delete from locations where id=%s", (TEST_ROW_ID,))
            for row in rows:
                conn.execute("""insert into locations (name, address, city, state, phone, appointment_note)
                                 values (%(name)s,%(address)s,%(city)s,%(state)s,%(phone)s,%(appointment_note)s)""",
                             row)
            conn.commit()
            report["status"] = "committed"
            report["deleted_test_row"] = bool(test_row)
            report["inserted"] = len(rows)
        else:
            conn.rollback()
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
