#!/usr/bin/env python3
"""
One-time backfill: set `locations.category_id` (the Designation dropdown,
D72) for every Bagger Customer from the real Early/Anytime/Umatilla column
on the live Bagger Customers tab (future TMS, 1KlPQ...).

Why this is needed: `scripts/import_bagger_customers.py` already keeps
`timing_window`/`is_umatilla` in sync with this same column, but `category_id`
didn't exist yet when that script was written (categories/Designation landed
later, D65/D72) so it was never backfilled — nearly every location's
Designation was blank even though the underlying Early/Anytime/Umatilla data
was there all along.

Reads the sheet directly (not the already-imported timing_window/is_umatilla)
so this reflects whatever is live right now, same parse rule as the importer:
"Umatilla" in the cell -> is_umatilla; "Early" in the cell -> early, else
anytime (blank cell -> no designation, leaves category_id untouched).

Only UPDATEs `locations.category_id` for parties that already exist in
Postgres (matched by case-insensitive name) — does not create or otherwise
edit parties/locations. Sheet names with no matching party, and DB bagger
customers with no matching sheet row, are both reported and left alone.

Usage:
    DEPT12_SHEETS_CREDS=secrets/<file>.json python3 scripts/designate_bagger_customers.py [--dry-run]
"""

import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))

import psycopg
from psycopg.rows import dict_row
from adapters import GoogleSheetsSync

DISPATCHER_SHEET_ID = "1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4"
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")

CATEGORY_NAMES = {
    (False, "early"): "Early store",
    (False, "anytime"): "Anytime store",
    (True, "early"): "Umatilla early",
    (True, "anytime"): "Umatilla anytime",
}


def parse_timing(raw):
    raw = (raw or "").strip()
    if not raw:
        return None
    is_umatilla = "Umatilla" in raw
    base = "early" if "Early" in raw else "anytime"
    return (is_umatilla, base)


def main():
    dry_run = "--dry-run" in sys.argv
    creds = os.environ.get("DEPT12_SHEETS_CREDS")
    if not creds:
        sys.exit("Set DEPT12_SHEETS_CREDS to the service-account key path first.")

    sheets = GoogleSheetsSync(creds, DISPATCHER_SHEET_ID)
    rows = sheets.read_range("Bagger Customers!A2:F500")

    conn = psycopg.connect(DSN, row_factory=dict_row, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("select id, name from categories")
        cat_by_name = {r["name"]: r["id"] for r in cur.fetchall()}
        for needed in CATEGORY_NAMES.values():
            if needed not in cat_by_name:
                sys.exit(f"Missing expected category {needed!r} — create it first.")

        cur.execute("""
            select p.id as party_id, p.name, l.id as loc_id, l.category_id
            from parties p join locations l on l.party_id = p.id
            where p.is_customer
        """)
        db_by_name = {r["name"].strip().lower(): r for r in cur.fetchall()}

        seen = set()
        updated, unchanged, blank, unmatched = 0, 0, 0, []
        for r in rows:
            name = (r[0] if r else "").strip()
            if not name or name.upper().startswith("NO DELIVERY"):
                continue
            key = name.lower()
            parsed = parse_timing(r[5] if len(r) > 5 else "")
            match = db_by_name.get(key)
            if not match:
                unmatched.append(name)
                continue
            seen.add(key)
            if parsed is None:
                blank += 1
                continue
            target_id = cat_by_name[CATEGORY_NAMES[parsed]]
            if match["category_id"] == target_id:
                unchanged += 1
                continue
            updated += 1
            if not dry_run:
                cur.execute("update locations set category_id = %s where id = %s",
                            (target_id, match["loc_id"]))

        missing_in_sheet = [r["name"] for k, r in db_by_name.items() if k not in seen]

    print(f"{'[dry-run] ' if dry_run else ''}updated={updated} unchanged={unchanged} "
          f"blank_in_sheet={blank} sheet_rows_with_no_db_match={len(unmatched)} "
          f"db_customers_with_no_sheet_row={len(missing_in_sheet)}")
    if unmatched:
        print("\nSheet names with no matching party (not touched):")
        for n in unmatched:
            print(" -", n)
    if missing_in_sheet:
        print("\nDB bagger customers with no matching sheet row (not touched):")
        for n in missing_in_sheet:
            print(" -", n)


if __name__ == "__main__":
    main()
