#!/usr/bin/env python3
"""Convert genuinely-unmatchable imported orders to plain schedule text, dry-run first.

Nate (2026-09-12): "make the shit plain text on the scheduler and say fuck
it, i can still search by number and once i give u documents to match u can
do the same thing and create loads from the docs if u need." Applies to any
imported external order with no broker match and any imported internal order
with no customer match — after reconcile_external_orders.py /
reconcile_internal_orders.py / add_new_brokers.py / reconcile_lignetics.py
have already run, so this only catches what's genuinely left unmatchable
(a one-off local carrier, a person's name, a code with no plausible
directory match), not something that could still be resolved.

Deliberately excludes:
  - is_transfer orders (already correctly classified, not part of this).
  - Any row still flagged repeated_full_order_number /
    repeated_broker_load_number — Nate is working through
    duplicate_order_numbers.csv by hand; those rows DO have a matched
    broker/customer, they're just held on a number collision, so converting
    them to text now would destroy the match and the CSV he's mid-review on.

The original text (raw sheet text for external, notes for internal) is
preserved verbatim as the schedule_notes body, so it stays searchable and
re-derivable once real rate-con/POD documents are matched later.
"""
import argparse
import datetime as dt
import json

import psycopg
from psycopg.rows import dict_row

from reconcile_umatilla_season import BASE, DSN


def candidates(conn):
    ext = conn.execute("""select * from orders where kind='external' and not is_transfer
        and broker_party_id is null and custom->>'source' in ('sheet2025','sheet2026')
        and not (custom->'external_import_review'->'issues' ? 'repeated_full_order_number')
        and not (custom->'external_import_review'->'issues' ? 'repeated_broker_load_number')
        order by delivered_at for update""").fetchall()
    intl = conn.execute("""select * from orders where kind='internal'
        and customer_party_id is null and custom->>'source' in ('sheet2025','sheet2026')
        and not (custom->'internal_import_review'->'issues' ? 'repeated_full_order_number')
        order by delivered_at for update""").fetchall()
    return ext, intl


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        ext, intl = candidates(conn)
        plans, deletes, held = [], [], []
        for row in ext + intl:
            text = (row["custom"].get("raw") if row["kind"] == "external" else None) or row["notes"] or ""
            loads = conn.execute("""select l.*, (select count(*) from load_orders x where x.load_id=l.id) as n
                from loads l join load_orders lo on lo.load_id=l.id
                where lo.order_id=%s for update of l""", (row["id"],)).fetchall()
            if len(loads) != 1 or loads[0]["n"] != 1:
                held.append({"order_id": str(row["id"]), "kind": row["kind"], "notes": row["notes"],
                             "reason": "not a standalone single-order trip"})
                continue
            if not text.strip():
                # Nothing to preserve — a genuinely blank imported cell (D65-
                # style), not a "shit data" edge case. Delete outright, same
                # as the Cascade Cannabis "can get wiped" precedent, rather
                # than writing an empty schedule_notes row.
                deletes.append({"order": row, "load": loads[0]})
                continue
            plans.append({"order": row, "load": loads[0], "text": text})
        report = {"status": "preview", "external_candidates": len(ext), "internal_candidates": len(intl),
                  "converting": len(plans), "deleting_blank": len(deletes), "held": held}
        folder = BASE / "output" / "import-review"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-unmatched-to-notes.json")
        path.write_text(json.dumps({**report, "plans": plans, "deletes": deletes}, default=str, indent=2) + "\n")
        if args.commit:
            for p in plans:
                order, load = p["order"], p["load"]
                # Some imported (truck,date,slot) keys are genuinely doubled up
                # (two loads landed on one sheet cell at import) — not something
                # to fix here, just don't lose either note's text when that
                # happens to be exactly the cell this conversion targets.
                conn.execute("""insert into schedule_notes (truck_id, scheduled_date, slot, body)
                    values (%s,%s,%s,%s)
                    on conflict (truck_id, scheduled_date, slot)
                    do update set body = schedule_notes.body || ' / ' || excluded.body""",
                    (load["truck_id"], load["scheduled_date"], load["slot"], p["text"]))
                conn.execute("delete from load_orders where load_id=%s", (load["id"],))
                conn.execute("delete from loads where id=%s", (load["id"],))
                conn.execute("delete from orders where id=%s", (order["id"],))
            for d in deletes:
                conn.execute("delete from load_orders where load_id=%s", (d["load"]["id"],))
                conn.execute("delete from loads where id=%s", (d["load"]["id"],))
                conn.execute("delete from orders where id=%s", (d["order"]["id"],))
            conn.commit()
            report["status"] = "committed"
            path.write_text(json.dumps({**report, "plans": plans, "deletes": deletes}, default=str, indent=2) + "\n")
        else:
            conn.rollback()
        print(json.dumps({"status": report["status"], "external_candidates": len(ext),
                          "internal_candidates": len(intl), "converted": len(plans),
                          "deleted_blank": len(deletes),
                          "held_count": len(held), "held_sample": held[:10], "report": str(path)}, indent=2))


if __name__ == "__main__":
    main()
