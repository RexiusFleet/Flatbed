#!/usr/bin/env python3
"""Add brokers present in the live "outside customer list" Google Sheet tab
but missing from the local parties table, preview first.

Nate: "u probably need to pull the new outside customer list from the future
tms google sheet" — the dispatcher sheet's "outside customer list" tab
(same one legacy/invoicing-local/index.html already reads for rate-con broker
matching) has grown since the local parties table was last populated from it.
Comparing the two by normalized name finds real new entries only — punctuation/
suffix variants of an already-local broker (", INC.", " ++", trailing spaces)
are not new and are left alone.

Source: dispatcher sheet 1KlPQ..., tab "outside customer list", col A = name,
col C = AP email — read via the authenticated Sheets API (D257), same
service-account path `import_outside_customers.py` already uses, not the
public unauthenticated gviz CSV export `legacy/invoicing-local/index.html`'s
BROKER_SHEET_URL relies on (that endpoint requires the sheet be link-public;
this script no longer needs that).

Usage:
  DEPT12_SHEETS_CREDS=secrets/dept-12-dash-....json \
    python3 scripts/add_new_brokers.py [--commit]
"""
import argparse
import json
import os
import re
import sys

import psycopg
from psycopg.rows import dict_row

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))

from adapters import GoogleSheetsSync

from reconcile_umatilla_season import DSN

SHEET_ID = "1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4"
TAB = "outside customer list"


def norm(name):
    return re.sub(r"[^A-Z0-9]", "", name.upper())


def fetch_sheet_rows(sheets):
    values = sheets.read_range(f"'{TAB}'!A:C")
    out = []
    for row in values[1:]:  # skip header
        name = (row[0] if len(row) > 0 else "").strip()
        email = (row[2] if len(row) > 2 else "").strip()
        if name:
            out.append((name, email))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()
    creds = os.environ.get("DEPT12_SHEETS_CREDS")
    if not creds:
        sys.exit("Set DEPT12_SHEETS_CREDS to the service-account JSON path.")
    sheets = GoogleSheetsSync(creds, SHEET_ID)
    sheet_rows = fetch_sheet_rows(sheets)
    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        existing = conn.execute("select name from parties where is_broker").fetchall()
        existing_norm = {norm(r["name"]) for r in existing}
        new_rows = [(name, email) for name, email in sheet_rows if norm(name) not in existing_norm]
        print(json.dumps({"sheet_rows": len(sheet_rows), "already_local": len(sheet_rows) - len(new_rows),
                          "new": [{"name": n, "ap_email": e} for n, e in new_rows]}, indent=2))
        if args.commit:
            for name, email in new_rows:
                conn.execute("insert into parties (name, is_broker, ap_email) values (%s, true, %s)",
                             (name, email or None))
            conn.commit()
            print(json.dumps({"status": "committed", "inserted": len(new_rows)}))
        else:
            print(json.dumps({"status": "dry-run"}))


if __name__ == "__main__":
    main()
