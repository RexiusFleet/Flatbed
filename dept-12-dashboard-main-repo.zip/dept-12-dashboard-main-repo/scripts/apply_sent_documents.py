#!/usr/bin/env python3
"""Split the scanned "Sent - 2026" PDFs into per-document files, preview first.

Reads output/sent-2026/plan.json (built by plan_sent_documents.py, itself
read-only) and, for every document identified inside every source PDF,
extracts that document's exact pages into its own PDF.

A group plan_sent_documents.py matched to a real order gets filed the same
way a normal upload would (api_save_document in server.py): one `documents`
row, file under app/storage/<order_id>/, match_method always
'document_text' — the match came from a printed order/load number read off
the page via OCR, not a structured field or the filename.

A group that couldn't be matched does NOT go into `documents` at all (Nate,
2026-09-14: "we cant have 512 in the billing queue... if they arent able to
be matched they cant clutter the app") — its split pages instead land under
output/sent-2026/unmatched-review/<source stem>/, a plain local folder Nate
can browse outside the app, untouched by anything Billing shows.

Idempotent both ways: a matched document's extracted_fields carries
{sent2026_sha256, sent2026_pages}, checked against already-inserted rows
before creating a duplicate; an unmatched document is skipped if its review
file already exists. Re-running after extending plan_sent_documents.py's
matching only files/writes what's new — including recovering a document
that used to be unmatched and is now confidently matched (it's inserted into
`documents` for the first time; its stale copy under unmatched-review/, if
any, is removed so it doesn't look filed twice).
"""
import argparse
import json
import os
import shutil
import uuid
from pathlib import Path

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from pypdf import PdfReader, PdfWriter

from reconcile_umatilla_season import BASE, DSN

SOURCE_DIR = BASE / "Sent - 2026"
OUT = BASE / "output" / "sent-2026"
STORAGE_ROOT = BASE / "app" / "storage"
REVIEW_ROOT = OUT / "unmatched-review"


def safe_name(name):
    return "".join(c if c.isalnum() or c in " ._-" else "_" for c in name).strip()


def extract_pages(reader, pages):
    writer = PdfWriter()
    for p in pages:
        writer.add_page(reader.pages[p - 1])
    return writer


def page_tag(pages):
    return f"p{pages[0]}" if len(pages) == 1 else f"p{pages[0]}-{pages[-1]}"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--commit", action="store_true")
    args = ap.parse_args()

    plan = json.loads((OUT / "plan.json").read_text())
    groups = plan["groups"]

    with psycopg.connect(DSN, row_factory=dict_row) as conn:
        conn.execute("set transaction isolation level serializable")
        existing = {(r["extracted_fields"].get("sent2026_sha256"),
                     tuple(r["extracted_fields"].get("sent2026_pages") or []))
                    for r in conn.execute(
                        "select extracted_fields from documents where extracted_fields ? 'sent2026_sha256'")}
        valid_orders = {str(r["id"]) for r in conn.execute("select id from orders")}

        to_file, to_review, skipped_stale, skipped_dup = [], [], [], []
        reader_cache = {}
        for g in groups:
            order_id = g["order_id"]
            if order_id and order_id not in valid_orders:
                skipped_stale.append(g)
                continue
            if g["source"] not in reader_cache:
                try:
                    reader_cache[g["source"]] = PdfReader(SOURCE_DIR / g["source"])
                except Exception as exc:
                    skipped_stale.append({**g, "error": str(exc)})
                    continue
            stem = safe_name(Path(g["source"]).stem)
            for doc in g["documents"]:
                if order_id:
                    key = (g["source_sha256"], tuple(doc["pages"]))
                    if key in existing:
                        skipped_dup.append({"source": g["source"], "pages": doc["pages"]})
                        continue
                    to_file.append({"group": g, "doc": doc, "order_id": order_id})
                else:
                    review_path = REVIEW_ROOT / stem / f"{doc['doc_type']}_{page_tag(doc['pages'])}.pdf"
                    if review_path.exists():
                        skipped_dup.append({"source": g["source"], "pages": doc["pages"]})
                        continue
                    to_review.append({"group": g, "doc": doc, "path": review_path})

        report = {
            "status": "preview", "ocr_pages": plan["ocr_pages"],
            "pending_files": plan["pending_files"], "total_groups": len(groups),
            "matched_groups": sum(bool(g["order_id"]) for g in groups),
            "documents_to_matched_orders": len(to_file),
            "documents_to_review_folder": len(to_review),
            "already_filed_or_reviewed_skipped": len(skipped_dup),
            "stale_order_or_unreadable_skipped": len(skipped_stale),
            "doc_type_breakdown": {},
        }
        for p in to_file + to_review:
            report["doc_type_breakdown"][p["doc"]["doc_type"]] = \
                report["doc_type_breakdown"].get(p["doc"]["doc_type"], 0) + 1

        if args.commit:
            filed = []
            for p in to_file:
                g, doc, order_id = p["group"], p["doc"], p["order_id"]
                reader = reader_cache[g["source"]]
                writer = extract_pages(reader, doc["pages"])
                doc_id = str(uuid.uuid4())
                stem = safe_name(Path(g["source"]).stem)
                filename = f"{doc_id}_{doc['doc_type']}_{stem}_{page_tag(doc['pages'])}.pdf"
                folder = STORAGE_ROOT / order_id
                folder.mkdir(parents=True, exist_ok=True)
                with open(folder / filename, "wb") as f:
                    writer.write(f)
                storage_path = os.path.join(order_id, filename)
                extracted = {
                    "sent2026_source": g["source"], "sent2026_sha256": g["source_sha256"],
                    "sent2026_pages": doc["pages"], "sent2026_reason": g["reason"],
                    "sent2026_evidence": g["evidence"],
                }
                row = conn.execute("""
                    insert into documents (id, order_id, doc_type, storage_path, original_filename,
                                           extracted_fields, matched_by, matched_at)
                    values (%s,%s,%s,%s,%s,%s,'document_text', now())
                    returning id
                """, (doc_id, order_id, doc["doc_type"], storage_path, filename,
                      Jsonb(extracted))).fetchone()
                filed.append({"id": str(row["id"]), "order_id": order_id, "doc_type": doc["doc_type"],
                              "source": g["source"], "pages": doc["pages"]})
                # A document that used to sit unmatched and is now confidently
                # matched shouldn't also linger in the review folder.
                stale = REVIEW_ROOT / stem / f"{doc['doc_type']}_{page_tag(doc['pages'])}.pdf"
                if stale.exists():
                    stale.unlink()
            conn.commit()
            report["status"] = "committed"
            report["filed"] = len(filed)
            (OUT / "applied.json").write_text(json.dumps(filed, indent=2))

            reviewed = []
            for p in to_review:
                g, doc, path = p["group"], p["doc"], p["path"]
                reader = reader_cache[g["source"]]
                writer = extract_pages(reader, doc["pages"])
                path.parent.mkdir(parents=True, exist_ok=True)
                with open(path, "wb") as f:
                    writer.write(f)
                reviewed.append({"path": str(path.relative_to(OUT)), "doc_type": doc["doc_type"],
                                  "source": g["source"], "pages": doc["pages"], "reason": g["reason"]})
            report["reviewed"] = len(reviewed)
            (OUT / "review-index.json").write_text(json.dumps(reviewed, indent=2))
        else:
            conn.rollback()

        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
