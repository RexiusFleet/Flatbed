#!/usr/bin/env python3
"""
One-time import: the real Bagger Customers tab (future TMS, 1KlPQ...) into
`parties` + `locations`.

This is deliberately a script, not a seed.sql insert — seed.sql is synthetic
test data checked into git (see its header comment), and this tab is real
customer data (names, phone numbers, manager names, addresses). It never
touches source control; it goes straight into the local Postgres database.

Column layout (confirmed by reading the live tab, D36):
  A Customer  B Address  C City  D State  E Forklift  F Early/Anytime
  G Notes     H LOAD CHIPS (derived, skipped)  I Phone  J Manager Name
  K Email     L Miles from Coburg  M Miles from Umatilla  N Map

Idempotent by customer name: re-running updates the existing party/location
instead of creating duplicates (parties.name has a case-insensitive unique
index already; locations doesn't, so this script looks the row up itself).

Usage:
    DEPT12_SHEETS_CREDS=secrets/<file>.json python3 scripts/import_bagger_customers.py
"""

import os
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE, "app"))

import psycopg
from psycopg.rows import dict_row
from adapters import GoogleSheetsSync

DISPATCHER_SHEET_ID = "1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4"
DSN = os.environ.get("DEPT12_DSN", "dbname=dept12 host=/tmp")

FORKLIFT_MAP = {"Forklift": "forklift", "NF": "NF", "Spyder Only": "spyder"}


def parse_timing(raw):
    raw = (raw or "").strip()
    is_umatilla = "Umatilla" in raw
    if "Early" in raw:
        base = "early"
    elif raw:
        base = "anytime"
    else:
        base = None
    return base, is_umatilla


def num(s):
    s = (s or "").strip()
    return float(s) if s else None


def main():
    creds = os.environ.get("DEPT12_SHEETS_CREDS")
    if not creds:
        sys.exit("Set DEPT12_SHEETS_CREDS to the service-account key path first.")

    sheets = GoogleSheetsSync(creds, DISPATCHER_SHEET_ID)
    rows = sheets.read_range("Bagger Customers!A2:N500")

    conn = psycopg.connect(DSN, row_factory=dict_row, autocommit=True)
    inserted, updated, skipped = 0, 0, 0

    with conn.cursor() as cur:
        for r in rows:
            r = r + [""] * (14 - len(r))  # pad short rows
            name = r[0].strip()
            if not name or name.upper().startswith("NO DELIVERY"):
                skipped += 1
                continue

            address, city, state = r[1].strip(), r[2].strip(), r[3].strip()
            forklift = FORKLIFT_MAP.get(r[4].strip())
            timing_window, is_umatilla = parse_timing(r[5])
            notes = r[6].strip() or None
            phone = r[8].strip() or None
            manager_name = r[9].strip() or None
            email = r[10].strip() or None
            miles_coburg = num(r[11])
            miles_umatilla = num(r[12])
            map_url = r[13].strip() or None

            cur.execute("select id from parties where lower(name) = lower(%s)", (name,))
            existing = cur.fetchone()
            if existing:
                party_id = existing["id"]
                cur.execute("update parties set is_customer = true where id = %s", (party_id,))
            else:
                cur.execute(
                    "insert into parties (name, is_customer) values (%s, true) returning id",
                    (name,))
                party_id = cur.fetchone()["id"]

            cur.execute("select id from locations where party_id = %s", (party_id,))
            loc = cur.fetchone()
            fields = dict(
                name=name, address=address, city=city, state=state,
                forklift=forklift, timing_window=timing_window, is_umatilla=is_umatilla,
                notes=notes, phone=phone, email=email,
                standard_miles=miles_coburg, miles_from_umatilla=miles_umatilla,
                map_url=map_url,
            )
            if loc:
                cur.execute("""
                    update locations set name=%(name)s, address=%(address)s, city=%(city)s,
                        state=%(state)s, forklift=%(forklift)s, timing_window=%(timing_window)s,
                        is_umatilla=%(is_umatilla)s, notes=%(notes)s, phone=%(phone)s,
                        email=%(email)s, standard_miles=%(standard_miles)s,
                        miles_from_umatilla=%(miles_from_umatilla)s, map_url=%(map_url)s
                    where id = %(id)s
                """, {**fields, "id": loc["id"]})
                updated += 1
            else:
                cur.execute("""
                    insert into locations (party_id, name, address, city, state, forklift,
                        timing_window, is_umatilla, notes, phone, email, standard_miles,
                        miles_from_umatilla, map_url)
                    values (%(party_id)s, %(name)s, %(address)s, %(city)s, %(state)s,
                        %(forklift)s, %(timing_window)s, %(is_umatilla)s, %(notes)s, %(phone)s,
                        %(email)s, %(standard_miles)s, %(miles_from_umatilla)s, %(map_url)s)
                """, {**fields, "party_id": party_id})
                inserted += 1

    print(f"inserted={inserted} updated={updated} skipped={skipped} total_rows={len(rows)}")


if __name__ == "__main__":
    main()
