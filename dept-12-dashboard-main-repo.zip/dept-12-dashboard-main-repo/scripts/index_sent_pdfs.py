#!/usr/bin/env python3
"""Read-only page/text inventory for the local Sent - 2026 PDF batch."""
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import warnings

from pypdf import PdfReader

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "output" / "sent-2026"


def inspect(path):
    raw = path.read_bytes()
    result = {"filename": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
              "bytes": len(raw), "pages": []}
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            reader = PdfReader(path)
            for i, page in enumerate(reader.pages):
                result["pages"].append({"page": i + 1, "text": page.extract_text() or "",
                                        "size": [float(v) for v in page.mediabox],
                                        "rotation": page.rotation})
    except Exception as exc:
        result["error"] = str(exc)
    return result


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    files = sorted((BASE / "Sent - 2026").glob("*.pdf"))
    with ProcessPoolExecutor(max_workers=3) as pool:
        records = list(pool.map(inspect, files))
    (OUT / "inventory.json").write_text(json.dumps(records, indent=2))
    pages = [p for f in records for p in f["pages"]]
    print(json.dumps({"files": len(records), "pages": len(pages),
                      "low_text_pages": sum(len(p["text"].strip()) < 80 for p in pages),
                      "errors": [f["filename"] for f in records if "error" in f]}))
