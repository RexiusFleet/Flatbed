(function () {
  "use strict";

  var client = null;
  var sdkPromise = null;
  var authSubscription = null;

  function config() {
    return window.DEPT12_AUTH_CONFIG || {};
  }

  function isConfigured() {
    var c = config();
    return c.enabled === true &&
      /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(c.supabaseUrl || "") &&
      /^(sb_publishable_|eyJ)/.test(c.publishableKey || "");
  }

  function callbackUrl() {
    /* Microsoft/Azure rejects 127.0.0.1 as a local redirect hostname. */
    if (window.location.hostname === "127.0.0.1") {
      return "http://localhost:" + window.location.port + window.location.pathname;
    }
    return window.location.origin + window.location.pathname;
  }

  /* Cookie storage is shared by localhost ports 8780 and 8770. In production,
     serve both surfaces on one host or set the same parent cookieDomain. */
  function cookieStorage() {
    var maxChunk = 3000;
    function map() {
      var out = {};
      (document.cookie || "").split(";").forEach(function (part) {
        var i = part.indexOf("=");
        if (i >= 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1));
      });
      return out;
    }
    function attrs(maxAge) {
      var s = "; Path=/; SameSite=Lax; Max-Age=" + maxAge;
      if (config().cookieDomain) s += "; Domain=" + config().cookieDomain;
      if (location.protocol === "https:") s += "; Secure";
      return s;
    }
    function remove(name) {
      var values = map(), count = parseInt(values[name + ".count"] || "0", 10) || 0;
      document.cookie = encodeURIComponent(name) + "=" + attrs(0);
      document.cookie = encodeURIComponent(name + ".count") + "=" + attrs(0);
      for (var i = 0; i < Math.max(count, 8); i++)
        document.cookie = encodeURIComponent(name + "." + i) + "=" + attrs(0);
    }
    return {
      getItem: function (name) {
        var values = map(), count = parseInt(values[name + ".count"] || "0", 10) || 0;
        if (!count) return values[name] || null;
        var value = "";
        for (var i = 0; i < count; i++) value += values[name + "." + i] || "";
        return value || null;
      },
      setItem: function (name, value) {
        remove(name);
        var chunks = [];
        for (var i = 0; i < value.length; i += maxChunk) chunks.push(value.slice(i, i + maxChunk));
        document.cookie = encodeURIComponent(name + ".count") + "=" + chunks.length + attrs(2592000);
        chunks.forEach(function (chunk, idx) {
          document.cookie = encodeURIComponent(name + "." + idx) + "=" + encodeURIComponent(chunk) + attrs(2592000);
        });
      },
      removeItem: remove
    };
  }

  function loadSdk() {
    if (window.supabase && window.supabase.createClient) return Promise.resolve(window.supabase);
    if (sdkPromise) return sdkPromise;

    sdkPromise = new Promise(function (resolve, reject) {
      var script = document.createElement("script");
      script.src = config().sdkUrl;
      script.async = true;
      script.crossOrigin = "anonymous";
      script.onload = function () {
        if (window.supabase && window.supabase.createClient) resolve(window.supabase);
        else reject(new Error("The Supabase client library did not initialize."));
      };
      script.onerror = function () {
        reject(new Error("The Supabase client library could not be loaded."));
      };
      document.head.appendChild(script);
    });

    return sdkPromise;
  }

  function getClient() {
    if (!isConfigured()) return Promise.resolve(null);
    if (client) return Promise.resolve(client);

    return loadSdk().then(function (sdk) {
      var c = config();
      client = sdk.createClient(c.supabaseUrl, c.publishableKey, {
        auth: {
          flowType: "pkce",
          autoRefreshToken: true,
          persistSession: true,
          detectSessionInUrl: false,
          storageKey: c.storageKey,
          storage: cookieStorage()
        }
      });
      return client;
    });
  }

  function exchangeCallbackCode(authClient) {
    var params = new URLSearchParams(window.location.search);
    var code = params.get("code");
    if (!code) return Promise.resolve(null);

    return authClient.auth.exchangeCodeForSession(code).then(function (result) {
      if (result.error) throw result.error;

      params.delete("code");
      var cleanQuery = params.toString();
      window.history.replaceState({}, document.title,
        window.location.pathname + (cleanQuery ? "?" + cleanQuery : "") + window.location.hash);
      return result.data.session;
    });
  }

  function initialize(handlers) {
    handlers = handlers || {};
    if (!isConfigured()) return Promise.resolve({ configured: false, session: null });

    return getClient().then(function (authClient) {
      var listener = authClient.auth.onAuthStateChange(function (event, session) {
        if (event === "SIGNED_IN" && session && handlers.onSignedIn) {
          handlers.onSignedIn(session.user, session);
        }
        if (event === "SIGNED_OUT" && handlers.onSignedOut) handlers.onSignedOut();
      });
      authSubscription = listener.data.subscription;

      return exchangeCallbackCode(authClient).then(function (callbackSession) {
        if (callbackSession) return callbackSession;
        return authClient.auth.getSession().then(function (result) {
          if (result.error) throw result.error;
          return result.data.session;
        });
      }).then(function (session) {
        if (session && handlers.onSignedIn) handlers.onSignedIn(session.user, session);
        return { configured: true, session: session };
      });
    }).catch(function (error) {
      if (handlers.onError) handlers.onError(error);
      return { configured: true, session: null, error: error };
    });
  }

  function signInWithMicrosoft() {
    if (!isConfigured()) return Promise.resolve({ configured: false });

    return getClient().then(function (authClient) {
      return authClient.auth.signInWithOAuth({
        provider: "azure",
        options: {
          scopes: "email",
          redirectTo: callbackUrl()
        }
      });
    }).then(function (result) {
      if (result.error) throw result.error;
      return { configured: true, data: result.data };
    });
  }

  function signOut() {
    return getClient().then(function (authClient) {
      if (!authClient) return { configured: false };
      return authClient.auth.signOut().then(function (result) {
        if (result.error) throw result.error;
        return { configured: true };
      });
    });
  }

  function destroy() {
    if (authSubscription) authSubscription.unsubscribe();
    authSubscription = null;
  }

  window.Dept12Auth = Object.freeze({
    initialize: initialize,
    isConfigured: isConfigured,
    signInWithMicrosoft: signInWithMicrosoft,
    signOut: signOut,
    destroy: destroy
  });
})();
