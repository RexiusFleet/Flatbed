# Dept 12 login scaffold

The login page is ready for Supabase Auth with Microsoft Entra ID (the provider
name used by Supabase is `azure`). It is deliberately disabled and makes no
Supabase or CDN requests in its current state.

## What is already implemented

- Lazy loading of `@supabase/supabase-js` v2
- A PKCE browser client with persisted sessions and automatic token refresh
- Microsoft OAuth with the required `email` scope
- OAuth code exchange on return to this page
- Existing-session recovery and auth-state subscription
- Sign-out support for the dashboard to call later
- Redirect to the dashboard after a successful session
- A hard configuration guard that keeps the scaffold offline

## Values to add later

Edit `supabase-config.js` and provide only the project's public browser values:

```js
enabled: true,
supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
publishableKey: "sb_publishable_YOUR_KEY"
```

Never add the Supabase `service_role` key or the Microsoft client secret to a
browser file.

## Supabase / Microsoft setup still required

1. Register the app in Microsoft Entra ID.
2. Give the Entra app this Web redirect URI:
   `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`
3. Enable the Azure provider in Supabase Auth and add the Entra client ID,
   client secret, and tenant URL there.
4. Add the login page URL to Supabase Auth's redirect allow list. For local
   development use `http://localhost:8780/` (Azure does not accept
   `127.0.0.1` as a local redirect hostname).
5. Add the public Supabase values to `supabase-config.js` and set `enabled` to
   `true`.
6. Protect the dashboard server/API and connect its sign-out control. This is
   intentionally not done yet.

The standalone login server remains:

```bash
python3 -m http.server 8780 --bind 127.0.0.1 --directory login
```
