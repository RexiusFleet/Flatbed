/*
 * Dormant authentication configuration.
 *
 * This file intentionally contains no live project values. Authentication
 * remains completely offline until `enabled` is changed to true AND the two
 * public Supabase values below are supplied.
 *
 * The publishable key is designed for browser use. Never put a service_role
 * key, Azure client secret, or any other private credential in this file.
 */
window.DEPT12_AUTH_CONFIG = Object.freeze({
  enabled: false,
  supabaseUrl: "",
  publishableKey: "",
  postSignInUrl: "http://localhost:8770/",
  storageKey: "dept12-auth",
  cookieDomain: "",
  sdkUrl: "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"
});
