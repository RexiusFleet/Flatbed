(function () {
  /* PKCE stores its verifier per origin. Keep local development on localhost,
     which Microsoft accepts, instead of beginning on 127.0.0.1 and returning
     to a different storage origin. */
  if (window.location.hostname === "127.0.0.1") {
    window.location.replace("http://localhost:" + window.location.port +
      window.location.pathname + window.location.search + window.location.hash);
    return;
  }

  var button = document.getElementById("microsoft-signin");
  var status = document.getElementById("auth-status");
  var statusCopy = status.querySelector("span:last-child");

  function showStatus(title, message, isError) {
    status.hidden = false;
    status.classList.toggle("error", !!isError);
    statusCopy.innerHTML = "";

    var heading = document.createElement("b");
    heading.textContent = title;
    statusCopy.appendChild(heading);
    statusCopy.appendChild(document.createTextNode(message));
  }

  function setBusy(busy) {
    button.disabled = busy;
    button.querySelector("span:nth-child(2)").textContent = busy
      ? "Opening Microsoft…"
      : "Continue with Microsoft";
  }

  function postSignInDestination() {
    var fallback = new URL(window.DEPT12_AUTH_CONFIG.postSignInUrl, window.location.href);
    var requested = new URLSearchParams(window.location.search).get("returnTo");
    if (!requested) return fallback.href;
    try {
      var target = new URL(requested);
      return target.origin === fallback.origin ? target.href : fallback.href;
    } catch (e) {
      return fallback.href;
    }
  }

  button.addEventListener("click", function () {
    setBusy(true);
    window.Dept12Auth.signInWithMicrosoft().then(function (result) {
      if (result && result.configured === false) {
        showStatus(
          "Authentication isn’t connected yet.",
          " Add the Supabase project URL and publishable key, then enable auth in supabase-config.js.",
          false
        );
        setBusy(false);
      }
    }).catch(function (error) {
      showStatus("Couldn’t start sign-in.", " " + error.message, true);
      setBusy(false);
    });
  });

  window.Dept12Auth.initialize({
    onSignedIn: function () {
      window.location.replace(postSignInDestination());
    },
    onError: function (error) {
      showStatus("Couldn’t complete sign-in.", " " + error.message, true);
      setBusy(false);
    }
  });
})();
