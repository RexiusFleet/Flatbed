# Rexius Bag Orders Portal

## Purpose

Provide a temporary, driver-facing web app for Umatilla/East bag orders without
using Google Drive. The portal is a separate web app and local host from the
Dept 12 dashboard, but it uses the dashboard's normal Postgres order records
and normal document storage. There is no East-only document lane.

The portal is expected to operate for roughly one year for two or three drivers.
It is intentionally isolated so it can be disabled and removed without changing
the permanent order, customer, POD, or billing records. Its visibility scope is
Umatilla now and can later be changed to all bag customers without changing the
upload, signature, completion, or document workflow.

## Source-of-truth rule

An order is eligible for the portal when all of these are true:

- it is a bag order (`orders.kind = 'internal'` and not an Internal Freight transfer);
- its delivery location has `locations.is_umatilla = true`;
- an unsigned `delivery_receipt` PDF is attached to the order;
- the order is still open (`ordered`, `released`, or `scheduled`); and
- no Bag Orders completion exists for the order.

The existing `is_umatilla` field deliberately covers both Umatilla Early and
Umatilla Anytime. Customer names and designation labels are never hard-coded.

Uploading the unsigned receipt is the publish action. There is no additional
publish queue, checkbox, or Google Drive folder.

## Dispatcher workflow

1. Create or open the Bag Order in the dashboard.
2. Print/export its unsigned delivery receipt as a PDF.
3. Drop that PDF into the order's normal **Documents** box. On a Bag Order, an
   unsigned PDF that is not clearly named as a POD, invoice, or rate confirmation
   is stored as the ordinary delivery-receipt document type. A descriptive
   "delivery receipt" filename is still preferred, but it is not required.
4. The order immediately appears in the separate Rexius Bag Orders web app.
5. The dashboard continues to hold the original unsigned receipt after delivery.

## Driver workflow

1. Open Rexius Bag Orders from the iPad Home Screen.
2. Select a ready order from the shared East Side queue.
3. Review the PDF, draw the customer signature, and optionally add a note.
4. Tap **Sign & Complete**, enter the truck number, and submit.

## Completion workflow

The portal server:

1. verifies that the order is still eligible;
2. saves the flattened signed PDF as an ordinary `pod` document in the same
   document list as the unsigned receipt;
3. records the source receipt, submitted truck number, note, and completion time;
4. marks the order delivered;
5. removes it from the ready queue; and
6. sends the signed PDF to the configured notification address.

The document/database write is authoritative. Locally, email is attempted
immediately after that write. Before hosted activation, this becomes the hidden,
durable server-side outbox in `supabase-server-port-plan.md`, so a restart cannot
lose the final email. It still adds no dashboard status or driver-facing UI.

## Local development layout

- Dashboard test host: `http://127.0.0.1:8775`
- Rexius Bag Orders: `http://127.0.0.1:8785`
- Both point to the isolated `dept12_east_test` database for the demo.
- The portal uses the dashboard's existing local/Supabase storage adapter shape.
- Local email defaults to writing an `.eml` file to a test outbox. SMTP can be
  enabled with environment settings when real credentials are available.

## Temporary boundary

All portal-specific routes and browser files live under `east_portal/`. The only
permanent dashboard change is an explicit, generic delivery-receipt document type
recognized by the existing order document drop box. At retirement, disable the
portal host and revoke its access; the original receipts and signed PODs remain
ordinary order documents.

## Hosted activation

Rexius Bag Orders is a required part of the dashboard's Supabase/server port,
not a later add-on. It will keep its own HTTPS web-app host while sharing the
dashboard's Supabase Postgres database and private `documents` bucket. The full
connection map, security work, migration order, acceptance gates, rollback, and
one-year retirement plan are in
[`supabase-server-port-plan.md`](supabase-server-port-plan.md).

The portal must not be made internet-accessible until the plan's server-only
database access, private Storage, tablet device gate, idempotent completion, and
automatic-mail requirements pass in staging.
