# Phase 0 — Freshness Check

**Run:** 2026-08-04 · **Outcome:** cleared to proceed, with two caveats below.

CLAUDE.md Phase 0 requires pulling the live version of each codebase, diffing it
against the curated local copy, and reporting discrepancies *before* planning.
This is that report.

---

## 1. TMS Apps Script — current, safe to trust

| Check | Result |
|---|---|
| Local `HEAD` | `f69f0b4` (2026-06-24) |
| `origin/main` | `f69f0b4` — identical |
| Unpushed commits | 0 |
| Stashes | 0 |
| Uncommitted changes | none (excluding `.DS_Store`) |
| Branches on GitHub | `main` only — no abandoned branches |

No divergence. The curated copy was already the live code.

Imported to `legacy/tms-appsscript/`. `NateTooNice/SHEETS-TMS-APPSCRIPT` stays on
GitHub untouched as the historical archive — this repo has fresh history by
design, so those 40+ commits live there, not here.

## 2. Invoice automation — **no repo existed**

`gh repo list NateTooNice` returns only `SHEETS-TMS-APPSCRIPT`,
`freight-rate-calculator`, and `storeimages`. The `fb invoicing app/` folder had
**no `.git` and no remote**. There was nothing to pull and nothing to diff.

**The curated local copy was the only copy of this code in existence, and it was
unbacked.** It is now committed verbatim as `9fb9ea6`, the first commit in this
repo, made before any reorganization.

This is a genuine deviation from what CLAUDE.md assumed (two repos to pull), and
it inverts the risk: the concern was staleness, but the actual exposure was total
loss.

---

## Caveat A — GitHub is not the live Apps Script code

Deployment is one-way: `legacy/tms-appsscript/.github/workflows/deploy.yml` runs
`clasp push --force` on every push to `main`. Nothing pulls the other direction,
so **any edit made in the Apps Script web editor is invisible to git.**

Confirmed instance of this drift:

> `legacy/invoicing-appsscript/appsscript.json` declares `"dependencies": {}`,
> but `Code.js:120` calls `Drive.Files.insert(...)` for OCR, and the file's own
> setup comment (`Code.js:1-4`) instructs you to add **Drive API v2** by hand in
> the editor.

The deployed script therefore has an advanced service enabled that the committed
manifest does not record. The manifest in this repo is provably incomplete.

**Action, deferred to Phase 3:** run `clasp pull` against both script IDs and
diff against `legacy/`. Not a blocker for Phase 1 or 2 — neither phase depends on
manifest accuracy. It becomes blocking the moment anything is pushed back.

Script IDs:
- TMS — `1CpJeAMukE5rseJwV13FfDfqX1eEkzWAjKW3NogqcbTGZAjSZePGP09ke`
- Invoicing — `1wTYhPSy1KJUe_2SsLnltWpXktsLzfN8XRRn1e7xjn9_Syg9iahIKE7_T`

## Caveat B — auto-deploy is intentionally disabled in this repo

The deploy workflow moved *with* its code to
`legacy/tms-appsscript/.github/workflows/deploy.yml`. GitHub only executes
workflows at the repository root, so it is now inert.

This is deliberate. A `clasp push --force` from this repo's root would push the
wrong tree to the live script. Re-enabling deployment is a Phase 3 decision, made
consciously.

---

## Findings that changed the plan

Recorded here because they are not obvious from either CLAUDE.md.

**There are two Sheets, and only one is driver-facing.** `1KlPQ…` is the
dispatcher's working sheet; `15f12…` is the read-only **mirror** the 8 tablets
read. The "Sheet ID must not change" golden rule applies to the mirror. This
narrows the hard constraint considerably.

**The mirror is already a pure projection.** `updateDriverTabs`
(`tms-appsscript/Code.js:774`) and `pushSheetToMirror` (`:104`) delete and rebuild
each driver tab on every run. It is already a stateless render target — so
"Supabase is the source of truth, the Sheet is an I/O adapter" is a swap of what
feeds the existing renderer, not a rewrite of it.

**The two tools already share a data source.** The invoicing app's
`BROKER_SHEET_ID` (`invoicing-appsscript/Code.js:8`) *is* the TMS sheet, reading
its `outside customer list` tab. The consolidation seam already exists.

**Driver and truck are separate things the Sheet conflates.** Column headers are
strings like `"Jordan 63/80 F"`, and there is a *Swap Trucks Between Drivers*
feature. A driver's truck changes over time and the Sheet has nowhere to record
that — so historical reporting silently attributes past loads to today's truck.
This is precisely the structural limit the project exists to escape.

**Three identifiers, not one.** `12-xxxx-xxxx` is the **Solomon** internal
billing order number (Solomon being the ERP that Acumatica will replace, which
makes this the eventual ERP join key). The rate con carries the **broker's own**
load number. Independent namespaces. The canonical Solomon regex
`/\d{2}-\d{4}-\d{4}/` already exists in the TMS code at `Code.js:517` and
`Code.js:876` — reuse it rather than reinventing it.

---

## Reference values recovered

CLAUDE.md's "Reference Info" section has `<PASTE>` placeholders. Filled from the
code:

| Field | Value |
|---|---|
| TMS Sheet ID (dispatcher working sheet) | `1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4` |
| Mirror Sheet ID (**driver-facing, must not change**) | `15f12Q0Nz4NFNUwbtQ7NgE7eCwSfqx3ai0VJAeZjtKJs` |
| Extraction logic | `legacy/invoicing-local/index.html` — `parseRateCon:2404`, `extractInvoiceInfo:1738`, `findBroker:1512`, `matchBrokerForFile:1567`, `normBroker:1500`, `GENERIC_SET:1539` |
| Store image database | `NateTooNice/storeimages` (~300 MB, files like `BM 601.png`) — referenced by URL, never vendored |
| Driver tablets | 8, shared account |
