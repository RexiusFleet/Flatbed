# Documentation archive

Completed point-in-time reports live here. They are retained for historical
context but are not current operating instructions.

- [`phase-0-freshness.md`](phase-0-freshness.md) — repository freshness audit
  completed on 2026-08-04.
