# Decision Log — Archive (D214–D249)

Older decisions preserved from the working log. Decisions D1–D124 are in [`decisions-archive.md`](decisions-archive.md); D125–D213 are in [`decisions-archive-125-213.md`](decisions-archive-125-213.md); the newest active decisions and open items are in [`decisions.md`](decisions.md).

### D214 — Up/Down cycles nav sections, mirroring Left/Right's sub-cycling (2026-09-11)

Nate: *"can we add up and down arrows when nothing is selected as a way to
cycle through sections in the nav? like if i go left right it uses those
arrows but up and down takes me section to section."*

`cycleNavSection(delta)` (`01-core.js`) walks `NAV` in its existing render
order (Dispatch → Orders → Billing → Reports → Database), skipping any
section with nothing visible to a restricted user
(`navVisibleSections()` — same skip rule `navMenuHtml` already uses for
Database). Landing sub is resolved the same way the sidebar's own
collapsed-icon click already does — `navSectionLandingSub`/
`databaseLandingSub` — so cycling into a section shows its current or
last-visited sub, not always the first one. `navArrowShortcutAvailable`
(D209) took an `axis` param so Up/Down shares every existing guard
Left/Right already had (no active cell/range/row selection, no focused
input/textarea/select, no open modal/menu/drawer, no conflicting
`KEYMAP` binding, mobile nav closed) rather than duplicating the check
with a gap. One `keydown` listener now handles all four arrow keys.

Verified live: ArrowDown from Scheduler stepped Dispatch → Bag Orders →
Billing → Export & Reports → Bagger Customers → back to Scheduler
(wraps both ends); ArrowUp from Scheduler wrapped straight to Database's
last-visited sub. Both directions work identically with the sidebar
collapsed (icon rail), and Left/Right's existing subsection cycling
(including Database's own tab bar) is unaffected. No console errors.

This is presentation/navigation only. Order actions, filtering, data,
APIs, schema, permissions, migrations, and Supabase behavior are
unchanged; the production feature baseline advances to D214.

### D215 — Repository housekeeping separates active work from historical material (2026-09-11)

The completed Phase 0 freshness report moved under `docs/archive/`, and the
three superseded dashboard prototypes moved under `legacy/prototypes/`. They
remain versioned and recoverable but no longer look like active implementation
surfaces. The working decision log again retains only the newest five decisions
and active open items; D125–D210 moved into a second range-labeled archive.

The empty migration `.gitkeep`, generated render output, Python bytecode, and
macOS metadata were removed. The ignore rules now cover the whole temporary
output directory. An unused alternate logo moved to `legacy/assets/`; an unused
logo that was byte-identical to `app/web/rexius-logo.png` was removed. Active
application code, immutable migrations, legacy source references, test fixtures,
the local document store, secrets, and real business data were not changed.

### D216 — Settings consolidates account access and uses one polished interaction system (2026-09-11)

Settings → General now combines profile, appearance, account status, Outlook,
and Scheduler sizing. The old density choice is retired; comfortable spacing is
the baseline and Scheduler dimensions remain directly adjustable. Font selection
uses a native dropdown with a generic sample load. Accent selection leads with
ten unlabeled visual presets, while a collapsed Custom color control supports a
guarded color well, hex entry, and up to 12 saved custom colors. Presets and
duplicate saved colors cannot be saved again. Accent text color is calculated
automatically, and colors that do not remain visible in both base themes are
rejected.

The admin-only tab is labeled Access and is linked from the administrator's
Account card. It remains backed by the existing `admin` route/sub-key and the
same View/Edit and Scheduler-window permission APIs; this is a clearer entry
point, not a permissions-model change.

Settings uses a two-column area grid: Theme and Outlook stack beside the taller
Accent card, with Typography and Account paired below. Inputs, dropdowns, and
buttons share a 36px control baseline; profile Save aligns with Display name,
focus matches Search, and the font dropdown arrow has a consistent inset.

The app shell now uses shared motion durations and a single restrained easing
curve. Menus, popovers, content changes, modals, the document viewer, drawer,
navigation, staging rail, History panel, toasts, and control press/hover feedback
use that system. Reduced-motion still disables all animation and transition.
No business data, APIs, schema, permission semantics, or Supabase behavior changed.

### D217 — Numbering is configurable and Help/Shortcuts reflect the live app (2026-09-11)

Order numbers are no longer treated as storage for order type, department, or
Bag Order month. The current formats remain the defaults, but administrators can
enter a different pattern in Settings → General. `{MM}`, `{YY}`, and `{YYYY}`
place optional date parts, and one run of `#` characters places the sequential
number anywhere in the pattern. Bulk reservation still accepts month, year,
starting number, and quantity; an advisory transaction lock prevents overlapping
ranges when two reservations happen together.

`orders.order_period` now owns Bag Order month/year grouping. The former generated
`department` field is ordinary stored data, populated from the active Bag or
External department setting for new numbers. The migration backfills these fields
without changing `solomon_order_no`; the pre/post checksum for all 210 local orders
matched exactly. Historical numbers remain editable but are never rewritten by a
format change. The reporting view was rebuilt against the independent department
field, and the migration is safe to reapply.

Settings subsections use the in-page Settings tab strip. The Shortcuts page
retains re-record/reset controls and adds a flow for assigning additional key
combinations to any supported action; these extra shortcuts are per-device like the
existing bindings. Help & FAQ was rewritten against the current Scheduler, order,
document, billing, database, sync, Settings/Access, History, and report behavior.

### D218 — Settings and Profile live in a dedicated navigation footer (2026-09-11)

Settings no longer appears as a work-navigation section, and Profile no longer
occupies the header. A divider at the bottom of the sidebar separates these
account controls from Dispatch, Orders, Billing, Reports, and Database. The
expanded sidebar presents the Settings gear and Profile side by side; the
collapsed rail stacks the gear above the profile avatar. The profile menu opens
upward from its new anchor and no longer duplicates the Settings destination.

The gear opens Settings → General directly. General, Shortcuts, Time Calc, and
admin-only Access now cycle through an in-page horizontal tab strip matching
Database's established navigation pattern. The settings tab list still passes
through the existing permission filter, so this shell change does not grant a
restricted account any new page access. The Settings symbol uses a toothed gear
outline rather than the prior radial mark, which read visually as a sun.

This is a navigation and presentation change only. Account permissions, profile
data, settings storage, business data, APIs, schema, migrations, and Supabase
behavior are unchanged; the production feature baseline advances to D218.

### D219 — Scheduler right-click menu: color removed, truck-off works on the selection (2026-09-11)

Nate: *"the scheduler right click menu is way outdated and broken set color
can go away cause i can paint bukcet color in if i want, and mark truck off
doesnt work, it should mark the truck off for the day or for the selected
cells whicher i have selected if i dont have it selected its the day im
right clicking in."*

**"Set color…" removed.** It opened a category-swatch popover
(`openPalette`, D66) that duplicated the toolbar's own paint-bucket Fill
button (`openSheetsPicker`, `11-toolbar.js`) — a different, more capable
color picker Nate already uses. `openPalette`/`colorCells` had no other
caller, so both were deleted outright rather than left dead; the `.palette`/
`.pal-sw`/`.pal-dot` CSS rules that only ever styled that popover's markup
went with them. `setCellColor` (the underlying per-cell primitive, still
used by clear/paste-restore) is untouched.

**"Mark/Clear truck off" was hard-wired to the single right-clicked cell's
own truck+day** — `truckOffToggle(truckId, ds)` never looked at the
marquee/multi-selection at all, unlike "Set color…" right next to it, which
already ran through `selectedKeys(key)` to apply to a selection. That
asymmetry is what read as "doesn't work": selecting several cells and
choosing Mark truck off only ever affected the one cell under the cursor.
Fixed by routing it through the same `selectedKeys(key)` helper, then
`truckOffPairsFor(keys)` collapsing the result to its distinct (truck, day)
pairs (a marquee can span multiple slot rows on one truck-day, multiple
trucks, and/or multiple days) and `setTruckOffMany` applying one state to
all of them as a single undo step. The right-clicked cell's own current
off state still decides the direction (mark vs. clear) applied to the
whole set, matching how the removed color action used to work.

Verified live: right-click a lone cell with nothing selected → "Mark truck
off" hatches only that truck's day, and a second right-click correctly
offers "Clear truck off"; a real marquee drag (synthetic `pointerdown`/
`pointermove`/`pointerup`, matching the app's actual pixel-box hit-testing)
across three different trucks' chips on the same day, then "Mark truck
off" from within that selection, hatched all three in one action
(confirmed 3 `truck_off_days` rows written) and a single Cmd-Z removed all
three together. No console errors. "Set color…" no longer appears in the
menu on either a chip or an empty cell.

This is presentation/interaction only. Cell coloring via the toolbar,
order data, scheduling, APIs, schema, and Supabase behavior are unchanged;
the production feature baseline advances to D219.

### D220 — Full 2025/2026 schedule reimport, replacing the Dec-2025 trial (2026-09-11)

Nate provided a freshly-downloaded, updated "Flatbed Master Schedule.xlsx"
(same file the D65 backfill used, now carrying a second tab, "Master
Schedule 2026") and asked to wipe all current order/scheduler data and
reimport both years from it, asking edge-case questions along the way
rather than guessing. His answers, verbatim:

1. *"yes wipe them"* — the 74 non-imported live orders already in the app
   (mixed test/real-looking data from earlier sessions, Feb–Sep 2026) get
   wiped along with everything else, not preserved.
2. *"bag plant to umatilla is a bagger load. the only clean data in the
   2026 tab is from january to septemeber 14 if theres anything after that
   dont import it cause its not clean."*
3. *"we dont care about colors on import we have our own color rules here
   inside the dashboard so just find the driver and reassign the color to
   the driver it was driven by just like our app would here. and the
   bagger customer orders you will be able to identify by looking at the
   load info, assign them based on designation early anytime etc."*
4. *"yes i think if im understanding correctly. im bringing the data from
   a downloaded sheet export and we will begin using this dashboard to
   test before i import it into supabase. we have documents to import as
   well but not yet... it will likely just be for 2026 and it will only be
   for external freight."*

**Pre-flight.** Took a full `pg_dump` before touching anything
(`output/backups/`, now gitignored — found `output/` had been untracked
but NOT ignored, a real gap against the "no real business data in git"
golden rule, fixed regardless of this import). Found and fixed a latent
crash in the existing `import_2025_schedule.py`: it read
`cat_id["Off"]`, and the `categories` table no longer has an "Off" row
(D72/D94 moved chip color to the Bagger Customer designation model,
leaving only the four store-timing categories) — the live app's own
`api_truck_off` already handles this with a `.get()`-style lookup, so the
script now matches it instead of throwing on the first off-day cell.

**New script, one per source (matching the existing
import_bagger_customers.py/import_outside_customers.py convention):**
`scripts/import_2026_schedule.py`, sharing every parsing primitive with
the 2025 script via import rather than duplicating them, tagging
`custom->>'source'='sheet2026'`, scoped to real 2026 dates up to
`--today` (run with `--today 2026-09-14` per Nate's cutoff, not the
system date).

**Business-rule fixes applied to both scripts** (answers 2–3 above):
- `is_internal` now also true whenever the cell's category is "Bag
  plant" (previously only store-timing colors or a matched customer
  counted) — "Bag Plant to Umatilla Yard #__" and similar lanes (168 in
  2025, 101 in 2026) are bagger loads, not a dept-to-dept Internal
  Freight transfer and not external.
- Sheet fill colors are no longer written to `loads.category_id` at all
  (internal or external) — Nate doesn't want the sheet's ad-hoc legend
  imported as data. Internal loads land uncategorized; he'll assign each
  matched Bagger Customer's real designation by hand from the raw lane
  text preserved in `notes`. External loads get `pushed_at` set at
  insert so they immediately pick up the truck's current driver color
  through the app's own existing mechanism (`pushColorFor`,
  `02-chips-extract.js`) — no new coloring logic, "just like our app
  would."
- `orders.department`/`order_period` (D217) are now populated at insert
  — a real gap found live after the first commit: `order_period` is what
  the Bag Orders month-tab actually groups on now (not the order number,
  which these rows never had), so without it every imported internal
  order was invisible in all twelve month tabs despite existing and
  rendering fine on the Scheduler. `department` reads the *live*
  `order_number_settings` default per kind rather than hardcoding
  `'07'`/`'12'`.
- `buildChip` (02-chips-extract.js) gained `isSheetImport(o)` — matches
  `sheet2025` *or* `sheet2026` — for the raw-lane-text chip fallback
  only. The narrower `isHistorical(o)` (`sheet2025` exactly) still gates
  the four places that exclude rows from the working Orders grids and
  the biller queue: 2026 stays fully visible/editable there on purpose
  (Nate's answer 4 — it's meant to become a normal, billable, eventually
  document-matched dataset, unlike 2025's permanent read-only history).

**Wipe, then commit.** `invoices` (3 rows — identical `created_at`
timestamp and sequential `55555555…`/`11111111…` UUIDs, unmistakably
leftover `seed.sql`-style fixtures, not real billing history), `loads`,
`orders`, and `truck_off_days` deleted first (that order, to clear the
`RESTRICT` FKs before touching `orders`); confirmed all four at 0 before
importing. `import_2025_schedule.py --commit --reset` (full calendar
year, not just the old Dec trial) then `import_2026_schedule.py --commit
--reset --today 2026-09-14` — 2335 loads (1117 internal / 1218 external,
288 off-days) and 2026 loads (1119 internal / 907 external, 145
off-days) respectively. ~30 new fill colors in the 2026 tab (new
lanes/customers not in the 2025 legend) were left uncategorized per the
"we don't care about colors" answer — logged for Nate as an FYI, not a
blocker.

Verified live: Scheduler shows real lane text with distinct per-truck
driver coloring across both years; External Orders tracker shows exactly
the 907 2026 external rows (2025's 1218 correctly stay hidden); Bag
Orders tracker's January and Off-Season tabs both populate with real
rows, several already carrying a Time Window from customers that matched
existing Bagger Customers by name; no console errors. Re-ran the wipe +
both imports a second time after the `order_period`/`department` fix
landed, since the first commit predated it.

This changes local data only — no schema, API, or Supabase behavior
changed; `docs/schema.md`'s shape is unaffected. The production feature
baseline advances to D220.

### D221 — Schedule import accuracy review: confirmed meanings (2026-09-12, in progress)

Nate clarified the source notation and superseded D220's Umatilla mapping:

- In a bag order such as `23/12`, the left number is the order number and
  the right number is the pallet count. The order month may differ from
  the scheduled month. Preserve the original number; do not reinterpret
  it as quantity, discard it, or invent a date suffix to avoid collisions.
  Nate will help resolve chronology and duplicate-order exceptions before
  full order identifiers are assigned.
- Bag Plant to Umatilla belongs in **Internal Freight**, credited to
  **Bagger - 07**, in the applicable year. This explicitly replaces the
  bag-order classification recorded in D220.
- Count these loads by season, preserve existing load numbers, and number
  unnumbered loads without a January reset. Nate clarified that the run
  normally starts in November and ends the following March. Its identifier
  is the starting year: fall 2025 into 2026 is the 2025–26 season. The
  early-2025 run belongs to 2024 and is outside this correction's focus.
- Nate clarified that the repeated December entries are **real separate
  trips whose labels were copied without changing numbers**. Keep every
  trip with its recorded truck/date; never collapse them by source number.
  Nate also explicitly included the October and late-spring entries in
  the 2025 season. November–March is descriptive, not a hard cutoff.
- This confirmation concerns the Umatilla route. Other routes mentioning
  Bag Plant still need their own classification; do not apply a blanket
  transfer rule merely because Bag Plant appears in the text.

Read-only inspection found repeated Umatilla load numbers and numbering
that spans years, resolved as above. Broader source-cell reconciliation and
other route classifications remain open; this is not a completed reimport.

Added nullable `orders.transfer_season`, restricted to transfers, with an
editable Season start field in the tracker/drawer. Season-assigned transfers
use the starting year in the Internal Freight filter; other transfers retain
calendar-year behavior. Explicitly seasoned 2025 history is visible in this
tracker. Actual schedule dates and source numbering are unchanged. A local
database backup was taken before applying the additive migration.

Applied the confirmed outbound Bag Plant → Umatilla correction with
`scripts/reconcile_umatilla_season.py`: every qualifying existing trip is
now Internal Freight, season 2025, credited to Bagger - 07. Repeated source
numbers are retained and flagged in `custom.season_review`; every actual
trip remains counted. Unnumbered trips receive consecutive numbers after
the highest existing season number, with original notes retained in custom
metadata. Missing sequence values never create synthetic trips. The
ignored `output/import-review/` reports retain each original order/load.

Verified seasonal grouping and 2025 visibility, calendar-year fallback,
database constraint rejection/acceptance in a rolled-back transaction,
unchanged checksums for all out-of-scope orders and every load's id/date/
truck/slot, and zero changes on a repeat dry run. Restarted localhost 8770
and verified the season count and corrected department/dates in the live
Internal Freight grid. The early-2025 transfer run remains unchanged.

**Follow-up confirmations and corrections.** Nate included Umatilla → Bag
Plant returns and direct Valley AG → Umatilla deliveries in the same season
and Bagger department. Applied these with `--related-routes`, preserving all
placements and earlier season corrections, and continuing added labels after
the existing maximum. The mixed Valley AG/Teufel/Umatilla/North End Boise
entry is specifically a Northend Organics bag customer order, not a transfer.

Nate confirmed Load/Deliver instructions are notes, even when preceded by a
time or short order number; Labor Day and admin text are also not loads.
`reconcile_schedule_notes.py` converts these in place to `schedule_notes`,
preserving body/truck/date/slot. Vertically spelled LABOR and DAY are recognized
only when both words occur on the same source date; standalone grid markers
also become notes. Original order/load/link records are retained in the audit.
The correction refuses shared loads, existing note conflicts, documents,
invoices, stop records, and full order numbers. Unrelated order/load checksums
and every new note's exact text and placement were verified before commit.

`reconcile_bag_customers.py` maps BM DC to the existing Bi-Mart DC customer
and North End to the confirmed Northend Organics customer (created with its
name and customer role only). It fills pallet counts from the first reviewed
order/pallet pair, preserving trailing date annotations and six-digit customer
references separately in `custom.bag_import_review`. Source order numbers are
retained as short numbers. Actual order months remain pending; existing
provisional import periods are not evidence of the true month. The Northend
month question is open. All source notes and truck/date placements were kept.
Both corrections passed zero-change repeat previews. Fresh local backups
preceded these corrections.

Nate also confirmed actual external entries use a leading short order number,
parenthesized broker/customer code, and following broker load number; future
paperwork should match by PO/load number. External number reconstruction and
broker-code resolution remain open. In particular, source codes can match
duplicate directory entries (e.g. Tradewinds), and spaced SPI identifiers plus
trailing date annotations need explicit interpretation. Do not fuzzy-assign
ambiguous brokers or fabricate full order identifiers from schedule dates.

Nate explicitly clarified that import completion means structured customer,
order-number, broker-load-number and pallet data throughout the app, not
merely readable scheduler chips. Audit confirmed the reviewed bag customer/
pallet mappings are real order fields, but imported full Solomon order
numbers and external broker/load-number fields are still unpopulated. These
remain required work; do not describe the overall import as complete.
For the SPI example ending in `9/11`, Nate said to ignore that trailing
date-like token, not incorporate it into the broker load number. Preserve
original source text. Before populating external broker/load pairs, check
the existing unique pair constraint and resolve repeated source identifiers
without deleting real trips or inventing disambiguating suffixes.

**Continued (2026-09-12).** Ran `reconcile_external_orders.py --commit`:
772 brokers linked, 706 broker load numbers, 465 full order numbers
(`12-{MM}{YY}-{####}`), nothing overwritten. Nate then confirmed 8 more
broker codes by exact party name — ROS→Rosboro Lumber Co, HAM→HAMMER
LUMBER CO., MTG→MULINO TRADING LLC +, KOF→King of Freight, HART→HARTMAN
STEEL, COT→CENTRAL OREGON TRUCKING, EAGLE→EAGLE FOREST PRODUCTS (not Eagle
Rock Freight, the other directory entry with "Eagle" in the name),
OR→OPEN ROAD TRANSPORTATION,INC. (his own hedge: "probably"). Added to
`ALIASES`; also confirmed to stop holding first-week-of-month entries for
separate carryover review ("try to assign the numbers by month they are in
and then if u see dupes let me know and ill correct them") — that hold was
removed from the script; the existing repeated-number check still holds
any genuine collision it produces instead of guessing. Re-ran with
`--commit`: 859 brokers, 771 load numbers, 676 full order numbers.

New `scripts/reconcile_internal_orders.py` does the equivalent for Bag
Orders — full order number (`07-{MM}{YY}-{####}`) from the same
order/pallet notation, plus a second pass Nate asked for in the same
message ("make sure we match customers too cuz there are a lot of orders
on there they have customer profiles that are easy to match but arent
matched yet"): brand+store-number pairing, tolerant of the sheet's
punctuation and abbreviations (`BI-M`→`BI-MART`) and of the directory
carrying an extra descriptive word the sheet omits (`HI-SCHOOL #1164`
matches `HI-SCHOOL PHARMACY #1164` via containment, not exact equality) —
only applied when exactly one candidate matches. Same collision-holding
model as external. `--commit`: 369 new customer matches (1392→1761 total),
1950 pallet counts, 1669 full order numbers, out of 2182 internal orders.

Verified live: External Orders and Bag Orders trackers show real broker
names, order numbers, and pallet counts; no console errors.

**Held for Nate, not guessed:** 341 rows across three conflict types (25
external full-order-number collisions, 35 external broker-load-number
collisions, 281 internal full-order-number collisions) — genuine
same-candidate collisions between different real trips, matching the
same "real separate trips, don't collapse them" pattern already
established for the December duplicates. Resolving these automatically
would mean guessing which of two-plus real trips gets the number, so per
Nate's instruction ("hold onto those dupes and ill manually confirm them
in list format") they're sent as `duplicate_order_numbers.csv` (kind,
conflict type, candidate, date, raw text, truck) for him to resolve in
one pass; nothing in this file has been assigned anything yet.

Still open: 807 external + 513 internal orders have no order number yet
(external: 624 have no broker resolved at all, so no number was
attempted; the rest are the 25 held collisions above or genuinely have no
leading short number in the source text — `short_order_number_missing`,
not a bug, just source rows that never carried one; internal: 281 held
collisions + 232 with no order/pallet notation at all). Broker resolution
for the long tail of one-off codes (BI, WITH, RED, WSFP, OB, MAT, WS,
RAIN, RV, SPECIALTY, VAN, HARM, ALL, WW, BOB M, and others) remains open
per Nate: "not sure on the others i would need to see the order."

**Continued (2026-09-12, review of the `short_order_number_missing`
internal rows).** Nate reviewed a sample and gave four fixed dispositions,
applied by the one-time `scripts/reconcile_yard1_transfers.py` (matched
by literal row id, not a re-runnable pattern): "Cascade Valley Cannabis BK
TLR SPYD" (2025-02-13) deleted outright ("can get wiped"); the two bare
"AM SULF" rows converted to `schedule_notes` cells (kept as a reminder,
not a real order); and 13 rows — every "Stutzman/Marion AG ... to Yard
#1..." variant (8), "Columbia Carb. Woodland to Yard #1" (1), and every
"Ultra Block Vancouver to the Rexius Yard #1" (4) — reclassified from Bag
Order to Internal Freight transfer against the existing "Yard 1 - 03"
department, same shape as the Bagger-Umatilla move above. Note: one
Ultra Block row, "37 Ultra Block Linnton Portland to Kipco Springfield
(VAN) 34616" (2026-06-17), goes to Kipco, not Yard #1 — left untouched;
`(VAN)` is already in the still-open broker-code list above, so this may
turn into a real external order once VAN is resolved, not a Yard 1
transfer.

**Sheet-import chip fallback fixed to check resolution, not just source
(2026-09-12).** `buildChip` (`02-chips-extract.js`) was showing a sheet-
imported row's raw note text forever, even after the reconciliation
scripts above filled in a real broker or customer — the fallback keyed
purely on `custom.source`, which reconciliation never clears. New
`sheetImportUnresolved(o)` only takes the raw-text path while the row is
still actually unmatched (`!broker_party_id` for external, non-transfer;
`!customer_party_id` for internal); a transfer is excluded since it
already renders its own "Internal Freight · department" line. A matched
external row now shows broker/load#/order# like any normal order (route
still reads "? → ?" since pickup/delivery were never part of the
reconciled fields — expected, not a bug).

**Transfer season removed (2026-09-12).** D221's `orders.transfer_season`
(added earlier the same day, migration `20260912000001`) was cut one
migration later (`20260912000002`) — Nate's call: the Internal Freight
tracker's existing Year picker already does that job, and having both was
confusing ("i think is dumb ... idk what the season thing even is or what
its for"). Internal Freight transfers no longer get the "2025 permanent
history" treatment ordinary bag/external import rows get at all — they
always show under their real `ordered_at` year via the same
`externalOrderInYear` every other order tracker uses. The 63 Bagger-07
Umatilla transfers (and the new 13 Yard 1 ones above) keep showing fine
under 2025/2026 with no season tag needed. Dropped: the column, its
`orders_transfer_season_scope` CHECK, the drawer's "Season start" field,
the tracker's Season column, and `transferOrderInYear()`.

**Login screen unreadable in dark mode with a non-default accent
(2026-09-12).** `.login-card input` never set its own `background`,
relying on the browser's native input chrome — but the app-wide
`button,input,select,textarea{color:inherit}` rule still made its text
color follow `--ink` (near-white in dark theme). Native UA inputs default
to a white/light background regardless of page theme, so dark-mode text
landed near-white-on-white — invisible. The focus ring looked "thick" for
the same underlying reason: with no input-specific `:focus` rule, it fell
back to the generic `:focus-visible{outline:2px solid var(--focus)}`,
which some interactions (pointer-click focus) skip in favor of the
browser's own heavier native outline. Fixed by giving `.login-card input`
the same explicit `background:var(--paper)`/`border:var(--rule-2)` every
other input in the app already has, plus its own thin `:focus` ring
(`border-color:var(--focus)` + a 1px `--focus-soft` box-shadow, matching
`.gs>input:focus`'s convention) instead of leaving it to native/inherited
styling.

### D222 — Import performance, live broker directory, "say fuck it" cleanup, truck-off push (2026-09-12)

**Performance.** Nate reported real lag/dropped drags "when dragging in the
past" after the full 2025/2026 import (~3700 orders, vs. the sparse data
this was all written against). Two real bugs, both found live:
- `order()`/`party()`/`locFor()`/`locById()` (`02-chips-extract.js`) were a
  linear scan per call — fine at a few hundred rows, genuinely slow once
  `buildChip` ran these across a chip-dense scheduler window instead of
  mostly-empty months. Indexed by id now (`reindexLookups()`, rebuilt once
  per `render()` alongside `CELLS`/`CATCOLOR`, not per lookup); `locFor`
  keeps first-match-wins on a party with more than one location, matching
  the old scan's order, since which location is "the" designation location
  for a multi-address party is meaningful.
- The Scheduler's rolling month window (`buildScheduler`/`onSchedScroll`,
  D53) only ever grew — every month ever scrolled past stayed resident in
  the DOM forever. Fine when historical months were sparse; with real
  chip-dense data, scrolling through 2025 built an ever-growing DOM that
  slowed the whole page and could make a browser drop a native `dragstart`
  entirely (matches "click and drag doesn't work every time"). Capped at
  `SCHED_MAX_MONTHS = 8`; `pruneSchedTop`/`pruneSchedBottom` remove the far
  edge once exceeded, compensating `scrollTop` when pruning above the
  viewport the same way the existing prepend path already does.

Also fixed while investigating a UI report ("anytime and forklift... being
expanded for some reason"): `.flag` (`app.css`) had no `white-space:nowrap`
or `flex-shrink:0`, so on a `.slotrow` chip (`flex-wrap:nowrap`) three or
more flags on a narrow column squeezed each pill below its content width,
wrapping the LABEL TEXT itself onto two lines instead of just clipping
overflow flags. Both properties added; a crowded chip now clips cleanly.

**Live broker directory pull.** Nate: "u probably need to pull the new
outside customer list from the future tms google sheet." The dispatcher
sheet's "outside customer list" tab (same public CSV export
`legacy/invoicing-local/index.html`'s `BROKER_SHEET_URL` already reads for
rate-con matching) had grown past what was locally imported. New
`scripts/add_new_brokers.py` diffs the live sheet against local
`parties(is_broker)` by normalized name (so punctuation/suffix variants
like ", INC." or " ++" aren't treated as new) and adds only the genuine
gap: AXLE LOGISTICS, Alliance Trucking, American Logistics, Central Forest
Products, Clarkes Sheet Metal, Coast to Coast Logistics, Green Line
Brokerage, Smokey Mountain Logistics (Nate's own example — "smokey is
smokey mountain logistics" — confirmed to be exactly this sheet row).
`reconcile_external_orders.py`'s `ALIASES` grew from 14 to ~85 entries
cross-checked against this directory — every new code is a shortening of a
company name already stated in the same raw text (e.g. "Harmer Steel
Portland... (HARM)"), not a blind guess; genuinely ambiguous codes (UTAH —
two plausible sheet matches; WG; CENTRAL O) and person/internal-looking
codes (NATE, MIKE, KEV, DAN, TOM, JR) were deliberately left unaliased.
Re-run: 1009 brokers linked, 893 load numbers, 764 full order numbers (up
from 859/771/676).

**Lignetics.** Nate: "take any 'lignetics' orders out of the 07 customers
those are for bi-mart but its external freight so its bi-mart as the
customer/broker." Two of 27 imported Lignetics rows had been matched by
`reconcile_internal_orders.py`'s brand+store-number pairing to a specific
Bi-Mart store (the store number happened to sit right after "Bi-Mart" in
the text) and landed as Bag Orders — wrong, Lignetics is a pellet-fuel
shipper delivering to Bi-Mart stores, not a bag customer. New
`scripts/reconcile_lignetics.py` sets all 27 to `kind='external'`,
`broker_party_id` = the general "BI-MART" broker party (not a specific
store), `customer_party_id=null`.

**"Say fuck it" — unmatched imports become plain schedule text.** Nate,
after seeing broken-looking "no order #"/blank-customer chips: "make the
shit plain text on the scheduler... i can still search by number and once
i give u documents to match u can do the same thing and create loads from
the docs if u need." The goal of this whole import was always "see what
the other dispatcher did" and get real data to test against, not
reporting-grade accuracy (Nate's words) — so a fake order with no
matchable broker/customer is worse than a plain text cell: it shows a
broken chip AND pollutes Orders trackers/reports for no benefit. New
`scripts/reconcile_unmatched_to_notes.py` converts every remaining
imported order with no broker (external) or no customer (internal) —
excluding transfers and excluding anything still flagged
`repeated_full_order_number`/`repeated_broker_load_number` (Nate is
working through `duplicate_order_numbers.csv` by hand; those DO have a
matched broker/customer, they're just held on a number collision) — into a
`schedule_notes` row with the original raw text preserved verbatim, then
deletes the order/load. A handful of imported rows had no text at all (a
genuinely blank sheet cell) — those are deleted outright, same as the
Cascade Cannabis precedent, rather than writing an empty note. Some
imported (truck, date, slot) triples turned out to be genuinely doubled up
(two loads landed on one sheet cell at import) — the insert merges into
the existing note's body (`... || ' / ' || ...`) instead of crashing on
`schedule_notes`' own uniqueness constraint. Result: 811 converted, 5
blank rows deleted, 0 held. Orders 3725 → 2909. Confirmed zero orphan
orders (every order still has a linked load) after all of this session's
scripts.

Also confirmed via `scripts/reconcile_yard1_transfers.py`'s
`am sulf`/`Cascade Cannabis` precedent and this new script's identical
pattern: nothing here is destructive-without-a-trail — the raw text
survives as a note, and a future document-matching pass can still turn a
`schedule_notes` cell back into a real order once real paperwork exists.

**Truck-off day now pushes "OFF" in red.** Nate: "when a truck is marked
off and the schedule gets pushed it needs to write OFF and change the cell
to red in the google sheet." `_driver_week_payload` (`server.py`) never
consulted `truck_off_days` at all — a truck marked off pushed either a
blank cell or, if a `schedule_notes` row happened to also exist in that
slot, that note's text. Added an `off_by_key` lookup (same shape as the
existing `notes_by_key`); in `truck_rows()`, an off day now wins over a
note in the same slot (a dispatcher needs OFF to read across the whole
day, not just whichever slot lacks a note) and writes `chip="OFF"`,
`color=TRUCK_OFF_COLOR` (`"#FF0000"`, added to `DARK_FILLS` for white
text). Since Current Week's `truck_rows(t, compact=True)` shares the exact
same function, this fix covers both driver tabs and Current Week for
free — no separate wiring needed.

### D223 — Remove order-screen count banners and redundant copy (2026-09-14)

Nate asked to remove the "21 transfers in 2026" message and check the app
for similar clutter. Removed Internal Freight's standalone record-count
banner and shortened its drawer subtitle to "Internal Freight". Reviewed
the other order screens and shared notices; retained actionable missing-field,
route-review and empty-state guidance. No record, count calculation, filter,
year selection, import rule, or database change is involved.

### D224 — Fill missing Bag Order numbers from notes (2026-09-14)

Nate authorized delivery-month numbering for blank imported Bag Orders,
extracting short number and pallet count from notation such as `191/24`.
For repeated short numbers within a delivery month, the earlier-delivered
entry uses the previous month. `fill_missing_bag_order_numbers.py` applies
this to missing numbers only, updates `order_period` along with the full
number, and preserves original notes, customer links and delivery dates.
Existing full numbers remain untouched. Same-day ties, occupied numbers and
collisions remaining after a single-month shift are held for review; no
extra trips, suffixes, or further month shifts are invented.

The parser rejects explicit ready/date annotations, full slash dates, and
`1/2 BT` trailer shorthand, and handles notation adjacent to text. Source
notes with multiple unresolved pairs remain held. Pallets are corrected
from an unambiguous pair even when its full number is still held.

Preview and original-row audit saved under ignored `output/import-review/`;
a full local database backup preceded commit. Verified parsing, December/
January rollover, two-way and three-way duplicates, same-day ties, and
occupied numbers. Commit-time checks verified unchanged unrelated orders,
all loads, original notes/customers/dates, and every assigned number/pallet/
period. A repeat preview proposed zero changes. Remaining exceptions are
listed in the local Bag Orders review document. No UI or schema changes.

### D225 — Scanned "Sent - 2026" batch split and matched to external orders (2026-09-14)

Nate added a local `Sent - 2026/` folder (359 scanned PDFs — rate cons,
BOLs, invoices) and asked to match them to external loads and, if
possible, split each packet into its component documents. ChatGPT had
started the pipeline (`scripts/index_sent_pdfs.py`,
`export_sent_match_context.py`, `ocr_sent_pdfs.swift`,
`plan_sent_documents.py`) but stopped with OCR only ~80% done (1182 of
1471 pages) and never built anything that actually wrote the split files
or `documents` rows — everything up to that point was read-only by
design (each script's own docstring says so).

Finished the pipeline:
- Resumed `ocr_sent_pdfs.swift` (macOS Vision, local-only, no deps) — it
  already tracks completed `(sha256, page)` pairs in its own output and
  skips them, so resuming cost nothing extra. Completed the remaining 289
  pages in ~3 minutes.
- Re-ran `export_sent_match_context.py` (read-only, `set transaction read
  only`) and `plan_sent_documents.py` fresh against the complete OCR text.
  Final plan: 503 document groups, 296 matched to a real order — a group
  matches only on an exact printed order number (cross-checked against
  the broker on file) or a broker + unique load/PO hit, corroborated by
  scheduled date proximity for a standalone (non-invoice) document;
  anything ambiguous (multiple candidates, conflicting numbers, no ID
  found at all) is deliberately left unmatched, never guessed.
- New `scripts/apply_sent_documents.py` (preview-then-`--commit`, same
  model as this session's other reconcile scripts) is the part that was
  actually missing: for every document in every group it extracts that
  document's exact pages into its own PDF (`pypdf`) and inserts one
  `documents` row — a matched group's file lands under
  `app/storage/<order_id>/` with `matched_by='document_text'` (the ID
  came from OCR'd text, not a structured field or filename — the one
  `match_method` value that means that); an unmatched group lands under
  `app/storage/unmatched/` with `matched_by='unmatched'`, landing in the
  existing Billing "unmatched documents" queue (D94) for a manual attach —
  no new review UI needed, the app already had the right mechanism.
  Idempotent: each row's `extracted_fields` carries the source sha256 +
  page range, checked before filing, so a re-run only files what's new.

Result: 1230 individual documents filed (472 POD, 481 invoice, 161 rate
con, 116 other) — 718 attached straight to 296 real orders, 512 sitting in
the unmatched queue for Nate to attach by hand. Verified live: a sampled
matched order (Sierra Pacific, `12-0826-0003`) shows its real invoice +
POD pages under its own storage folder; a sampled unmatched rate con
opened as a genuine single-page PDF from Billing's queue. Backed up the
database before commit, per this session's standing practice for any
bulk write. `Sent - 2026/` and `app/storage/` are both gitignored — real
paperwork, never committed (same golden rule as the xlsx imports).

**Continued (2026-09-14) — better matching, unmatched documents pulled out
of the app.** Nate: "we cant have 512 in the billing queue... gotta search
the app better for matches if they aren't able to be matched they can't
clutter the app," then, on the matching itself: "why cant you go by date
thats what i would do invoice date is usually a week or so after the load
was delivered sometimes sooner." Three real, safe improvements to
`plan_sent_documents.py`'s `match_group()`, none of them guesses:
- A printed Solomon-format order number that matches exactly one order, on
  the confirmed correct broker, with no *conflicting* load/PO hit, is now
  trusted even without load/PO corroboration — that combination (a specific
  `12-MMYY-####` number + the right company) is already the same standard
  `reconcile_external_orders.py` trusts elsewhere. Recovered 35 groups
  previously held as "needs review" for no real reason.
- `broker_compatible()` learned one confirmed name variant: the party
  directory has "Vanport Trucking," their own invoice letterhead says
  "Vanport Transportation, Inc." — verified against 5 real printed order
  numbers that only made sense as Vanport trips. Recovered 5 groups that
  were being reported as a broker *conflict* when they weren't one.
- New delivery-date fallback (`date_match`): when a document's broker is
  identified but there's no order number or load/PO hit at all, check every
  broker-compatible order's `delivered_at` against every date found on the
  document, accepting 0–14 days document-after-delivery (Nate's "a week or
  so... sometimes sooner"). Only trusted when it singles out exactly one
  order — a high-volume broker (Bi-Mart, Hammer Lumber) usually has several
  trips inside that window and stays correctly held, not force-matched.
  Recovered 7 groups outright; many more now report *why* they're
  ambiguous ("matches multiple orders") instead of "no existing order
  identified," which is a real answer, not just more of the same bucket.

Net: 296 → 343 of 503 groups matched (718 → 839 documents attached to real
orders). The remaining 160 groups (391 documents) are genuine dead ends —
no broker, no printed number, or a real conflict/tie a stronger signal
can't resolve from the document alone.

Separately, per the "can't clutter the app" half: **an unmatched group no
longer becomes a `documents` row at all.** `apply_sent_documents.py` now
only inserts into `documents` (and Billing's unmatched queue, D94) for a
group `plan_sent_documents.py` actually matched to an order — an unmatched
group's split pages are written to a plain local folder,
`output/sent-2026/unmatched-review/<source stem>/<doc_type>_pN.pdf`,
untouched by anything the app shows. Deleted the 512 already-filed
unmatched rows/files from the first pass and re-ran clean. Idempotent both
ways — re-running after adding more scanned PDFs or improving matching
further only files/writes what's new, and a document that flips from
unmatched to matched is removed from the review folder when it's filed for
real so it doesn't look like it exists twice.

### D226 — Clicking into a smart-date field edits that segment, not the whole date (2026-09-14)

Nate: "when i type into the scheduler or current week date bar it needs to
let me select one part of the date without deleting the entire date. right
now if i click and type it wipes it." D151's smart-date inputs (Scheduler's
jump box, Current Week's "First day drivers see," Reports' From/To, the
order-tracker date cells, Settings' per-user Scheduler window) were built
around one flow — Tab or click into the field and type a whole new date
from scratch, `08` `Tab` `22` `Tab` `2026` — so the focus handler always
reset all three segments blank, and the very first digit typed after
_any_ focus, click included, replaced the entire displayed value.

A click is a different intent than tabbing in: the user is aiming at one
part of an already-correct date. A new `click` listener
(`10-select.js`, right after the existing `focus` handler) re-seeds the
segment state from the field's real value, maps the caret position the
click actually landed at to month/day/year, and blanks only that one
segment — the next digit replaces it while the other two stay put. It
backs off once the user has typed anything this focus session
(`touched`), so it can't interfere with an in-progress edit, and it never
touches the Tab-in fresh-start path (no click event fires for a keyboard
focus), so "tab in and type a whole new date" keeps working exactly as
D151 shipped it.

Verified live with real keydown events (`computer.type`'s synthetic
text-insertion bypasses the smart-date keydown handler entirely and isn't
a valid way to test or reproduce this class of bug — `computer.key`,
one keystroke at a time, is): clicked into the year of `09/14/2026`,
typed `2027`, got `09/14/2027`; clicked into the month, typed `03`, got
`03/14/2027` — day and year both untouched both times. No console errors,
no change to the fast full-date-typing flow.

**Follow-up, same day.** Nate: "i'd like it to not take the year away if i
go to type the day of month, or take the year away if i change the year
right now if i type it takes it away out of the box." The click fix above
only cleared the ONE segment actually clicked — but filling that segment
auto-advances `cur` into the next one (month → day, day → year), and that
next segment still held its real, un-cleared value from the click re-seed.
The first digit landing there APPENDED instead of replacing: click day,
type an extra keystroke past the 2 digits, and it rolled into a still-
intact year ("2026" + "5" = "20265"), which then failed `smartDateCommit`'s
length check and silently fell back to the stale pre-edit year — reads
exactly like "typing the day took the year away."

Added `opened: [bool,bool,bool]` to the smart-date state — which segments
have actually been cleared-and-started-fresh this focus session, vs. which
still hold a real preserved value. The click handler marks only the
clicked segment `opened`; `smartDateFeed` now checks `opened` before
appending each digit and clears the segment first the FIRST time a digit
actually lands in it, however `cur` got there (fill-and-advance, `/`, or
Tab). A segment nobody ever types into is never touched. Verified: click
day on `09/14/2026`, type `205` (2 fills day, extra `0`... `5` rolls into
year) → year now cleanly reads just `5`, not a concatenated garble;
Tab away → commits `2026-09-20` (day changed, year correctly falls back to
its real prior value, not corrupted). Click month, type `1105` straight
through (crossing the month→day boundary) → `11/05/2026`, day cleanly
replaced, year untouched.

### D227 — Real Pick/Drop List imported from the future TMS sheet (2026-09-14)

Nate: "use the google sheets thing and go to the future tms sheet, and then
grab the pick and drop list from that and import it into this app to
replace the current test pick and drop list in the app which is just a
copy of the bag customers." The Pick/Drop List page is the same
`locations` table as Bagger Customers, unfiltered by `party_id`
(pre-existing trap, CLAUDE.md) — with no real standalone rows, that
unfiltered view showed only Bagger Customers' 269 rows plus one seed.sql
placeholder ("Bag Plant," uuid ending `...205`), which is exactly what
read as "just a copy of the bag customers."

New `scripts/import_pickdrop_list.py` pulls the dispatcher sheet's own
"Pick/Drop List" tab (same public CSV export mechanism `add_new_brokers.py`
already uses for the outside-customer-list tab) — App?/Company
Name/Address/City/State/Phone Number, 938 real rows. Confirmed the
placeholder "Bag Plant" row is referenced by nothing (no order, order_stop,
or load_stop) before deleting it; the sheet's own "Rexius Bag Plant" entry
supersedes it. Inserted all 938 as new `party_id`-null `locations` rows —
duplicate company names in the sheet (19 of them, e.g. three different
"Cascade WH Salem" addresses) are genuinely different physical addresses,
not redundant rows, and were kept as-is; a handful of source rows have
their own data-entry slips (a store number that spilled into the address
column on one Home Depot row) preserved verbatim rather than guessed at.
Backed up the database before commit. Verified live: Pick/Drop List now
shows real entries (A-1 Pallet, ABC Roofing Eugene, ...) instead of only
Bagger Customer rows.

### D228 — External Orders workflow: broker combo lag, editable broker in the drawer, real inline location creation, rate-con auto-adds to Pick/Drop (2026-09-14)

Nate: "right now it lags a lot when you start typing a broker, in that
side window theres no way to change the broker, also i need to be able to
add locations to my pick and drop list right then and there, and also be
able to add locations to picks and drops based on the rate con dropping...
however it needs to work with typing as well in case i can['t] drop rate
cons in." Four changes, one workflow:

**Broker-typing lag.** `renderLocSuggest`/`renderPartySuggest`
(`03-drawer-billing.js`) repositioned their suggestion panel with
`getBoundingClientRect()` on every single keystroke, not just when the
panel opens. That forces a synchronous layout flush — cheap on a small
page, a real felt cost on External Orders' 1000+-row unwindowed tracker,
where every keystroke recomputed layout for the whole table. The input's
own on-screen position doesn't move while the user types, so both now
position once, the first time the panel opens, and just update
`innerHTML` on every keystroke after that.

**No way to change the broker in the drawer.** `openOrder`'s "Order"
section had Order #, Load #, PU/PO, Delivery #, dates, and Notes — never
`broker_party_id`. The tracker grid already had a broker `partyCombo`;
the drawer never got one. Added `partyCombo(oid, "broker_party_id", ...)`
as the first field. Verified live: typing "Rosboro" found "Rosboro Lumber
Co," picking it updated the drawer header, chip preview, and
`orders.broker_party_id` in Postgres; reverted cleanly back to the
original broker.

**Real inline location creation.** `locCombo`'s "+Create" used to
comma-split whatever was typed into a raw guess at name/city/state and
insert it directly — no address, no phone, no confirmation. `addLocationModal`
(the same fill-out popup Pick/Drop List's own "+ Add Location" uses) now
takes an optional prefill name and `{oid, field}` target; "+Create" opens
it pre-named instead of guessing, and `#modal-save-loc`'s handler assigns
the saved location straight onto that order/field when a target was given.
Verified live: typed a new pickup name, "+Create" opened the real modal,
filling in a street address and saving produced a real `locations` row
with that address AND set it as the order's `pickup_location_id` in one
step — "Location added and set."

**Rate-con drop adds to the Pick/Drop List.** `parseRateCon`'s
pickup/delivery extraction was explicitly designed to only ever suggest,
never apply — rate cons are noisy and Nate always confirmed manually. New
`resolveStopToLocationId(stop)` (`03-drawer-billing.js`) matches an
extracted stop against `DB.locations` by exact case-insensitive name
first (so re-ingesting the same shipper/consignee never piles up
duplicates); on no match, it creates the location outright.
`ingestRateCon` calls this for pickup/delivery right after the order/
document are created, and only WRITES the result onto the order's own
`pickup_location_id`/`delivery_location_id` when that field is still
blank — a matched EXISTING order that already has real pickup/delivery
data is never overwritten. This is deliberately narrower than the drop
itself always assigning things with total confidence: it only grows the
address book automatically; an order's own field still only fills in
when there was nothing there to protect. Not live-tested end-to-end (no
real rate-con PDF/OCR pipeline available to drop in this session) —
reviewed carefully against the existing `ingestRateCon`/`rateConSuggest`
flow instead; flag for a real-world check on the next actual rate-con
drop.

The "needs to work with typing as well" half of the ask is the location-
creation fix above — the SAME `addLocationModal`-backed "+Create" now
handles both the manual-typing path and whatever a rate-con drop couldn't
resolve on its own, rather than two different code paths for "dropped a
document" vs. "typed it by hand."

### D229 — loc-suggest panel moved off-subtree to fix zoom misplacement; zoom itself now persists (2026-09-14)

Nate: "we have an issue typing into the picks and drops where the dropdown
is like down and off to the right instead of being in the correct spot,"
then separately "make sure settings are persistent including zoom, i
noticed zoom resets to 100 when i refresh."

**Zoom never persisted.** `ZOOM` (`11-toolbar.js`) was a bare `var ZOOM = 1`
with no localStorage read/write anywhere, unlike every other PREFS-style
setting. Now reads `pref_zoom` at startup (clamped 0.5–2, same bounds
`setZoom` already enforced) and writes it on every `setZoom` call;
`applyZoom()` also runs once unconditionally at load so a saved zoom
takes effect before any user interaction.

**The dropdown bug turned out to be caused by that same fix.** Before it,
`#main.style.zoom` was only ever set once the zoom control had actually
been touched in that session — meaning a fresh session/refresh usually had
no explicit zoom style on `#main` at all, and `.loc-suggest`'s plain
`position:fixed` positioned correctly against the true viewport. Once zoom
persistence made `applyZoom()` run on every load, `#main` always carries
an explicit `style.zoom` from the first paint onward — and it turns out
ANY explicit CSS `zoom` value on an ancestor, including exactly `1`, makes
that ancestor the containing block for a `position:fixed` descendant
(confirmed live, reproducible at 100%, 150%, and 200%): a fixed panel's
`left`/`top` become relative to `#main`'s own on-screen corner instead of
the viewport's, and a non-1 zoom value ALSO re-scales that offset by the
zoom factor again on top. A `.loc-suggest` panel rendered as a `.loccombo`
child (every tracker-grid Broker/Customer/Pickup/Drop combo lives inside
`#main`) inherited both distortions and landed down-and-right of the
input — exactly Nate's report. The drawer's own combos were never affected
(`#drawer` is a sibling of `#main`, outside the zoomed subtree) — which is
why this wasn't obvious everywhere.

Tried compensating for the distortion with math first (subtract `#main`'s
own rect, divide by `ZOOM`) — it worked for a single case but broke again
the moment zoom changed while a panel from an earlier focus was still
open, and re-deriving the exact browser-internal scaling relationship by
trial and error is not something to leave load-bearing. Went with the
robust fix instead: `.loc-suggest` is now ONE shared panel
(`locSuggestPanel()`, `03-drawer-billing.js`) parked directly on
`document.body` — never a `.loccombo` child, so it's never inside any
zoomed subtree regardless of which combo opened it, and position math
goes back to plain `getBoundingClientRect()` values with no compensation
needed at any zoom level. `SUGGEST_INPUT` (`01-core.js`) tracks which
input the shared panel is currently serving, since pick handlers can no
longer find it by walking up from the clicked option (the panel isn't a
DOM descendant of the combo anymore). Bumped `.loc-suggest`'s z-index from
60 to 330 (above `#drawer`'s 301 and `#modal`'s 320) since a body-level
panel no longer inherits stacking-above-the-scrim for free from being
nested inside the drawer. `render()` hides the shared panel at the start
of every re-render so it can't survive pointing at a detached input.

One more real bug surfaced while fixing this: the existing "only
reposition when the panel transitions from closed to open" perf guard
(D228) compared display state alone, so refocusing the SAME input after
an intervening zoom change (or scroll/resize) left the panel showing its
old, now-wrong position — the guard thought nothing needed recomputing.
`renderLocSuggest`/`renderPartySuggest` now also treat a change of
`SUGGEST_INPUT` as "not already open," and the `focus` handler
(`07-events.js`) passes `force=true` so refocusing always repositions
fresh regardless — only continued keystrokes into the same still-focused
field skip the recompute, which is the actual case D228 needed to fix.

Verified live at 100%, 150%, and 200% zoom, in both a tracker-grid combo
and a drawer combo: panel lands exactly under the input every time. Also
re-verified the "+Create" → `addLocationModal` flow (D228) still works
through the new `SUGGEST_INPUT` wiring. No console errors.

### D230 — Day notes: dispatcher-only annotations pinned to a scheduler date (2026-09-18)

Nate: "i'd like the ability to right click add notes to a specific date,
and have that also show up in the reports if i export the entire app.
like literally just a text note that lives on a day in the scheduler that
never leaves the app like it doesnt get shown to the drivers." A separate
concept from `schedule_notes` (a truck+date+slot cell's own note, D82) —
this is one plain note per calendar date, with no truck/slot, no fmt/color,
and no driver-tab or Sheets exposure at all.

New table `day_notes` (`note_date date unique`, `text`) — one row per date,
its own durable-history trigger (D131/D190 pattern). `/api/day-note`
upserts by `note_date`; empty text deletes the row outright rather than
leaving a blank one around, since (unlike a scheduler cell) there's no
formatting to preserve alongside an empty note. Gated on the existing
`("dispatch","sched")` permission bucket — same as every other scheduler
mutation.

Right-click the date header (`openDayMenu`, `09-color.js`) — same menu
that already has "Add row"/"Remove row"/weekend toggle — now also offers
"Add day note…" or "Edit day note…" (label flips once a note exists),
opening `dayNoteModal` (`06-modals-grids.js`): a plain textarea, Save, and
a "Delete note" button that only appears when editing an existing note.

**Displayed as real text under the date, not just a hover title** — Nate's
follow-up ask, after seeing the first pass (a small dot + title tooltip):
"i like that but also i need it to display the note below the date so i
can read it when i scroll." `schedMonthHtml` (`04-views.js`) renders a
`.daynote-txt` div inside the date's `td.rowhd` (which already spans the
day's full `rowspan` of slot rows) right under the existing dwk/dnum/trk
spans; `title` stays on the `td` too as a full-text fallback for anything
long enough to wrap past what's comfortable to read inline. A long note
wrapping taller than the day's slot rows grows that whole day's row height
across every truck column, same as any other table cell would — verified
live, looks fine, not worth capping.

`DAY_NOTES`/`dayNote(ds)` (`02-chips-extract.js`) is a plain date-keyed
lookup, rebuilt in `render()` via `buildDayNotes()` right next to
`buildOffDays()` — same pattern, deliberately a separate map (a day note
is keyed by date alone, not `truck|date` like `OFFDAYS`).

**Export path:** added to `PARAM_SQL`/`_REPORT_LABELS` (`app/server.py`)
as its own date-range-filterable report, `day_notes`, and a matching card
on the Export & Reports page (`vReports`, `04-views.js`) next to
Customers/Brokers/Fleet — "the only place they leave the app," per Nate's
own framing. Also fell into `api_bootstrap`'s explicit select-list (the
usual trap, D127 follow-up #3) and `build_report("everything")`'s
server-side combined dump for free, since it iterates `REPORTS`+`PARAM_SQL`.
Deliberately NOT added to `_DUMP_SQL` (the per-order wide dump) — a day
note isn't order-scoped, so it has no natural row to attach to there.

Verified live: added a note on a real date, confirmed the toast, the
inline text, and the `title` tooltip; reloaded the page and confirmed it
persisted; right-clicked again and confirmed the menu read "Edit day
note…" with a working "Delete note" that cleared both the text and the
`has-daynote` class; exported `/api/report/day_notes` and confirmed the
CSV. All test rows cleaned up from the real `day_notes` table afterward —
Nate's own real 2026-09-17 note left untouched.

**Follow-up, same day:** Nate wanted the note boxed and higher-contrast
("a box around it and give it like accent color and contrast text so the
notes are really visible") — `.daynote-txt` now renders on `--brand`
(the user's chosen accent) with `--brand-ink` text (D172's calculated
readable-on-accent color, same pairing the active-nav/primary-button use),
bold, padded, rounded. Verified live at the default accent — solid green
box, white bold text, clearly the loudest thing in the row header.

**Second follow-up, same day — app-wide Enter-to-submit/Escape-to-exit
(2026-09-18):** Nate: "ensure all popup windows submit with enter or
return, and exit with escape, thats app wide." D194 already covers
Enter-to-submit for every `#modal` popup via its single `.btn.pri`
(`06-modals-grids.js`) — that part was already app-wide and needed no
change. Two real gaps, both surfaced by day notes being the first popup
with a `<textarea>`:

1. **No Escape-to-close existed for `#modal` at all** — only the drawer
   (`DRAWER_OID`) and the History panel had their own Escape handlers;
   plain Escape over an open modal just ran the grid's Escape-deselect
   (D196) harmlessly in the background, never closing the popup itself.
   Added a capture-phase `keydown` listener (`06-modals-grids.js`, right
   after the Enter listener) that clicks the open modal's `#modal-cancel`
   button (falling back to a bare `closeModal()` if a popup somehow lacks
   one) — same button a real click already hits, so any popup-specific
   cleanup wired to that click keeps working. Extended to `#viewer.on`
   (the in-app PDF/image viewer) too, since it's the same kind of
   dismissible overlay even though it isn't part of the `#modal` system.
2. **A textarea inside a modal (day notes' `#daynote-text`) had no
   Enter-to-submit path** — and correctly so: D194's existing plain-Enter
   listener deliberately skips `TEXTAREA` targets so a real newline still
   works, but that left no submit shortcut at all from inside one. Added
   Cmd/Ctrl+Enter as the textarea-specific submit (same single-`.btn.pri`
   resolution as plain Enter) so the popup's one obvious action is still
   reachable without tabbing out of the field first.

Both new listeners are capture-phase + guarded on an actual open
`#modal`/`#viewer`, so they never fire (and never call
`stopPropagation()`) when neither is open — the existing bubble-phase grid
Escape-deselect (D196) and drawer Escape-close are untouched for every
other case.

Verified live: Escape from inside the day-note textarea closes the modal
with no save (confirmed via DOM inspection, not just visually — the
row header's `has-daynote` class/`title` never appeared). Cmd+Enter from
inside the textarea saved and closed (confirmed the note persisted after).
Plain Enter still submits an ordinary single-input popup (Add Shortcut's
"Choose keys") exactly as before — cancelled the resulting key-recording
state with Escape afterward, confirmed no shortcut was accidentally bound
and `RECORDING` cleared. No console errors. (Note for future live testing
in this browser tool: its synthetic `key` action for "Enter"/"Return"
dispatches a keydown with an EMPTY `.key` string, not `"Enter"` — every
app-level Enter handler correctly ignores it, so this reads as "Enter does
nothing" and is a tooling artifact, not a real bug. `key: "Escape"` maps
correctly. Verify any Enter-key app logic with a real synthetic
`KeyboardEvent({key:"Enter", ...})` dispatched via `javascript_tool`
instead, the same way `computer.type` vs `computer.key` already has its
own documented trap for the smart-date fields, D226.)

### D231 — Two more "New order" shortcuts; dropped Add Shortcut / second-binding-per-action (2026-09-18)

Nate, on the custom-shortcut system (`CUSTOM_SHORTCUTS`, D97): "theres no
way for me to create or select a shortcut theres a key listener but i cant
set it to do whatever i want." Talked through a real macro-recording
system first — recommended against it: recorded clicks/DOM state go stale
the moment a grid re-renders or an async save changes what's on screen, a
lot of engineering for something fragile. Nate agreed, and once he saw
that "Add shortcut" only ever added an EXTRA key combo pointing at an
action he could already rebind directly (every row already has its own
Record button), he called it pointless outright: "i cant imagine its
useful if u can remap the ones we have and you cant add a new one it just
remaps them anyway." So instead of building anything new: two more fixed
actions, and delete the redundant layer.

**Two new `BASE_SHORTCUTS` entries** (`01-core.js`): "New Bag Order
number" (`Alt+I`) and "New Internal Freight order" (`Alt+F`), alongside
the existing "New external order" (`Alt+N`) — now all three order kinds
have a one-key create, not just external. Both reuse the EXACT logic their
tracker's own "+ Add one" toolbar button already runs
(`addBagOrderNumber`/`addTransferOrder`, extracted to shared functions in
`07-events.js` so the button and the shortcut can't drift apart) — no new
server-side behavior, no modal, callable from anywhere in the app, not
just while already on that tracker. Bag Order reserves the next number
for whatever month/year context is current (or the sensible defaults if
you've never visited that tracker this session) and just toasts; Internal
Freight creates a blank transfer and opens its drawer, same as the
external one does.

**Removed:** `CUSTOM_SHORTCUTS`, `addShortcutModal` (`06-modals-grids.js`),
the "Add shortcut" button, and the per-row "Remove" button (dead code now
that every row is a base row) — a real second-binding-per-action feature
never existed under a different name here, this genuinely was pure
redundancy over the existing per-row Record/Reset. `SHORTCUTS` is now just
`BASE_SHORTCUTS` directly. `runShortcut` no longer routes through a
`custom:*` id lookup first.

Verified live: Settings → Shortcuts shows all 15 actions (was 13) with no
Add-shortcut button and no stray Remove buttons; `Alt+I` from Settings
(not even the Bag Orders tab) reserved a real order number and toasted;
`Alt+F` opened a real Internal Freight drawer pre-filled the same way the
toolbar button does. Both test orders deleted afterward via direct
`psql`. `node --check` clean on all four touched files.

### D232 — Billed import backfill; collapsed Billed/Delivered sections on External Orders and Internal Freight (2026-09-18)

Nate: "inside external orders i want all the delivered orders we have rn
from the import to be set to billed so they arent in the billing queue."
Every one of the 1,033 delivered-not-yet-billed external orders in the
database turned out to be from the sheet import (620 `sheet2025`, 413
`sheet2026` — confirmed by query before running anything), so there was no
ambiguity about scope. One-time `update orders set billed_at = now()
where kind='external' and not is_transfer and delivered_at is not null
and billed_at is null` via direct `psql`, no new script — 1,033 rows.
Billing's own queue (`vBilling`'s `!o.billed_at` filter) dropped from
hundreds of stale import rows to the 2 real ones actually needing action,
verified live.

**Then, same conversation:** "i want to be able to have billed orders be
in a dropdown that sorts newest to oldest like it already does. just
adding dropdown to avoid clutter... if its been billed i don't really
need to see it unless im looking for it" — and, a message later, "same
with internal freight if its delivered collapse it. cause ones i search
it ill find it." Added one reusable disclosure pattern
(`TRACKER_COLLAPSED_OPEN`/`trackerCollapseToggleRow`, `04-views.js`),
closed by default each render, that mirrors the History panel's day-header
arrow exactly (`.tracker-collapse-*` classes, same rotate-on-
`aria-expanded` CSS formula as `.history-day-hd`, D135) — a `<tr>`
spanning every column with a "▸ Billed (N)" / "▸ Delivered (N)" toggle,
appended after the live rows in the SAME `<tbody>`, expanding into the
exact same row markup those orders would otherwise render inline.
External's split key is `billed_at` (per Nate's own framing); Internal
Freight's is `delivered_at`, since transfers are never billed at all
(`orders_transfer_shape` — no solomon #, no customer/broker, ever) so
`billed_at` isn't a meaningful axis there. This only hides `<tr>`s — it
never filters `orders()`, so global search and drawer-open-by-id find a
collapsed order exactly as before, which is the whole basis of "once i
search it i'll find it."

`extOrderRowHtml`/`xferOrderRowHtml` (04-views.js) are the per-row
templates split out of `vOrders`/`vInternalFreight` so the same markup
renders for both the live and collapsed halves without duplication; the
numbered gutter stays one continuous sequence across the split (a billed/
delivered row picks up numbering where the live rows left off) so
expanding the group doesn't restart the gutter at 1. `EXT_TRACKER_COLS`/
`XFER_TRACKER_COLS` are the toggle row's `colspan`, hand-kept in sync with
each tracker's own `<thead>` column count — same kind of coupling as the
`dvSlotCellsHtml` sibling-count trap (CLAUDE.md), flagged the same way.

Verified live: Bag Orders/External/Internal Freight badges reflected real
counts before/after; expanded/collapsed both groups, confirmed the arrow
rotates and the row body renders correctly with proper newest-to-oldest
order; confirmed reload() after any bill/deliver change (already existing
behavior, `billDone`/`billBatch`/etc. all `.then(reload)`) correctly moves
a row between buckets. No console errors beyond the known harmless
transient logo-asset `ERR_CONNECTION_RESET`.

### D233 — Bag Orders: dropped the monthly breakout, flat newest-to-oldest, bulk-add by number range (2026-09-18)

Same conversation, immediate follow-up: "i think we do the same thing for
bagorders too and we just eliminate the monthly breakout and make it just
sort newnest to oldest and keep bulk import i just give the bulk import
ranges maybe? i think that would work like order number start and order
number end and it inputs them all in there."

**View:** `vInternal` dropped the JAN–JUL/Off-Season `MONTH_GROUPS` tab
strip and its `INT_MONTH` filter state entirely — `MONTH_GROUPS`,
`INT_MONTH`, `currentMonthGroup()`, and `orderMonthCode()` are all deleted
from `01-core.js` (confirmed dead everywhere else first via repo-wide
grep). The tracker is now flat and year-scoped only (`orderYearCode`
unchanged, still the real year filter), sorted newest-to-oldest by
`bagOrderCompare` — the same numeric-locale-compare tail
`externalOrderCompare` already uses, safe here for the identical reason:
the grid is already year-scoped by the Year picker, so comparing the
`{MM}{YY}{####}` order number as one numeric-aware string sorts correctly
within that year. Split into a live section + a collapsed "Delivered"
group via the same D232 disclosure (`delivered_at`, matching Internal
Freight's key, not `billed_at` — Bag Orders/kind='internal' never sets
that field either). `resortInternalTrackerRow` (D156's live-resort-on-
edit) was rewritten around the same flat/bucketed model: a number edit
never changes `delivered_at`, so the row always stays in whatever bucket
(live/delivered) it was already in — it just needs repositioning within
that bucket, anchored on the collapse toggle row when it's moving to the
end of the live bucket, or the tbody's own end otherwise; if the row isn't
in the DOM at all (its bucket is currently collapsed), there's nothing to
reposition and the function is a no-op, same as it already was for a row
that scrolled off a since-removed month filter.

The bottom quick-add button is now plain "+ Add one" (no month name to
show), and `addBagOrderNumber()` (07-events.js, shared with the `Alt+I`
shortcut, D231) simplified to just reserve into today's real-world month
under whichever year the picker is on — dropping the `MONTH_GROUPS`
indirection changes nothing observable, since the old code already
resolved to today's month whenever it was in the currently selected
group, which it now always is by construction.

**Bulk add:** `bulkInternalModal`'s "How many orders" field is now
"Ending #" alongside the existing "Starting #" — Nate's own suggested
shape. The save handler (`07-events.js`) computes `count = end - start +
1` and calls the exact same `/api/internal-order` `{month, count, start}`
endpoint as before; no server change. Validates `end >= start` before
submitting.

Verified live: Bag Orders shows no month tabs, a flat list, and a
collapsed "Delivered" group with a correct count; expanded it and
confirmed newest-to-oldest ordering; opened "Add Orders" and confirmed the
Starting #/Ending # fields render and the example-number preview text
still resolves correctly. `node --check` clean on all four touched files.

### D234 — Toolbar title/primary-button widths fixed so switching tabs doesn't shift controls (2026-09-18)

Same conversation, immediate follow-up: "the top bar on internal freight
external orders and bag orders can we unify the design of it so it
doesn't shift the buttons around when i cycle thru, like the new order
and add orders buttons need to be the same width and the year selector
stays same with the titles regardless of me cycling it shouldn't move
them just change them depending on the screen im on" — then, one message
later: "same deal with current week and driver tabs."

Root cause: `toolbarHtml` (D171) lays the title, context controls, a
flex spacer, then secondary/primary out in a plain flex row with no fixed
slot widths — a shorter or longer title (`External Orders` vs `Bag
Orders` vs `Internal Freight`; `Current Week` vs `Driver Tabs`) changed
how much horizontal space it took up, which shifted the X position of
whatever followed it (the year picker, in the Orders trio) even though
the actual page content never moved. Separately, External's primary
button reads "+ New Order" while Bag Orders'/Internal Freight's both
already read "Add Orders" (same text, same width) — only the External
button's own width differed from the other two, at its right-aligned
position.

Fix is pure CSS, no markup restructuring: `.orders-toolbar h2{min-width:
150px}` (covers "Internal Freight", the longest of the three) holds the
title's slot constant so the year picker right after it always starts at
the same X; `.orders-primary-btn{min-width:100px;text-align:center}`
applied to all three primary buttons (`new-order`/`int-bulk`/`xfer-bulk`)
holds their own width constant too. Current Week/Driver Tabs don't use
`.orders-toolbar` (a different className, no year picker, no horizontal
scroll) — added a new `cw-toolbar` className to both `toolbarHtml` calls
and `.cw-toolbar h2{min-width:120px}` (covers "Current Week", the longer
of the two); their primary button text is already identical ("Update
Google Schedule") so no button-width rule was needed there.

Verified live via `getBoundingClientRect()`, not just eyeballing:
title/year-picker/primary-button `left` and `width` are pixel-identical
across Bag Orders, Internal Freight, and External Orders (214 / 374 /
977.9 respectively, each exactly 100px or 150px wide as set). Current
Week and Driver Tabs render identical control positions at both the
pane's normal width (where the toolbar wraps to two rows — confirmed the
wrap point itself matches between the two, not just the first row) and
after clearing viewport emulation back to the pane's native size.

### D235 — Paged rendering inside an expanded collapse group, fixing scroll lag (2026-09-18)

Same conversation: "we're having the same issue we had before where it
lags the app when i scroll on the delivered or billed orders in the order
trackers cause they're probably reloading each time i scroll." Not a
reload-on-scroll (checked: the only scroll listeners app-wide are the
Scheduler's own `onSchedScroll`, on a different element entirely, and a
cheap capture-phase `positionFillHandle` that no-ops instantly whenever
`SEL` is null) — the real cause is the same one D222 already fixed for the
Scheduler: External's Billed group alone was rendering 1,000+ real
`<tr>`s into the DOM the instant it opened, and a DOM that large is
genuinely slow to scroll/paint regardless of whether anything is
re-rendering.

Added bounded paging inside an expanded group instead of full
virtualization: `trackerCollapsedRowsHtml` (04-views.js) renders at most
`TRACKER_COLLAPSE_PAGE` (150) rows, followed by a "Show N more (M left)"
row (`trackerCollapseMoreRow`) that pulls in another page on click
(`TRACKER_COLLAPSED_SHOWN`, `07-events.js`). Collapsing the group again
clears its shown-count, so reopening later always starts back at one page
rather than silently restoring whatever it had grown to. All three
trackers (External Billed, Bag Orders Delivered, Internal Freight
Delivered) route through the same helper. `resortInternalTrackerRow`
(D233's live-resort-on-edit) got one more edge-case guard for this: if an
edited row's real next bucket-mate exists but isn't currently rendered
(paged out), there's no reliable local DOM anchor to reposition against —
falls back to a full `render()` instead of guessing a spot, rather than
risk placing the row somewhere wrong.

Verified live: expanding External's Billed group (2026 scope) now renders
152 `<tr>`s instead of 1,036+; clicking "Show more" grew it to 302 with an
accurate remaining count; collapsing and reopening correctly reset back to
one page. No console errors.

### D236 — Font-size stepper widened to align with Current Week/Driver Tabs' "Days shown" stepper (2026-09-18)

Nate, half-joking but not: "this is dumb but itll bug the shit out of me
if its not lined up, the font selector and days shown selector have to
line up perfectly, so im wondering if we can expand the font selector to
fill the space." First pass widened `.fb-font` (the "System" font-NAME
button) to 200px so its own right edge matched the "Days shown" stepper's
right edge — wrong pairing. Nate caught it immediately: "you expanded the
text bar too far so they dont line up... the goal is to get the plus and
minus selectors for the font and days show to be lined up." The actual
intended pair is two same-shaped stepper widgets: `.fb-fs` (the "− 10 +"
font-SIZE control right after the font-name button) and Current Week/
Driver Tabs' "Days shown" stepper — which turns out to be the exact same
`.fb-fs` markup/class, just reused in a different toolbar, so aligning
them is the natural pairing, not a coincidence.

Corrected: `.fb-font` is 126px (not 200px) — enough that the `.fb-fs` span
immediately after it starts at the same X the "Days shown" `.fb-fs` does,
both measured live via `getBoundingClientRect()` (both toolbars sit at a
fixed position relative to the nav sidebar regardless of page, so this
alignment is stable, not a coincidence of current content).

Verified live at 1600×900 (no wrapping): the two `.fb-fs` spans' `left`
values differ by 1.35px — as close as subpixel rendering gets — confirmed
on both Current Week and Driver Tabs (same shared `cw-toolbar` markup,
D234). Screenshot-confirmed the "− 10 +" and "− 3 +" steppers visually
flush, one above the other.

**Follow-up, same day:** Nate reported it still looked off and asked to
have the app open live while adjusting. Re-verified with the app open by
drawing temporary 2px debug guide-lines at each stepper's exact
`getBoundingClientRect()` edges (red/blue for Current Week's stepper,
lime/orange for the fmtbar's) and screenshotting — the four lines land
within 1.35px of each other and are visually indistinguishable at normal
zoom. No further CSS change made; if it still reads as off after this,
the most likely explanation is a stale cached view rather than the fix
itself — app.css is served `no-cache, no-store, must-revalidate` (D51), so
a hard refresh (Cmd/Ctrl+Shift+R) should pick up the current version.

### D237 — Orders trackers restructured to fill available space + real toolbar background (2026-09-18)

Two related asks, same conversation. First: "in the orders section i would
like it to have a different background color for the header area like we
have in the current week and driver tabs i think it makes the header
standout... im hoping that doesnt mess up ur static changes." Then,
immediately after: "can we have the orders section expand width and
height to fill the gaps between the main tool bar and the stager and menu
navs? i just want it to fill that space there like the rest of the app
does."

Root cause of both, same place: `render()`'s section dispatcher
(`05-settings-nav-search.js`) wrapped Bag Orders/Internal Freight/External
Orders' HTML in a generic `.pad` div (`padding:10px 14px;overflow:auto`) —
the same wrapper Billing/Reports/Settings/Database use — while Scheduler/
Current Week/Driver Tabs are inserted straight into `#main`
(`main.insertAdjacentHTML`), which is already a flex column
(`main{display:flex;flex-direction:column}`) so their toolbar sits at
natural height and their `.grid-wrap` (`flex:1;overflow:auto`, already
generic, not `.pad`-scoped) fills all remaining space edge-to-edge. `.pad`
gave the three Orders trackers padding-inset content that scrolled as one
block (toolbar included) instead of a fixed header over a filling,
independently-scrolling grid — which is both why their toolbar never got
a real background bar (`plain:true` explicitly set `background:none` to
suit that inset look) and why they never filled the gap the way Scheduler-
style views do.

Fixed both by treating "int"/"xfer"/"ext" exactly like "cw"/"driver" in
the dispatcher — direct `main.insertAdjacentHTML`, no `.pad` — and
dropping `plain: true` from all three `toolbarHtml()` calls so their
toolbar picks up its own real `background:var(--panel)` + `border-bottom`
for free. `.orders-toolbar`'s D234 min-width rules (title/primary-button)
are separate class-based CSS and were unaffected by either change —
confirmed live, pixel-identical before and after.

One real, disclosed behavior change: anything a tracker renders outside
`.grid-wrap` (External's rate-con drop zone, which sits before it; Bag
Orders'/Internal Freight's "+ Add one", which sits after) is now a
persistent flex sibling that never scrolls away with the grid, rather than
scrolling as part of one `.pad` block — verified live as a strict
improvement (drop zone and add-button are now always reachable without
scrolling first), not a regression, but worth knowing if a future agent
wonders why a tracker's trailing button behaves differently from a
Database grid's.

Verified live: External Orders/Bag Orders/Internal Freight toolbars now
sit flush edge-to-edge with a visible panel background and border, same
visual family as Current Week/Driver Tabs; `.grid-wrap` fills all
remaining height down to a persistent "+ Add one"/drop-zone footer;
scrolling a long expanded collapse group (D235) keeps the toolbar and
footer fixed in place, only the grid body scrolls. No console errors.

### D238 — Cache headers on static images/fonts, fixing a real repeated-fetch pattern behind the "harmless" logo console error (2026-09-18)

Nate: "fix that harmless logo error its annoying" (`net::ERR_CONNECTION_
RESET` on `rexius-logo.png`, visible in devtools on and off through this
whole session). Root cause found in `Handler._send` (`app/server.py`):
Cache-Control was only ever set for HTML/CSS/JS (must never be stale,
D51) and `/api/*` (must never be shared-cached) — anything else,
including every static image, got **no cache header and no validator
(Last-Modified/ETag) at all**. With nothing telling the browser it's safe
to reuse a previous fetch, every single reference to the logo — the
static header `<img>` in `index.html`, and the login card's own separate
`<img>` in `renderLoginGate()` (`00-auth.js`) — triggers a genuine fresh
network round trip, not a cache hit. A real repeated fetch of the same
small file in quick succession (most visibly across the login→dashboard
transition, but really on every page load) is exactly the kind of request
pattern that can race a navigation and show up as a spurious
`net::ERR_CONNECTION_RESET` once in a while.

Added a `Cache-Control: public, max-age=86400` branch for `image/*` and
`font/woff(2)` responses — static assets like the logo never change
without also changing filename in this app, so a day of caching is safe
and turns every later reference into a same-page or same-session cache
hit instead of a fresh fetch.

Verified live: `curl -s -o /dev/null -D - .../rexius-logo.png` confirms
the new `Cache-Control: public, max-age=86400` header is present.
Honesty check, not just an assertion: this genuinely eliminates the
*redundant-fetch* pattern that's the most likely real driver, and is
correct, well-justified, low-risk behavior for a file that never changes
in place — but this session's own browser-automation tooling appears to
run with caching disabled (a common automation default, for reproducible
tests), so the console line could still be reproduced here even after the
fix and its absence couldn't be 100% confirmed from inside this tool. In
a normal Chrome tab (Nate's real usage) standard HTTP caching applies and
this should stop recurring. The error was never functionally harmful
either way — the resource always resolved fine on the retry that
follows — and Python's bundled `http.server` (`HTTP/1.0`, connection-per-
request, D24's dependency-free constraint) is not a production-grade
server, so a residual low-level connection quirk under rapid requests
can't be fully ruled out without changing that, which is out of scope for
a cosmetic console line.

### D239 — Truck column on Bag Orders/Internal Freight, sourced from a real `orders.truck_id` (2026-09-18)

Nate: "for the internal freight and bag orders we need a 'truck' column
next to the miles like keep miles and $ next to each other but we need
truck, that should be something we pull anyway when we run the delivery
date function so it should be easy, and then the report can pull the
truck from that column cause itll be way easier than however it currently
does."

New column `orders.truck_id uuid references trucks(id) on delete set
null` (migration `20260918000002_order_truck.sql`). `api_sync_delivery_
dates()` (`app/server.py`, the "Sync Delivery Dates" button both trackers
already have) now stamps `truck_id = l.truck_id` in the exact same
`update ... from load_orders lo join loads l` statement that already
writes `delivered_at` — genuinely free, no new query, per Nate's own
observation. Same staleness model as `delivered_at` itself: refreshed only
when that button runs, not live-tracked on every reschedule. `api_
bootstrap`'s orders query denormalizes `t.number as truck_number` (same
join-and-alias pattern as `customer_name`/`broker_name`) — remember this
next time a client-facing column is added to `orders` (the `api_bootstrap`
explicit-select trap doesn't apply here since that query is `select o.*`,
a wildcard, so `truck_id` itself needed no bootstrap change — only the
denormalized display name did).

**UI:** `truckCell(o)` (`04-views.js`) is a new plain read-only `<td>` —
deliberately NOT another `data-oedit` field, since a manual override would
misrepresent which truck actually ran the load. Placed directly before
Miles in both `bagOrderRowHtml` and `xferOrderRowHtml` (Nate: "keep miles
and $ next to each other but we need truck"), with matching `<th>Truck</th>`
header cells and both trackers' fixed table `width` bumped (+80px) and
`INT_TRACKER_COLS`/`XFER_TRACKER_COLS` (the D235 collapse-row colspans)
bumped to 13/10 to match.

**Report:** `_DUMP_SQL`'s truck resolution now prefers the plain
`orders.truck_id` (joined directly to `trucks`) over the existing
lateral-subquery-through-`load_orders`/`loads` guess, falling back to that
lateral only for an order that hasn't been (re-)synced since getting a
truck — so the dump never loses a truck it could already show, but
converges to the plain-column path Nate asked for as more orders get
synced. Deliberately did NOT touch `_FREIGHT_SQL` (already a plain join on
`loads`, not a lateral, and switching its date-range-filtered truck
resolution to `orders.truck_id` would silently drop any load that hasn't
been through a delivery-date sync yet — a real correctness regression for
a report used for actual freight billing) or `_MILEAGE_SQL` (doesn't
surface truck at all today). Only `_DUMP_SQL` had the actual "lateral
subquery through loads" pattern Nate was describing as convoluted.

Verified live: ran "Sync Delivery Dates" on Bag Orders (2,909 rows synced;
confirmed via `psql` that `truck_id` populated correctly, spot-checked
against the real `trucks` table); Truck column renders directly before
Miles/Transfer $ on both Bag Orders and Internal Freight trackers with
real truck numbers, for orders in both the live and collapsed-Delivered
sections. `node --check`/`ast.parse` clean; server restarted to pick up
the Python changes.

### D240 — Scheduler "home base" visual cue (2026-09-18)

Nate: "i want the scheduler to have unique ui like its the center of the
app if you will, its where i will spend the most of my time so i want it
to have some kind of different bar ui and highlight effect so its obvious
im in scheduler." Asked what I'd suggest before building anything:
recommended against inventing a new visual language — reuse the existing
`--brand` accent (already used for the active-nav pill and primary
buttons) as a distinct frame/rule around the Scheduler specifically,
rather than a new color, but make sure it reads as a genuinely different
*kind* of treatment than the sidebar's own active-nav highlight so it
doesn't just look like ordinary nav state. Nate approved: "yes continue...
do a deliberate home base cue."

Two pieces, both `--brand`-colored, both Scheduler-only:
`#main.home-base{box-shadow:inset 0 0 0 3px var(--brand)}` — a full inset
frame around the workspace (a `box-shadow`, not `border`/`outline`, so it
costs no layout and can't be clipped by `main{overflow:hidden}` the way a
positive outline pushed inward would need special-casing for) — and
`.home-base-bar{border-bottom:3px solid var(--brand)}` on the Scheduler's
own toolbar (a new `className` passed to its `toolbarHtml()` call,
replacing the default 1px `--rule` border with a thicker accent one).
`render()` (`05-settings-nav-search.js`) toggles the `home-base` class on
`#main` itself, scoped tightly to `SEC === "dispatch" && SUB === "sched"`
— Current Week and Driver Tabs, despite living in the same Dispatch
section and sharing the Scheduler's own edge-to-edge layout pattern, are
deliberately excluded; this cue is for the Scheduler specifically, not
"anything schedule-shaped."

Verified live: Scheduler shows a clear green inset frame around the whole
content area plus a thicker green rule under its toolbar; Current Week
(same section, adjacent nav item) shows neither — confirmed via
screenshot the toggle is real, not just present by coincidence of shared
CSS. No console errors.

**Follow-up, same day:** "i want the header bar to be different
aesthetically too" — the frame + thin 3px rule read as too subtle without
looking for it. `.toolbar.home-base-bar` now also sets
`background:var(--brand-soft)` (the same translucent accent wash the
active sidebar item already uses, D172) — a compound selector, since
`.home-base-bar` alone has equal specificity to the base `.toolbar` rule
and needs the extra class to reliably win regardless of declaration
order. Verified live: Scheduler's toolbar now has a visibly tinted green
background at a glance; Current Week (same section) confirmed still
plain, untouched.

**Second follow-up, same day — final direction:** the tinted-bar pass
still wasn't it. Nate: "i dont want that i think we just change the
background color to the accent color on the top header and adjust the
buttons and text contract accordingly and then remove the outlines on the
bottom and sides" (confirmed scope: "just for the scheduler"). Replaced
both earlier passes outright — `#main.home-base`'s inset frame is gone
entirely (and the `render()` class toggle that drove it, now dead code,
removed from `05-settings-nav-search.js`; the toolbar's own
`className: "home-base-bar"` is the only scoping mechanism left, still
Scheduler-only). `.toolbar.home-base-bar` is now a **solid** `--brand`
fill, no border. Text/controls inside it switch to `--brand-ink` (D172's
calculated readable-on-accent color — the same one `.btn.pri` uses
everywhere else in the app) so they stay legible against a fully colored
bar: the title goes `--brand-ink`; plain buttons (Go/Today) become a
ghost/outline treatment in `--brand-ink`; the primary button
("Update Google Schedule") flips to a **solid `--brand-ink` fill with
`--brand` text** — inverted from its normal colors everywhere else in the
app — because a normal `.btn.pri` (brand background, brand-ink text)
would disappear into a now-brand-colored bar behind it.

Verified live: Scheduler's toolbar renders as a solid green bar with a
white title, white ghost-outlined Go/Today buttons, and a white "Update
Google Schedule" button with green text — all clearly legible, no
lingering frame anywhere on the page; Current Week (same section)
re-confirmed unaffected. No console errors.

### D241 — Font-size/Days-shown stepper alignment made robust via absolute positioning (2026-09-18)

D236's flow-based fix (widening `.fb-font` so the following `.fb-fs`
naturally landed at the right X) kept failing in ways this session's own
browser never reproduced — Nate's screenshots showed a real, visible gap
(first ~40px, undershooting; after literally adding one `.fb` button's
measured width — 32px — per his own suggestion, this session's test
browser then showed a ~33px *overshoot* in the other direction). The
likely explanation: the two rows' preceding content is mostly text
(titles, labels, the font-name button's own label), and text width is
system-font-and-rendering-engine-dependent — perfectly reproducible
within one browser, not guaranteed to match between environments. Chasing
an exact `min-width` number was chasing a moving target.

Nate's own proposed fix: "can we make both static somehow and make them
start and lineup on the same pixel width." Implemented literally —
`position: absolute; left: 600px` on both `.fmtbar .fb-fs` and
`.cw-daysshown .fb-fs` (a new wrapper class added around Current Week/
Driver Tabs' "Days shown" label+stepper, `04-views.js`, so the label
keeps sitting immediately before its own stepper in normal flow — only
the stepper itself is pinned, not the label, since Nate's ask was
specifically the two +/- controls, not the labels). `.fmtbar` is already
`position:sticky` (itself a positioning context); `.cw-toolbar` gained
`position:relative` plus its padding normalized to match `.fmtbar`'s exact
`4px 10px` (was `7px 14px` via the base `.toolbar` rule) so `left:600px`
means the identical offset in both — otherwise the differing padding
alone would reintroduce a small, constant mismatch. This is now
completely immune to how wide the preceding title/label text renders, in
any font, in any browser — the whole point.

Guarded behind `@media (min-width: 1200px)`: absolute positioning doesn't
participate in flex-wrap, so pinning either stepper at a viewport narrow
enough that its own row's siblings wrap to a second line would strand it
disconnected from the content it's supposed to sit next to. Below that
width, both rows fall back to plain flow (D236's approach) — alignment
matters less there since the rows are already visually broken up
differently by the wrap itself.

Verified live at 1600×900: `getBoundingClientRect().left` for both
`.fb-fs` spans is **exactly** 800, a 0px difference — not "close," exact
— on Current Week and Driver Tabs alike. Re-verified at 1000×700 (below
the 1200px guard) that the fallback layout wraps cleanly with nothing
overlapping or stranded. No console errors.

### D242 — Scheduler home base, final direction: left accent rail + bold title (2026-09-18)

After two solid-fill passes (D240) both read as too loud, Nate: "why dont
we build a few different options in a model for me to pick from... you go
ahead and suggest some options." Built a standalone comparison artifact
(five directions, faithfully recreated app chrome/tokens, click to
preview each live) rather than iterating blind in the real app again —
https://claude.ai/artifact/TDvU321bYs5fAY2aST9uJz. Options offered: solid
accent fill, left accent rail, dark command bar, accent gradient, badge +
bold type.

Nate's pick: "left accent rail and making the scheduler text bigger and
bolder. i like that." Implemented as the simplest of the five to build,
by design — the toolbar's background goes back to the normal `--panel`
(so nothing about Go/Today/the primary button needs the D240 contrast-
inversion treatment anymore; they're exactly the same styling as every
other toolbar's buttons) — only a `::before` accent stripe on the left
edge (absolutely positioned, no layout cost) and the title itself
(`color:var(--brand)`, bumped from `--fs-body-sm` to `--fs-h2`,
`font-weight:800`) carry the "this is home base" signal. Still scoped
purely through `vScheduler()`'s own `className: "home-base-bar"` — no
separate `#main` class or `render()` toggle exists anymore (removed with
D240's second follow-up).

Verified live: Scheduler shows a clean green left rail with a noticeably
larger, bold, green "Scheduler" title; Current Week (same section)
confirmed still plain. No console errors at all this pass.

**Follow-up, same day:** "too big on the text, im okay with it being the
older size but making it extra bold and the accent color is a great
touch." Dropped the `font-size:var(--fs-h2)` override — the title is back
to the normal `.toolbar h2` size (`--fs-body-sm`) — and pushed
`font-weight` from 800 to 900. Verified live: title reads at its usual
size, visibly heavier than the standard 700 weight, still green, rail
unchanged.

### D243 — Logo click jumps to Scheduler, today (2026-09-18)

Nate: "can we make when you click the rexius logo at the top left take
you to the scheduler i think that would be cool almost like a home button
without being one. hidden feature." `#logo-home` id added to the
`.brand-mark` span (`index.html`, the static header logo — not the
separate copy `renderLoginGate()` renders pre-auth, which has nowhere to
navigate to yet); click reuses `runShortcut("today")` verbatim (same
"Go to Scheduler, jump to today" behavior the `Alt+T` shortcut already
has) rather than duplicating that logic. Deliberately minimal affordance
per "without being one" — just `cursor:pointer` on `.brand-mark`, no
hover background/border change, no title tooltip that would spoil the
"hidden feature" framing by explaining itself on hover.

Verified live: from External Orders, clicked the logo — landed on
Scheduler scrolled to today's row, exactly like the existing Today
shortcut. No console errors.

### D244 — Rate-con ingestion hardened against 133 real matched rate cons (2026-09-18)

Nate: "use the rate cons in the system that we split from the docs we
matched with order import to train the ocr for adding new rate cons and
creating orders to ensure that feature is rock solid." Built
`scripts/test_ratecon_extraction.js` (one-off, Node, kept as a reusable
regression test — not run automatically): loads the D225 pipeline's 133
already-matched `rate_con` documents (the answer key — which real order
each one belongs to is already known) plus the real OCR text Vision
captured for each page (`output/sent-2026/ocr.jsonl`), and runs the
UNMODIFIED real `parseRateCon()`/`findBroker()`/`matchBrokerForFile()`
from `02-chips-extract.js` (loaded via Node's `vm` module, not
reimplemented) against every one, comparing extracted broker/load #
against the real order's recorded values. Same fixture-driven-tightening
methodology as D27→D105, just against 12x more real documents than that
set had.

Baseline: broker match 63.2% (84/133), load # match 49.6% (65/131). Three
real, confirmed bugs found and fixed:

1. **Literal broker-name-in-text matching picked whichever party matched
   FIRST in `DB.parties`' array order, not the one that actually occurs
   first in the document** — confirmed on a real fixture (an "Inland
   Transport" rate con whose pickup stop is a real customer, "Clarkes
   Sheet Metal"; both names appear literally in the text, and array order
   picked the pickup location instead of the broker in the letterhead).
   Fixed in `parseRateCon` (`02-chips-extract.js`) to take the match with
   the smallest `text.indexOf` — the broker/sender's own name is reliably
   the earliest such mention in practice.
2. **`LOAD_PATS` had no pattern for "Freight Bill #" or "Our Billing #"**
   — Tradewinds' template prints both "Trip #:" (the carrier's own scratch
   number) and "Freight Bill #:" (the number Nate actually records as
   `broker_load_no`) on the same line pair, and the old pattern order
   matched Trip # first since Freight Bill # wasn't in the list at all.
   Nationwide's template splits "Our Billing #" from its value across a
   flattened two-column OCR read (`"Our Billing # :\nCompany :\n165845"`).
   Both patterns added to `LOAD_PATS`, ahead of "trip"/"order" — confirmed
   against 3+ real fixtures each before committing.
3. **Two real data issues, not code**: `parties` had a duplicate
   "Tradewinds Brokerage" row (no comma/Inc, one incomplete order attached)
   perfectly tying the real "TRADEWINDS BROKERAGE,INC." row on every
   filename-based fuzzy match — archived (`broker_archived_at`) rather
   than deleted, per the existing archive-don't-delete convention; its one
   attached order is untouched. "NATIONWIDE TRANSPORT SERVICES, INC. +"
   had a stray trailing " +" (same class of typo as this session's earlier
   "Meza Logstics" fix) that silently defeated the literal-substring check
   for every Nationwide document, forcing a fallback to filename-token
   matching that then collided with the unrelated customer "NW Natural
   Gas" on the shared two-letter token "NW" — fixed by correcting the
   name.

After all four fixes: broker match 97.0% (129/133), load # match 88.5%
(116/131). Remaining gaps are genuine edge cases, not regressions: pages
that are pure boilerplate/terms with no load number printed at all (a
correct "nothing to extract" result), one-off informal broker templates
("Reference: ORD-P234829" instead of any recognized label), and a
"Trade"-abbreviated filename with no clean text-layer match — none
common enough across the 133-document corpus to justify a broader
matching-algorithm change without more fixtures. `solomon`/`po` match
rates are not meaningful metrics here (a broker's own rate con never
prints Rexius's own Solomon number — it doesn't exist yet when the rate
con is issued) and were excluded from the pass/fail read.

Verified live end-to-end, not just offline: fetched a real already-billed
order's own stored rate-con PDF via `/api/file/...`, fed it through the
real `#file-ratecon` input/`ingestRateCon` path in the running app —
correctly matched to its existing order via broker + load # ("Freight
Bill #: B178301", not the "Trip #: 205,495" it used to grab). Cleaned up
every artifact the test created afterward (the duplicate `documents` row
and stored file it attached, and reverted the order/`order_stops`/
`load_stops` rows and two junk `locations` rows that `ingestRateCon`'s
own blank-pickup/delivery autofill created from OCR noise) — confirmed
the order and DB back to their exact pre-test state, and confirmed clean
`created_at`/console-error checks after.

### D245 — Day notes folded into the full data dump, dropped as their own report (2026-09-18)

Nate: "i don't need dispatch notes being its own report, i just wanted to
make sure the field shows if i export the entire app." The standalone
"Day notes" card/report (`_DAY_NOTES_SQL`, `PARAM_SQL["day_notes"]`,
`_REPORT_LABELS["day_notes"]`, the `day_notes` entry in `vReports`'
`reps` array) is removed entirely. `_DUMP_SQL` ("Export entire app," the
one Nate meant) gains a `day_note` column instead — left-joined on
`day_notes.note_date = coalesce(ld.scheduled_date, o.delivered_at,
o.ordered_at)::date`, the exact same `activity_date` expression every
order in the dump already sorts/pivots by, so a day note surfaces on
whichever order(s) land on that calendar date. `dayNoteModal`'s copy
("Included in the Day Notes export") updated to name the dump instead.
`day_notes` stays in `api_bootstrap` (`DB.day_notes`, unrelated — that's
what renders notes under the date on the Scheduler and feeds the popup)
— only the reporting path changed.

Verified live: restarted the server, confirmed `GET /api/report/dump`'s
header row carries "Day Note" as the last column; inserted a throwaway
day note on a date a handful of real orders already share, confirmed it
appeared on every one of those rows in the exported CSV, then deleted
the throwaway note. Reports page screenshot-confirmed the "Day notes"
card is gone and the dump card's description now mentions day notes.
Console clean.

### D246 — Invoice batch OCR fallback, tested against 326 real matched invoices (2026-09-18)

Nate: "you're free to test invoices to make sure the invoice batch
system works properly using invoices we imported and matched with."
Built the same kind of live end-to-end check as D244, this time for
`ingestBatch`/`extractInvoiceInfo` (`06-modals-grids.js`/
`02-chips-extract.js`): merged all 326 real `invoice` documents the D225
pipeline already matched into one combined PDF (each real page paired
with a blank filler, satisfying `ingestBatch`'s "2 pages per invoice"
split), uploaded it through the real `#file-batch` input in the running
app, and read the resulting pool pills' extracted invoice numbers
straight out of the DOM — no `assignInvoice` call, so this makes zero
database writes and needed no cleanup.

**Baseline: 0 of 326 got anything — every real invoice pill fell back to
a blank "Invoice N" label.** Root cause: `extractInvoiceInfo` only ever
read `pdfjsLib`'s embedded text layer, with no OCR fallback at all —
every one of these real invoices is a scanned/faxed page with no text
layer (the same reason D225 needed a macOS Vision OCR pass in the first
place), so the position-aware extraction and both regex fallbacks always
had empty input to work with. `ingestRateCon` solved this exact problem
for rate cons back in the original D7 design (thin text → `ocrPdf()` →
re-run the regexes against the OCR'd text) — `extractInvoiceInfo` never
got the same treatment. Added it: a "thin" text layer (same `<40`
non-whitespace-char threshold `ingestRateCon` uses) now triggers
`ocrPdf(b64)`, and the invoice-number/Solomon regexes re-run against the
OCR'd text; the position-aware item-coordinate pass is skipped on that
path since it only means anything against a real text layer.

Re-tested a 22-document sample (all with a known real order attached,
spanning most of the same brokers as the D244 corpus): every single one
now extracts a plausible real invoice number via OCR (up from 0). Did
not score these against an exact ground-truth field — `invoices.
invoice_number` exists in the schema but the table has zero rows locally
(never populated by any import), and the printed number on a real
invoice is a plain sequence number, not `orders.solomon_order_no`'s
dash-separated format, so there's no dash-format match to expect here
(the same lesson D244 already drew for rate cons — Rexius's own
generated numbers don't appear on paperwork issued before they existed).
Spot-checked several extracted numbers by eye against their source
filenames' own embedded order references — consistent, plausible reads,
not garbage. Did not run the full 326-document corpus through OCR live
(tesseract.js serializes on one shared worker, and 326 real pages would
take on the order of 15-20 minutes) — the fix targets the exact
mechanism (`ocrPdf`) already proven correct at scale in D244, and Nate's
ask here was permission to check, not a rock-solid mandate like D244's.

### D247 — Settings tabs cycle with Left/Right; Shift+Up/Down reaches Settings from anywhere (2026-09-18)

Nate: "when im in the settings page i'd like to be able to use left and
right arrow keys to cycle tabs... can we create a shift arrow down and
up functionality that allows me to go through the nav in ways that i
normally can't... like if i hold shift itll actually take me to the
settings." Two related gaps in the existing D209/D214 arrow-nav cycler:

1. Plain Left/Right already cycles `subsOf(SEC)` generically
   (`cycleNavSub`) and Settings' own tabs already come from that same
   `subsOf("settings")` call (`settingsTabsHtml`) — the only reason it
   didn't already work is `navArrowShortcutAvailable`'s guard required
   `SEC` to be a literal member of `NAV`, and Settings deliberately lives
   outside `NAV` (D54, reached from the header gear). Widened that one
   check to also accept `SEC === "settings"` — no new cycling logic
   needed, it rides the existing machinery for free.
2. New `cycleNavSectionWithSettings(delta)` (`01-core.js`) — the same
   shape as `cycleNavSection` but appends Settings as one more stop after
   the normal visible sections, so Shift+Up/Down cycles Dispatch → Orders
   → Billing → Reports → Database → **Settings** → back to Dispatch.
   Landing into Settings reuses `navSectionLandingSub("settings")` (already
   generic, no changes needed) so it reopens on whichever tab was last
   open rather than always General — same behavior every other section
   cycle target already gets.
   `navArrowShortcutAvailable` gained an `allowShift` param (only the new
   Shift+Up/Down path passes `true`) and an `axis === "section-ext"` case
   for its length check — every other caller keeps rejecting a held Shift
   exactly as before, so this never fights a real shifted shortcut or a
   shift-click/shift-select gesture elsewhere. Plain arrows are completely
   unchanged: from Settings, a plain Up/Down still falls through to the
   normal 5-section cycle (Settings isn't in that list, so it lands on
   Database or Dispatch depending on direction) — only a held Shift can
   reach or leave Settings via Up/Down.

Verified live: in Settings, ArrowRight stepped General → Shortcuts → Time
Calc → Access → wrapped to General; from Scheduler, Shift+ArrowDown
stepped Dispatch → Orders → Billing → Reports → Database → **Settings**
→ wrapped to Dispatch, and Shift+ArrowUp from Dispatch landed directly on
Settings going the other way. Plain ArrowUp/Down from Settings correctly
skipped Settings and landed on Database/Dispatch. (Note: this Browser
pane's synthetic `key` action doesn't reliably set `shiftKey` on
Arrow keys — same class of gap as D226's Enter/Return trap — verified
instead with a real dispatched `KeyboardEvent({key:"ArrowDown",
shiftKey:true})` via `javascript_tool`.)

### D248 — Scheduler cell wrap-around no longer leaves the destination column clipped behind the sticky date rail (2026-09-18)

Nate: "on the scheduler if i select a box and use the arrow keys to
cycling thru when it cycles back through to the front, so wayne in this
case, it doesn't show his column at normal width it cuts it off."
Root cause: `move()`'s cell navigation (`06-modals-grids.js`) called
`t.scrollIntoView({block:"nearest", inline:"nearest"})`, which has no
concept of a *sticky* sibling column overlapping the target — arrowing
right off the last truck column wraps to the next row's first truck
(Wayne), and the moment that cell's left edge crosses into the region
still nominally "inside" the scrolled viewport, the browser considers it
already visible and scrolls no further, even though the sticky
`td.rowhd` date column (`position:sticky;left:0`, 88px) is still sitting
on top of it, clipping roughly its first third.

New `revealCell(td)` wraps the existing `scrollIntoView` call with a
second pass that measures real bounding rects: it finds the row's own
`td.rowhd` (sticky-left) and the table's `thead` (sticky-top, every
grid), computes the actual left/top bounds those impose past the
container's own edges, and nudges `scrollLeft`/`scrollTop` directly when
the cell falls inside that overlap — a no-op wherever a grid has neither
(replaces both call sites in `move()`, so Database/order-tracker grids
get the same top-header-clip protection for free even though the
reported symptom was Scheduler-specific).

Verified live: selected the last cell of a Scheduler row scrolled fully
right, pressed ArrowRight to wrap to Wayne's column on the next row —
`scrollLeft` landed at exactly 0 and the cell's measured left edge sat
flush against the sticky date column's right edge (no overlap), screenshot-
confirmed Wayne's column rendering at full width instead of clipped.

### D249 — Orders nav badges no longer count billed/delivered/cancelled orders as needing placement (2026-09-18)

Nate: "theres an active order on the notifcation for external orders but
there is no order." Traced to a real stray row: an external order
(`59e1e27d…`, created 2026-09-14, attached to the duplicate "Tradewinds
Brokerage" seed party archived in D244) that was never scheduled but
already has `billed_at` set — `navUnplacedCounts()` (`01-core.js`) only
ever checked placement + Staging membership, with no awareness of
`billed_at`/`delivered_at`/`stage`, so a closed-out order that happens to
have never been scheduled counts toward the "needs placement" badge
forever. The External Orders tracker's own "Billed" collapsed group
(`vOrders`, `04-views.js`) already treats `billed_at` as the live/done
boundary, and Bag Orders/Internal Freight use `delivered_at` the same
way — `navUnplacedCounts` now matches each tracker's own boundary
exactly, plus excludes `stage === "cancelled"` across all three (D93: a
cancelled order is detached from scheduling for good, so it can never
need placement either). `placement()` is still computed once per call
(D222) and passed into the new shared `needsPlacement(o, pm)` helper,
not recomputed per order.

Left the stray order itself alone — pending Nate's call on whether to
delete it (it also has a nonsense `po_number` of "Tradewinds Brokerage",
consistent with leftover test data from this session's earlier D244
work, but a billed order is exactly the kind of record D29 says stays
locked, so it wasn't unilaterally touched here).

Verified live: before the fix, the collapsed sidebar's Orders icon
carried an aria-label of "Orders, 1 unplaced orders"; after, reloading
shows a plain "Orders" label with no stray count. Console clean. The one
stray order causing it (`59e1e27d…`, billed but never scheduled, garbage
`po_number` of "Tradewinds Brokerage") was confirmed leftover test debris
and deleted per Nate's go-ahead ("yes you can clear the billed data that
wasnt scheduled").

