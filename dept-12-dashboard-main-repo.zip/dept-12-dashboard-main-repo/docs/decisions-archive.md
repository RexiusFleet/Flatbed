# Decision Log — Archive (D1–D124)

Older decisions, moved out of `docs/decisions.md` to keep the working log lean (D69, extended D102, extended D129). Full reasoning preserved; newest active decisions live in [`decisions.md`](decisions.md).

## D1 — Fresh repo, fresh history

`dept-12-dashboard` starts clean. `NateTooNice/SHEETS-TMS-APPSCRIPT` keeps its
40+ commits on GitHub as the archive; nothing was renamed or force-pushed over.

The invoicing app never had a repo — it was committed here verbatim as `9fb9ea6`
before any reorganization. Nate has other local copies and doesn't need it
preserved, but the commit costs nothing and stays.

## D2 — Three identifiers on a load, none of them the primary key

| Column | Example | Origin |
|---|---|---|
| `solomon_order_no` | `12-0426-0001` | Microsoft Solomon, the current accounting system |
| `broker_load_no` | `884895` | the broker's own number, off the rate con |
| `id` | uuid | ours — the only real primary key |

These are independent namespaces. Internal Rexius loads carry a Solomon number
and usually no broker number; external broker loads carry a broker number and get
a Solomon number when billed; some have both.

`solomon_order_no` gets first-class treatment because **Solomon is the ERP
Acumatica will replace** — it is the join key to accounting before and after that
migration, not an incidental reference.

Reuse the canonical regex already in the TMS code rather than writing a new one:
`/\d{2}-\d{4}-\d{4}/` at `legacy/tms-appsscript/Code.js:517` and `:876`.

## D3 — The load chip is rendered, never stored

Chips are derived from `loads` + `load_stops` + `parties`, so they become a render
function rather than a column.

Today the chip text *is* the data, which is why `extractExternalKeyFromChip`
(`legacy/tms-appsscript/Code.js:871`) has to reverse-engineer it with three
fallback strategies. Storing rendered text and parsing it back is the specific
mistake this project exists to undo.

## D4 — Driver and truck are separate entities with a time-ranged link

`drivers`, `trucks`, and `driver_truck_assignments (driver_id, truck_id,
effective_from, effective_to)`.

The Sheet conflates them into one column header string (`"Jordan 63/80 F"`) and
has a *Swap Trucks Between Drivers* feature with nowhere to record the change.
The consequence is silent: a load hauled in March reports whatever truck is
assigned *today*. The time range makes historical reporting correct and makes
truck swaps lossless.

## D5 — `++` broker suffix is legacy noise — strip at import

7 of 102 broker names carry a `++` suffix (e.g. `ROSBORO LUMBER CO ++`).
Confirmed with Nate: no lasting meaning. `normBroker`
(`legacy/invoicing-local/index.html:1500`) already strips it via `/\+\+.*$/`.

Strip at import; do not carry into Postgres and do not model a flag for it.

## D6 — Restore OCR in Phase 4

**The version currently in use cannot read scanned rate cons at all.**

Verified against the real fixture: `fixtures/Rosboro 884895.pdf` is a 4-page
scan, and pdf.js extracts **4 characters** from it. `parseRateCon` returns its
`loadNum: 'XXXXX'` fallback.

This is a capability regression, not a bug. The Apps Script version OCR'd via
Drive (`legacy/invoicing-appsscript/Code.js:120`, `Drive.Files.insert` with
`{ocr: true}`). The local rewrite dropped it deliberately —
`legacy/invoicing-local/index.html:1438` reads *"Local rate-con text extraction
(replaces Google Drive OCR)"* — and falls back to `"OCR unavailable — enter
manually."` at `:2399`.

Since the whole point is granular queryable data, scanned loads landing with
empty fields defeats the goal. Phase 4 restores OCR in the ingestion pipeline.

## D7 — Filename is a first-class matching signal, ranked above PDF text

Originally ranked third in the matching cascade. Demoting PDF text above it was
wrong, and testing showed why: on a scanned con the text layer is empty, so the
filename is the *only* signal available.

Measured on the real fixture:

| Input | Function | Result | Score |
|---|---|---|---|
| `"Rosboro 884895"` | `matchBrokerForFile` | `ROSBORO LUMBER CO ++` | **0.85** |
| `"Rosboro 884895"` | `findBroker` | `ROSBORO LUMBER CO ++` | **0.90** |

The load number `884895` is in the filename too. Revised cascade:

1. Exact `solomon_order_no` via `/\d{2}-\d{4}-\d{4}/` — highest confidence
2. Exact `broker_load_no` + broker match
3. **Filename match** — `matchBrokerForFile` (≥0.4) / `findBroker` (≥0.45)
4. PDF text extraction / OCR
5. Below threshold → **Unmatched Documents queue**, manual attach. Never
   auto-attach below threshold.

Reuse the existing tuned matchers rather than writing new ones —
`findBroker:1512`, `matchBrokerForFile:1567`, `normBroker:1500`, and the
`GENERIC_SET` stopword list at `:1539`, which encodes real domain knowledge about
freight company naming.

No barcode/QR option: it would require changing what brokers send us, which we
don't control.

## D8 — Auto-deploy stays disabled in this repo

`legacy/tms-appsscript/.github/workflows/deploy.yml` is `clasp push --force` to
the live Apps Script project on every push to `main`. It moved *with* its code
into `legacy/`, so GitHub won't execute it — workflows only run from the repo
root.

Deliberate. Re-enabling is a Phase 3 decision made on purpose, not a side effect
of a file move.

## D9 — The invoice amount is the money of record, not the rate con

Nothing in either legacy system captures a dollar amount. `extractInvoiceInfo`
(`legacy/invoicing-local/index.html:1738`) pulls the invoice number and customer
name only.

Revenue comes from `invoices.amount`, captured at invoice generation. Nate's
reasoning: the rate con and the invoice should agree, but the rate con may need
adjusting depending on how a load actually goes, and *"the price only matters on
the close out anyway"* — invoice generation is what closes a load. The invoice is
therefore the later and more authoritative number.

## D10 — Three loads per driver per day, as policy not layout

The sheet gives each date 3 rows (`legacy/tms-appsscript/Code.js:622`,
`cwRow = 2 + (d * 3)`), which capped a driver at 3 loads a day. Confirmed that
was the intent, not just formatting.

Kept at 3 via a `check (slot between 1 and 3)` on `loads`. It is now a business
rule that can be changed by editing one constraint, rather than a consequence of
how tall a spreadsheet row is.

## D11 — Miles are typed in, sourced from the existing customer list

Mileage already exists in the sheet's customer list, so it seeds
`locations.standard_miles`. `loads.miles` holds the actual for a run and defaults
from the location.

Nate plans to connect the **Motive ELD API** to pull real mileage eventually.
Explicitly future work — but it is why miles lives on the load rather than being
computed on the fly, so an ELD feed can populate it later without a migration.

## D12 — Season is fixed: Jan–Jul peak, Aug–Dec off

The `OFF SZN` block in the Internal Order Tracker reflects real seasonality, not
a spreadsheet-width workaround, and the month boundary is fixed year to year.

Computed in `v_orders_reporting` rather than stored — a fixed rule needs no
maintained column.

## D13 — Order-to-delivery is the KPI

`days_order_to_delivery` is the primary metric, per customer. Release-to-delivery
is also exposed since `released_at` is captured anyway, but order-to-delivery is
the one that matters *"for simplicity"*.

`released_at` means production handed over the paperwork saying a load is ready
to haul. Releasing and scheduling are separate acts, which is why they are
separate stages and separate timestamps.

## D14 — PODs attach to stops, but are not required per stop

Whether a multi-drop load comes back with one POD or one per drop **varies by
customer**. So `documents.load_stop_id` allows per-stop attachment, while
`documents.load_id` allows one-per-load, and nothing requires one per stop.

`v_loads_missing_pod` therefore reports loads with *no* POD at all rather than
assuming a count.

## D15 — Outside carriers are a party on the load, with no margin tracking

An "Outside Carriers" load is one brokered out to another trucking company.
Modeled as `loads.carrier_party_id` with no driver or truck, enforced by the
`loads_driver_xor_carrier` constraint.

Nate chose this over the variant that also tracks what the carrier was paid, so
there is **no carrier-cost or margin field**. Adding one later is a single
nullable column plus a view change — noted so it is a deliberate omission rather
than an oversight.

## D16 — Internal loads have two money paths, not one

This surfaced during Phase 2 questioning and is in neither legacy codebase.

An internal load generates:

1. **A freight transfer to the bag plant** — `loads.internal_freight_amount`,
   entered by hand, never calculated. Aggregated weekly per truck by
   `v_freight_transfer_weekly` and posted into `freight_transfers`.
2. **An end-customer invoice** — Nate does the baggers' billing too.

The sequence at close: paperwork comes back (physical today, digital later) →
load closes → internal freight transfer → bill the end customer.

`loads_internal_freight_only` enforces that only internal loads carry the bag
plant charge.

## D17 — East/West is discarded

The East/West organization in the Internal Order Tracker is spreadsheet layout,
not a business dimension. Region, where it matters, derives from the delivery
address on `locations`.

## D18 — Both departments live in one orders table

`07-xxxx-xxxx` orders belong to another department, but Nate delivers ~80% of
them and needs to know what is coming and what stage it is at. They go in the
same `orders` table; `department` is a stored generated column from the prefix
(`left(solomon_order_no, 2)`).

## D19 — The app is four sections, and the grid is a real spreadsheet

**Sections:** Dispatch · Billing · Database · Reports, with sub-tabs inside each.
Nav is two-level: sections across the top, sub-tabs beneath.

**The scheduler is the whole year**, top-down scroll, ~1000 rows. Not a week at a
time. Jump by typing a date or hitting Today. Sundays stay in the grid but
minimized to one short row — weekends are rare and, when they happen, Saturday.

**Cells accept free text**, exactly like the sheet. A cell holds either a dragged
load or whatever you type — an ad-hoc job, a note, "SHOP — DOT inspection".
Nate's call, and the right one: the sheet never blocked him and neither should
this. The tradeoff is that typed-in loads are not structured records until
they're linked to an order; the reconciliation problem is deferred, not solved.

**Full spreadsheet keyboard model** on the scheduler and every Database table:
type-to-edit, Tab/Enter/arrows to move, Esc to cancel, Delete to clear. Deleting
a placed load returns it to staging rather than destroying it.

**Why this matters beyond the UI:** the Database section is where Bagger Customer
annotations are written, and they propagate to every chip for that customer. That
is the loop Nate asked for — write it once, see it on the board while
reshuffling. It is informational only. Nothing validates or blocks an assignment
(see the working-style note in `CLAUDE.md`).

## D20 — Equipment constraints are annotations, never rules

Rejected during Phase 5 prototyping. The proposal was to block dropping a
"straight trailer only" customer onto a flatbed driver.

Nate's reasoning: *"our flatbeds are straight trailer or b train"* — so the
mapping isn't clean and the rule would be wrong as often as right. What he
actually wants is to **write it down and have it appear on the chip** so he
doesn't forget when reorganising the schedule. Same for Early/Afternoon: *"its to
mitigate logistics errors nothing more."*

Generalise from this: prefer surfacing information over enforcing logic. This
domain has too many real-world exceptions for validation to be a favour.

## D21 — Rate con creates the order; documents hang off the order forever

Rate con intake moved **out of Billing** and became the order-creation path.

Drop a rate con → text (or filename) is parsed for broker, load #, PO, rate and
any Solomon number → an `orders` row is created → the PDF is filed against it.
The order exists **before** it has a Solomon number, which `orders` already
allowed (nullable column, partial unique index), so no schema change was needed.

Documents attach to `order_id` and follow it everywhere. Clicking an order
anywhere in the app opens a drawer with its fields, its documents, what's
missing, and a drop target to add more at any time.

**Scheduling is allowed without a Solomon number, but flagged.** The chip carries
a `NO ORDER #` marker and the drawer says so. It cannot be closed or billed until
the number is filled in.

## D22 — Billing is assignment and export, not intake

Invoices come **from Solomon**, dropped in as a batch: one PDF, two pages per
invoice. The batch is split, each page scanned for its invoice number and any
Solomon number, and the pieces sit in a pool until dragged onto an order. Ported
from `legacy/invoicing-local/index.html:2341`.

**Package contents differ by type:**
- external → rate con + POD/BOL + invoice
- internal → signed delivery paperwork (+ invoice)

**Export has three modes:** merged PDF, individual files, or Outlook draft.
The Outlook draft is merged-only — a draft with eight attachments is not what a
mill wants. The `win32com` bridge is ported verbatim from
`legacy/invoicing-local/server.py`, retry semantics included; it stays
Windows-only.

**Group merge** combines several orders into one PDF for the largest mill, which
only accepts a single file. The legacy multi-broker guard is ported
(`legacy:3090`): grouping refuses to proceed across two different customers,
because a package addressed to one customer containing another's paperwork is
the worst possible bug in this system.

## D23 — Match against the whole AP directory, not just brokers

Caught while testing the real fixture. `matchBrokerForFile` was filtering to
`is_broker`, so `Rosboro 884895.pdf` matched nothing — Rosboro is a *mill*, a
customer, not a broker.

The legacy app matched against the entire **outside customer list** tab, which is
the AP-billing directory and contains mills and direct customers as well as
brokers. Rate con filenames are frequently the mill, not the broker. Corrected to
match `is_broker OR is_customer`.

With the fix, the scanned Rosboro rate con — **zero extractable text across four
pages** — resolves to "Rosboro Lumber Co" and load `884895` purely from its
filename. That is D7 working on real data rather than in principle.

## D24 — The application is Python + Postgres + vanilla JS, no build step

`app/server.py` serves the UI, exposes a JSON API over local Postgres, stores
documents on disk, and hosts the Outlook bridge. Stdlib plus `psycopg`.

No framework, no bundler, no `node_modules`. It has to start with one command on
an office Windows machine and keep working when nobody is maintaining a
toolchain. The existing local app set this precedent and it was the right call.

Free-text scheduler cells live in their own `schedule_notes` table rather than in
`loads` (migration `20260805000002`), so `loads` still means "a truck run that
happened" and every revenue and utilisation query stays honest without filtering.

## D25 — Everything that is not Postgres goes through an adapter

The target is **Supabase plus a hosted web app**. No local assumption may leak
into the core, so `app/adapters.py` isolates the two that would:

| Concern | Local (now) | Hosted (port) | Selected by |
|---|---|---|---|
| Documents | `LocalStorage` — files under `app/storage/` | `SupabaseStorage` — REST, written and **untested** | `DEPT12_STORAGE` |
| Mail | `OutlookDraft` — win32com, Windows only | `GraphDraft` — Microsoft Graph, written and **untested** | `DEPT12_MAIL` |

`documents.storage_path` was already storage-agnostic, so swapping storage is one
class and nothing else.

**Mail is the one that does not simply port.** Outlook COM automation requires
Outlook running on the same machine as the code — a hosted web app cannot do it,
at all, ever. Nate asked for the Outlook draft to survive, and it can, but only
via **Microsoft Graph**, which needs an Entra app registration with
`Mail.ReadWrite`. Graph still creates the draft in his real mailbox, so the
behaviour survives even though the mechanism cannot. That is a decision to
schedule, not a port to perform.

`NoMail` is the honest fallback: it reports *why* it is unavailable rather than
failing silently, and the UI shows that message.

Remaining local couplings, for the port checklist:

- The Python server itself. Under Supabase this becomes Edge Functions, or the
  browser talks to Supabase directly via PostgREST and RLS. The JSON API surface
  in `server.py` is the contract to reproduce.
- `DEPT12_DSN` points at a local socket; a hosted DSN is a config change.
- pdf.js / pdf-lib and all merging are already client-side and port unchanged.

## D26 — Correction: how the scan finding was actually verified

Recorded because the earlier commit message credited the wrong evidence.

An end-to-end test dropped what it believed was the Rosboro rate con and
concluded "scanned, no text layer". It had in fact fetched a **seed document row
whose `storage_path` pointed at a file that never existed**, received a 404, and
dropped the 22-byte JSON error as if it were a PDF. Empty text was guaranteed
regardless of the fixture.

Re-tested by uploading the real fixture through `POST /api/document` and fetching
it back: 321,021 bytes, byte-identical to source, `%PDF-` header, **4 pages, 0
extractable characters**. The conclusion was right; the test that appeared to
prove it was not.

Two fixes: `supabase/seed.sql` now warns that its document rows have fabricated
paths, and `/api/file/` URL-decodes properly so filenames containing spaces work.

The lesson worth keeping: a test that cannot fail is not a test. "No text
extracted" looks identical whether the document is a scan or was never fetched.

---

## D27 — OCR restored client-side, via a vendored Tesseract.js worker

Phase 4. Scanned rate cons (D6, `fixtures/Rosboro 884895.pdf` — 4 pages, 0
extractable characters) had no way to be read at all since Phase 2 dropped the
old Google Drive OCR path (`legacy/invoicing-appsscript/Code.js:118`,
`Drive.Files.insert(..., {ocr:true})`) — that mechanism is Apps Script–only and
cannot run from a hosted web app.

Restored the same way pdf.js and pdf-lib are already handled (D24): vendored,
client-side, no server or cloud account. `app/web/vendor/` gained
`tesseract.min.js`, `worker.min.js`, `tesseract-core.wasm.js` (the wasm
inlined as base64 rather than a separate `.wasm` file, to sidestep the
static-file MIME-type question entirely) and `eng.traineddata.gz` — about
15.7 MB added, versus ~2 MB for the existing pdf.js vendor files. Deliberate
trade: a heavier repo and a slower first OCR call (the model has to load once)
against zero new external dependencies and unchanged offline operation.

`ingestRateCon` (`app/web/app.js`) now checks the pdf.js text layer first; if
it comes back under ~40 non-whitespace characters, it rasterizes each page to
a canvas (`pdfPageImage`, 2.5× scale for legibility) and runs it through a
lazily-created singleton Tesseract worker (`getOcrWorker`, `ocrPdf`). Worker
paths must be **absolute** (`location.origin + "/vendor/..."`) — the worker's
own base URL is a `blob:` URL, so relative paths that resolve fine on the main
page fail inside it (`importScripts` throws `SyntaxError`).

**Verified against the real fixture**, not synthetic data: OCR text pulled
"Rosboro Lumber Co" and a $750 rate directly from the document body, so the
broker now matches on `document_text` — the priority above filename in D7's
pipeline — instead of falling all the way through to the filename-only match
D23 documented. `matched_by` was also corrected in the process: it was
hardcoded to `"filename"` unconditionally, even when a normal text layer was
read; it now reflects what actually happened (`document_text` vs `filename`).

**Known false positive, left as-is:** the same test run pulled load
number `"owes"` and PO `"Box"` out of OCR noise — the PO regex
(`/\b(?:PO|P\.O\.)\s*#?\s*...`) matched the "PO Box 20" mailing address in the
letterhead. This regex is ported verbatim from the legacy app and was already
latent; OCR just gives it real text to misfire on where a scanned document
previously gave it nothing. Per the working-style rule (surface information,
don't guess at rules), this is flagged here rather than silently tightened —
tuning the extraction regexes is a separate, Nate's-call piece of work.

**Not tested:** OCR page-render time was extremely inconsistent in this
session's browser-automation environment — one page took over 100 seconds due
to what looks like renderer/tab throttling under the automation tooling, then
subsequent runs completed quickly. Worth a real-user timing check (tab
focused, not driven by CDP) before calling Phase 4 done — if OCR genuinely
takes 30+ seconds per page for a real dispatcher, the UI should say so instead
of just cycling a small toast.

## D28 — Current Week / Driver View ported without Pickup/Drop columns

Ported `vCurrentWeek` and `vDriverView` from `legacy/prototypes/dashboard-v2.html`
(lines 543 and 562) into `app/web/app.js`, added as new Dispatch sub-tabs
alongside Scheduler. Both are read-only projections built from the same
`CELLS`/`buildChip` machinery the Scheduler already uses — no drag, no
staging rail (matches the prototype's `RAIL_ON` set, which never included
`cw` or `driver`), non-draggable chips.

**Current Week** is the Monday–Friday slice containing `TODAY`, three slots a
day, one column per driver — the same window `updateCurrentWeek` /
`updateDriverTabs` push to the mirror sheet in the legacy Apps Script
(`legacy/tms-appsscript/Code.js:774`). The Monday-finding formula
(`d.getUTCDate() - d.getUTCDay() + 1`) is ported verbatim from the prototype,
including its known Sunday quirk (it lands on the *next* Monday if `TODAY` is
a Sunday) — not fixed here, since silently changing approved-prototype
behaviour is exactly what the working-style rule warns against.

**Driver View is intentionally missing two columns the prototype has:**
Pickup and Drop. In the legacy sheet these come from the External Order
Tracker's pickup/drop address columns (G/H, see
`legacy/tms-appsscript/CLAUDE.md`); the real schema's equivalent is
`load_stops` (location_id per stop, keyed by load), which exists in
`supabase/migrations/20260804000001_initial_schema.sql` but **nothing writes
to it** — `POST /api/order` and `POST /api/document` never create a stop row.
Wiring the columns up against an always-empty table is the "no half-finished
implementations" case CLAUDE.md calls out, so they were left out rather than
shipped as permanently blank. Store Map is real, not a stub: it reuses the
same `locFor(customer_party_id).map_url` lookup `buildChip` already relies on
for internal orders, so it only appears where the data genuinely exists — and
per legacy behaviour (`BAGGER_MAP_URL_COL` only feeds internal/bagger
customers), external orders never show one, which is faithful, not a gap.

Verified by placing a real load via `POST /api/schedule` (internal order
`12-0826-0100`, driver Jon, Wed 2026-08-05) and confirming the chip rendered
correctly in both new views, then switching the Driver View picker to Jon and
back. Cleaned up the test load afterward.

**Bug found in passing, not fixed here (flagged as a separate task):**
`api_schedule` (`app/server.py`) unconditionally deletes any prior load a
being-scheduled order was on, before creating the new one. If that old load
already has an invoice against it (`invoices.load_id` FK), the delete throws
a foreign-key violation and the whole `POST /api/schedule` call 500s instead
of failing gracefully. Reproduced directly while picking a test order:
`12-0226-0002` and `12-0626-0088` — both tied to invoiced loads in
`supabase/seed.sql` — both crashed the same way. Out of scope for this port,
spun off as its own task.

## D29 — Invoiced loads are locked: no clear, no overwrite, no reschedule

Fixes the crash found during D28 verification. Confirmed with Nate: once a
load has an invoice against it, it's done — it can't be cleared, overwritten
by a note, or have its order moved elsewhere. If the same lane needs to run
again, the move is to copy the order into a new one from External Orders, not
touch the invoiced original.

`app/server.py` gained `_load_at_cell` / `_load_for_order` / `_is_invoiced`
and three guard checks in `api_schedule` — on `clear`, on `note`, and on
placing an order that's still riding an old invoiced load. Each now raises a
clean `ValueError` that reaches the UI as a normal toast, instead of a raw
Postgres foreign-key violation surfacing as an unhandled 500. Reproduced the
original crash (orders `12-0226-0002` / `12-0626-0088`, both on invoiced
seed loads) and confirmed the new message; confirmed a genuinely free order
still schedules normally.

The "copy an invoiced order into a new one" side of this — so a repeat lane
doesn't require touching the locked original — is a separate, not-yet-built
feature; see the open item below.

## D30 — Internal Order Tracker rebuilt as a month-grouped safeguard log, plus External Orders "Copy"

Confirmed directly with Nate, replacing the flat Internal Orders list with
something closer to the legacy sheet's actual behavior:

**Structure.** Jan–Jul each get their own tab; Aug–Dec are one combined
"Off Season" tab — exactly the legacy Internal Order Tracker's grouping
(`legacy/tms-appsscript/CLAUDE.md`). A row's month comes from its own order
number (`solomon_order_no.slice(3,5)`, the `MMYY` block), not `ordered_at` —
a reserved row can sit completely blank, with no dates at all, until Nate
fills it in. That's deliberate: *"the order doesn't exist in the real world
until I fill it out."*

**Numbers are never typed.** `+ Add order` calls `POST /api/internal-order`,
which auto-generates the next sequential number for the department/month
(`_next_internal_number` in `app/server.py` — finds the max existing
`DD-MMYY-####` for that prefix and increments, or starts at `0001`). Defaults
to dept 12; there's no picker for 07 in this pass since Nate didn't ask for
one and it's the ~20% case — the number is a plain text display, not
editable inline, so a 07 row still has to come in some other way for now.

**No Delivery replaces "cancelled" rather than adding a column.** The
`order_stage` enum already had `'cancelled'`, unused anywhere in the app.
Setting it grays the row out (`tr.row-dead`), disables its inputs, and swaps
the row's actions for an "Undo" button — but the order number stays visible,
because the point is exactly what Nate described: *"the order number exists
so I can reference the numbers jumping... it is an order the bagger made,
just not one I hauled."* No migration needed.

**Customer is a dropdown (`is_customer` parties), pallet count and dates are
plain inputs, all wired through the existing generic `data-oedit` → `POST
/api/order/update` path** (which gained `customer_party_id` in its allowed-
fields set — it wasn't there before, since nothing previously edited it after
creation).

**External Orders "Copy"** (`POST /api/order/copy`) is for the case Nate
described: *"the broker sends a new rate that's the exact same pick and
drop."* Clones every field except `solomon_order_no` and `broker_load_no`
(both start blank on the copy) — broker, customer, PO, delivery #, pallet
count, notes all carry over. Documents do not copy; the new order starts
with none, since it represents a fresh shipment.

Verified end-to-end in the browser: sequential numbering across a fresh
month (`0126-0001` → `0002`) and a month with real seed data (`0826-0100` →
`0101`), customer/pallet-count edits persisting, No Delivery graying a row
out and Undo reverting it, and Copy producing a new external order with PO
and notes carried over and both numbers blank.

## D31 — Correction: internal is always dept 07, external is dept 12

D30 shipped with the department mapping backwards — `+ Add order` defaulted
to generating dept-12 numbers for internal orders, and the seed data's own
comments described dept 12 as "Nate's" with dept 07 as an occasional
exception. Nate corrected this directly: **internal orders are always
department 07** — that department's own product (the bagger's), which dept
12's trucks physically haul. **External orders are always department 12** —
Nate's own broker business, and he builds those in Solomon and types the
number in by hand (already the case since D21; nothing changed there).

This isn't a minor tweak — it's the actual meaning of "internal" and
"external" in this schema, and CLAUDE.md's own domain notes support it
("Dept 12 vs Dept 07 — 07 is a different department's work, but Dept 12
hauls ~80% of it") once read correctly: Dept 12 is Nate's own dispatch/broker
operation, not a label for "in-house."

Fixed:
- `app/server.py` — `api_add_internal_order` hard-codes `"07"`, no
  department parameter accepted or needed anymore (internal is never
  anything else, so there's nothing to choose).
- `app/web/app.js` — `+ Add order` no longer sends a department; the Internal
  Orders subtitle now reads "Dept 07"; the Dept column and its `d07`
  highlight styling are gone from the tracker — with every row now always 07,
  a per-row "flag the exception" color meant something before and is just
  noise now. `app.css`'s now-dead `.dept`/`.dept.d07` rules removed too.
- `supabase/seed.sql` — the four internal seed orders that had `12-…` numbers
  are now `07-…` (`07-0226-0001`, `07-0226-0002`, `07-0526-0007`,
  `07-0826-0100`); the external orders were already correctly `12-…`. Applied
  the same fix directly to the running local `dept12` database so the app
  reflects it without a full reseed.

Verified: reloaded the app, confirmed the existing internal order displays as
`07-0826-0100`, and confirmed `+ Add order` generates `07-0826-0101` next.

## D32 — Truck-centric Scheduler, driver colors, per-load chip notes, Sheets-sync scaffolding

Confirmed directly with Nate: staging semantics needed no change (the app's
flat backlog — a load gets a date only when dragged onto the Scheduler — was
already correct; the sheet's date-aligned staging does not need replicating).
Three real requests followed, plus scaffolding for Phase 3:

**Scheduler columns are now trucks, not drivers.** A truck has the permanent
spot; the driver shown defaults to whoever `driver_truck_assignments`
currently says, with Motive ELD expected to override that default per-shift
later. The schema needed no redesign — `loads` already carried both
`driver_id` and `truck_id` (`loads_driver_truck_together`), and
`driver_truck_assignments` already resolved the relationship in either
direction. `schedule_notes.driver_id` became `truck_id` (migration
`20260806000004_truck_centric.sql`) since free-text cells are addressed by
column too. `api_schedule`, `_load_at_cell`, `_load_for_order` all now key on
`truck_id`; placing an order resolves `driver_id` from
`driver_truck_assignments` by `truck_id` — the mirror image of the old
lookup. **Driver View stays driver-centric on purpose** — a driver's tablet
is about that person, not a truck — it resolves the driver's current truck
(`truckForDriver` in `app/web/app.js`) and looks up `CELLS` from there.

**Driver colors** — a nullable `drivers.color` column (same migration),
edited as a plain text cell in the rebuilt Fleet view (`dcell("drivers", ...,
"color")`, no new UI widget). Shown as a small left-accent bar on the
Scheduler/Current Week column header (`.drv::before`, `--dc` CSS var) — not a
full cell fill, which Nate explicitly declined.

**Per-load chip notes** use a column that already existed and had no writer:
`loads.notes`. Typed the same way any cell is (F2/Enter/type-to-edit) — the
one change was `commitEdit()` no longer silently ignoring input over a
placed chip; it now calls the new `POST /api/load/note` (`{truck_id, date,
slot, note}`) instead, leaving the chip and its order untouched. Rendered as
a second annotation line on the chip (`chipHtml`'s new `dispatchNote` param,
`.chip .dnote`) — a neutral pencil icon (✎), visually distinct from the
existing red-flag order note (⚠) so the two kinds of annotation don't get
confused.

**Fleet rebuilt truck-primary**: rows are trucks (`dcell` for number/
equipment type), a driver-reassignment `<select>` per row
(`data-assign-truck` → `POST /api/assign-truck`), and a color cell for
whichever driver currently holds that truck. Both "Add truck" and "Add
driver" exist independently now — a driver no longer implies a truck.

**Bug found and fixed during verification, not before:** the first cut of
`api_assign_truck` inserted the new assignment *inside* the same loop that
closed out each side's old assignment, so reassigning a truck to a driver who
already held a different truck would try to insert while that driver still
had two open assignments — tripping `dta_no_driver_overlap`. Fixed by closing
*both* sides out completely before the single insert. Reproduced the exact
scenario (reassigning truck 31 from Jon to Jordan, who was still on truck 72)
and confirmed the fix, then reverted the test data.

**Sheets-sync scaffolding** (`app/adapters.py`) — no credentials exist yet, so
this is shape only, following the exact `LocalStorage`/`OutlookDraft` pattern
(D25): `SheetsAdapter` interface, `NoSheetsSync` default (honest
`.available`/`.why`, mirrors `NoMail`), `GoogleSheetsSync` written against the
real Sheets API v4 shape (`values.get`/`values.update`) but UNTESTED — even
its token exchange raises `NotImplementedError` rather than pretending to
work. Deliberately generic (`read_range`/`write_range`, not "sync a
placement") since the real SCHEDULER tab's row/column mapping can only be
confirmed against the live sheet. `GET /api/sheets/status` surfaces
availability to the UI the same way the drawer already handles `MAIL`.
Selected via `DEPT12_SHEETS=google` + `DEPT12_SHEETS_CREDS` (service-account
path) + `DEPT12_SHEETS_ID`, matching the existing env-var adapter selection
pattern exactly — dropping in real credentials later is the entire
integration step.

Verified: trucks render as Scheduler/Current Week columns with driver name +
color; a load placed by `truck_id` correctly derives its driver from the
current assignment; a note attached to a placed chip persists and renders
without disturbing the order; Driver View resolves a selected driver to
their current truck correctly; Fleet's reassignment and color edits persist;
`GET /api/sheets/status` reports unavailable with a clear reason. All test
rows/assignments created during verification were cleaned up afterward.

## D33 — External Orders gets full sheet parity: Pick/Drop List, pickup/delivery, and manual entry

Confirmed with Nate: External Orders needs to carry everything the legacy
External Order Tracker does — Order #, Load #, Broker/Customer, PU/PO,
Delivery #, Notes/Appointment info, Pickup Address, Delivery Address — and
there need to be **two ways in**: drop a rate con (existing, auto-detected)
or hit **+ New Order** and type it by hand.

**Pick/Drop List** (new Database sub-tab) is the legacy sheet's standalone
address directory, reused from the existing `locations` table rather than a
new one — `party_id` was already nullable there, so a location never tied to
a Bagger customer or broker already worked, it just had no UI. Bagger
Customers' existing dcell-editing pattern (`dcell("locations", ...)`) covers
name/address/city/state/phone/notes with zero new server logic; only a bare
`POST /api/location` (no party_id) and the appointment-required checkbox
(`data-appt` → `POST /api/row`) were new.

**Pickup/delivery addresses live directly on `orders`**
(`pickup_location_id`, `delivery_location_id`, migration
`20260806000005_pickup_delivery.sql`), not `load_stops` — `load_stops.load_id`
is `NOT NULL`, so a stop can only exist once a load does, but Nate fills in
pickup/delivery at order-entry time, before scheduling ever happens. Forcing
this into `load_stops` would have meant fighting a constraint built for a
different moment in the workflow; two plain nullable FKs match the sheet's
G/H columns exactly and cost nothing extra.

**External Orders became fully inline-editable**, matching the spreadsheet
feel already established for Internal Orders: every column (Order #, Load #,
Broker/Customer dropdown, PU/PO, Delivery #, Notes, Pickup/Delivery Address
dropdowns, Ordered, Delivered) is a `data-oedit` input or select posting to
the existing `POST /api/order/update` — which gained `broker_party_id`,
`pickup_location_id`, and `delivery_location_id` to its allowed-fields set
(`broker_party_id` was previously only ever set at rate-con-creation time,
never edited after).

**Whole-row click-to-open was removed.** With real `<input>`/`<select>`
elements in every cell, a `data-open` attribute on the `<tr>` would fight
the click delegator — clicking into a dropdown to edit it would also bubble
up and pop the drawer open. Replaced with an explicit **Open** button per
row (documents/packaging still live in the drawer, unchanged) — the same
tradeoff Internal Orders already made by never having a clickable row at all.

**+ New Order** calls `POST /api/order` with just `{kind:"external"}` —
already supported since D21 made every field on that endpoint optional — then
opens the drawer immediately so every field, including the two new address
dropdowns, is ready to fill in by hand.

Verified: added a Pick/Drop List entry and confirmed it appears in both
Pickup/Delivery dropdowns; created a blank order via **+ New Order**, set
load #/PO/pickup/delivery through the table's inline dropdowns, confirmed
persistence via direct DB check; confirmed the rate-con path and Copy (D30)
still work unaffected. All test rows removed afterward.

## D34 — Chip click-to-open, a simpler internal drawer, and moving Sync Delivery Dates

**Any chip now opens the drawer on a plain click** — Scheduler, Current Week,
and the staging rail — while drag still drags. This relies on a real HTML5
browser guarantee rather than any bookkeeping: a completed native drag never
fires a `click` on the dragged element, so a single `document` click listener
for `.chip[data-oid]` (checked first, ahead of every other click branch)
can't fight the existing drag-and-drop. Verified directly: dispatching a
`click` on a chip in all three locations opened the correct order every
time, and normal dragging was unaffected since drag never reaches `click`.

**Internal orders get a deliberately different, simpler drawer**
(`openInternalOrder`, split out from `openOrder`) instead of reusing the
external one: pallets and a note at the top, then every Bagger Customer
field for that order's customer (address, city, timing, forklift, miles,
phone, manager, notes) editable through the exact same `data-table/
data-id/data-field` cells the Database tables already use — no new editing
mechanism, just the existing `commitEdit()` recognizing the same attributes
wherever they appear. A **Last order** line at the bottom is computed
client-side from the customer's other orders' `ordered_at` values — nothing
persisted, since it's a fact about existing data, not new data.

**The order-level Notes field now shows on internal chips too.**
`buildChip` previously only surfaced the customer *location's* standing
notes on an internal chip's annotation line; it now also appends this
specific order's own `notes`, matching the drawer's stated purpose — "notes
I put on that screen will show up on the chip." Confirmed directly: typed a
note in the drawer, confirmed it persisted, confirmed it appeared on the
chip, then rolled it back.

**A yearly customer-order-count report**, not a UI feature — Nate's own
call: *"probably wouldn't be worth making a feature for it, can be a report
we pull."* `customer_order_counts` groups internal orders by customer and
year.

**Sync Delivery Dates moved off the Scheduler onto Internal and External
Orders**, and now covers both kinds — it was internal-only in the legacy
sheet (and in this app until now) simply because that's all the sheet's
version touched; there's no reason an external order's `delivered_at`
shouldn't sync from its load the same way.

**Current Week gained a configurable day count** (`CW_DAYS`, persisted in
`localStorage`, default 5, still anchored to Monday of the current week) and
an **Update driver tabs** button wired to `POST /api/sheets/push-driver-tabs`
— honest scaffolding, same as the rest of Sheets sync (D32 part 2): reports
`SHEETS.why` when unavailable (always, today), and would still raise
`NotImplementedError` even with real credentials, since the actual
`updateCurrentWeek`/`updateDriverTabs` mapping against the live sheet
doesn't exist yet.

**Two real data-corruption bugs found and fixed during verification, from
earlier in this session, not from this pass's changes:** truck `31`'s
`number` had been overwritten to `"r"` — a stray keystroke from spreadsheet-
style cell editing during earlier browser testing (typing while a cell was
selected replaces its whole value, by design) — and a stray truck `"135"`
existed with no driver, left over from an earlier `+ Add truck` test that
was never cleaned up. Both fixed directly; a reminder that this app's
click-to-type editing model means a misplaced keystroke silently overwrites
whatever cell is selected, with no undo.

## D35 — Real Sheets auth: hand-rolled JWT signing, verified against the live dispatcher sheet

Phase 3 credentials now exist (a Google Cloud service account, key file in
`secrets/`, gitignored — see `.gitignore` and D-none-below for where it
lives). `GoogleSheetsSync._access_token` was a stub before this; it's now a
real Google OAuth service-account token exchange.

**No pip dependency added.** Signing a JWT with RS256 normally means
`cryptography` or `pyjwt`, but this project stays dependency-free (D24) and
neither package is installed in this environment. The alternative isn't
hard, just unusual: `_rsa_key_from_pem` hand-parses the DER structure of the
PEM key (PKCS#1 or PKCS#8, both handled) to pull out the two integers RSA
signing actually needs — modulus `n` and private exponent `d` — using
nothing but `base64` and Python's native bignums. `_rsa_sign_sha256` then
does RSASSA-PKCS1-v1_5 padding by hand (RFC 8017 §9.2: a fixed SHA-256
DigestInfo prefix, `0xff` padding to the key's byte length, then
`pow(m, d, n)`). This is standard, spec-defined padding, not a novel scheme —
the risk of hand-rolling was in getting the DER offsets and padding length
right, not in inventing cryptography.

**Verified for real, in three steps, each one gated appropriately:**
1. Token exchange alone (`_access_token()`) — talks only to Google's OAuth
   endpoint, never touches the spreadsheet. No permission needed to run this;
   it can't affect anything of Nate's. Passed on the first real key.
2. A read-only Sheets API call against the actual dispatcher sheet
   (`1KlPQ…`) — this **does** touch a live system Nate depends on, so this
   one was asked for explicitly before running. Confirmed: title "future
   TMS", and all 8 expected tabs came back (SCHEDULER, Internal Order
   Tracker, External Order Tracker, Current Week, Bagger Customers, Outside
   Customer List, Pick/Drop List, FLEET/DRIVER INFO) — proof the service
   account was actually shared as an Editor, not just that the code runs.
3. `GET /api/sheets/status` through the running server, with
   `DEPT12_SHEETS=google` set — confirmed it flips from the honest
   `NoSheetsSync` unavailable message to `{"available": true}`.

**One unrelated environment fix, needed to make step 1 possible at all:**
this machine's python.org Python build has no root CA certificates wired
into its trust store, so any real HTTPS call failed with
`CERTIFICATE_VERIFY_FAILED` before ever reaching Google. Added `_urlopen()`,
a thin wrapper that supplies `certifi`'s CA bundle when available (already
installed as a `psycopg` dependency) and falls back to the default SSL
context otherwise, so this is a no-op on environments that don't need it.
Used for every Sheets HTTP call.

**Still not done — the actual point of Phase 3 proper:** `read_range`/
`write_range` are generic REST calls against a range you name; nothing yet
maps the live SCHEDULER tab's real row/column layout to `loads`/
`schedule_notes`, and `push-driver-tabs` (D34) still raises
`NotImplementedError` on purpose. Auth and connectivity are proven; the sync
logic itself is the next piece, and needs the real tab layout confirmed
against `legacy/tms-appsscript/CLAUDE.md` before writing it, not guessed at.

## D36 — Real driver-tab push targets the mirror, not "future TMS"; real Bagger Customer data imported; timing split into two axes

**Correction: `push-driver-tabs` was scoped wrong.** D32/D34 built it (and
the adapters.py docstring) around "never touch the driver-facing mirror
(15f12…), only the dispatcher's working sheet" — but that's backwards for
this specific feature. `updateDriverTabs`/`runDriverUpdate` in the legacy
Apps Script (`legacy/tms-appsscript/Code.js:774`) write *into* the mirror on
purpose — that's the whole point of a driver tab. The actual rule (from
CLAUDE.md's golden rules) is narrower: the mirror's **sheet ID** must never
change, not that our app can never write to it. Corrected the docstring and
this endpoint's design accordingly.

**`/api/sheets/push-driver-tabs` now computes a real payload from Postgres.**
`_driver_week_payload()` builds, per truck-with-a-current-driver, one row
per day (Mon–Sat of the current week) with chip/notes/pickup/drop/store-map
— sourced from `loads`/`orders`/`locations`, not guessed at. Default
behavior is a **dry run**: the computed payload comes back as JSON with zero
Sheets API calls, so it can be reviewed before anything live is touched.
Passing `{"confirm": true}` does the real write — but only into mirror tabs
it can positively match by searching existing tab titles for the truck
number as a whole word (`SHEETS.list_tabs()`, new). No match, or more than
one, and that driver is reported back as skipped rather than guessed at. It
never creates or deletes a sheet — a live tab an actual driver might have
open on a tablet doesn't get touched structurally, only its data range.

**Verified against real seed data**: dry run against the current week
(empty, seed data doesn't land there) and against a week that does have a
scheduled load — correctly surfaced `"Tradewinds Brokerage — 991234"` with
its dispatch note for the right driver/day. Zero live Sheets calls in this
path; confirmed by inspection, not just absence of errors.

**Real chip-text formatter — built and verified byte-for-byte.**
`_driver_chip_text()` / `_fmt_location()` in `server.py` produce the legacy
DRIVER LOAD CHIP exactly:

    {broker name} - {solomon_order_no} - {broker_load_no}

    PICK: {po_number} | {pickup name, address, city state, phone}

    DROP: {delivery_number} | {delivery name, address, city state, phone}

Confirmed with Nate and reflected in the code: `,INC.` is literally part of
the stored broker name (not a template suffix), `PICK:` is `po_number`,
`DROP:` is `delivery_number`, and an empty number keeps its `| ` — the
Tradewinds example's `DROP:  |` (two spaces) is an empty `delivery_number`,
which the formatter reproduces exactly. Empty header parts (e.g. an order
with no solomon number yet) are dropped, not left as ` -  - `. Verified two
ways: (1) fed the exact Tradewinds screenshot values to the formatter and
diffed against the screenshot text — identical, including the double space;
(2) set real pickup/delivery locations on a real scheduled order and ran the
full `push-driver-tabs` dry run — the chip rendered correctly from live DB
data, with pickup/drop map URLs and assembled notes. Test data reverted
after. Internal-order chips are provisional (customer / city-state -
forklift / pallets) since every example Nate gave was external.

Still not built on top of this: the Current Week **color** legend
(Green=Early Store / Yellow=Anytime / Dark Yellow=Early EAST / Brown=Anytime
EAST) and bold `PICK:`/`DROP:` prefixes — that's cell *formatting*, which
needs `spreadsheets.batchUpdate`, not the plain-text `values.update` the
chip text rides on.

**The 4-way timing legend needed a real schema fix, not a guess.** Read the
live Bagger Customers tab to settle it (Nate: *"the bagger customers tab is
literally perfected with all the info i need"*) and found the real color
column has exactly 4 values: `Early`, `Anytime`, `Umatilla`, `Umatilla
Early` — confirming the legend is two independent axes (early/anytime ×
normal/Umatilla), not the three-value enum the schema had
(`early`/`anytime`/`umatilla`), which had no way to represent "Umatilla
Early" at all. Migration `20260806000006_bagger_timing_split.sql`: narrowed
`timing_window` to `early`/`anytime` and added `is_umatilla boolean`. No
backfill needed — no existing row used `'umatilla'`. Also added
`miles_from_umatilla` (the real sheet tracks mileage from two yards, Coburg
and Umatilla — `standard_miles` was implicitly "from Coburg" already) and
`locations.email` (a per-store contact, distinct from `parties.ap_email`
which is AP billing).

**Imported the real Bagger Customers directory** — 267 real customers (1
placeholder row, "NO DELIVERY", correctly skipped), via a new one-time
script, `scripts/import_bagger_customers.py`, not a seed.sql insert. This
matters: seed.sql is synthetic test data committed to git by design (see its
own header comment); this is Nate's real customer list — names, phone
numbers, manager names, addresses — and it goes straight into the local
Postgres database, never into source control. The script is idempotent by
customer name (safe to re-run if the sheet changes). Verified via direct
query: `BI-MART #605 - U` → `timing_window='anytime', is_umatilla=true`
(bare "Umatilla" in the sheet), `BI-MART #619 - U` →
`timing_window='early', is_umatilla=true` ("Umatilla Early") — both parsed
correctly. Distribution across all 267: 197 anytime, 55 early, 16
anytime+Umatilla, 4 early+Umatilla.

**Also fixed while building this**: `GoogleSheetsSync.read_range`/
`write_range` didn't URL-encode the range argument, so any tab name with a
space in it (nearly all of them — "Bagger Customers", "Current Week", every
driver tab) crashed with `InvalidURL`. Found immediately on the first real
read call. Fixed with `urllib.parse.quote`.

**Still open, in order**: a color selector in the app driven by
`timing_window`/`is_umatilla`; then a real, permission-gated write test
against one driver's tab as a canary before pushing to all of them. (The
plain-text chip formatter is done — see above — and the cell formatting is
done in D37 below.)

## D37 — Cell formatting on the push: wrap, legend/driver colors, bold PICK/DROP

The plain-text write (D35/D36) rode `values.update`, which can't touch cell
*format* — so a multi-line chip written into a Current Week cell whose wrap
was off overflowed and covered its neighbors (Nate hit this; the JON 33 BT
tab looked right only because that column already had wrap on from the legacy
setup). Fixed with a real `spreadsheets.batchUpdate` formatting pass —
`SHEETS.batch_update()` / `SHEETS.sheet_id()` (new, generic, matching
read/write_range's shape) and `_fmt_requests()` / `_chip_fill()` /
`LEGEND_COLORS` server-side.

**Color rule, confirmed with Nate** (his exact split): internal loads take
the timing legend color; external loads take the **assigned driver's** color
(the per-driver color from D32) and have no legend color of their own —
which is *why* he wanted driver colors in the first place. `_chip_fill`
encodes exactly that: external → `drivers.color`, internal →
`LEGEND_COLORS[(timing_window, is_umatilla)]`.

**Legend colors weren't guessed** — read straight off the live Current Week
legend swatches (A2:A5), so they're byte-identical to what the sheet already
uses (all four are Google stock colors): Early Store `#D9EAD3` (green),
Anytime `#FFF2CC` (yellow), Early EAST `#F1C232` (dark yellow), Anytime EAST
`#783F04` (brown). Brown is dark enough that the chip's text is flipped to
white on it (`DARK_FILLS`).

**Bold PICK:/DROP:** via `textFormatRuns` — the label prefixes are bolded by
locating `PICK:`/`DROP:` in the chip text and emitting bold/unbold runs
around the 5-char labels. Sent together with the value in one `updateCells`
so text and its runs stay atomic.

**Two chip formats, decided with Nate live**: the driver tab keeps the full
dump (`_driver_chip_text` — solomon/load#, `PICK:`/`DROP:` with full address
+ phone). The **Current Week** tab gets a deliberately compact chip
(`_current_week_chip_text`) because its cells are a fixed size he does not
want to resize — broker, then `PICK:`/`DROP:` as name + city + state only,
no address/phone/numbers:

    {broker}
    PICK: {pickup name}, {pickup city} {pickup state}
    DROP: {delivery name}, {delivery city} {delivery state}

The app can address each location field singly, so nothing has to be crammed
into one string the way the legacy sheet's dropdowns forced.

**The mirror is organized by driver, not truck** (Nate's correction). A
column headed "JON 33 BT" means Jon is the driver; 33 is his truck. So there
is no stale-header problem to reconcile when driver↔truck differs in our
data — a driver keeps his tab. Rare real truck swaps are picked up on the
back end (Motive ELD API, later), never reconciled in the sheet push. The
current push matching-by-truck-number is therefore a stand-in; matching by
driver is the correct long-term key, but not worth changing now.

**Verified live**, not just by absence of errors: formatted the test cells
and read the format back — `wrapStrategy: WRAP`, `backgroundColor:
rgb(111,168,220)` = `#6FA8DC` (the assigned driver's color fills the external
Tradewinds chip — the external rule working end to end), bold runs at exactly
the `PICK:`/`DROP:` label positions. Also confirmed `_chip_fill` returns the
green `#D9EAD3` for an early/non-Umatilla internal customer.

The `push-driver-tabs` endpoint now runs this formatting pass after each
tab's value write (chip column C, per populated row). One real config change
made in the course of demoing: set Wayne's `drivers.color` to `#6FA8DC` so
his external chips have a visible fill — a legitimate setting, not test junk;
Nate can change it in the app once the color picker exists.

**Still open** (not to be touched yet, per Nate): the in-app driver-color /
customer-legend picker (colors are set in the DB for now), and wiring the
Current Week *tab* into an automated push (its 3-row-per-day block layout).
Both chip formats are locked; the plumbing to generate the whole week from
scheduler data is the remaining piece, deferred.

## D38 — Internal freight fields wired into the drawer (Phase 5 gap closed)

`api_freight` (per-load `miles` + `internal_freight_amount`, feeding
`v_freight_transfer_weekly` — the weekly bag-plant charge) has existed and
been routed at `/api/freight` since the app was built, but **nothing in the
UI ever called it**, so the entire internal-freight billing path was
unreachable from the app. Closed it: `openInternalOrder`'s drawer now has a
**"Freight to bag plant"** section with Miles and Freight-$ inputs
(`frFld` → `data-fr` → a dedicated blur handler → `/api/freight`), separate
from the existing order-field (`data-of` → `/api/order/update`) and
Database-cell (`data-table/id/field` → `/api/row`) editors.

Deliberately kept distinct from the customer's `standard_miles` shown in the
same drawer: `standard_miles` is the location's reference figure (a `location`
column), while these are the **actual** miles and the hand-entered charge for
*this specific load*. The drawer shows both on purpose — reference above,
actual-for-this-run in the freight section — not a duplication.

Only appears once the order is on a truck (the charge lives on a `load`, and
`api_freight` rejects an unscheduled order); otherwise the section shows a
hint to assign it on the Scheduler first. Internal-only, matching the schema
constraint `loads_internal_freight_only`.

Verified in the browser against a real scheduled internal order
(`07-0226-0001`): section rendered prefilled from the load (miles 40.5,
freight 285), edited miles to 47.3, confirmed it persisted to `loads.miles`
via psql, then reverted. No console errors.

## D39 — Fleet made fully spreadsheet-editable; no swap-trucks function

Nate: *"i want the fleet section in the database to be fully editable as if
its a sheet so i can just click and move guys around. i dont need a swap
trucks function… each guy has a truck they will swap them as needed on their
own we will get it on the backend of the load."*

The Fleet grid already had editable truck # and equipment, plus a driver
dropdown, but the driver's **name** wasn't editable anywhere and color was a
raw hex text field. Now every column is a real control:

- **Truck #** — editable cell (unchanged).
- **Equipment** — a `<select>` (F/BT/CV) instead of a free-text cell, so a
  mistyped value can't violate the `equipment_type` check constraint. Posts
  the changed field to `/api/row` via a new generic `data-rowtable/rowid/
  rowfield` change handler.
- **Driver** — the existing assignment dropdown; this is the "move guys
  around" control. No separate swap-trucks workflow was built — deliberately,
  per Nate. Ad-hoc truck swaps are captured on the load itself (`loads` stores
  `driver_id` + `truck_id` at schedule time) and, later, via Motive ELD;
  the Fleet grid only sets the current default.
- **Name** — new inline-editable cell (`dcell` → `drivers.full_name`), so a
  driver can be renamed in place.
- **Color** — a real `<input type="color">` swatch (same `/api/row` handler),
  replacing the hex text field — matches Nate's earlier ask for a proper
  color picker driving the external-load chip fills (D37).

Verified live: changed a truck's equipment (BT→F) and a driver's color, both
persisted to Postgres, then reverted. The generic `data-rowtable` handler is
reused by both the equipment select and the color picker.

## D40 — Phase 6: one giant date-filtered dump to pivot, not custom reports

Nate's call on reporting: *"one giant dump i can pull everything out of this
app and just select which date ranges i want to pull from and then the pivot
table will get me the data i need… i dont need some crazy specific custom
reports section."* So Phase 6 is a single wide export, not a query builder.

`/api/report/dump?from=&to=` (`_DUMP_SQL`, `build_report` param path) returns
**one row per order**, left-joined to its most-recent load, truck, driver,
pickup/delivery, and both money paths — external revenue from `invoices`,
internal freight from `loads.internal_freight_amount`. Plus derived pivot
dimensions: `iso_year`, `iso_week`, `year_month`, and `season` (peak Jan–Jul /
off Aug–Dec). Date-filtered on an `activity_date` = first non-null of
scheduled → delivered → ordered.

**Double-count guard (the one subtlety).** Load-level money is per LOAD, but an
internal load can combine several orders. Each order row carries both the full
load figure (`internal_freight_load` / `external_revenue_load`, for reference)
**and** an even split (`internal_freight_share` / `external_revenue_share` =
amount ÷ `orders_on_load`), so summing at order grain is correct. Verified: two
Feb orders sharing one $285 load each show $142.50, summing back to $285 per
truck — not $570.

**This directly answers Nate's transfer question** (*"$ per truck only for
internal loads… so i know how much to take out of the bagger accounts"*):
filter `kind = internal`, sum `internal_freight_share` by `truck_number` over
the date range. The pre-existing `v_freight_transfer_weekly` "Weekly freight
transfer" report still gives the same figure pre-cut by ISO week.

UI: Reports page leads with a **Full data dump** card — From/To date pickers
(blank = everything) and one export button. Per Nate, the report list is
trimmed to just two he uses today — the dump and **Internal freight
transfer** — with the rest of the `REPORTS` dict left server-side, ready to
re-surface as needed. The freight transfer is now date-filterable too (D40
follow-up, at Nate's request: *"i'd like to be able to customize date ranges…
having the date on there like the full data dump is great"*): moved to a
parameterized `_FREIGHT_SQL` (with `_DUMP_SQL` in a `PARAM_SQL` map), still
weekly-per-truck, delivered/closed internal loads only, now with an optional
scheduled-date range. Any report card marked `dates:true` renders a From/To
range (`dateRange()`) that the export handler reads generically from the
clicked card. Verified end to end in the browser: `GET
/api/report/dump?from=2026-02-01&to=2026-02-28 → 200` and `GET
/api/report/freight?from=2026-02-01&to=2026-02-28 → 200` (Feb → truck 31
$285 only), downloaded, no console errors.

## D41 — Phase 4: document→order matching cascade + unmatched queue

The rate-con drop already extracted fields and created an order, stored the
file linked (D27) — but it *always* created a new order and there was no path
for a loose POD/invoice. Phase 4 closes that with the D7 matching cascade and
an unmatched queue.

`_match_order(solomon, broker_load_no, filename)` — deterministic-ID only:
exact Solomon # → exact broker load # → a number pulled from the filename
(Solomon-shaped, then any 5–9 digit run as a load #). Never fuzzy-guesses;
the fuzzy text/OCR work already happened in `parseRateCon` upstream.

Two entry points use it:
- **Rate con** now goes through `api_ingest_order` (`/api/order/ingest`):
  match first, attach to the existing order if found, only create when
  nothing matches. This kills the duplicate when Nate keyed a Dept 12 order
  in by hand and the broker's rate con arrives after. The toast says whether
  it matched (and how) or created.
- **Loose documents** (POD/BOL/single invoice) — a new "Drop a POD or loose
  document" zone (`ingestLoose` → `guessDocType` from the filename → `POST
  /api/document` with no order_id). `api_save_document` runs the matcher when
  no order_id is given; a hit attaches, a miss lands in the **unmatched
  queue** on Billing, where each doc gets an order picker (`data-attach-doc`
  → `api_attach_document`, which also moves the file into the order's folder).

Verified end to end in the browser and API: a POD named `POD_884901.pdf`
auto-attached to the matching order (`matched_by = broker_load_no`); a
no-match doc parked in the queue and then attached via the picker
(`matched_by = manual`). Test docs and files cleaned up after.

**Fixed in passing:** `_match_order` returns a `UUID`, and
`STORE.save(order_id, …)` joins it into a filesystem path — which fails
(`join() argument must be str … not 'UUID'`) since client-supplied order_ids
are strings. `api_save_document` now `str()`s a matched order_id before the
path join.

**Not built (deliberate, unchanged):** pickup/delivery extraction from the
rate con body, and Supabase Storage — the golden rule keeps storage local for
now, and `SupabaseStorage` is a config swap when that changes.

## D42 — Rate-con pickup/delivery: extract as a suggestion, confirm via type-ahead

The last ingestion gap: a dropped rate con left `pickup_location_id` /
`delivery_location_id` blank. Nate's call on how to fill them (both parts
confirmed with him): **suggest, never silently auto-create**, and **"a window
that allows me to confirm and type-over/dropdown so as i type it autofills if
the locations exist."** So the durable piece is a type-ahead confirm; the
extraction just pre-fills it.

**Type-ahead combo** (`locCombo` / `renderLocSuggest` / `handleLocPick`) in the
external order drawer, one for Pickup and one for Delivery: as Nate types it
filters the Pick/Drop List (`locations`) by name/city; picking one sets the
order's `pickup_location_id` / `delivery_location_id` via `/api/order/update`;
a name with no match offers **+ Create "…"**, which makes the location
(`/api/location`, parsing a trailing `, City ST`) and sets it — never
auto-created without his click. Outside-click closes the panel.

**Extraction** (`extractStop` in `parseRateCon`) is best-effort only, since
rate cons vary broker-to-broker and scanned ones are OCR-noisy (the legacy app
never extracted pick/drop at all — this is new, not a port). It anchors on the
usual labels (SHIPPER/PICKUP/ORIGIN, CONSIGNEE/DELIVERY/DROP/DESTINATION) and
grabs a name-ish line plus a nearby "City, ST". The result rides in the rate_con
document's `extracted_fields` and pre-fills the combo (dashed border + a
"prefilled from the rate con — confirm" note); if extraction finds nothing the
combo is just empty and Nate types.

Verified end to end in the browser: extraction parsed a synthetic rate con to
`{ABC Roofing Supply, Eugene, OR}` / `{Accurate Lumber Co, Orting, WA}`;
type-ahead filtered ("bi-mart 60" → Bi-Mart 601/602 + Create); picking set
`pickup_location_id`; **+ Create "Zzz Test Yard, Portland OR"** made the
location (name/city/state parsed) and set it as delivery. Test data cleaned
up, no console errors.

This closes Phase 4's auto-populate. Still deliberately deferred: Supabase
Storage (local per the golden rule until Nate wires it up).

## D43 — Whole-row click opens the order (reverses D33's Open button)

Nate: *"instead of having to click an 'open' button i want to click the load
… it doesnt matter where i click it if i click that row it pulls up the load
info."* D33 had deliberately used an explicit **Open** button because every
External Orders cell is an inline-edit input and a naive row click would fight
clicks into the fields. The standard resolution: open on row click **except**
when the click lands on an interactive element.

Every order row (External Orders, Internal Orders, Billing) now carries
`data-roworder`. The click delegator, right after the chip check, opens the
drawer for any click inside a `[data-roworder]` row whose target is not inside
`input,select,button,a,textarea,option,label`. So clicking a field still
edits it and a row button (Stage / Copy / Merged PDF) still fires its own
action, but clicking anywhere else on the row opens the order. The explicit
"Open" buttons were removed; a `cursor:pointer` on the rows hints the
affordance.

Verified in the browser across all three tables: a plain cell opened the
right drawer (External → "Tradewinds Brokerage", Internal → "Bi-Mart 601",
Billing → order drawer); clicking an input kept the drawer closed and focused
the input; the Open buttons are gone. No console errors.

## D44 — Global search, active-orders header, resizable staging, threaded server

A batch of navigation/UX asks. **Global search** (header): type anything and it
scrapes the already-loaded `DB` (orders by Solomon #/load #/PO/delivery #/notes/
customer/broker, plus parties, locations, drivers, trucks) — arrow keys + Enter
or click; an order opens its drawer, everything else jumps to its Database tab.
All client-side since bootstrap already holds the whole DB. **Header** now shows
a live "N active orders" (both kinds, excluding delivered/closed/no-delivery)
instead of "N orders · M drivers" — Nate wanted the volume-at-a-glance, not the
driver count. **Staging rail** is drag-resizable (left-edge handle, `--rail-w`
CSS var, clamped 120–640px, persisted in localStorage). **"Driver View" →
"Driver Tabs".**

**"Failed to fetch" fix**: the server was a single-threaded `HTTPServer` with
one shared psycopg connection, so any slow request (e.g. a live Sheets call)
blocked every other click. Now `ThreadingHTTPServer` with a thread-local
connection — each request is independent. Verified 5 concurrent requests all
return 200.

## D45 — Fleet simplified to truck + type + free-text driver

Nate: the Driver dropdown, the separate Name column, and the Add-driver button
were all redundant. Fleet is now **Truck # | Type | Driver | Color**. Driver is
a plain text field — type a name and `api_set_truck_driver` finds-or-creates
the driver and assigns it to the truck (clearing it unassigns); drivers and
`driver_truck_assignments` stay intact underneath for reporting and the coming
Motive ELD integration, which will drive this per-shift. Truck **type is
free-form** — a datalist suggests existing types but any new one sticks;
migration `20260806000007` drops the `equipment_type` CHECK so the fleet can
grow new types without a code change.

## D46 — Add-customer popups (External + Bagger) + Rexius Customer Number

Nate needed a way to add customers, not just edit existing rows. An **Add
customer** button on both the External Customers and Bagger Customers grids
opens a modal (`api_add_customer`, `/api/customer`). External makes a
broker/customer party carrying the **Rexius Customer Number** — the accounting
account id, migration `20260806000008` adds `parties.rexius_customer_no` (free
text, shown as a new editable column on the External grid and searchable).
Bagger makes an internal-customer party **and** its `locations` row, with the
delivery-window and forklift fields as **dropdowns** (not free text) so a new
customer can't break the timing/forklift enums. Verified both paths create the
right rows; test customers cleaned up after.

Still open (Nate's biggest ask, deferred to its own effort): making the
**Database section fully spreadsheet-editable** — add/delete rows and columns,
per-cell type control (turn a column into a dropdown, add dropdown options),
create arbitrary new columns/rows anywhere. That's a large feature (dynamic
schema + a cell-type system) and warrants a dedicated design pass, not a bolt-on.

## D47 — Spreadsheet freedom on the Database grids: custom columns, rows, delete

Nate is *creating* the reference database and wanted the Database section to
behave like a spreadsheet — add his own columns (type-in or dropdown), add/
delete rows, highlight-and-delete. The catch: the four grids sit on real tables
the app depends on. Locked scope with him (plan approved): **custom columns on
the existing grids only** (no brand-new blank sheets yet), and **deleting a
referenced row is blocked with a clear message**.

**System vs custom columns.** Every grid keeps its *system* columns (real
schema fields, `dcell` → `/api/row`, protected — no menu, can't be deleted or
retyped). On top, Nate adds *custom* columns whose values live in a new `custom
jsonb` on the grid's canonical row (`bagger`/`external` → parties,
`pickdrop` → locations, `fleet` → trucks). Column defs live in one new
`grid_columns` table (grid, key, label, type, options, sort_order); migration
`20260806000009`.

**Types**: text, number, date, **select** (dropdown with editable options),
checkbox. Custom cells render by type and save to the JSONB via
`/api/row/custom` (empty value drops the key).

**Server**: `api_grid_column` (add — generates a stable `c_…` key),
`…/update`, `…/delete` (drops the col and strips its key from every row's
`custom`); `api_grid_row` (insert a blank canonical row); `api_grid_row_delete`
(FK-safe — counts references in orders/loads/invoices and raises a clean
`ValueError` when non-zero, else deletes). `api_update_custom` writes one key
into the `custom` bag (JSONB param needs a `::text` cast, learned the hard way).

**Client**: each grid gains a `+ Column` (reuses the D46 modal — label, type,
options), a `⋯` menu on each custom header (edit/retype/options/**Delete**), a
`+ Row`, a left checkbox gutter (`selrow` highlight) and **Delete selected**.
Shared helpers `customTh`/`customTd`/`gridCols`/`columnModal` keep all four
grids in sync; system cells stay on `dcell`.

**Verified** end to end: added a `select` column (dropdown, options) and a
`text` column; a value saved to `parties.custom` and rendered back; `+ Row`
created a blank customer, selected it, `Delete selected` removed it; deleting a
customer with orders was **blocked** with "Can't delete — N … reference this
customer." All test columns/rows cleaned up.

**Still deferred** (Nate's choice): brand-new user-created blank sheets
(generic `sheets`/`sheet_rows`) — a later effort, not built.

## D48 — Motive ELD mileage sync for the internal freight transfer

Nate's internal freight transfer to the bag plant should be grounded in real
miles. Motive's `/v1/logs` gives per-driver-per-day logs whose `odometers` map
is **keyed by truck number** (start/end readings) plus a `total_miles` — so we
get exact **miles per truck per day**. Verified live against his key.

**Adapter** (`app/adapters.py`): `MotiveClient` (X-Api-Key from
`secrets/motive-key.txt`, via `_urlopen`) with
`daily_miles(start,end) -> {(truck_number, 'YYYY-MM-DD'): miles}` = Σ(end−start)
over each truck's odometer segments, **guarding against zero/reset readings**
(a raw run showed a −1,004,511 mi segment; the guard requires `end ≥ start > 0`
and falls back to `total_miles` for single-vehicle days). `NoMotive` default,
`make_motive()` selected by `DEPT12_MOTIVE=motive` +
`DEPT12_MOTIVE_CREDS=secrets/motive-key.txt`, same pattern as Sheets.

**Schema** (`20260806000010`): `loads.motive_miles` (raw pull, reference) and
`loads.miles_adjusted` (flag). `loads.miles` stays the effective figure;
`internal_freight_amount` unchanged.

**Server**: `/api/motive/status`; `/api/motive/sync-miles` — finds internal
loads with a truck + date and `motive_miles is null`, makes **one** date-range
call, sets `motive_miles` (and `miles` when not adjusted). Batched + cached (a
filled load is skipped next run) + manual-triggered, so a sync is a couple of
API calls. `api_freight` (D38) extended: typing `miles` flips
`miles_adjusted=true` so a re-sync won't clobber it; `reset_miles` drops back to
the Motive value.

**Client**: a **Sync mileage** button on Internal Orders, and **Miles** +
**Transfer $** columns per scheduled row (`milesCell`/`freightCell` off
`loadForOrder`). Miles shows an **ELD** badge when from Motive, an **adj** badge
+ reset (↺) once typed over. Pricing stays fully manual (Nate types the $) —
miles are reference only, per his call.

**Verified end to end** (real key, read-only): `daily_miles` returned truck
31's daily miles (338/331/370/347/18/164) with the bad segment corrected;
`/api/motive/sync-miles` filled a load to 370; type-over → 999 + adjusted, a
re-sync left it, reset → 370; the UI shows the Miles/Transfer$ cells and the
ELD badge. All test loads reverted.

**Deferred, per Nate**: auto $/mile pricing, live truck location, pushing
dispatches to Motive.

## D49 — Pick/Drop popup, appointment-as-text, Drop rename, all-field type-ahead

A batch of Database/Orders fixes (2026-08-10):

- **Redundant `+ Row` removed** from Bagger + External Customer grids — the
  `+ Add customer` popup already creates the canonical row.
- **Pick/Drop List "Add location" is now a popup** (`addLocationModal`), mirroring
  `addCustomerModal`, replacing the inline top-bar inputs. New save handler
  `#modal-save-loc` → `POST /api/location`.
- **Appointment is free text, not a checkbox.** Migration `20260810000001`
  renames `locations.appointment_required` (bool) → `appointment_note` (text);
  the Pick/Drop grid column and the popup are now a free-text
  "Appointment / dock hours" field (dock hours, "call ahead", etc.) — an
  annotation, not a rule (D20). Server select/whitelist/insert + `data-appt`
  checkbox handler all updated; the old checkbox handler is gone.
- **External Orders "Delivery Address" → "Drop Address"** (drawer label
  "Delivery" → "Drop" too). The two grid cells are now the type-ahead
  `locCombo` instead of a name-only `<select>`.
- **Type-ahead matches ANY location field** (`renderLocSuggest`) — name,
  address, city, state, phone, notes — so typing a town or street finds the
  row. The suggestion panel is now `position:fixed` with JS-set coordinates so
  it escapes the grid's `overflow:auto` clip. All verified live (typing
  "medford" surfaced rows by city/address; a pick saved to the order).

## D50 — Modal z-index bug, Excel row selector, Driver Tabs buttons

- **Modal was uninteractable (blocking bug).** `#modal` was `z-index:120` but
  `#scrim` was `300` — the scrim sat on top of the card, eating every click
  (couldn't focus fields; a click closed it). Fixed: `#modal` → `z-index:320`
  (above scrim) and a backdrop click (`e.target.id === "modal"`) now closes it,
  since the scrim is no longer the top layer. This had affected every popup
  since D46. Verified: typing into Add-customer now sticks, modal stays open.
- **Excel-style numbered row gutter** on all four Database grids, replacing the
  checkbox column. `selTh(grid)`/`selTd(grid,id,n)` render a `#` header
  (select-all/clear) and numbered cells; `ROWSEL`/`ROWSEL_ANCHOR` globals track
  selection per grid, applied to the DOM without a re-render (`paintRowSel`,
  `handleRowSel`): plain click = one row, ⌘/Ctrl = toggle, Shift = range.
- **Delete now confirms first** — `Delete selected` opens a confirm modal
  (`#confirm-del`) instead of deleting immediately. FK-safe blocked deletes
  still reported (D47). Verified: range-select rows 2–5, confirm dialog, cancel.
- **Driver Tabs is a row of selectable buttons** (`data-dvpick`), not a
  dropdown — one click shows that driver's tablet view, matching the Internal
  Orders month selector. Defaults to the first driver.
- **Sync delivery dates** removed from External Orders (it's paired with
  **Sync mileage** on Internal Orders, and the action already covers both kinds).

## D51 — Orders tab, active-count rule, bulk internal orders, doc viewer

Built and verified 2026-08-10 (items 1–4 of Nate's batch; 5–6 stay future):

1. **"Orders" top-level tab** (`NAV`) holding Internal + External Orders, moved
   out of Dispatch (which is now Scheduler / Current Week / Driver Tabs). The
   **combined active count is a badge on the Orders section tab**
   (`.section-tab .ct`); the old top-right `#conn` counter is cleared.
2. **Active = has customer data.** `isActiveOrder(o)`: not delivered/closed/
   cancelled AND `customer_party_id || broker_party_id`. A bare reserved
   internal number and a No-Delivery (stage cancelled) do **not** count.
   Verified: 6 blank January orders left the badge at 2.
3. **Bulk internal-order generation.** `api_add_internal_order` takes `count`
   (1–500), computes the start seq once, inserts N sequential `07-MMYY-####`.
   UI: top **"Add orders"** opens `bulkInternalModal` (month + year + count) and
   jumps to that month tab; bottom **"+ Add one to <month>"** (`#int-add`) does
   one. Year field is a first step toward multi-year (#5). Verified: reserved
   `07-0126-0004…0006`, sequential, blank to tab through.
4. **In-app document viewer.** `openViewer(path,name)` overlay (`#viewer`,
   z-index 400): `<img>` for images, `<iframe>` for PDFs, "Open in tab"
   fallback + Close/backdrop close. A **View** button sits next to Open on each
   drawer doc row. Server fix: `/api/file/` now sets Content-Type from the
   extension (was hardcoded `application/pdf`, so images were unrenderable).
   Verified: overlay opens, file 200s. NOTE: the Claude in-app test browser has
   no PDF plugin so the iframe looked blank there; a real browser renders it,
   and images render everywhere.

### Still future (Nate said not now)

5. **Multi-year support.** ~~Not fully done.~~ **Built in D52** (Scheduler +
   Internal Orders year switcher). The historical *import* of 2024→today data is
   still a separate future task, but the UI now holds any year.
6. **Mobile layout + hamburger menu** so Nate can edit from his phone.
7. **Automated billing-email drafting (Outlook).** Once the billing workflow is
   ironed out, Nate wants the system to draft the outgoing billing emails for
   him — hooking into / giving it access to Outlook somehow. NOT SPEC'D YET
   (Nate said he still needs to figure out the workflow first). Relevant
   existing scaffolding: the `MAIL` adapter (`app/adapters.py`) already models
   this — `NoMail` is the current default, and the note says Outlook drafts need
   Windows + Outlook (`win32com`) **or** a Microsoft Graph app registration for
   the hosted web app. So the plumbing point exists; the trigger, recipients
   (broker AP emails already in `parties.ap_email`), and body template are TBD.

## D52 — Multi-year support (Scheduler + Internal Orders)

Built and verified 2026-08-11. `YEAR` (was a hardcoded `2026` global) is now
switchable so several years coexist in one UI — groundwork for the eventual
2024→today backfill.

- **`availableYears()`** = 2024 … max(currentYear+1, 2026); `YEAR` defaults to
  the real current year clamped into that range. `TODAY` stays the real date
  (demo pin now hardcodes `2026`, not `YEAR`, so it doesn't move with the
  switcher).
- **`yearPicker()`** — a shared `<select id="year-pick">` rendered on both the
  **Scheduler** toolbar and the **Internal Orders** toolbar; both read/write the
  same `YEAR`, so switching year anywhere is consistent. Change handler:
  `YEAR = +val; schedNode = null; render()`.
- **Scheduler** renders `yearDays(YEAR)`; the jump date input's min/max/value
  follow `YEAR`. **"Today"** first switches `YEAR` back to the real current year
  (if different) then scrolls to today.
- **Internal Orders** filters rows by `orderYearCode(o)` (`solomon_order_no`
  slice 5–7 = `YY`) `=== YEAR`'s two-digit year, so a month tab shows only that
  year. `+ Add one` uses `YEAR`; the bulk modal defaults its Year to `YEAR` and,
  on save, switches `YEAR` to the year it just filled so the rows are visible.
- Verified live: switched the board 2026→2024 (month rows re-labeled "JANUARY
  2024", dates from 01/01); Internal Orders 2024 was empty while 2026 kept its
  orders; bulk-created `07-0124-0001/0002` for Jan 2024 (correct `07-MMYY-####`),
  then cleaned up. Test rows removed from the DB.
- **Not year-scoped (intentional):** Current Week and Driver Tabs stay on the
  real `TODAY` (drivers always see the live week). External Orders is a flat
  broker list keyed by real dates, not a year-coded number — left unfiltered;
  year-scoping it is a possible later refinement, not requested.

## D53 — Rolling infinite-scroll Scheduler (supersedes D52's Scheduler year picker)

Built and verified 2026-08-11. Nate wanted the calendar to "just roll down and
add dates the further you scroll" rather than a fixed set of years, for an
open-ended lifespan.

- The Scheduler no longer renders a fixed `yearDays(YEAR)`. It renders a moving
  **window of months** (`SCHED_WIN = {start, end}`, first-of-month bounds) built
  from `schedMonthHtml(monthStart)`. Initial window = 1 month back … 5 ahead, so
  today lands near the top; `render()` scrolls to `#row-<TODAY>` on a fresh build
  (`schedNeedsScroll`).
- **`onSchedScroll`** (listener on `#sched-wrap`): near the bottom it appends the
  next month (`SCHED_WIN.end++`); near the top it prepends the previous month and
  bumps `scrollTop` by the added height to hold the viewport steady. Guarded by
  `schedBusy`. Months roll into the next/previous **year** automatically —
  verified Jul 2026→Jun 2027 by scrolling down, back to Mar 2026 by scrolling up.
- The year `<select>` is **gone from the Scheduler** (label is now "rolling
  calendar"); the date input has no min/max. **`jumpTo(ds)`** re-centers the
  window on the target month if it's out of range (`schedNode = null; render()`)
  then scrolls — verified jumping to 2024-03-15. **Today** is just `jumpTo(TODAY)`.
- `yearDays()` removed (dead). **Internal Orders keeps its year picker** (D52) —
  it's a month/year-coded list, not a calendar, so `YEAR`/`yearPicker`/
  `availableYears`/`orderYearCode` all stay for it.
- Cells are keyed by real date (`cellKey`), so data mapping is unchanged and any
  range works. Known limitation: the DOM grows as you scroll far in one session
  (no row trimming/virtualization yet) — fine for realistic use, revisit if it
  ever drags.

## D54 — Settings shell: Appearance, Help/FAQ, Account (Phase A of the admin plan)

Built and verified 2026-08-11. First slice of the Settings/Admin program agreed
with Nate — the safe, no-auth parts. A **gear** in the header (`#settings-btn`)
opens a `SEC="settings"` view (outside `NAV`; `subsOf` special-cases it) with
three sub-tabs:

- **Appearance** — UI customization persisted to `localStorage` via a `PREFS`
  object + `applyPrefs()` on `:root`: **Theme** (System/Light/Dark; the header
  toggle now routes through `setPref` too, so it finally persists), **Accent
  color** (7 swatches → overrides `--signal`/`--signal-soft`; whole app follows
  — buttons, badges, tab underline), **Density** (Comfortable/Compact →
  `data-density` on `:root`, compact tightens cell/chip/toolbar padding).
- **Help & FAQ** — an in-app guide (`settingsHelp`) covering Scheduler, Orders,
  internal numbering, documents, database grids, sync, reports.
- **Account** — placeholder stating logins/roles arrive with Supabase Auth.

**Deliberately NOT built yet** (per the agreed plan): real users, login/logout,
roles/permissions. Those wait for Supabase Auth so we don't ship throwaway local
auth. `PREFS` is per-device until then. This is Phase A; Phase B (users/roles)
and C (RBAC) are future.

## D55 — Date search, drawer→scheduler nav, Outlook draft out of the drawer

Built and verified 2026-08-11.

- **Flexible date search.** The global search bar now parses date-shaped queries
  (`parseDateQuery`): "march 2025", "mar 15 2025", "03/04/25", "3-4-2025", ISO —
  month-name (+optional day/year, any order) and numeric mm/dd(/yy) both handled;
  2-digit years → 20xx. A match adds a top "Go to <date>" result that jumps the
  rolling calendar there (`gotoDate` → `jumpTo`), and for a specific day it also
  lists the loads on that date (`loadsOnDate`, scanning `CELLS`). Order numbers
  like `12-0326-0044` and load #s like `884895` deliberately don't parse as
  dates. Verified "aug 10 2026" surfaced the day + the Tradewinds load.
- **Drawer → Scheduler.** The order drawer opens with a status strip
  (`schedBar`): **On the board · <date>** + a **Show on scheduler →** button
  (`data-showsched` → closes drawer, jumps the board to the load), **Staged**
  badge when it's in the staging rail, or **Not scheduled**. So an order opened
  from search can always be located on the board. `schedDateForOrder` finds the
  cell date from `CELLS`.
- **Outlook draft removed from the order drawer** (Nate: drafting belongs only in
  the Biller app). The drawer's Billing package section keeps Download
  merged/individually. `doPackage`'s `draft` branch stays for the future Biller
  app; it's just no longer reachable from the drawer.

### Upcoming (raised 2026-08-11, not started)

- **Current Week = editable portal into the Scheduler.** Make Current Week
  editable (it's read-only today, D28) so edits there write through to the same
  board data and vice versa — e.g. tweak this week while planning months ahead,
  push, and go back. Both already share `CELLS`/`cellKey`, so it's reusing the
  scheduler cell markup + edit/drag on the Current Week grid.
- **Biller app redesign.** When the Billing phase is built out, design it more
  intuitively; Outlook drafting lives there (ties to the future Outlook item).

## D56 — Current Week is an editable portal into the Scheduler

Built and verified 2026-08-11. Current Week was read-only (D28); Nate wanted to
edit this week without leaving whatever he's planning months out (driver calls,
he flips over, tweaks, pushes, flips back).

- `vCurrentWeek` now emits the **same `data-key` cells** as the board
  (`cellInner(cellKey(...))`), so the existing spreadsheet edit, drag/drop, and
  chip-click handlers (all `closest("td[data-key]")`, view-agnostic) work here
  too and write straight through (`api("schedule")` / `api("load/note")`, keyed
  by truck|date|slot). Sunday = 1 slot like the board.
- **`repaintCell` now updates every copy** of a key, not the first — a key can
  live in both the detached scheduler node and the visible Current Week grid at
  once, so an in-place repaint has to hit both. `CELLS` is shared, so a rebuild
  of either view reflects the edit regardless.
- Verified: typed a note in Current Week → persisted to `schedule_notes` →
  appeared on the Scheduler cell. Test note removed.

## D57 — Fleet add-truck popup

Built and verified 2026-08-11. The Fleet grid's inline toolbar inputs
(`#nt-number`/`#nt-eq`) are replaced with a **+ Add truck** button opening an
`addTruckModal` fill-out popup — Truck #, Type (free-form), and an optional
Driver — matching Add customer / Add location. On save it creates the truck
(`api("truck")`) and, if a driver name was given, assigns it
(`api("truck/driver")`) before reload. Verified: created a truck with a driver,
both landed (truck + `driver_truck_assignments`); test data removed.

## D58 — Header redesign: profile avatar (settings folded in), fonts, more colors

Built and verified 2026-08-11.

- **Header stripped to one control**: the light/dark toggle is gone (theme is a
  Setting) and — after Nate's follow-up — the settings gear is gone too. Top
  right is now a single circular **profile avatar** showing the signed-in user's
  initials, Outlook-style (`profileName` → `initials()` → e.g. "NL" from "Nate
  Lee", default seeded, editable in Account). `.hbtn`/`.avatar` styles.
- **3-zone header layout**: brand and a `.hdr-right` wrapper both `flex:1 1 0`
  with the search a fixed centre piece, so the search bar sits **centered** and
  the avatar is pinned **far right** (fixed a report where everything clustered
  left on a wide window, no spacer distributing the space).
- **Avatar dropdown (`#profile-menu`)** is the profile + settings + sign-in/out
  home: header shows name + initials, items **Settings** (→ Appearance),
  **Account**, **Sign out** (placeholder toast — real auth arrives with
  Supabase). Closes on outside click. This is the eventual sign-in surface.
- **Font choices (D-req)** in Appearance: System / Helvetica / Humanist / Serif /
  Monospace — system stacks only (offline/CSP), applied via `--font` on `:root`
  (`--mono` untouched). **Accent palette expanded** 7→12 (added Rose, Indigo,
  Gold, Sky, Olive). Both persist in `PREFS`/localStorage like the rest.
- **Account tab** gained a display-name field (sets the avatar initials).
- Nate: **stop UI work here for now.**

## D59 — Customizable keyboard shortcuts (Settings → Shortcuts)

Built and verified 2026-08-11. A **Shortcuts** tab in Settings with sensible
defaults, fully rebindable per-device (localStorage `keymap`, until Supabase
accounts).

- **Defaults** (`SHORTCUTS`): `/` focus search; **Alt+**S/W/O/B/D/R jump to
  Scheduler / Current Week / Orders / Billing / Database / Reports; Alt+T today;
  Alt+N new external order; Alt+, open settings.
- **Combo model**: `comboFromEvent` builds a stable string (modifiers +
  `event.code`-normalized key, e.g. "Alt+S", "/", "Alt+Shift+P"); `keyLabel`
  renders it (⌥ ⇧ ⌘ ⌃). A single global keydown handler runs actions, guarded
  so it never fires while typing in a field, editing a grid cell, or over a
  modal/viewer; single-key shortcuts also yield when a cell is selected, but
  **modifier combos work anywhere**.
- **Recorder**: click **Record** → the next keypress is captured (Escape
  cancels), de-duped against other actions; **Reset** per row and **Reset all**.
- Verified live: Alt+O → Orders; recorded Reports to Alt+Shift+P, it navigated,
  then Reset-all restored Alt+R.

## D60 — Mobile layout + hamburger menu

Built and verified 2026-08-11. A responsive layout kicks in at **≤768px**.

- **Hamburger** (`#navtoggle`, hidden on desktop) opens a left slide-out
  `#navmenu` that consolidates the whole nav — every section grouped with its
  sub-tabs (`data-navto="sec|sub"`), the current page highlighted. Reuses the
  existing scrim; closes on item click or backdrop.
- **Mobile CSS** (`@media(max-width:768px)`): the desktop `.sections`/`.subs`
  bars are hidden (nav is in the hamburger); the staging rail is hidden
  (desktop-only for now); header compacts (brand subtitle hidden, search
  flexes, 16px input font to stop iOS zoom-on-focus); toolbars wrap; the order
  drawer goes full-width; modals drop their max-width.
- Wide grids (Scheduler, tables) keep their horizontal scroll, which is the
  intended mobile interaction for a dispatch board.
- Verified: at 375px the hamburger shows, nav bars + rail hide, the slide-out
  lists all sections/subs and navigates + closes; at 1200px it's the full
  desktop layout again (no regression).
- **Deferred**: touch drag-and-drop for chips (HTML5 DnD is mouse-oriented), and
  a mobile-friendly staging surface — both later if Nate wants full dispatch
  editing on the phone.

## D61 — Touch drag for the Scheduler + hamburger restyle

Built and verified 2026-08-11.

- **Touch drag** (`TOUCHDRAG`): hold-and-drag a chip like the Google Sheets app.
  A ~200ms long-press starts the drag (a quicker swipe scrolls instead, via a
  move-threshold that cancels the timer); a `position:fixed` `.touch-ghost`
  clone follows the finger; `elementFromPoint` finds the drop target under the
  touch and highlights it; drop onto an empty cell or the staging rail. `touchend`
  `preventDefault`s to suppress the synthetic click (so the drawer doesn't open).
  Reuses the **same drop actions** as mouse DnD — refactored into `dropLoadOnCell`
  / `dropLoadOnRail`, called by both the HTML5 `drop` handler and touch. HTML5
  `draggable` stays for desktop; native DnD doesn't fire on touch so they don't
  conflict. Verified: simulated a hold-drag moved a chip cell-to-cell, target
  highlighted, persisted via `api("schedule")`.
- **Hamburger restyle**: `.navtoggle` drops the `.hbtn` circle (no border/
  background), just the ☰ glyph at avatar size next to the brand; the profile
  avatar keeps its filled circle on the right.

## D62 — Billing workflow: external-only queue with billed-out completion

Built and verified 2026-08-11. The biller is now a **queue of external orders to
bill out**, per Nate's spec.

- **External only.** Internal orders never enter the biller — their paperwork
  lives on the order drawer's document attach. The queue = `isExt(o) && !billed_at`.
- **Completion.** Migration `20260811000001` adds `orders.billed_at`. New route
  `/api/order/bill` (`api_bill_order`) sets `billed_at = now()` (out of queue) or
  null (reopen). Client `billOrder(oid, billed)`.
- **Fulfilled = POD + invoice attached** (`isFulfilled`). Each row shows POD /
  Invoice ticks + Ready/Waiting, with **Download**, **Draft**, **Done** actions.
  Download/Draft are disabled until fulfilled; **Done** is always available but
  **confirms an override** if not fulfilled (Nate wanted the escape hatch though
  "it'll never happen").
- **Download/Draft bill the order out** on success (`doPackage` now returns its
  promise, chained to `billOrder` + reload). Batch: tick rows → **Download
  selected** / **Draft selected** package + bill each in sequence; **Mark done**
  bills the selection (override-confirm if any unfulfilled).
- **Draft** uses the existing `create-draft` / `MAIL` adapter — unavailable on
  this Mac (needs Windows+Outlook or MS Graph), so it reports and doesn't bill;
  **Download works now**. Ties to the future Outlook item + Biller redesign.
- **Reopen**: a billed order's drawer shows a "Billed out · Reopen for billing"
  strip (`data-reopen-bill`) — the way to pull one back (Nate: find it again by
  search). Verified end to end (bill → drops from queue; reopen → returns).

### D63 — App-wide undo/redo (2026-08-11)

Shipped the undo/redo half of the item raised below. **Client-side command
stack, not a server-side action log** — each undoable action registers a pair
of promise-returning closures (`undo` reverses, `redo` re-applies), both routed
through the *same* server-backed primitives the forward action used, so Postgres
stays the source of truth and the stack never holds phantom state. Linear
history: a new action clears the redo stack. Cap **5 each way** (Nate's "up to
like 5"). Bound to **Cmd/Ctrl-Z** and **Cmd/Ctrl-Shift-Z** (+ Ctrl-Y) via a
capture-phase keydown; inside a live cell editor or a real text field it yields
to the browser's native text undo (we only reverse *committed* actions).

Primitives added in `app/web/app.js`: `moveLoad(oid, from, to)` (schedule/
unschedule/move; refuses to land on an occupied cell so an undo can't clobber a
slot filled after the fact), `scheduleNote`, `loadNoteSet`, `gridCellSet`.
`HIST`/`histPush`/`histUndo`/`histRedo` are the stack. Wired into: **scheduler
load moves** (drop-to-cell, drop-to-rail, Delete-to-clear), **cell notes** and
**chip/load notes**, **grid cell edits** (commit + Delete-key clear — directly
addresses the documented "stray keystroke clobbers a truck number, no undo"
trap), and **single billing** bill-out + reopen. Batch billing is deliberately
*not* undoable (multi-order reversal is ambiguous — reopen individually).

Verified live end to end: grid-cell edit (`orig`→`CHANGED`→undo→`orig`→redo→
`CHANGED`, toasts correct) and a scheduler move (08-10/2 → 07-01/1 → undo →
08-10/2). Test location cleaned up; order 58008920 restored.

**Still future:** the **action/session history view in Settings** (raised below)
— the stack is per-session and in-memory; a persisted, browsable log is a
separate buildout.

### D64 — Stripped the narrator UI copy (2026-08-11)

Nate: the tab subtitles and inline instructions read like "weird ai code
written style adlibs." Removed, app-wide: the Scheduler "rolling calendar"
subtitle + "Tab ↵ type to edit · Del clears" hint (and the identical Current
Week hint + its "Live slice of the Scheduler…" note-bar); the `<p>` taglines
under External Orders, Internal Orders, Driver Tabs, Billing, and Settings;
the drop-zone explanation sentences (kept the bold "Drop X here" affordance
labels); the how-to note-bars on the Database grids (bagger/brokers/pickdrop/
fleet), the Reports pivot-tip, and the Billing footer; and the staging-rail
"Drag onto the board…" footer. Also cleared the empty-container placeholders
("Nothing attached yet.", "Nothing staged.", "No match.", "Nothing to bill…",
"Nothing scheduled…", "Nothing reserved…", the drawer freight/customer empty
notes, and Driver Tabs "Not currently assigned…") — empty containers now just
render empty. **Kept** the functional, data-driven notes: the Rexius-number
billing warning, the rate-con "Prefilled — confirm each" prompt, per-report
catalog descriptions, the Settings device-scope note, the Shortcuts how-to, and
the server-unreachable error.

### D65 — 2025 historical backfill + scheduler categories (2026-08-11)

Importing the legacy "Flatbed Master Schedule" 2025 tab into the live model, and
the scheduler-coloring concept it needs. Built against Nate's real dataset (his
call: "this is my dataset to build this app around").

**The sheet's shape** (reverse-engineered, `scripts/import_2025_schedule.py`
header has the full map): 9 trucks down the rows, hours 06:00–19:00 across, each
business day a 15-col block, ~26 day-blocks tiling left→right per "band", bands
stacked newest-on-top. Merges are just text overflow — a load lives in one cell,
its hour column only approximate (real time often written into the text). ~2,700
load cells + OFF/FMLA/SICK marks across the year.

**Nate's color legend → app meaning** (he labeled all 36 via the published
swatch artifact): the ~40 fill colors conflate three axes — load type (anytime
store, early store, Umatilla side, bag-plant-as-customer, other-dept), driver
identity (8 colors, *ignored* — we key on truck now), and flags (magenta =
don't-miss, red = off, white = plain note/load). Seeded 7 `categories`
(name+color, one `is_off`) from the load-type + flag colors.

**Business rules confirmed with Nate:**
- **internal (dept 07) = the delivery customer is a Bagger Customer** (or a store
  category); everything else external (dept 12). Color does NOT decide it — the
  customer match does. Validated: 95% of store loads auto-match on the Bi-Mart
  store number (`BI-M #639` → `BI-MART #639`); the rest fall to the D41 unmatched
  queue.
- **Key on truck, not driver** — drivers churn/leave, trucks persist. History
  loads carry a truck and **no driver**.
- **White cells stay as chips** (Nate's rec) — the genuine loads show; the
  "LOAD"/"Deliver X" reminders read as plain chips, same as the sheet.
- **2025 calendar only**; stray 2024 bands + Jan-2026 tail skipped; the
  overlapping duplicate Dec band de-duped by truck+date+text.

**Schema (`20260811000002`):** `categories`; `loads.category_id`; **dropped the
1..3 slot cap** (a truck-day can stack any number of loads — Nate: rare but it
happens) and **relaxed driver/truck both-or-neither → driver-implies-truck** (a
truck load needs no driver); `truck_off_days`; `orders.custom` jsonb for
provenance (`source=sheet2025`, raw text, color) so the backfill is idempotent
and reversible (`--reset`).

**Board (D65 display half):** chips take the category color on their edge;
`DAYSLOT` lets a day render more than 3 rows; off-days get a red hatch +
reason tooltip; historical chips show the raw lane text (no "(no broker) / NO
ORDER #" clutter). Historical orders are **kept out of the biller queue and the
Orders grids** (`isHistorical`, `custom.source==='sheet2025'`) but show on the
Scheduler and feed Reports.

**Status:** Dec-2025 trial committed & verified live (136 loads: 10 internal /
126 external, 28 off-days, category edges + hatch confirmed in the DOM). Trucks
63/80/135/162 auto-created. **Not yet done:** (a) run the full year; (b) the
*interactive* coloring UI — paint a cell's category / mark a truck off by hand
(only the display + import-set colors exist so far); (c) external broker/lane
parsing is left raw (broker codes, load #s in the text) — the raw text is kept.

### D66 — Scheduler coloring: named palette, right-click, fill (2026-08-12)

The interactive half of D65 — making the board paint like a spreadsheet. Nate's
decisions (asked up front): **named managed palette** (not free colors — every
swatch is a real category, so the import, future chips, and Reports stay
consistent); colorable = **chips, empty cells/notes, and a whole truck-day off**;
apply via **both** a right-click menu and a toolbar **Fill** button; right-click
menu carries color / truck-off / open / clear / copy / paste; and he wants
**multi-cell spreadsheet selection + copy/paste** (that part lands next).

**Shipped this pass:**
- Chips become **full-background category color** with auto black/white text
  (`textOn` luminance threshold), not just a left edge. Empty/text cells fill too.
- **Category palette** popover (`openPalette`) — swatch grid of the managed
  `categories` + "No color".
- **Right-click context menu** (`openCtxMenu`) on any board cell: Set color…,
  Mark/Clear truck off, Open order, Copy chip, Clear cell, Paste chip.
- **Toolbar "🎨 Fill"** applies a color to the selected cell.
- Primitives: `setCellColor` (load → `loads.category_id`; empty/text →
  `schedule_notes.category_id`), `setTruckOff`, `copyCell`/`pasteCell`; all
  undoable (D63) via `colorCells`/`truckOffToggle`. Server: `/api/cell/color`,
  `/api/truck/off`, `/api/category`. Migration `20260811000003` adds
  `schedule_notes.category_id`.

Verified live: color a Dec-2025 chip → persists (`cat_color` #FF00FF), chip
renders filled, Cmd-Z reverts it; truck-off toggle writes `truck_off_days` and
shades the cell. 18 filled chips confirmed with correct backgrounds + contrast.

**Multi-cell selection (shipped 2026-08-12):** spreadsheet-style **drag-marquee**
(`MARQ`, pixel-rect intersection over `td[data-key]`) + **shift-click** to
extend/toggle; `MULTISEL` + `.selrange` highlight; a plain click clears it. The
color action routes through `selectedKeys()`, so filling colors the whole
selection in one undoable step. Verified live: drag selects 4 cells → color all
4 (persisted as `#92D050` notes) → Cmd-Z reverts all 4 and cleans up the empty
note rows. A chip still drags to move a load (marquee only starts on the cell
background).

**Still open (next):** a Settings **categories editor** (add/rename/recolor —
`/api/category` already exists); richer **copy/paste of ranges** (single
copy/paste works today).

### D67 — Sheets-style formatting toolbar + per-cell formatting (2026-08-12)

Nate wants the board to feel like Google Sheets. A persistent **formatting bar
lives under the Dept 12 header** (`#fmtbar`), global, with: print · undo · redo ·
**zoom % dropdown** · fill color · text color · bold · italic · font size. Undo/
redo drive the existing D63 stack; print uses `window.print()` + a print
stylesheet; zoom sets `#main { zoom }`. The color/text/bold/italic/size controls
only bite on the **Scheduler / Current Week** selection (disabled elsewhere) and
act on the marquee selection or the single selected cell.

**Model pivot (reverses D66's named-only palette):** colors are now **free, exact
Google Sheets hexes** (`SHEETS_COLORS`, the standard 80-swatch grid + custom hex
`<input type=color>`). Meaning didn't disappear — it moves to a **conditional-
formatting** model Nate described: bagger customers carry a **designation**
(open, user-defined legend) and internal chips get their color *from the
customer's designation*; **external loads + empty cells are hand-painted** ("I
only change colors on external loads, never bagger customers"). The legend +
customer-designation dropdown live in the **Database** section. *This turn shipped
the toolbar + manual per-cell formatting; the conditional-designation layer and
the driver-tab color push are the next stages.*

**Per-cell formatting** stored as a `fmt` jsonb on `loads` + `schedule_notes`
(migration `20260812000001`): `{fill, text, bold, italic, size}`. Render
precedence for fill: `fmt.fill` (manual) > category/conditional color > timing
edge. Endpoint `/api/cell/format` merges a patch (or replaces, for undo); every
change is one undoable step (`applyFormat`, `fmtSetFull`).

**Icons:** inlined **Material Symbols** paths (`ICONS`/`svgIcon`, Apache-2.0 —
the same family Sheets uses) so the toolbar matches without external assets. The
old per-Scheduler "🎨 Fill" button was removed (the global bar replaces it).

Verified live: toolbar renders 7 SVG icons + zoom dropdown; bolding a Dec chip
persisted (`fmt.bold`, rendered weight 800) and Cmd-Z reverted it; format
endpoint writes/clears cleanly. **Still open:** conditional designations
(customer→color) + legend grid in Database; driver-tab color push; wiring text
color/size were built and render but get their fuller workout next pass.

### D68 — Board interaction fixes: selection, day borders, add-row (2026-08-12)

Three board-usability fixes on top of D66/D67.

**Click-drag was selecting page text, not cells.** The real bug (Nate's
screenshot: a blue native text-selection sweeping the date column) was that the
grid was text-selectable — dragging started a browser selection. Fix: `table.grid
{ user-select: none }` (editors keep `user-select: text`). The marquee logic was
fine; it just fought the native selection. Also now: the marquee box is always
removed on mouseup / window blur (it used to get left on screen), and a **no-drag
path** — click a cell, **shift-click** another to select the whole rectangle
(`SEL_ANCHOR` + `rectFromCells`), which is reliable on a trackpad where a
hold-drag is finicky.

**Thicker day dividers.** `tr.dstart` (the first row of each day) gets a 3px top
border so the eye catches exactly where a day ends.

**Right-click a date → "Add a row to this day."** Inserts a 4th+ slot across all
trucks for the rare day a truck runs more than three loads (`DAYADD`, honored by
both the DOM insert and a later rebuild via the slots calc).

Verified live with a real mouse drag: selects cells, no text highlight, no stray
box; shift-click selects a 9-cell rectangle; add-row bumped a day 3→4 rows.

### D69 — Split the client into fragments to cut agent token cost (2026-08-12)

Nate was blasting through usage limits because the project is big — every touch
of the 3,561-line `app/web/app.js` cost tokens. Two moves:

1. **Slimmed `CLAUDE.md`** (loaded every session) from 522 lines / ~8,200 tokens
   to 186 / ~2,850 by dropping the embedded D49–D67 changelog + two "Current
   state" narratives (already in this file); kept all rules/reference/domain/traps.
2. **Split `app.js` into `app/web/js/01…12-*.js`.** No build step (D24 holds):
   the server assembles them, in filename order, inside one shared
   `(function(){ "use strict"; … })()` when the browser GETs `/app.js`. Chose
   server-side concatenation over separate `<script>` globals (246 top-level
   names would have leaked to `window`) and over ES modules (huge import/export
   churn) precisely because the **runtime stays byte-identical** — verified: the
   assembled output equals the old monolith exactly, `node --check` passes, and
   the live app renders every section with zero console errors. Fragments are the
   closure body (all share scope, order-independent); each is still
   independently `node --check`-able. A new area = a new `js/NN-name.js`, globbed
   automatically. The `app.js` section map moved to WORKTREE.md (now per-file).

Trade-off accepted: fragments aren't standalone-runnable (only meaningful
concatenated), and there's a tiny per-request assembly cost (local, no-cache
already). Worth it — an agent now opens one ~300-line file, not 3,500.

### D70 — Drag-select worked in Chromium but not on Nate's Safari/Chrome (2026-08-12)

The marquee (D68) passed every automated test in headless Chromium yet selected
nothing on Nate's real Mac (both Safari and Chrome, trackpad). Root cause:
`setPointerCapture` on the plain cell `<div>`. Once the pointer is captured to a
non-button element, Safari (and some Chrome builds) don't bubble the captured
`pointermove` events back to the `document` listener — so `pointerdown` set the
anchor, **zero** moves arrived, `MARQ.moved` stayed false, and release ran
`clearMulti()`. Headless Chromium bubbles correctly, which is why it was
invisible in testing. Fix: **drop pointer capture entirely** — without it,
`pointermove` fires on the element under the cursor and bubbles to `document` in
every engine. Added a `selectstart` guard (Safari fires it even after
`pointerdown.preventDefault()`) to keep page text from highlighting mid-drag. No
parallel `mousedown` marquee is added, so pointer and mouse paths never fight
(the existing `mousedown` → `selectCell` single-cell handler is untouched — it
paints `.sel`, a different class from the marquee's `.selrange`).

Lesson: pointer capture on non-button elements is a cross-browser trap; a
headless-Chromium pass is not proof for Safari.

### D71 — The real bug: selection styled with a nonexistent CSS var (2026-08-13)

D70 misdiagnosed. Drag-select still "didn't work" for Nate on mouse AND trackpad
across multiple browsers. Added a toggleable on-screen debug overlay
(Ctrl/Cmd+Shift+D or `?dbg=1`, in `js/10-select.js`) that logs pointerdown/move/up
and the exact bail reason — and it revealed the selection was working the whole
time: `pointerup: DONE, selected 33 cells`. **The highlight simply never
painted.** `.marquee`, `td.selrange`, `.fb.on`, and `.sw-cell:hover` were all
styled with `var(--accent)` — a variable that does not exist. The app's accent
token is **`--signal`** (`#E2510B` light / `#FF6B24` dark). An undefined
`var()` makes the whole declaration invalid at computed-value time, so
`box-shadow`/`border` fell to `none` and `color-mix(...var(--accent)...)` fell to
transparent. Selection logic (D68/D70) was fine; it was painting in invisible ink.

Fix: replaced all six `var(--accent)` → `var(--signal)` in `app.css`, and moved
the selrange border into the `::after` overlay (`z-index:6`, 20% fill + 2px inset
`--signal`) so it reads above both empty cells and colored chips. The debug
overlay is kept (off by default, zero cost until toggled) as the tool that
finally isolated this class of "logic works, nothing visible" bug.

Lesson: when behavior "doesn't work," confirm whether it's the logic or the
paint before rewriting the logic — a missing CSS variable fails silently and
looks exactly like a broken handler. D70's capture removal still stands as a
real robustness improvement, but it was not the fix.

### D72 — Conditional designation coloring for internal chips (2026-08-13)

The "colors mean something, driven by the DB" model Nate asked for (D67 moved
meaning out of hand-painting). A **Bagger Customer carries a designation** — one
of the scheduler `categories` (Early store, Anytime store, Bag plant, Umatilla
side, …) — and **every internal load delivering to that customer draws its chip
fill from the designation, live.** Recolor the legend or reassign a customer and
all their chips recolor on reload.

Locked with Nate (both answers changed the schema, so asked first):
- Internal chip fill = **live from the customer's designation**, superseding the
  per-load color the 2025 import stamped.
- Internal is **purely designation-driven** — no per-load override. Emphasis
  like "Don't miss" applies to external loads only. He never hand-paints bagger
  customers; he only paints external loads.

Implementation:
- `locations.category_id` (migration `20260813000001`) = the designation, FK to
  `categories` with `on delete set null`.
- The designation resolves through the **customer, not a delivery stop**: an
  internal order names its bagger customer via `customer_party_id` (D65), NOT
  `delivery_location_id` (which internal orders leave null — that tripped the
  first pass). `designationColor(o)` → `locFor(o.customer_party_id)` →
  `category_id` → `CATCOLOR[id]`.
- `chipHtml` (D67 precedence, revised): **internal → designation color only**
  (fmt/per-load category ignored); **external → fmt.fill > per-load category >
  timing edge** (unchanged).
- Legend + assignment live in **Database → Bagger Customers** (Nate: the meaning
  lives in the DB, not Settings): an editable `legendBar()` (recolor / rename /
  add / delete → `/api/category`, which already existed from D66) above the grid,
  and a per-row **Designation `<select>`** (`designationSelect`) tinted with its
  color, persisted through the generic `data-row*` → `/api/row` handler (added
  `category_id` to the locations allow-list, no new endpoint).

Verified end-to-end: assigned "Anytime store" to a customer → its internal chip
rendered `#FFD966` (`rgb(255,217,102)`, `filled`); reverted the test assignment.

### D73 — Sheets-parity cell editing: borders, fill-vs-border, shortcuts (2026-08-13)

A batch of spreadsheet-fidelity fixes on the Scheduler / Current Week:

- **Type-to-edit + visible single-cell select already worked** once D71 fixed the
  accent var — `selectCell` paints `.sel` (2px `--signal` inset) and the grid
  keydown starts an edit on any printable key. Verified, no change needed.
- **Per-side cell borders** (`fmt.border = {t,b,l,r:hex}`) via a Sheets-style
  border menu in the toolbar (All / Top / Bottom / Left / Right / Clear + a color
  picker). Rendered as **inset box-shadows on `.cell`** (`cellBorderShadow`), NOT
  real borders — so they sit above the fill and never disturb the grid lines or
  the 3px day separators. `applyBorder` merges per cell (Top then Right keeps
  both) and is undoable.
- **Fill no longer paints over grid lines.** Two parts: `background-clip:
  padding-box` on `td[data-key]`, AND setting the fill as `background-color`
  (NOT the `background` shorthand, which silently resets `background-clip` to
  `border-box` — that was the actual bug; computed clip proved it).
- **Search shortcut → F3** (retired `/`; migrates any saved `/` binding). Function
  keys now fire even over a selected cell (they used to yield to the grid).
- **Clear formatting + color → Cmd/Ctrl-\\** (`clearFormatting`, undoable). Leaves
  designation-driven colors alone since those aren't `fmt`.
- Centralized the scheduler/Current-Week cell HTML in `schedCellHtml` so fill +
  borders render identically in both (Current Week previously rendered no fill at
  all — fixed as a side effect).

### D74 — Database becomes a spreadsheet app: custom sheets (2026-08-13)

Nate: "the database needs to literally be a spreadsheet app" — a **+** in the
Database tab row adds a blank sheet, each a real grid you grow at will (default
25×25, add rows/columns). Capped at **10 sheets** (his call — he'll likely add
one, but wants the ability). The rest of the app is built around the database and
it's meant to keep evolving.

Model: a `sheets` table (name, n_rows, n_cols, sort) + a **sparse** `sheet_cells`
(sheet_id, r, c, value, fmt) — only touched cells exist; `fmt` mirrors the
scheduler's per-cell jsonb so the D73 toolbar can format sheet cells later.

Key reuse decision: sheet cells are rendered with the **existing Database grid
machinery** — `dcell("sheet", sheetId, "r|c", val)` emits the same
`data-key/data-table/data-id/data-field` a normal grid cell has, so single-select,
marquee-select, arrow-key nav, and type-to-edit all work with **zero changes** to
the cell-editing code. The only seam is `gridCellSet`: `table==="sheet"` routes to
`/api/sheet/cell` (field is `"r|c"`) instead of `/api/row`. Column labels via
`colLetter` (A…Z, AA…). Sheets are dynamic Database sub-tabs (`SUB="sheet:<id>"`)
appended by `subsOf`; the `+` and per-sheet add-row/add-column/rename/delete are
plain click-delegated actions.

**This increment = structure + editing + grow + persist.** Still to layer on
(increment 2): **per-cell formatting on sheets** (the toolbar's `fmtCanFormat` is
Scheduler/Current-Week only today) and **conditional formatting** — a toolbar
control to pick a database and color rows/cells by rule (supersedes the D72
always-on "Designations" legend, which Nate wants renamed "Conditional
formatting" and moved off the Bagger page into the toolbar).

### D75 — Sheet formatting, collapsible toolbar, CF in the toolbar (2026-08-13)

Follow-on to D74, all from Nate:
- **+ opens a sheet instantly** (no name prompt); **double-click a sheet tab to
  rename inline**; **grow via a trailing +** on the last column header and last
  row (Sheets-style), not toolbar buttons.
- **Per-cell formatting now works on sheet cells.** The toolbar's format targets
  became **element-based** (`fmtTargets` reads `SELSET`/`SEL` and classifies each
  cell as `{kind:"sched"|"sheet"}`), and `fmtApply` routes sheet cells to
  `/api/sheet/cell` with an **in-place repaint** (`repaintSheetCell`) so
  multi-cell formatting keeps the selection. `fmtCanFormat` now also allows
  `SUB=sheet:*`. fmt renders + persists on sheet cells.
- **Collapsible toolbar** (chevron, `localStorage.fmtbarOpen`).
- **"Conditional formatting"** is now a **toolbar popover** (`openCondFmt`), not
  the always-on legend above Bagger Customers (renamed from "Designations"). It's
  the same editable category legend (recolor/rename/add/delete → `/api/category`)
  that drives designation → chip color (D72); the per-customer assignment stays as
  the Designation dropdown in the Bagger grid.

Still open from Nate's spec: **per-database CF rules** (pick any database, color
rows by rule) beyond the bagger designation model — today non-bagger coloring is
manual per-cell formatting (works on sheets). And **reformatting the built-in
Database grids to behave like sheets** — deferred/needs a scope call, since those
grids carry structured columns and behaviors (designation dropdown, add-customer,
D72 coloring) that a freeform sheet would drop.

### D76 — Spreadsheet feel on the built-in grids + tab divider (2026-08-13)

Nate: give the built-in Database grids (Bagger, External, Pick/Drop, Fleet) the
"spreadsheet feel" but **keep their structure** (Designation dropdown, +Add
customer, custom columns, D72 coloring — a freeform conversion would drop all
that), and add a **divider** in the tab row separating the coded-in databases
from ad-hoc custom sheets.

- **Divider** between the built-in subs and the custom sheets (`.sub-div`), so
  the structured databases and the blank project sheets share one container but
  read as two groups.
- **Per-cell formatting on the built-in grids.** New polymorphic sparse store
  `grid_cell_fmt(table_name, row_id, field, fmt)` (D76 migration) — no FK since
  row_id spans parties/locations/trucks. The toolbar gained a third target kind
  `{kind:"grid",table,id,field}` in `fmtTargets`, `fmtApply` routes it to
  `/api/grid/cell-fmt` with an in-place `repaintGridCell`, and `fmtCanFormat` now
  allows the four built-in Database subs. `dcell` renders the stored fmt (shared
  `fmtStyles` helper) and carries `data-bold` so the structural bold on name
  columns survives a format repaint. Fill uses `background-color` +
  `background-clip:padding-box` so grid lines stay crisp (D73 rule extended to
  all `table.data td[data-field]`).

### D77 — Fixes: sheet-tab rename, in-app confirm, real toolbar collapse (2026-08-13)

Three bugs Nate hit on D74–D76:
- **Double-click-to-rename never fired.** Every sub-tab click ran `render()`,
  which rebuilt `#subs` with fresh nodes — so the two clicks of a double-click
  landed on *different* elements and the browser never emitted `dblclick`. Fix:
  clicking the already-active tab is a no-op (no re-render), so the node is stable
  and `dblclick` fires on the current sheet tab.
- **Delete used the browser `confirm()`.** Added an in-app `confirmModal(message,
  onYes, label)` on the existing modal system; sheet-delete and designation-delete
  now use it (styled, matches the app).
- **Collapsing the toolbar only hid the icons**, leaving a full-height empty bar.
  `.fmtbar.collapsed` now zeroes the padding/min-height and shrinks the lone
  chevron to a ~16px strip, actually reclaiming the space.

### D78 — Per-cell fonts, Sheets-style size stepper, more system fonts (2026-08-13)

Font handling moved into the formatting toolbar so a cell can carry its own
typeface, matching how fill/text/bold/italic/size already work.

- **`fmt.font`** — a new per-cell fmt key holding a CSS font-family *stack* string.
  Stored in the same opaque `fmt` jsonb (server merges arbitrary keys — no schema
  or handler change). Rendered wherever fmt is turned into CSS: `cellInner`
  (scheduler/CW), `fmtStyles` (built-in grids), `sheetCellStyles` (custom sheets).
- **Toolbar font picker** — a `.fb-font` button opening `openFontMenu`, a custom
  popover (NOT a native `<select>`, because browsers — macOS especially — ignore
  `font-family` on `<option>`). Each row previews in its own face, Sheets-style,
  with a check on the current font. First entry (`""`, "System") clears the
  per-cell font back to the app default. Pick → `applyFormat({font})`.
- **Font stacks use single-quoted family names** (`'Helvetica Neue',…`) not double.
  The stack is emitted into HTML `style="font-family:…"` attributes everywhere
  (cells, previews); a double quote inside a double-quoted attribute closes it
  early, so quoted faces (Helvetica, Times, Palatino…) silently fell back. Single
  quotes are valid CSS and safe inside the attribute. Trap: any new font stack
  must quote multi-word family names with `'…'`, never `"…"`.
- **Sheets-style font-size stepper** replaces the old size `<select>`: a
  `−  [ N ]  +` box (`.fb-fs`). Buttons step ±1 from the current size (base 10 when
  unset); the numeric input applies on Enter/blur. Undoable like any format.
- **Fill/text color bars persist a last-used color** (Sheets behaviour). `LAST_FILL`
  (default `#ffff00`) / `LAST_TEXT` (default `#000000`) in localStorage; the bar
  under the bucket/A icons shows the selected cell's color if set, else the
  last-used one, so there's always a visible swatch. Picking a color updates it.
- **`FONTS` expanded** from 5 to 27 system stacks (Arial…Papyrus), shared by
  Settings (whole-app `--font`) and the toolbar picker. All degrade across
  macOS/Windows; still no external/web fonts (CSP-locked, offline).

Themes and broader UI customization are a deferred future update (Nate's note).

### D79 — Sheets-parity border window: styles, thickness, color pencil (2026-08-13)

The toolbar border control got a full Google-Sheets-style window and the borders
themselves gained line style + thickness.

- **Render moved from inset box-shadow to real CSS borders on `.cell`**
  (`cellBorderCss`, was `cellBorderShadow`). `.cell` is `box-sizing:border-box`
  and fills the td, so a real border shifts nothing and sits inside the td's own
  1px grid line / 3px day separator (separators are on the `tr.dstart > td`, D68 —
  a border on the inner `.cell` can't touch them). Box-shadow was chosen in D73 to
  avoid layout shift, but it **cannot draw dashed/dotted** — real borders can, so
  the model now stores style + width.
- **`fmt.border` gained `s` (style) and `w` (px)** alongside `{t,b,l,r:hex}`. One
  style/width per cell (all its sides share them), Sheets-like. Legacy borders
  with no `s`/`w` default to solid/1px in `cellBorderCss`.
- **Border window** (`openBorderMenu`) is a 2×5 icon grid — All, Inner, Horizontal,
  Vertical, Outer / Left, Top, Right, Bottom, Clear — plus a color **pencil** and a
  line-style picker (Thin/Medium/Thick + Dashed/Dotted, `BORDER_PRESETS`). Each
  position icon shows *where* the line lands.
- **Positional ops resolve against the selection's on-screen grid** (`borderGrid`
  buckets cells by rounded top/left into rows/cols; `borderSides` maps op+position
  → sides). So Outer draws only the frame (shared inner edges suppressed), Inner/
  Horizontal/Vertical draw interior lines, edges hit only their row/col. Single-cell
  selections: Outer/All = 4 sides, Inner/H/V = nothing. `fmtTargets` now derives
  from `targetEls` (keeps the element so positions are readable).

### D80 — Toolbar bug fixes: format-before-write, font toggle, size stepper (2026-08-13)

Three toolbar bugs Nate hit:

- **Formatting an empty cell was wiped the moment you typed into it.** `scheduleNote`
  set `CELLS[key] = { text }`, dropping the cell's `fmt`/`cat`. The server's note
  upsert only touches `body` (it *keeps* fmt), so this was purely the local model
  discarding it — the format would reappear on reload but vanish live. Fix:
  `scheduleNote` now carries `fmt`/`cat`/`catId` forward when writing text. So
  "select empty cell → bold → type" keeps the bold (the intended pre-format flow).
  Clearing a cell still deletes the note (server deletes the row on `clear`).
- **The font picker "freaked out" when opened then closed without picking.** The
  outside-close listener runs on `mousedown` **capture** (fires before the toolbar
  `click`), so clicking the open font button closed the menu then the click
  reopened it — you could never toggle it shut, and it flickered. Fix: track
  `PALETTE_KIND`; the capture handler skips closing when the mousedown is on a
  toolbar palette-opener (`fill/text/border/font/condfmt`), and each opener toggles
  via `togglePalette(kind)`. Clicking the button now cleanly opens/closes; clicking
  a different opener switches; clicking a cell closes it.
- **The font-size ± stepper jumped by 1–2 on its own.** It read the step base from
  `firstFmt().size`, which updates async — rapid clicks read a stale value. Fix:
  step from the input's shown value (synchronous source of truth). Verified clean
  ±1 stepping (11→15, 14→12).

### D81 — Single-cell selection ring made visible over fills/borders (2026-08-14)

Clicking one cell set `SEL`/`.sel` but often showed nothing. `td.sel` used
`box-shadow: inset 0 0 0 2px var(--signal)` at `z-index:3` — a box-shadow on the td
sits *under* the cell's own children, so a cell's fill (`background-color`) or real
border (`.cell` border, D79) painted right at the edge hid the ring. Range
selection already solved this (D71) with a high-z `::after` overlay. Fix: give
single-cell `.sel` the same `::after` overlay (`z-index:6`, ring only, no fill
tint — Sheets single-cell style). Verified visible on scheduler, built-in grids,
and custom sheets, including over a thick-bordered cell.

### D82 — Whole-app bug scrape + hardening; UI theme sweep (2026-08-14)

A three-agent read-only audit (client core / client rest / server+SQL) plus
adversarial stress testing. Confirmed bugs fixed:

- **`schedule_notes.slot` cap breaks 4th+ rows.** The 3-rows/day limit was dropped
  for `loads` (D65/D68) but `schedule_notes_slot_check (slot ≤ 3)` was missed, so a
  load could sit at slot 4 but noting/coloring/formatting that cell 500'd. Migration
  `20260813000004_schedule_notes_slot.sql` relaxes it to `slot >= 1`. (Verified live:
  a load already existed at slot 4.)
- **Clearing content destroyed a cell's formatting.** "Clear" deleted the whole
  `schedule_notes` row where `fmt`/`category` live, so undoing a text-add (or clearing
  a category color) on a formatted cell wiped the fill/border. Now clear/color-null
  keep the row (blank the body) when `fmt` or category is set, and drop it only when
  truly bare — Sheets parity (Delete clears content, not format). Fixed server-side
  (`api_schedule` clear, `api_cell_color`) and client-side (`scheduleNote`,
  `setCellColor`). Extends the D80 principle.
- **`api_unschedule` had no invoiced-lock guard (D29).** Unscheduling an invoiced
  load (undo-move / toolbar clear) hit the FK RESTRICT as a raw 500. Now raises the
  same friendly lock error the sibling paths do.
- **Umatilla/EAST chip coloring was dead code.** Code tested
  `timing_window === "umatilla"`, but EAST is the `is_umatilla` boolean (D36) —
  `timing_window` is early/anytime only. EAST cells rendered as normal early/anytime.
  Fixed in `buildChip` (`02`) and the internal-order tracker (`04`); adds an EAST flag.
- **Toolbar swatch showed the stale color after a recolor.** `renderFmtBar()` ran
  before `applyFormat`'s async model update. Moved it into the `.then` (and dropped
  the redundant sync calls) so fill/text/font/bold indicators reflect the new state.
- **Marquee selection survived a chip/control click**, so the next format hit stale
  cells. `selStart` now clears the marquee on a chip / non-toolbar-control click,
  while still preserving it for formatting-UI clicks (`.fmtbar`/`#palette`/etc.).
- **Hardening:** border ops re-resolve detached SELSET nodes before reading rects
  (`liveTargetEl`); `api_grid_cell_fmt` allow-lists `table` (CUSTOM_TABLES) + `field`;
  filename doc-classifier anchors `\binv\b`/`\brc\b`/`\brate\b` on word boundaries;
  `fmt.size` is `parseInt`-guarded at every emission; deferred Supabase/Graph adapters
  route through `_urlopen` (D35). `mondayOf` backs up to the true Monday (`(day+6)%7`)
  instead of returning next Monday on Sundays — view-only, Nate's OK.

**UI theme sweep:** the app is well-tokenized. The only literal colors are
intentional (white text on `--signal`/`--bad` buttons, black-alpha drop shadows,
the neutral `#333`/`#fff` PDF-viewer backdrop). All recent popovers (font menu,
border window, conditional-formatting, size stepper) use theme tokens and render
correctly in both light and dark — verified visually.

**Noted, not fixed (latent/low):** `documents.load_id` cascade-deletes on clear
(no code sets `load_id` yet); internal-order numbering is a select-max-then-insert
race (negligible single-dispatcher).

### D83 — Single-click selection actually works; multi-cell delete (2026-08-14)

- **Single-click selection was dead on real clicks** (D81 only fixed the ring's
  *visibility*; the deeper bug was the ring never getting added). Root cause:
  `selectCell` was bound to `mousedown`, but the marquee's `selStart` calls
  `e.preventDefault()` on `pointerdown` — which suppresses the compatibility
  `mousedown` in Chromium. So on a real click `mousedown` never fired and `.sel`
  was never set. (Synthetic tests that dispatched `mousedown` directly masked it.)
  Fix: do the single-cell selection inside `selStart` itself (commit any open edit,
  set `SEL_ANCHOR`, `selectCell(td)`), so it no longer depends on the suppressed
  event. The `mousedown` handler stays for click-away edit-commit (that path isn't
  preventDefaulted). Verified with real clicks: ring appears, moves, no duplicates.
- **Multi-cell delete** (Nate): Backspace/Delete now clears the whole marquee
  selection, not just the single cell — one undoable step. `deleteSelection()` maps
  each selected element to a `clearCellOp` (grid/sheet value → "", placed load →
  unschedule to staging, note cell → clear), runs them together, and pushes one
  `histPush`. Empties are skipped. Verified: marquee two cells → Delete clears both
  → one Cmd-Z restores both.

### D85 — Platform pivot: metadata-driven Database core (2026-08-14)

**Direction (Nate):** grow Dept 12 from a hard-wired freight app into a
configurable ops platform (Airtable/Acumatica-style) where an admin adds/renames/
reorders/retypes fields, adds whole databases, attaches conditional formatting to
any column, and eventually re-wires how dispatch reads from the databases. Built
**incrementally** so the app keeps working; "worst case we roll back — that's why
we have GitHub." Nate is the sole user for now and wants maximum freedom, with two
carve-outs that stay typed + SQL-queryable no matter what: **delivery date/timing**
and **internal transfer cost**. This partially supersedes the old golden rule
"model the schema around real freight entities" — see CLAUDE.md.

**Architecture:** three metadata tables (migration `20260814000002`):
- `entities` — one row per database (`slug`, `name` renamable, `kind`
  builtin/custom, `backing_table`, `sort_order`).
- `fields` — generalizes `grid_columns`. **Stable `id` is the wiring anchor**;
  `key`/`label` are renamable properties, so "fully rename a field" never breaks a
  reference. `storage` = `column:<table>.<field>` (real typed column) or `json`
  (lives in the record jsonb / the backing table's `custom`). `ui` names special
  cell renderers (designation/equipment/truckdriver/color). `width`, `hidden`,
  `sort_order`, `locked` (report-critical), `conditional_format`.
- `records` — generic row store for future custom entities (built-ins keep their
  real tables + `custom` jsonb).

**Phase 1 shipped so far (all verified in-browser, byte-identical regression gate):**
1. Schema + seed — the 4 built-ins seeded as entities/fields mirroring today's
   columns exactly; bootstrap serves them.
2. **Generic renderer** — `vDatabase → vBuiltin` + `fieldTh`/`fieldCell`/
   `builtinRows` replaces the four hardcoded grid bodies; special cells become
   field `ui` handlers; custom columns still ride `grid_columns`.
3. **Rename tabs + columns** — double-click; `api_entity_update`/`api_field_update`;
   `subsOf` builds Database tabs from `entities`; shared `inlineRename()`.
4. **Column drag-resize** — pixel-precise via `table-layout:fixed` (scoped to a
   `.gridfixed` class so custom sheets are untouched); persists `fields.width`.
5. **Fleet color chip** (#4) — replaces the raw `<input type=color>` with a picker
   chip (`openSheetsPicker` → `drivers.color`), like the designation cells.

6. **Manage columns (hide/reorder)** — a "Columns" button opens a list of a
   builtin's fields with a show/hide checkbox and up/down reorder, writing
   `fields.hidden`/`sort_order` (already-existing `api_field_update` support,
   no schema change). `manageColumnsModal`/`colmgrRowsHtml`/`refreshColMgr`.
7. **Per-column conditional formatting** — right-click a field header (D85
   right-click redesign, below) opens a rule editor (`fields.conditional_format
   = [{op,value,color}]`; first match wins, top to bottom). Applied in
   `fieldCell`/`dcell`; a manually colored cell (`gridFmtOf` fmt.fill) always
   wins over a rule, same precedence as fmt.fill > category color elsewhere.
   `condFmtFieldModal`.
8. **Add-column feeds the Add-row popup** — custom `grid_columns` for a
   builtin now render inside its Add-customer/-location/-truck modal (a
   "Custom fields" section via `customFieldsHtml`), so a new row can be filled
   in fully at creation instead of a second inline pass. `saveCustomFields`
   posts each filled value to `/api/row/custom` after the base row is created.

**Phase 1 shipped in full** (items 1–8 above) — all verified in-browser.

**Phase 2 shipped so far:**
- **External push-coloring** — `loads.pushed_at` (migration `20260814000003`),
  stamped on the pushed truck's loads for the pushed week when
  `/api/sheets/push-driver-tabs` confirms (`_driver_week_payload` now carries
  `truck_id` per driver so the handler can target the update). Client:
  `pushColorFor(o, v)` (D85, `02-chips-extract.js`) — once `pushedAt` is set,
  an external chip's fill is the truck's CURRENT `driver_color` (looked up
  live via `truckById`, so it follows reassignment, not frozen at push time),
  ahead of fmt.fill/category in `chipHtml`'s precedence chain. Internal is
  unaffected — still purely designation-driven (D72). Verified live: pushed a
  load, reassigned its truck to a different colored driver, chip recolored
  without touching the load row.
- **Create custom databases from the UI.** A "+ New database" tab (next to
  "+ New sheet") creates a `kind='custom'` entity (`api_entity_create`, no
  `backing_table`, no `slug` — addressed as `SUB = "custom:<id>"`, resolved by
  `entityByKey`, same convention as `sheet:<id>`). Its columns ARE `fields`
  (`storage='json'`, `api_field_create`/`api_field_delete`, migration adds
  nothing new — the metadata core already had this shape) instead of the
  legacy `grid_columns` the 4 builtins still ride; its rows are `records`
  (`data` jsonb keyed by field id, `api_record_create/update/delete`).
  `vBuiltin` now branches on `ent.kind` to source rows from `recordRows(id)`
  instead of a real table, and `fieldCell` dispatches json-storage fields to
  a new `jsonCell`. Deleting a custom database cascades fields+records via FK
  (`api_entity_delete`; builtins can't be deleted). Verified live end-to-end:
  created a database, added a field, added a row, edited the cell, confirmed
  it landed in `records.data`, deleted the database.
- **Right-click redesign (Nate's ask, mid-build):** replaced the inline ⋮
  menu buttons (field headers' conditional-formatting menu, custom columns'
  "Column options" menu) and the sheet grid's inline "Delete sheet" button
  with a right-click context menu — cleaner headers, one interaction pattern
  for "act on this thing" instead of a button per thing. Extends the existing
  scheduler-cell context menu (`openCtxMenu`, D66) with a generic `openMenu(x,
  y, items)` in `09-color.js`; the shared `contextmenu` listener now also
  branches on `th[data-fieldid]` (conditional formatting / hide / delete-if-
  custom), `th[data-customcol]` (edit/delete a legacy grid_columns column),
  `.sub-tab[data-sub^="sheet:"]` (rename/delete a sheet), and a custom-entity
  `.sub-tab` (delete database). Same `#ctxmenu`/`.ctxmenu` styling and
  outside-click-closes behavior as the existing scheduler menu — no new UI
  language. The toolbar's own "Conditional formatting" button (`data-fb=
  condfmt`) is untouched — that's the older, separately-scoped Bagger
  Customers designation legend (D72/D75), not this per-field feature.

**Phase 3 started — dispatch reads from metadata bindings, slice 1:**
investigation found the gap was bigger than expected — outside `vBuiltin`'s
Database-grid rendering, nothing read `fields.label`; the order drawer,
chip builder, and Driver View all hardcode label strings. Rewiring all of
it (values too, plus orders/loads/drivers/schedule_notes, which have no
metadata entity and include the delivery-date/timing and internal-transfer
carve-outs that must stay typed) in one shot was too large a single change,
so Phase 3 is being sliced. Slice 1 (shipped): the internal-order drawer's
customer panel (`openInternalOrder`, `03-drawer-billing.js`) now renders
its 8 row labels via a new `fieldLabel(slug, key, fallback)` helper
(`04-views.js`, next to `entityBySlug`) instead of literals — renaming a
field in Database → Bagger Customers now propagates to the drawer live,
falling back to the old literal if metadata is ever missing so a label can
never blank out. Migration `20260814000004_umatilla_field.sql` also closed
two real gaps found along the way, corrected same-day per Nate:
- `locations.is_umatilla` got a `fields` row on `bagger`/`pickdrop` so it's
  wired, but shipped **hidden** — Nate: the location Designation color
  already distinguishes "Umatilla early" vs. "Umatilla anytime" (he'd split
  the single seeded "Umatilla side" category into those two live in the
  legend editor), so a raw is_umatilla checkbox next to it in the grid is
  redundant. The column stays hidden, not deleted — `buildChip`'s EAST flag
  still reads the real `is_umatilla` value, unaffected.
- `locations.miles_from_umatilla` (added `20260806000006`, D36 — Rexius
  dispatches out of two yards, Coburg and Umatilla) never got a `fields`
  row on `bagger`, so the sheet's second mileage figure was invisible in
  Bagger Customers even though the column existed in Postgres already —
  Nate caught this ("two mileage sets in the original sheet"). Added,
  visible, next to `standard_miles`.

Verified live: renamed "Notes" in the Bagger Customers grid, confirmed the
drawer picked it up without a reload, reverted the test rename; confirmed
`is_umatilla` is present in metadata but not shown as a grid column;
confirmed Umatilla Miles now populates from real data. Chip rendering,
colors, and all write paths are untouched by this slice.

### D86 — Order tracker: Stage moved to the leftmost column (2026-08-14)

Nate: the stage/status indicator (On board / Staged / Stage → button, plus
No delivery for internal) lived in the last column of both Internal and
External Orders — behind 8-10 scrollable columns, so checking an order's
status meant scrolling all the way right. Moved it to column 1 in both
`vOrders` (external, `04-views.js:267`) and `vInternal` (internal, `:364`).
Copy (external-only) and No delivery/Undo (internal) stay as standalone
buttons in the last column, no longer paired with the stage pill. Internal
Orders' dead/cancelled state now shows its own pill (`No delivery`) in the
leftmost column instead of suppressing the stage indicator entirely.
Verified live in both grids; Copy confirmed still rightmost after Docs.

**Same-day follow-up — real lifecycle stages, not on-board/staged pills.**
Nate wanted actual lifecycle stages instead of the placement-derived pill:
Internal = No delivery / Staging / Scheduled / Delivered; External = Staging
/ Scheduled / Delivered / Billed. Investigated first: `orders.stage` (the
`order_stage` enum from the initial schema — ordered/released/scheduled/
delivered/closed/cancelled) turned out to be dead — nothing ever writes it
except the existing cancelled↔ordered "No delivery" toggle, so `released`/
`scheduled`/`delivered`/`closed` are never set. `STAGED` (the client-side
staging-rail array) is pure in-memory state, not persisted — resets on
reload. Rather than start writing to the unused enum or persisting `STAGED`,
kept the same computed-not-stored approach the old on-board pill already
used (`placement()`/`pm[o.id]`), just with real precedence:
- Internal: `stage==='cancelled'` → **No delivery**; else `delivered_at` set
  → **Delivered**; else on board (`pm[o.id]`) → **Scheduled**; else
  **Staging** (the new default — previously the dash "—"/nothing).
- External: `billed_at` set → **Billed** — this is the real field the
  Billing page's own biller-queue toggle already writes (D62,
  `api_bill_order`/"Reopen for billing"), not a guess. (First pass read
  `DB.invoices` instead and mislabeled several delivered-but-unbilled rows
  as Billed — caught immediately in verification since `billed_at` was
  sitting right there; fixed same session, see `orders.billed_at` D62.)
  Else same delivered/scheduled/staging chain as internal.
Both live in a new shared `stagePill(o, on)` (`04-views.js`, above
`vOrders`), used by both grids' leftmost cell. The "Stage →" action button
(pushes an order into the `STAGED` rail for the scheduler's staging panel —
unrelated to the new label, still ephemeral/session-only) moved out of the
pill cell into the actions column, gated by a new `canStageOrder(o, on)` so
it only shows while an order is actually in the Staging bucket — no dangling
"Stage →" on a Delivered/Billed/cancelled row. New CSS `.pill.billed` (signal
color) since only 3 semantic pill colors existed (on/mid/bad) for what are
now 4 states. Verified live: all four states render correctly per grid,
Billed rows (seeded invoices) show the new orange pill and hide Stage →,
Copy/No-delivery/Undo unaffected.

**Later phases:** the rest of Phase 3 (chip-builder flags, Internal Orders
grid headers, External Orders drawer — Driver View is explicitly excluded,
out of scope per the driver-facing golden rule); admin wiring/automations.

### D87 — Truck column drag-reorder; tarp toggle; external chip redesign (2026-08-14)

Three Nate requests landed together:

**Drag-and-drop truck column reorder.** New `trucks.sort_order`
(`20260814000006_truck_sort_order.sql`, backfilled to the existing
alphanumeric-by-number order so nothing moved on deploy); `api_bootstrap`'s
trucks query now `order by t.sort_order, t.number`; `api_add_truck` appends
new trucks at `max(sort_order)+1` instead of defaulting to 0 (which would've
jumped them to the front). Persistence reuses the existing generic
`api_update_row`/`/api/row` updater (D85-era pattern) — just added
`sort_order` to trucks' allowed-columns set — no new endpoint. Client:
`th.trkcol[draggable=true]` in `buildScheduler()`'s header loop, wired into
the existing chip/invoice `DRAG` global-state HTML5 DnD machinery
(`11-toolbar.js` dragstart/dragover/dragleave/drop) as a new
`DRAG.kind==="truckcol"` branch — same pattern as chip dragging, no new
drag system. `reorderTrucks(draggedId, targetId)` (`04-views.js`, by
`truckColHeader`) splices `DB.trucks` client-side, re-renders immediately
(`schedNode=null; render()`, the existing YEAR-change pattern), then
persists every truck's new `sort_order` via `Promise.all`. Cell keys are
`truck_id`-keyed (D32), not column-index-keyed, so this is purely a display
reorder — no CELLS/loads rewiring. **Current Week mirrors automatically**
(Nate's ask) since `vCurrentWeek()` already iterates the same `DB.trucks`
array with no separate copy — confirmed live, no Current-Week-specific code
needed. Side effect, not addressed: the Fleet Database grid's row order
also derives from `DB.trucks`, so it'll reorder too — flagged, not fixed.
**Caught during verification:** the first drag produced a silent no-op
(`{"ok":true}` from `api_update_row` — empty `sets`) because the Python
server process was still running the pre-edit `server.py`; JS is reassembled
per-request but Python needs a restart to pick up code changes. Restarted,
redragged, confirmed `trucks.sort_order` actually changed and survived a
reload. **Second bug, caught by Nate right after shipping:** dragging a
truck header instead selected the scheduler cell underneath it. Root cause:
`selStart` (`10-select.js`, the D66/D70/D71 pointerdown-driven cell-marquee
handler) runs on every `pointerdown` in a `.grid-wrap` with no exclusion for
`th` — it doesn't select a `td` for a header click (no `td[data-key]`
match), but it still calls `e.preventDefault()` unconditionally, which kills
the browser's native HTML5 dragstart before it can begin, and still arms a
marquee drag starting from the header. Fixed by adding a `th.trkcol` early-
return in `selStart`, right alongside the existing `.chip` exclusion (same
reasoning: some drag targets need pointerdown to fall through untouched so
native DnD — not marquee-select — owns the gesture). Verified: a mouse-drag
starting on a truck header no longer paints a selection marquee; normal
cell-to-cell marquee selection elsewhere in the grid still works; the
synthetic-DragEvent reorder test still reorders `DB.trucks` correctly.

**Tarp load toggle.** Was free text buried in `orders.notes`
("tarp, appointment, etc."); Nate wanted a real toggle instead, both because
typing "tarp" isn't a queryable/flag-able signal and because the removed
BROKER chip flag (see below) left an obvious slot for it. New
`orders.tarp boolean default false` (`20260814000005_order_tarp.sql`,
external-only concept per the legacy sheet's External Order Tracker, so not
surfaced on Internal Orders). `tarp` added to `api_update_order`'s allowed
set. Checkbox added to the External Orders grid (new "Tarp" column) and the
`openOrder` drawer, both riding the existing `data-oedit`/`data-field`
generic-update wiring — which only handled `.value` before; fixed the
shared `change` listener (`07-events.js`) to read `.checked` for
`type==="checkbox"` instead, since that's a real (if latent) gap for any
future checkbox on this path. `buildChip` pushes a `TARP` flag when set.

**External chip redesign.** Nate: the External chip's "BROKER" flag added
no information (it's always a broker/customer, of course it says BROKER),
and he'd rather see customer name / origin → destination city / load #
& order # than broker name + load#/order#. `buildChip`'s external branch
(`02-chips-extract.js`) now: title = `o.broker_name` (still the resolved
Broker/Customer party name — "broker" is the field name, not what's shown),
line = `originCity → destCity · loadNo / orderNo` (via `locById` on
`pickup_location_id`/`delivery_location_id`, falling back to "?" when a
location isn't set yet). BROKER flag removed entirely; TARP (above) fills
that flag slot when relevant. "NO ORDER #" warning flag unchanged.

**Drawer/grid stage sync.** `schedBar()` (the order drawer's status strip,
`03-drawer-billing.js`) was still hardcoded "On the board"/"Staged"/"Not
scheduled" — stale against the D86 Stage column redesign. Now calls the
same `stagePill(o, on)` used by both grids, so the drawer can never show a
different stage than the grid it was opened from; kept the jump-to-scheduler
button and staging-rail note as before. Applies to both `openOrder`
(external) and `openInternalOrder` (both call `schedBar`).

Verified live throughout: dragged a truck column, confirmed Current Week
followed, confirmed `sort_order` persisted after reload; toggled tarp in the
grid, confirmed it landed in Postgres and (after a bootstrap refresh — the
D84 in-place-model-update means a same-session chip won't show a toggle
until the next full render, expected) showed as a chip flag; opened the
drawer and confirmed its stage pill matches the grid's row.

### D88 — Database grid edits no longer reload the whole app (2026-08-14)

Nate: "when im in a database i cant scroll without beating how fast the page
loads the database... it adds lag while it loads." Root cause: `gridCellSet`
(`08-undo.js`, the persistence function behind every typed-cell commit AND
the drawer's `dcellRow`) and the `data-rowtable` `<select>` handler
(`07-events.js` — Fleet's equipment dropdown, the Designation dropdown via
`designationSelect()`, D72) both ended in `.then(reload)`: a full
`/api/bootstrap` refetch (every table in the app) followed by nuking and
rebuilding the ENTIRE current view's `innerHTML`. On a Bagger Customers grid
with 300+ rows, that's a real stall on every single field edit, and because
`main.innerHTML = ""` + rebuild always lands scrolled to the top, it reads
exactly like "can't scroll" — any edit while scrolled down snaps the view
back to row 1.

Fixed the same way D84 already fixed this for the order drawer: patch the
one changed row's fields in the in-memory `DB` array instead of refetching
everything. New `patchLocalRow(table, id, row)` (`08-undo.js`, table ∈
parties/locations/trucks/drivers — the four real tables Database grids edit
directly) replaces both `.then(reload)` call sites. The Designation
`<select>` tints its own background with the chosen category's color
(`designationSelect()`); since skipping `render()` means that repaint
wouldn't otherwise happen, the `data-rowtable` handler now also recomputes
just that one `<select>`'s background/text color inline when the edited
field is `category_id` — a targeted DOM patch, not a rebuild. Left
`gridCellSet`'s `table==="sheet"` branch (custom spreadsheet cells, D74) on
`reload()` for now — the sparse-storage delete-when-empty behavior made an
equivalent in-place patch riskier to get right without checking against a
sheet in active use; flagged as a follow-up, not fixed here. Driver-color
picker (`data-colorchip`) and category legend recolor/rename
(`data-catcolor`/`data-catname`) already had (or separately still have)
their own reload path — out of scope for this pass, lower-traffic controls
than a scrolling grid of typed cells.

Verified live: scrolled deep into Bagger Customers (row ~70+), changed a
Designation dropdown, confirmed via network log that only one `POST
/api/row` fired with no follow-up `GET /api/bootstrap`, and confirmed the
scroll position held (no snap to top). Reverted the test edit.

### D89 — Bagger Customers Designation backfill from the live sheet (2026-08-14)

Nate: go through the future TMS sheet and designate every Bagger Customer
correctly. Turned out `locations.timing_window`/`is_umatilla` were already
correct — `scripts/import_bagger_customers.py` (D36) keeps those synced from
the sheet's Early/Anytime column — but `category_id` (the Designation
dropdown/color, D65/D72) came **after** that importer was written and was
never backfilled, so almost every location's Designation was blank even
though the underlying data was there. New `scripts/designate_bagger_customers.py`:
reads the live Bagger Customers tab directly (not the already-imported
columns, so it reflects whatever's on the sheet right now), same parse rule
as the existing importer ("Umatilla" in the cell → Umatilla; "Early" → early,
else anytime; blank → untouched), matches to existing `parties`/`locations`
by case-insensitive name, and sets `category_id` to the matching category
(Early store / Anytime store / Umatilla early / Umatilla anytime — the
categories.name rows are looked up by name, not hardcoded ids). Only updates
existing rows — never creates/edits parties or locations, and reports
(without touching) any sheet row with no DB match or DB customer with no
sheet row, so nothing gets silently guessed.

Ran `--dry-run` first, reviewed the report, then for real:
**265 updated, 2 already correct, 0 sheet rows unmatched, 5 DB customers
with no sheet row** (left alone — "Rosboro Lumber Co", "Bi-Mart 601"/"602"
[duplicates of "BI-MART #601"/"#602" under different casing/spacing],
"Grange Co-op Medford", "New customer"). Verified live: DB counts by
category (194 Anytime store / 53 Early store / 16 Umatilla anytime / 4
Umatilla early) match the sheet's raw column counts exactly; Database →
Bagger Customers now shows every row's Designation colored correctly.

### D90 — Row drag-reorder on Bagger Customers (2026-08-14)

Extends D87's truck-column drag to grid ROWS, scoped to Bagger Customers for
now (Nate's ask). New `parties.sort_order` (`20260814000007_party_sort_order.sql`,
backfilled alphabetically, partitioned by `is_customer` so customers and
brokers/carriers get independent sequences sharing the one column);
`api_bootstrap`'s parties query now `order by sort_order, name`; `sort_order`
added to parties' `/api/row` allowlist; `api_add_customer` appends a new
customer at `max(sort_order)+1` within `is_customer` instead of defaulting
to 0.

Client: the existing Excel-style row-number gutter (`selTd`, D50 — already
used for click-to-select) grows a `draggable="true"` + `data-partyid`
variant (class `rowdrag`) only when `grid === "bagger"`, so Fleet/Pick-Drop/
brokers/custom sheets are untouched. Reuses the D87 `DRAG` global-state DnD
plumbing as a new `DRAG.kind === "bagrow"` branch (`11-toolbar.js`) and a new
`reorderBaggerRow(draggedId, targetId)` (`04-views.js`, beside
`reorderTrucks`) — same shape: splice `DB.parties`, `render()` immediately,
persist every customer's new `sort_order` via `Promise.all`. No `selStart`
exclusion needed this time — `[data-rowsel]` (which `data-partyid` rides
alongside) was already excluded from the D66/D70/D71 cell-marquee handler,
so the D87 header-drag bug (pointerdown's `preventDefault()` eating the
native dragstart) didn't recur here for free.

Verified live: dragged a row to the top, confirmed it persisted after
reload; confirmed plain click-to-select (no drag) still works on the same
cell; confirmed External Customers (only 1 broker row in this DB) is
unaffected. Reverted the test drag back to alphabetical via the same
backfill query.

### D91 — Row-drag scroll lag; toolbar Sort for Database grids (2026-08-14)

**Row-drag scroll lag.** Right after D90 shipped, Nate reported the Bagger
Customers list laggy to scroll. `selStart` (10-select.js) already excludes
`[data-rowsel]` from the marquee handler, and D88 had already killed the
reload-per-edit cause — so this was new, from D90 itself: making the entire
270+-row-number `<td>` `draggable="true"` meant the browser had to
disambiguate "is this gesture a drag-start or a scroll" starting from
anywhere in that whole column, which reads as hesitation/lag on every scroll
that begins near it. Fixed by shrinking the drag target: the `<td>` itself
is no longer draggable — a small `⋮⋮` grip (`.rowgrip`, `draggable="true"`,
opacity 0 until row-hover) sits inside it and owns `dragstart`; `dragover`/
`dragleave`/`drop` still target the whole `td.rowdrag` (a generous drop
zone), only the drag *source* narrowed. `selTd`/`11-toolbar.js` updated to
match. Verified: drag still works via the grip; a synthetic scroll-timing
check (20 forced-layout scroll steps) showed no obvious layout cost either
way, but the fix addresses the actual mechanism (gesture disambiguation),
not a guess.

**Toolbar Sort.** Nate: "sort data in the database however I want." New
per-grid, session-only view sort (not persisted, doesn't touch any
`sort_order`) — a "Sort" button in every builtin/custom Database grid's
toolbar (`vBuiltin`, next to Columns), opening a field list via the existing
D85 `openMenu(x,y,items)` popover. Picking a field sorts ascending; picking
the same field again flips to descending, a third click (or "Clear sort")
returns to the grid's stored/manual order. New `GRIDSORT` global (keyed by
grid key, `01-core.js`) and `fieldRawValue(f, ctx)` (`04-views.js`) — the
same value `fieldCell()` would render, but as a comparable primitive,
covering the special `ui` renderers too (designation sorts by the
category's name, not its uuid; truckdriver/color/equipment read straight
off the truck row) so every visible column is sortable, not just plain
`storage='column:...'` ones. `sortRows()` applies it before `vBuiltin`
renders rows; numeric fields compare numerically, everything else via
`localeCompare` with `numeric:true` (so "BI-MART #605" < "BI-MART #620"
sorts naturally, not lexically). Manual drag-reorder (D90) is disabled
while a sort is active on Bagger Customers — the grip only renders when
`!GRIDSORT[grid]`, since reindexing a drag against sorted-but-not-actually-
reordered rows would silently corrupt the stored order (same reasoning
Airtable/Sheets use). Caught and fixed one bug in passing: `gridKey()`
diverges from the entity's own slug for brokers only (`"external"` vs.
`"brokers"`) and the existing `+ Column` button on External Customers
(`data-addcol`) already called `entityByKey(gk)` directly, which fails
silently for that one grid since `entityBySlug("external")` matches
nothing — pre-existing, unrelated to this feature, not fixed (flagged only
so the sort handler doesn't repeat it: it translates `"external"` →
`"brokers"` before resolving the entity).

Verified live: sorted Bagger Customers by City (alphabetical, confirmed
blank-Designation rows group correctly under Designation sort), toggled
asc→desc→cleared, confirmed the row-drag grip disappears while sorted and
reappears once cleared; sorted Fleet by Driver (exercises the `ui:
truckdriver` raw-value path) and got the correct alphabetical order with
unassigned trucks first. No console errors throughout.

### D92 — Verify the real handoff; normalize metadata grid lookup (2026-08-14)

Nate asked to run the real app before trusting the written handoff. Started
`app/server.py` against the local `dept12` database (151 orders), loaded the UI
in-browser, and tested the D85 Database controls directly. The D91 note saying
External Customers' `+ Column` failed was stale: it already opened the legacy
custom-column modal correctly. The real failure was **Columns** —
`manageColumnsModal("external")` called `entityByKey`, which cannot resolve the
metadata entity whose slug is `brokers`, so the button silently did nothing.

Added `entityForGrid(key)` as the single `external` → `brokers` translation and
used it for metadata-backed grid toolbar lookups. External Customers' Columns
modal now opens all four fields; `+ Column` still opens normally. The same live
sweep found custom database tabs could not be renamed: the double-click handler
used `entityBySlug("custom:<id>")` despite the rest of the custom-entity UI using
`entityByKey`. Switched that handler to `entityByKey`. Verified by creating a
temporary custom database, renaming it through the UI, confirming the renamed
tab, then deleting only that test database.

Continued Phase 3's safe label-only slice: Internal Orders' Customer and Timing
headers now use `fieldLabel("bagger", ...)`, so the live metadata label `Window`
appears there and future admin renames propagate. Order-owned fields, chip value
bindings, and Driver View remain untouched; those need a deliberate binding
design, not guesses. JavaScript syntax and `git diff --check` pass; live UI has
no console errors.

### D93 — Order actions at left; cancel/delete; Database scroll fix (2026-08-14)

Nate: both order trackers still put the Stage button at the far right even after
D86 moved only the status pill; there was no cancellation in the trackers or
order drawer, no order deletion, the Database column resize click target felt
off the divider, and Bagger Customers scrolling was severely laggy.

**Tracker/drawer actions.** New shared `stageControls(o,on)` keeps the lifecycle
pill and its Stage + Cancel/Restore buttons together in the first column for both
Internal and External Orders. That column is sticky-left during horizontal
scroll. Stage was removed from the far-right actions cells; External keeps Copy
there and both trackers expose Delete there. Both internal/external drawers use
the same status/action strip and add a Delete button in the header, so tracker
and drawer behavior cannot drift again.

**Cancel/restore/delete.** New `/api/order/cancel` detaches an unlocked order
from its load, removes it from the session staging rail, and marks it cancelled;
Restore returns it to ordered/staging but deliberately does not guess its former
truck/date. Shared internal loads keep their other order links. An empty load
with load-attached documents is retained as an unscheduled cancelled shell so
paperwork is not cascade-deleted. New `/api/order/delete` permanently removes an
unlocked order after an in-app confirmation, including order-owned document rows
and storage files. Delivered, billed, and invoiced orders are rejected by the
server for both operations. Verified with temporary orders: tracker Stage →
Cancel removed it from the rail, Restore returned the controls, Delete removed
the row; a separately scheduled slot-99 test order cancelled to zero
`load_orders`/zero orphan load, then was deleted. All temporary records were
removed.

**Bagger scroll + column divider.** The actual Bagger `.grid-wrap` measured
~7,099px tall: `.pad` owned page scrolling while the intended inner scroll box
expanded to every one of the 274 rows. Database renders now add `.pad.grid-pad`
(flex column + hidden outer overflow), constraining the real grid scroller to
the available viewport (507px in the live test, with the same 7,099px scroll
content). Header stays sticky inside that box and outer-page relayout is gone.
The resize hitbox is now an even 8px centered over the header divider and paints
the exact line on hover. Live internal/external controls, drawer controls,
Database sizing, Python/JS syntax, and browser console all verified clean.

### D94/D95 — Row/document deletion; one color source; tracker/drawer polish (2026-08-14)

Database deletion keeps the numbered gutter Nate chose—no checkboxes. Clicking
row numbers (Shift or Command/Ctrl for multiple) enables `Delete selected` and
shows its count. The guarded server path remains authoritative: referenced
customers, locations, and trucks are rejected; custom records use their own
delete endpoint. A temporary Bagger customer was created and deleted through the
real UI; the row and selection state cleared.

Removed the redundant global Conditional formatting toolbar button/editor.
Migration `20260814000008` copied the four existing designation colors into the
Bagger Customers `Designation` field's conditional rules without overwriting a
non-empty user rule set. Both the designation cell and internal Dispatch chip
now call `designationRuleColor`, so editing that column's rules updates Dispatch.
Live verification proved the distinction: the legacy category color for Early
Store was `#92D050`, while the migrated rule is `#669c35`; scheduled internal
order `07-0526-0007` rendered `#669c35`. Timing badges now use the same
contrasting callout as equipment. EAST text was removed; equipment normalizes to
Forklift, Spyder, or No Forklift.

Billing exposes Delete only in the genuinely unmatched queue. The server rechecks
`matched_by='unmatched'` and that order/load/stop are all null, then removes both
the database row and stored file. A temporary unmatched PDF was created, deleted
through Billing, verified absent from storage, and the existing real unmatched
PDF was left untouched.

Both order trackers use rigid row/action geometry. External has deliberate
right-side overscroll so its complete Copy/Delete column is reachable; browser
testing showed both actions fully visible. Internal mileage/Transfer-$ cells own
their click area and focus their input instead of opening the drawer. Both
drawers lead with the exact live chip preview; Internal then shows customer,
order details, mileage/transfer, and documents last. Preview-relevant drawer
typing repaints the chip immediately, and blur writes serialize to prevent stale
requests winning. Live tests changed External load number and Internal PAL in
the preview, then verified their original database values were restored.

### D96 — Spreadsheet column flow, scheduler geometry, and universal history (2026-08-14)

Built-in Database grids now have one spreadsheet-style column surface. Metadata
fields and older JSON custom columns are interleaved by their shared sort order,
drag directly from the headers, and end with a single `+` header that opens the
existing add-column dialog. The redundant toolbar `+ Column` / `Columns` controls
are gone. Migration `20260814000009` offsets any pre-existing legacy custom-column
orders so they append safely instead of colliding with seeded metadata fields.
Header selection follows row selection: clicking the same selected header or row
number again clears it.

Scheduler Add row no longer collides with Database's add-record handler. The day
menu owns distinct add/remove commands, tracks an explicit displayed slot count,
and refuses to remove rows containing data or the default rows. At 100% zoom,
schedule slots and chips have fixed geometry; all chip lines remain present and
the full composed text is also in the chip title. Month dividers sit beneath the
sticky driver/truck header instead of painting through it.

Tracker rows and buttons are compact and fixed-height, and status pills use solid
state colors with contrast-safe text. Billing's unmatched-document scroller now
reserves enough right padding for the complete Open/Delete action column.

Undo/redo is now a single 50-action app-wide history for committed reversible
mutations: Scheduler moves/notes/formatting, order tracker and drawer fields,
Internal mileage/transfer cost, Database built-in/custom cells, column ordering,
column rename/resize, and column-level conditional rules. The async history runner
resolves its destination stack after each request, preventing redo from writing
into a stale array. Live API-backed tests passed edit → undo → redo → undo for an
External order field and a Bagger customer designation, with both original values
restored. Permanent confirmed deletes remain intentionally non-undoable.


---

### D97 — Contextual Delete, rebinding, and Current Week stepper (2026-08-14)

The physical Delete key (including macOS's Backspace-named Delete key) now routes
to the active section's existing delete action: it clears a selected sheet range,
opens the guarded confirmation for selected Database rows, or invokes the visible
order/document delete action. Inputs, textareas, selects, and live cell editors
retain native typing behavior; live verification typed `abc` in search and
Backspace produced `ab` without opening a delete dialog. Database row selection
now uses the same accent overlay and outline language as cell/column selection.

Settings → Shortcuts exposes Undo, Redo, and contextual Delete alongside the
existing navigation/actions. Every listed action can record any key combination;
assigning an occupied combination moves it from the old action, and every action
or the whole map can be reset. Undo/redo now run through this configurable router
instead of a second hard-coded listener.

Current Week's Days shown control now reuses the formatting toolbar's compact
`− value +` stepper, still clamps/persists 1–14 days, and was live-tested 5 → 6 → 5.

### D98 — Rolling driver handoff and unified selection geometry (2026-08-14)

Current Week is no longer anchored to Monday. It has a persisted **First day
drivers see** date and a default three-day `− value +` window. Weekdays always
count; Saturday/Sunday count only when a real scheduled load exists. This makes
a normal Friday handoff Friday/Monday/Tuesday, while a loaded Saturday becomes
Friday/Saturday/Monday. Browser and server use the same rule. The driver-tabs
button first requests an exact dry-run, then confirms the range; the confirmed
write clears B2:G15 (values and old formatting) before writing the new rolling
window so the oldest days actually disappear. Live API verification returned
`2026-08-14`, `2026-08-17`, `2026-08-18` for a three-day Friday start.

Scheduler weekends are one gray row by default. Schedule data automatically
expands a weekend to normal slot geometry; right-clicking the date exposes
Activate/Collapse weekend for intentionally opening an empty weekend. The manual
state persists per device. Both Saturday activation (1 → 3 rows) and collapse
were browser-tested.

Tracker lifecycle pills and adjacent Stage/Cancel/Restore buttons are exactly
64×20 in both trackers. Whole-column selection now uses one continuous outline,
matching whole-row selection, and toggling the same header clears it. Selection
state now clears both the range and single-cell ring when leaving the grid or
clicking a non-cell area; clicking the same cell toggles it off. Sticky driver
headers were raised above the selection overlay to prevent selection borders
painting through names. Unmatched Billing documents now use a responsive 100%
width table (measured 1,252px table/wrapper at a 1,280px content width).

All true confirmation dialogs also accept Enter/Return as the affirmative
action (D98 follow-up). The handler is scoped to `#modal-confirm` and
`#confirm-del`, so Enter in add/edit/data-entry modals is untouched; a repeat
guard prevents an async Database delete from firing twice.

### D99 — One Bagger Time Window field (2026-08-14)

Bagger Customers now exposes one **Time Window** column backed by
`locations.category_id`; the raw compatibility `timing_window` field is hidden.
The add-customer modal uses the same category dropdown as the grid and order
drawer, and no longer shows the obsolete EAST-run checkbox. Saving a category
derives `timing_window` and `is_umatilla` server-side so older consumers remain
compatible. Migration `20260814000010` updates the field metadata. Live browser
and API verification created an Early-store customer, confirmed all derived
values, and then deleted the test row.

### D100 — Guarded schedule history and balanced tracker actions (2026-08-14)

Past scheduler days are lightly dimmed but still permit note/text corrections.
Their row add/remove and empty-weekend activation controls are disabled. Moving,
clearing, or pasting a load into or out of a historical date requires a clear
confirmation; undo/redo itself does not reprompt.

Future-day Add row and Remove row are universal-history actions. Remove targets
the bottom extra row, warns when occupied, shifts each occupied cell into the
first opening for that truck, and returns overflow loads to Staging. Notes,
colors, and formatting are restored by Undo. Browser verification exercised
empty add/undo/redo plus an occupied fourth-row note through remove, Enter to
confirm, compact-to-slot-one, undo back to slot four, redo, and cleanup.

Both order trackers now keep Status/Stage and External Copy on the left, with
Cancel/Delete on the far right. The columns scroll normally rather than sticking;
all status and action pills measured exactly 64×20 in both trackers.

### D101 — Remove placeholder Time Window (2026-08-14)

The old global designation add action inserted a literal `New designation`
category. Its UI had already been retired, but one unused row remained in the
shared Time Window dropdown. Migration `20260814000011` deletes exact placeholder
rows, and the dead event handler was removed so the value cannot be recreated.

### D102 — Archived D65–D96 to keep the working log lean (2026-08-17)

`docs/decisions.md` had grown to 37 live entries / ~1,220 lines (~19.5k tokens)
— the file's own header rule ("when a decision scrolls past ~5 back, move it to
the archive," set by D69) had gone unenforced since D65. Any agent reading it
for context (routine per the CLAUDE.md docs table) was paying that whole cost
every time. Moved D65–D96 verbatim into `docs/decisions-archive.md` (now
D1–D96, no gaps/dupes — diffed byte-for-byte before/after); this file keeps
D97 forward. Live decisions.md dropped to ~130 lines / ~1.9k tokens. No content
lost, only relocated — same fix D69 already applied once to `app.js`/CLAUDE.md,
just re-applied to this file since it's the one that keeps growing fastest.

### D103 — Internal mileage/transfer-$ move from load to order (2026-08-17)

Nate: the internal drawer's Miles/Transfer $ fields should be fillable the
moment an internal order exists — no requirement to stage or schedule it on a
truck first. That was a real schema constraint, not just a UI gate: these
figures lived on `loads.miles`/`loads.internal_freight_amount` (D38/D48), and
a `loads` row only exists once an order is actually placed on the scheduler
(`truck_id`/`scheduled_date`/`slot` are all required). Asked Nate how to
resolve it rather than guess (D31) — options were move the fields to the order
(breaks the load-level "combine several orders, one shared freight figure"
model) or auto-create a draft load (needs `loads`' truck/date/slot to become
optional, touching scheduling elsewhere). He picked moving to the order.

**Schema** (migration `20260817000001`): `orders` gained `miles`,
`miles_adjusted`, `motive_miles`, `internal_freight_amount` (same types/checks
as their `loads` counterparts), constrained to `kind='internal'` like the
original. `loads.*` equivalents are left in place — external loads still
carry `loads.miles` and nothing in the app writes it, so dropping those
columns wasn't worth the risk for zero benefit. Checked first: only synthetic
`seed.sql` fixture rows had any real values here (real Nate data had none yet
for internal freight), so the backfill risk was near zero. Backfilled anyway,
correctly: miles copies unchanged onto every order riding a combined load
(same truck run); the freight dollar figure — previously one hand-entered
total for the whole load — splits evenly per order so truck-week sums don't
inflate post-migration (verified: a seed load with 2 orders and $285 total
split to $142.50 each, and every downstream report still sums back to $285
for that truck's week).

**Server:** `api_freight` now updates `orders` directly by `order_id` — the
"order is not on the schedule yet" error is gone entirely. `api_motive_sync_miles`
still requires a truck+date (Motive only reports per truck per day), so an
order only gets auto-filled once it's actually staged, same as before — but
now writes onto every order sharing that load individually, respecting each
order's own `miles_adjusted` rather than one flag for the whole load.

**Reporting:** `v_loads_reporting` and `v_freight_transfer_weekly` (`create or
replace view`, same migration) now source internal figures from `orders` via
`load_orders`/`loads`, coalescing to the legacy `loads.*` value for external
so that path is untouched. The Reports "giant dump" (`_DUMP_SQL`) dropped the
derived `internal_freight_share`/`internal_freight_load` split — the order's
`internal_freight_amount` is a real per-order figure now, not something to
divide by `orders_on_load`. External revenue sharing is unchanged (external
loads are always one order per load, so that split was always trivial).

**Client:** `milesCell`/`freightCell` (Internal Orders grid) and the drawer's
Mileage/transfer section (`openInternalOrder`) dropped their `loadForOrder(o.id)`
gate entirely — always render the inputs off `o.miles`/`o.internal_freight_amount`
instead of a resolved load's fields. `loadForOrder` had no other callers left
and was deleted.

Verified live end-to-end: an unstaged internal order ("STAGING", no `loads`
row) showed working Miles/Transfer $ inputs in both the grid and the drawer;
typing a value round-tripped to `orders` and confirmed in Postgres; all three
Reports (`loads`, `dump`, `freight`) returned correct figures with no errors.

### D104 — Drawer restructure, destructive-action placement, broker/customer split (2026-08-17)

A batch of Nate's UI requests on the order drawers and trackers.

**Internal drawer reorder + collapse.** Order details and Mileage/transfer
cost now render before Customer (`openInternalOrder`) — the day-to-day
dispatch fields lead, the customer lookup follows. Customer is wrapped in a
native `<details>`/`<summary class="sec-h">`, collapsed by default, expandable
on click — no new toggle state to track, keyboard-accessible for free. New
`summary.sec-h` CSS (`app.css`) hides the native marker and draws a small
▸/▾ chevron that flips on `[open]`, keeping the same look as every other
`.sec-h` section label.

**Delete removed from both drawers; Cancel moved to the far right.** The
header's Delete button (next to Close, an easy misclick) is gone from both
`openInternalOrder` and `openOrder` — deleting an order is now only possible
from the Internal/External Orders trackers' Actions column
(`destructiveOrderControls`, unchanged). `schedBar()`'s Cancel button no
longer rides inside the left `stage-actions` strip next to Stage → — it's
pulled out and pushed to the end of the `.dw-sched` flex line with a
`flex:1` spacer, matching the "positive actions left, destructive actions
right" split the comment above `stageControls` already documented but the
drawer hadn't actually followed. `stageControls`'s now-unused `includeCancel`
parameter was dropped.

**External Orders' Broker/Customer dropdown was pulling in Bagger Customers.**
`vOrders`' dropdown filtered `is_broker || is_customer` — since every Bagger
Customer has `is_customer=true`, all 271 of them showed up alongside the
handful of real brokers. Fixed to `is_broker` only, the same population the
External Customers Database grid already uses (`builtinRows('brokers')`).
Root cause traced one level deeper: `api_add_customer` (server.py) hardcoded
`is_customer=true` for every new party regardless of kind, so adding a new
External Customer through its own "+ Add customer" modal would have
re-broken this fix the first time Nate used it (and, in the other direction,
would have leaked into the Bagger Customers grid and Internal Orders'
customer picker, both of which filter on `is_customer`). Fixed to set
`is_customer`/`is_broker` from `kind` like the rest of the party model
already assumes — bagger gets `is_customer` only, external gets `is_broker`
only. `brokerList()` (`02-chips-extract.js`, rate-con OCR matching) is
deliberately untouched — its `is_broker || is_customer` is a documented,
different population (the legacy "outside customer list," which really did
include direct-pay mills, not just brokers).

**Billing queue "Done" button.** Read as red to Nate because of his personal
accent color, not literal red — `.btn.pri` uses `--signal`, whatever that's
themed to. Since red is reserved for cancel/delete/missing-info, dropped
`.pri` (now plain `.btn`, the same neutral style Close/Cancel use) and
relabeled it "Mark complete" for clarity. The unrelated toolbar batch action
(`#bill-done-sel`, "Mark done") was already plain and untouched.

Verified live: internal drawer section order and collapsed Customer panel,
delete button absent from both drawer headers with the tracker Actions column
still intact, Cancel right-aligned on its own line in both drawers, External
Orders' dropdown down to just the one real broker, a live `/api/customer`
call confirming `is_customer=false, is_broker=true` on a new external add,
and the Billing "Mark complete" button rendering gray with no accent color.

### D105 — Rate-con extraction stress-tested against 11 real bundles, tightened (2026-08-17)

Nate dropped 11 real Rexius billing bundles into `fixtures/` (Aaron Wilson,
Bob Murray, COT, CTE Logistics, Iosco, Jenks, Nationwide, Open Road,
Tradewinds, Uber Freight, Witham — each an invoice + rate confirmation + BOL/
packing-list PDF, one per broker) and asked for the rate-con → new-order
pipeline (`ingestRateCon`, `parseRateCon`, D7) to be stress-tested and
tightened until it reads them with real confidence — the D27 PO-regex bug had
sat "flagged, deliberately unfixed; ask Nate before tightening" until now.

**Method.** Read every bundle to find the actual rate-con page(s) inside each
(they range 3–8 pages; the rate con is one page on most, 2 on Bob Murray/
Iosco/Open Road, 4 on Uber Freight's multi-stop confirmation) and recorded
ground truth by hand: broker, load/trip/reference #, PO #, rate, pickup/
delivery. Built a harness that, in the real browser, uses the app's own
vendored PDFLib to cut just that page range out of a bundle, synthesizes a
real `DragEvent`+`DataTransfer` drop onto `#rc-drop` (the exact path a real
drag does — the click handler is untouched, only the input path is
synthetic), and reads the resulting order back over the API. Most of these
pages turned out to have no text layer at all despite reading clean
on-screen (only visible via the OCR fallback path, D27) — that alone
disproves the assumption that "looks like clean text" means pdf.js can read
it, which is exactly the kind of thing this stress test was for.

**Confirmed real bugs (verified against actual extracted OCR text, not
guesses):**
- **PO regex grabbed "PO Box 872"** as if "BOX" were the PO number — the
  exact D27 false-positive, now reproduced on a real document and fixed with
  a negative lookahead.
- **PO regex also matched "PO" as a bare prefix of an unrelated word** — an
  address line "...PORTLAND OR, 97217" was read as "PO" + "RTLAND" and
  "RTLAND" got stored as the PO number.
- **"Purchase Order #:" (spelled out) was never recognized at all** — three
  fixtures (Bob Murray, Jenks, Witham, all the same "ITS Dispatch" template
  family) only ever say "Purchase Order," never bare "PO," so the PO field
  silently stayed blank on real documents.
- **The rate regex could grab a boilerplate penalty clause instead of the
  real total.** COT's rate con reads "...will decrease the Agreed Rate by
  $100.00" ahead of the real "TOTAL PAY: $1,000.00" — the old single flat
  regex took the first "rate/total/amount...$" match in the document, so it
  read the load as $100, not $1,000. Confirmed on the real fixture before
  fixing.
- **The rate vocabulary was too narrow.** "Net Pay" (Aaron Wilson) and a bare
  "Flat:" label matched nothing — the trigger word list only had rate/total/
  amount/linehaul.
- **The load-number regex required an explicit "#"/"No."/"Number" marker**,
  so OCR rendering "Pro: 702229" with the "#" dropped (a real, confirmed OCR
  artifact) fell through to the filename fallback and picked up **875377 —
  the Rexius invoice number embedded in Nate's own filename convention, not
  the broker's actual load number (702229).** "Trip" wasn't a recognized
  term at all (COT), and a comma inside a real number ("Trip #: 206,775",
  Tradewinds) would have truncated the capture to "206."

**Fixes** (`02-chips-extract.js`):
- `LOAD_PATS`/`NUMTOK`: every captured token now requires at least one digit.
  Without that, a stray "Order Number" table header or a company name like
  "NATIONWIDE" sitting where a value should be gets captured as if it were
  the real identifier — confirmed happening on two different real fixtures
  before this fix. Added "trip" and a looser colon-only "pro:" pattern;
  commas are now allowed in the match and stripped before storage.
- `RATE_PATS`: tiered instead of one flat pattern — "Total Pay"/"Grand
  Total"/"Net Pay"/"Total Cost or Charges or Freight"/"Agreed Rate or
  Amount" are tried first (each requiring a literal `$` or `USD` marker so
  "Total Weight 61,206" can never be mistaken for a dollar figure — verified
  against the real Rosboro fixture, which has exactly that shape), falling
  back to the original loose rate/amount/linehaul/pay/flat pattern only if
  nothing more specific matched.
- PO regex: added the "Purchase Order" alias, the `(?!BOX\b)` exclusion, and
  `(?![A-Za-z])` so "PO" can't match as a word-prefix.

**Verification.** Regex changes were unit-tested in Node against the real
captured OCR text (Aaron Wilson) plus faithfully-transcribed representative
text for the other ten, including two purpose-built regression cases (a bare
"Total Weight" figure with no currency marker, and the exact COT penalty-
clause trap) — all 14 cases pass. The live browser pipeline was independently
confirmed twice end-to-end against real fixtures (Aaron Wilson and COT, both
via genuine OCR, both landing in Postgres with the correct fields), and the
final deployed `/app.js` was diffed to confirm the fix actually shipped. Test
orders/documents were deleted afterward — nothing persisted to Nate's data.

**Not fixed, flagged instead:** a brand-new broker (not yet a `parties` row)
never gets its own name captured — `findBroker`/`matchBrokerForFile` only
match against existing parties, there's no letterhead-name heuristic, so 10
of the 11 new brokers create an order with no broker set at all (correct,
not silently wrong — Nate fills it in from the drawer). `extractStop`'s
pickup/delivery guess can grab OCR-garbled table headers on heavily
tabular/scanned forms (Aaron Wilson, Nationwide) — already documented as
best-effort/always-confirmed, not tightened further given the risk of
overfitting to one document's layout.

### D106 — Live outside-customer import through Sheets API (2026-08-17)

Read the dispatcher spreadsheet's `outside customer list` tab through the
existing service-account `GoogleSheetsSync` adapter and imported it into local
`parties` with the new idempotent `scripts/import_outside_customers.py`. The
live tab had headers `CUSTOMER/BROKER`, `NOTES`, `AP EMAIL`, 107 nonblank rows,
and 106 unique normalized names. All imported rows set `is_broker=true` while
preserving any other existing role flags; AP email and notes follow the sheet.
The D5 `++` suffix is stripped.

Rows 53/54 were a real duplicate after that normalization: `Oregon Canadian`
and `OREGON CANADIAN ++`, with different AP recipients. The importer merges
distinct duplicate emails using semicolons, which both mail adapters already
split into multiple recipients. Applied locally: 105 inserts, one update, 101
unique parties with AP email. A post-import live dry run returned `insert=0,
update=0, unchanged=106`; the External Customers grid rendered 107 total rows
(the 106 sheet-tagged parties plus the pre-existing synthetic `Tradewinds
Brokerage`) with no browser errors.

### D107 — Driver-tab push color/merge formatting closed out (2026-08-17)

The push-to-Sheets pipeline (D35/D37/D98) wrote cell text but not the color
fill, header banding, or row sizing Nate's dispatcher sheet has always had —
listed since D37 as the still-open "color/merge half of the driver-tab push."
`app/server.py` now builds real `spreadsheets.batchUpdate` requests
(`_fmt_requests`, `_header_cell_request`, `_three_slot_grid_requests`,
`_contrast_text_color`, `_lighten_hex`) and issues them right after each
tab's values write, for both individual driver tabs and Current Week: header
cell = driver/truck color at higher contrast, chip fill = the same load
color the dashboard shows, row height fixed per slot except a multi-stop
chip (more than 2 `\n\n`-separated sections, from D108's route text) gets a
taller row so the full itinerary stays visible. This was pure formatting
plumbing riding on the D108 multi-stop work, not a new decision — closing it
here so CLAUDE.md's phase-status list stops carrying it as open.

### D108 — External orders can carry a custom multi-stop route (2026-08-17)

Every external order already implied a two-stop itinerary (`orders.pickup_location_id`
→ `orders.delivery_location_id`, D33) but the schema had no way to represent
more than one pickup or drop on a single order. New `order_stops` (migration
`20260817000003`) makes that itinerary an explicit, ordered table and adds
`orders.route_mode` (`simple`/`custom`). Every order defaults to `simple`:
`_sync_simple_order_stops` keeps a 2-row shadow itinerary in `order_stops`
in lockstep with the familiar `pickup_location_id`/`delivery_location_id`/
`po_number`/`delivery_number` fields, so nothing about the ordinary one-pick/
one-drop workflow changes. Only a deliberate save from the new route editor
(`routeEditorModal`, 06-modals-grids.js — add/remove/drag-reorder 2-20 stops)
flips an order to `route_mode='custom'`, guarded by `api_order_route_save`
(2-20 stops, needs at least one pickup and one delivery, blocked once
delivered/billed/invoiced same as every other order-locking rule).

Scheduling snapshots the order's current itinerary onto `load_stops` via
`_sync_load_stops` (`order_stop_id` links a load stop back to its order
stop) — once stop-specific paperwork exists on that load, the route locks
and can no longer be silently replaced by a re-save. Chip text
(`_driver_chip_text`, `_current_week_chip_text`) and the External Orders
grid/tracker (`driverExternalRouteText`, `driverRouteMaps`,
`externalOrderCompare`) render the extra stops only when `route_mode==='custom'`;
a simple order's chip is byte-for-byte the same D36 format as before.

`docs/schema.md`'s ER sketch and the "planned vs. completed route" paragraph
were updated in the same change. Verified via `scripts/test_multistop_rollback.py`
(every write inside one rolled-back transaction: create → simple 2-stop
shadow → save a 4-stop custom route → confirm `order_stops` matches → roll
back, nothing persists) and `scripts/seed_driver_push_stress_test.py` (a
reversible current-week matrix exercising the D107 push formatting against
real early/anytime/EAST customers and multiple brokers).

### D109 — Database grids can save a custom row order (2026-08-17)

Database grids (built-in and custom) previously rendered rows in whatever
order the backing table/query returned. New `grid_row_orders` (migration
`20260817000002`, keyed by `grid, row_id` so the same party can sort
differently in Bagger Customers vs. External Customers) lets a saved order
persist per grid. Two ways to set it: drag a row by its gutter
(`reorderGridRow`, writes `DB.grid_row_orders` optimistically then posts
`/api/grid/row/reorder`) or open the new sort dialog (`databaseSortModal`,
sort by any field ascending/descending, then "save as default order" writes
the sorted result the same way). `api_grid_row_reorder` re-derives the
grid's full current population server-side before writing, so a stale
client can't silently drop a row from the saved order by omission.
`storedOrderRows` applies the saved order at render time, falling back to
source order for any row that predates a saved order for that grid.

### D110 — Supabase Auth + delegated Outlook drafts scaffolded, off by default (2026-08-17)

Two feature-flagged integrations were built end-to-end but left disabled:
app-wide Supabase Auth gating every dashboard route, and per-user delegated
Outlook Graph drafts for Billing (so a mail draft is created and sent under
the actual dispatcher's own mailbox, not a shared service account). Both
default `false` (`DEPT12_AUTH_ENABLED`, `DEPT12_OUTLOOK_ENABLED`) and the
app makes zero Supabase/Microsoft/CDN requests while disabled — verified by
reading `00-auth.js`'s guard and `app/adapters.py`'s `NoAuth`/`SupabaseAuth`
split (`make_auth()` picks by flag). Full architecture, the chunked-cookie
session sharing between the standalone `login/` page (port 8780) and the
dashboard (port 8770), the Graph attachment-upload flow, and the activation
checklist all live in `docs/auth-outlook-activation.md` rather than
duplicated here — that file is the source of truth for turning this on.
This does not change the "Supabase stays local/unconnected for now" golden
rule: nothing here points at a hosted project until someone flips the flags
and fills in `login/supabase-config.js` + `.env`.

### D111 — push-driver-tabs was pointed at the wrong sheet (2026-08-18)

Nate tried testing the D107 push and got a credentials error. Root cause
wasn't credentials — the running server had no `DEPT12_SHEETS_ID` set at
all (so `SHEETS` was `NoSheetsSync`, hence the "not configured" error). But
setting it to the value CLAUDE.md's Reference table actually showed
(`1KlPQ…`, the dispatcher's working sheet) would have been wrong too: Nate
confirmed the push must land on the **mirror** (`15f12…`), and a live
`list_tabs()` check proved it — `1KlPQ…` has no per-driver tabs at all
(`SCHEDULER`, `Internal Order Tracker`, …), while `15f12…` has exactly the
8 hand-named tabs (`WAYNE 31 BT`, `JON 33 BT`, …) `push-driver-tabs` matches
truck numbers against. Pointed at the working sheet, every driver would have
silently landed in the response's `skipped` list — no error, just nothing
written, easy to miss.

This was always implied by the golden rule ("the mirror is a pure
projection… pointing it at Postgres is a data-source swap") but two other
places in the code said the opposite: `adapters.py`'s module docstring said
Sheets sync must "never touch the driver-facing mirror," and
`GoogleSheetsSync`'s class docstring repeated it — both written before
`push-driver-tabs` (D98/D107) existed and never updated after. Fixed both
docstrings, and the CLAUDE.md Reference row, to say what's actually true:
`app/server.py`'s only use of the shared `SHEETS` instance is
`push-driver-tabs`, which needs `DEPT12_SHEETS_ID=15f12…`; one-off `scripts/`
that read dispatcher input (e.g. `import_outside_customers.py`) hardcode
`1KlPQ…` themselves rather than sharing that env var, since one global ID
can't serve both jobs.

Verified live: read-only `list_tabs()` against both sheet ids (service
account has access to both), and a dry-run push with `DEPT12_SHEETS_ID`
pointed at the mirror returned matched truck numbers (`31, 33, 72, 63, 39,
162, 62, 135, 80`) lining up with the mirror's real tab names. The actual
confirmed write (batchUpdate) is still Nate's to trigger from the UI —
that's a live write to the sheet 8 tablets read in the field, not something
to fire off unattended.

### D112 — push-driver-tabs is fleet-future-proofed; Store Map is internal-only (2026-08-18)

Nate: adding a truck or reordering the fleet should show up on the pushed
sheet with zero manual tab work, and he doesn't want drivers seeing that a
load went to an outside carrier. Two changes, one API-call refactor:

**Auto-provisioning.** `push-driver-tabs` now fetches every tab's
title/sheetId/index/rowCount once up front (`SHEETS.tab_props()`, new)
instead of one `sheet_id()` round trip per driver — fewer calls, and gives
the index/rowCount data the two features below need. A truck with no
matching tab gets one created (`addSheet`, same "{DRIVER} {NUMBER} {TYPE}"
naming the hand-made tabs already use, e.g. "WAYNE 31 BT" / "135 BT" when
unassigned). Every driver tab's index is then set to match the app's live
truck order (`trucks.sort_order`) in one `updateSheetProperties` batch,
right after Current Week — so a Fleet reorder in the app reorders the real
tabs too. Both steps are skipped (no extra round trip) when nothing's out of
place, so the common case isn't slower for it. Untouched: tabs for a truck
that's been deactivated/removed are left alone, not deleted — Nate didn't
ask for that and it's a one-way door.

**Store Map (column G) is now 07/internal-only.** It used to also carry
`row["drop"] or row["pickup"]` for external orders, duplicating what's now
D113's dedicated pickup/drop links. External's own columns are the answer
for external; what (if anything) shows in Store Map for an external load is
still open.

### D113 — External pickup/drop become "view location" map links (2026-08-18)

Nate used to link external loads' pickup/drop to a Google Maps address —
wants it back, but flagged two real problems: consumer Google Maps has no
truck-safe routing (a generated turn-by-turn route can send a truck under a
low bridge or down a weight-restricted road), and a multi-stop route
(D108) doesn't reduce to one destination. Discussed both; his call: a "view
location" link (pin + satellite, no route drawn) over turn-by-turn, so
drivers can see where they're going and how to get the truck in without the
app ever implying a route — he'll route separately (leaning against paying
for Trucker Path; mentioned OpenRouteService as worth a look for actual
truck-safe routing later — not decided, not built).

`_maps_view_link(name, address, city, state)` builds a
`google.com/maps/search/?api=1&query=…` link (Google's documented "search
action" URL, not "dir" — never generates a route) from a stop's address, or
falls back to the order's own pickup/delivery location if a custom route
has no stops of that type yet. Multi-stop keeps the existing convention
(first pickup, last delivery) rather than a link per intermediate stop —
every stop's full address is already in the chip text itself (D108); this
is only the one-tap convenience for the endpoints. Both `pickup`/`drop`
columns are now written as real `=HYPERLINK()` formulas (D112's
`_hyperlink_formula`, labeled "Pickup"/"Drop"), matching Store Map.

### D114 — The "5 days" bug was a 17-row grid cap, not a days bug (2026-08-18)

Nate reported the pushed sheet always showing ~5 days no matter what Days
Shown was set to. The client already wired `CW_DAYS` correctly end to end —
the real cause was the confirmed-write clear range: it only cleared
`row_count` rows (the *current* push's day count), so shrinking the window
left whatever a wider previous push had written still sitting below it,
looking like extra days. First fix attempt (always clear the full 1-14 day
range regardless of this push's size) immediately 400'd against the real
sheet: `WAYNE 31 BT`'s actual grid was capped at **17 rows** — caught by a
direct scratch-cell write during verification, not by inspection. That's
the same reason the old bug existed at all: nothing could ever clear past
row 17 either, so a "wider" leftover was really just whatever fit in that
fixed ~5-day grid.

Fixed by growing the grid, not shrinking the clear: any driver or Current
Week tab short of `1 + 14×3` rows gets grown via `updateSheetProperties`
(bundled into the same D112 provisioning batch); new tabs are created at
full size from the start. The clear range can then always safely span the
full 14-day ceiling. Verified live: `WAYNE 31 BT` grew 17 → 43 rows, a
push with `days=3` left rows 11-43 genuinely empty (`read_range` returned
only 10 rows), and a direct `valueRenderOption=FORMULA` read confirmed a
written `=HYPERLINK(...)` cell stores as a real formula and renders its
label, not raw formula text.

**Incident, not part of the fix itself:** the same verification pass found
41 leftover synthetic orders/loads in local Postgres from a prior session's
`scripts/seed_driver_push_stress_test.py` run (tagged `[DRIVER PUSH TEST]`)
that were never cleaned up — they had round-tripped onto the **live** mirror
sheet through an earlier confirmed push this session, before this bug was
even found. Deleted (orders, their loads, load_orders, order_stops) and
re-pushed. Auto-create was then verified deliberately and safely: a real
temporary truck (`TEST99`) was added, confirmed-pushed (created a real
`TEST99 F` tab correctly positioned/sized), then both the truck and the
created sheet tab (`deleteSheet`) were removed immediately after.

### D115 — Outside-carrier scheduler lane (2026-08-18)

Nate: brokering a load out to an outside carrier needs to go through Staging
like any normal load — that's where the real dispatch decision happens, and
it's how delivery-date sync and everything downstream keeps working — but it
must never reach a driver's tablet. Works for both internal and external
(one load = one order for a carrier load; he wouldn't broker out a
combined/multi-stop run).

**The schema already had this** — `loads.carrier_party_id` and the
`loads_driver_xor_carrier` constraint (`carrier_party_id is null OR
(driver_id is null and truck_id is null)`) have existed since the very first
migration, unused until now; `v_loads_reporting` already joined the carrier
name. Only `loads.carrier_cost` was missing (migration `20260818000001`).
This superseded an earlier, wrong plan of mine (a fake `trucks` row) — the
real design needs no truck at all.

**Client:** a pinned, grayed-out "Outside Carrier" column (`CARRIER_TID =
"carrier"`, a client-only cell-key identity, never a real `trucks` row) is
appended after every real truck in the main Scheduler only — not Current
Week, which stays real-fleet-only since it's what actually gets pushed.
`placement()`/`cellContents()` route a load to that column when
`carrier_party_id` is set instead of `truck_id`; everything else (chip
rendering, staging removal, undo-eligible unschedule) reuses the existing
machinery unchanged. Dropping onto it opens one small modal (carrier name +
$ paid — carrier is free-text, create-if-missing same as a truck's driver
name) before it calls `/api/load/carrier`; this one step isn't wired into
undo/redo like a normal placement is. The same modal, prefilled, reopens
from a new "Outside carrier" drawer section (both drawers) to edit
carrier/cost after the fact — that section only renders once an order is
actually on the lane. The Status/Stage pill gets an additive "Outside
Carrier" badge alongside Delivered/Billed/Scheduled — a different axis (who
ran it) than completion state, so it doesn't replace anything.

**Server:** `api_load_carrier` creates the load (`truck_id`/`driver_id`
null) on first placement or updates carrier/cost on an existing one, keyed
by whether the order already has a load. `push-driver-tabs` needed zero
changes — its truck query only ever matches a real `truck_id`, so a carrier
load is structurally invisible to it, not filtered out by any added check.

**Verified live:** a real test order placed on the lane via the API,
confirmed rendering in the Scheduler cell (grayed styling), the drawer
(badge + carrier section + working Edit round-trip — caught and fixed a real
bug where editing didn't refresh the open drawer, same `DRAWER_OID` re-open
pattern every other drawer save already uses), the Internal Order Tracker
(additive badge), and a `push-driver-tabs` dry-run confirming the order
never appears in any driver's payload. Cleaned up afterward — nothing
persisted.

**Also found and fixed in passing:** the D107 stress-test's leftover
synthetic data (D114 already cleaned the tagged rows) had one more stray
`schedule_notes` row and one order whose own `notes` didn't carry the
`[DRIVER PUSH TEST]` tag (only its load's did) — missed by a `notes`-text
search. Found this time via the script's actual `custom->>'source'` tag,
which is the reliable way to find every row it created; used that for the
final sweep instead of grepping display text.

### D116 — In-app Driver Tabs linked to Fleet, not DB.drivers (2026-08-18)

Nate: the in-app "Driver Tabs" view (`vDriverView`) should always show as
many tabs as there are trucks — flagged it not being "linked" to Scheduler/
Fleet. Root cause: the picker was built from `DB.drivers`, not `DB.trucks`.
Drivers and trucks are deliberately decoupled (D32 — "adding a driver no
longer creates one"), so the two lists silently drift: `135 BT`/`80 F`
(currently unassigned, no driver) got no tab at all despite being real
scheduled trucks, and any driver without a current truck would have gotten a
dead tab. `DRIVER_VIEW` now holds a **truck** id and the picker iterates
`DB.trucks` (Fleet's `sort_order`) same as the Scheduler's columns; the
now-dead `truckForDriver` helper (driver id → truck) was removed along with
it. Outside Carrier (D115) is correctly excluded — it's not a `DB.trucks`
row.

Verified live: Driver Tabs now shows exactly 9 buttons matching Fleet 1:1,
including both previously-invisible unassigned trucks; clicking one renders
its (empty) week with no errors.

### D117 — External Orders gets year filtering; explicit + Add Year (2026-08-18)

Nate: needs to be able to add a year, for both Internal and External orders.
Asked two things rather than guess: whether External (which had no year
concept in the UI at all — one flat list, forever) should get it too, and
what "add a year" meant given the picker already silently auto-extends to
real-current-year+1. He confirmed both: yes to External, and yes to an
explicit **+ Add Year** button — direct control instead of waiting on the
clock.

**+ Add Year** appends `availableYears()`'s current max + 1 to a persisted
`EXTRA_YEARS` list (`localStorage`, per device — this only widens what the
picker offers, the order data itself was never year-restricted, so no
server round trip). It's additive to the existing auto-extend, not a
replacement — real-current-year+1 is always already there; the button adds
the year *after* that.

**External's year filter can't reuse Internal's `orderYearCode`.** Internal
numbers are app-generated `07-MMYY-####`, so the year is reliably embedded.
External numbers are hand-typed from Solomon with no such guarantee. New
`externalOrderInYear(o, year)` filters by `ordered_at`'s year instead, and —
matching the existing `externalOrderCompare` rule that live/incomplete rows
never get sorted away by date — an order with no `ordered_at` yet always
shows regardless of the selected year, rather than silently vanishing.

Verified live: External Orders now shows the same year picker + Add Year
button as Internal, filters correctly, `+ Year` correctly added 2028 (2027
was already auto-included), survived a reload via `localStorage`, and a
real seed-data load with `carrier_party_id` set (D115) rendered its Outside
Carrier badge correctly in the process — confirmed genuine pre-existing
`seed.sql` data, not a leftover.

### D118 — Excel-style fill handle, app-wide (2026-08-18)

Nate asked for drag-to-fill "like Excel" — Database-only unless app-wide was
easier. It was: the selection system (`10-select.js`) already spans the
Scheduler and every Database grid uniformly (D68 — `td[data-key]` and
`td[data-field]` are both "selectable cells"), so scoping to Database only
would have meant adding exclusion logic, not less code.

**Scope (v1):** single-cell source only — `SEL`, not a multi-cell marquee. A
real Excel block-pattern tile-fill is a further, separable feature. Never
fills over a placed load chip (`CELLS[key].oid`) — there's no sane "value"
to copy there; only Database cell text and Scheduler/Current-Week note text
are fillable, matching exactly what `clearCellOp` already treats as a real
value (new `fillCellOp`/`fillValueOf`, `06-modals-grids.js`, same `{do,
undo}` shape as `clearCellOp` so a whole drag commits as one `histPush`
step).

**Two real bugs found and fixed during verification, not designed around
up front:**
1. A vertical fill leaked into the *next column* and the row *above* the
   source. Root cause: the drag box's fixed edges are the source cell's own
   `getBoundingClientRect()`, which sits exactly on the shared pixel with
   the neighboring cell — `boxTds`'s overlap test is inclusive (`>=`/`<=`),
   so that neighbor matched too. Fixed by insetting the box 1px on every
   side; the dragged (moving) edge tolerates this fine since the cursor is
   essentially never exactly on a boundary pixel mid-drag.
2. Nate: "the selection part of the drag needs to be bound to the cells
   you're dragging across" — the live preview was a separately-positioned
   floating div (`.fill-preview`), which could visually drift from the real
   cell edges. Replaced with `paintFillTargets` — a `.fill-target` class
   applied directly to the real `<td>` elements each pointermove, same
   binding principle the marquee's `.selrange` already uses. Misalignment
   is now structurally impossible since there's no separate shape to align.

Also enlarged the handle's actual hit target (`#fillhandle::before`,
`inset:-6px`) well past its 7×7px visual size — a miss on the literal dot
lands on the cell/background instead and looks like broken selection, not a
missed click; this was a live contributor to Nate's first "doesn't select
correctly" report.

**Verified live**, including undo/redo: filled 3 real Bagger Customer rows'
city field from a 4th, confirmed no leak into the address/state columns,
confirmed Undo reverted all 3 in one step to their real original values
(AUBURN/ALBANY/MEDFORD), confirmed Redo re-applied, confirmed Undo again
left real data exactly as found. Also verified on Scheduler note cells
(vertical fill, multiple rows/days). Nothing left uncommitted afterward.

### D119 — Clear-borders icon is a plain empty box (2026-08-18)

Nate: the border toolbar's "Clear borders" icon should just be an empty
box, no diagonal slash through it. One-line fix in `bordIcon()`
(`11-toolbar.js`) — dropped the diagonal `<line>`, kept the box.

### D120 — Sheets-style copy/paste, app-wide (2026-08-18)

Nate: copy a cell (with a Sheets-style highlight on the source), then paste
over whatever's currently selected — "the highlight ui can be like the
select ui sheets uses." Cmd/Ctrl+C and Cmd/Ctrl+V were completely unbound in
this app before now (the existing `copyCell`/`pasteCell` in `09-color.js`
are a different, older feature — copying a Scheduler *load chip* via the
right-click menu, keyed on `CELLCLIP`, never on a keyboard shortcut — so
there was no collision to design around).

New `VALCLIP` clipboard + `gridShape()` (`10-select.js`): copy captures the
current selection (`SEL` or `SELSET`) as a real 2D grid of values, grouped
by actual visual row/column position via rounded `getBoundingClientRect()`
— not selection order, so a copied block always reflects what was actually
on screen. Paste tiles that grid across whatever's selected at paste time
(`value[r % copiedHeight][c % copiedWidth]`), wrapping/repeating exactly
like real Sheets when the paste target is a different shape than what was
copied — copy one cell, select a 20-cell range, paste, all 20 get that one
value. Both reuse `fillCellOp`/`fillValueOf` (D118) — same value model,
same "never touches a placed load chip" rule.

The copy highlight (`.copy-marquee`, real animated dashed "marching ants" —
plain CSS `border-dashed` can't animate, so it's four gradient strips each
scrolling along their own edge) paints directly on the real source `<td>`s,
same cells-not-an-overlay principle D118 landed on for the fill preview.
Stays visible while picking a paste target (matching real Sheets), clears
on Escape or a completed paste.

Bound in `06-modals-grids.js`'s existing grid-keydown listener, right next
to Delete (same `SEL || SELSET` reach, D121) — not the separate rebindable-
shortcuts system (`01-core.js`), since this is cell-grid interaction like
arrow-key navigation and Enter-to-edit already living in that listener, not
an app-wide command.

Verified live: single-cell copy → paste over a multi-cell range (tiled
correctly), copy highlight rendered and persisted through target selection,
undo/redo round-tripped correctly. Directly exposed the D121 batch-write bug
below — first found here, before confirming it also affected D118's fill.

### D121 — Batch cell writes (Delete/fill/paste) didn't handle multi-cell selections correctly (2026-08-18)

Two related bugs, both only visible with a real multi-cell selection (a
single selected cell always worked), found live-testing D120:

**Delete silently no-opped on a selected range.** Two separate keydown
listeners handle Delete: the rebindable-shortcuts system (`01-core.js`,
`contextualDelete`) and a direct grid-navigation switch
(`06-modals-grids.js`) — the second one is what actually fires for a
selected cell/range (the first yields to it by design). Both listeners
checked `SEL` (single-cell) but not `SELSET` (a marquee/shift-click range) —
`06-modals-grids.js`'s own comment already said "clears the whole marquee if
there is one" (D83's intent), but the guard *above* that code (`if (!SEL ||
DRAWER_OID) return`) meant a real range never reached it. Fixed both:
`contextualDelete` now checks `SEL || SELSET.length`, and the Delete/
Backspace case in the grid listener was pulled out ahead of the `if (!SEL)
return` guard that the rest of that switch (arrow-key navigation, Enter-to-
edit) still correctly needs.

**A batch write spanning mixed-type columns silently lost its undo record.**
Selecting a wide range and filling/pasting a text value across it can hit
columns that reject that value server-side (a numeric column, a
CHECK-constrained one like `forklift`) — the generic `data-field` cell
system has no per-field type awareness, so this is expected, not something
to prevent. The bug was the fallout: `Promise.all(ops.map(do))` rejects as
soon as ANY op fails, so `histPush` — inside the `.then()` after all of
them — never ran, even though the compatible cells' writes had already
landed in Postgres. Real, committed changes with no way back. Also,
`fillCellOp`'s DOM update ran *before* confirming the server accepted it, so
a rejected cell could still show the new value on screen, out of sync with
the database. New `commitCellOps` (`06-modals-grids.js`, shared by fill and
paste) uses `Promise.allSettled`: only the cells that actually succeeded go
into the undo record, a clear toast reports how many didn't and why, and
`fillCellOp`'s DOM write now happens inside the `.then()` after
`gridCellSet` resolves, not before.

Verified live by deliberately reproducing both: a shift-click range across
Fork/Notes/Miles/Umatilla Miles columns took a real Delete keypress
correctly (was silently ignored before) with working undo; the same range
pasted into now correctly updates only the compatible column (Notes) with a
working undo, while surfacing the rejected columns via toast instead of
losing the successful write's undo record. All test data cleaned up after
each check — several rounds of it, since this genuinely touched real Bagger
Customer rows during verification (all confirmed restored to original
values).

### D122 — Outside-carrier badge fit + no-modal placement with a collapsible drawer section (2026-08-18)

Two carrier-lane follow-ups from D115, both Nate's ask:

**Badge overflow.** The tracker's Outside Carrier pill used the same rigid
64×20 box every status/action pill uses (D100); "Outside Carrier" at 9px
uppercase mono simply didn't fit and bled out of the box. Shortened the
label to "Carrier" — same box, same convention, no CSS special-case needed.

**Drag-to-carrier-lane felt clunky.** The original flow (D115) blocked the
drop behind a modal demanding a carrier name before it would place at all —
Nate: *"i wonder if that's because of the carrier name and cost convention
you added... can we just make that a collapseable field in the side window
pane and then only show it when the load is drug into the outside carrier
spot?"* Root cause: `api_load_carrier`'s placement branch hard-required
`carrier_name`, and `loads.carrier_party_id` was the ONLY signal
`placement()`/`cellContents()`/`carrierMap()` used to route a load onto the
`CARRIER_TID` lane — so an unnamed load had nowhere to render.

Added `loads.is_carrier boolean` (migration `20260818000002`), independent
of whether `carrier_party_id` is filled in yet — the real "is this load on
the lane" signal now. `placement()`/`cellContents()`/`carrierMap()` all
switched from keying on `carrier_party_id` to `is_carrier`. `moveLoad`
(`08-undo.js`) now special-cases a `CARRIER_TID` target inline (routes to
`/api/load/carrier` instead of `/api/schedule`) so `dropLoadOnCell` needs no
special branch at all anymore — dragging onto the carrier lane is now
identical to dragging onto any truck cell, undo/redo included.
`api_load_carrier` split into two branches by payload shape: `date`/`slot`
present = a placement (drag), always replaces any prior load exactly like a
normal schedule move, no name required; absent = a drawer edit of an
already-placed load's name/cost, partial update. This also fixed a latent
bug the old code never exercised: dragging an already-scheduled truck load
directly onto the carrier lane used to just tag `carrier_party_id` in place
without ever clearing the old truck_id — now it goes through the same
delete-and-recreate every other move uses.

Carrier name/cost moved from a modal into a `<details>` section in both
order drawers (`carrierSectionHtml`, matches the existing collapsed-by-
default Customer section convention) — rendered only once `carrierMap()[oid]`
is truthy (i.e. `is_carrier`), so it's invisible until a load actually sits
on the lane. Name and cost autosave on blur like every other drawer field,
each its own undo step via a new `carrierFieldSet`.

Two bugs found live-testing the field-splitting itself:

- **A fast Tab from Carrier name → Cost could 500.** The cost field's
  client-side "carrier name required" guard read the stale `carrierMap()`
  cache, which hadn't been refreshed yet by the name save's async round
  trip — a real race, not a flake. Fixed by having the cost save always
  include the *live* DOM value of the sibling name field in its own request
  body, so the server never depends on timing between the two saves.
- **The name save's blur handler was calling `openOrder(oid)`** (a full
  drawer rebuild) on success, matching every other `[data-of]` field — but
  tabbing straight into Cost while that rebuild lands mid-keystroke tears
  out the very input being typed into, silently dropping it. Replaced with
  `refreshCarrierSummary(oid)`, which patches just the `<summary>` text and
  leaves the rest of the drawer DOM (and focus) untouched.
- Also made the server's name-clear presence-based (`"carrier_name" in d`,
  not truthy) instead of silently no-op'ing on an explicit blank — otherwise
  `carrierFieldSet`'s undo of a name-set could never actually undo it. A
  name clear also nulls cost in the same statement when the request didn't
  already touch cost, since `loads_carrier_cost_only` forbids cost surviving
  a null `carrier_party_id`.

Verified live end-to-end: drag from Staging straight onto the carrier lane
(no modal, chip lands immediately with `is_carrier=true`,
`carrier_party_id`/`carrier_cost` both null); drawer section expands, name
+ cost autosave individually with working undo (including the corrected
name-clear round-trip); dragging the chip back out to the Staging rail
unschedules cleanly. All test parties/loads cleaned up afterward.

### D123 — Database/sheet cells linkify a pasted URL (2026-08-18)

Nate: *"can we also make links i paste in the databases actually
clickable."* Applies to the built-in Database grids' generic column cells
(`dcell`, e.g. Bagger Customers' Notes) and custom spreadsheet-style sheets
(`sheetCellHtml`) — both already render as a plain `<div class="cell">`,
not an `<input>`, so a real `<a>` can live inside without disturbing the
click-to-select/type-to-edit mechanics. (Custom Database *entities'*
`jsonCell` fields render as literal `<input>` elements instead — genuine
HTML links aren't possible there without a larger structural change, so
those are out of scope for now.)

New shared `cellDisplayHtml(val)` (`01-core.js`, next to `esc`): if the
**entire trimmed value** is a URL (`https://…` or `www.…`), renders a real
`<a target="_blank" rel="noopener noreferrer">` instead of plain text — a
whole-value match only, so a note that just mentions a URL mid-sentence
stays plain text. Opens in a new tab specifically so the click still
reaches the cell's own selection handler in the current tab (same pattern
already used for the Documents section's file links).

Every render/repaint path that writes a `data-field` cell's body had to
switch to `cellDisplayHtml` and, where it writes after the fact,
`.innerHTML =` instead of `.textContent =` — otherwise the link silently
reverts to plain text the next time that cell repaints: `dcell`/
`sheetCellHtml` (initial render), `repaintGridCell`/`repaintSheetCell`
(format-change repaint), `commitEdit` (live cell editor), and `fillCellOp`
(shared by the fill-handle drag and paste, D118/D120). Reads (`.textContent`
inside `startEdit`/`clearCellOp`/`fillValueOf`) needed no change — an
anchor's `textContent` already returns the plain URL string.

Verified live: typed a URL into a Bagger Customers Notes cell, confirmed it
renders as a real clickable `<a>`; copy/pasted it into a second row and
confirmed the pasted cell *also* renders as a link immediately (not just
after a reload) with a working undo. Test note cleaned up afterward.

### D124 — Motive sync stops retrying orders it can never match (2026-08-18)

Nate: *"id rather not flag previous orders in the history each time we run
the function... i dont want it to try and find data for those orders."*

`api_motive_sync_miles`'s "needs sync" query was `where o.motive_miles is
null` — an order whose scheduled date predates that truck (or the whole
account) being on Motive can never get a match, so `motive_miles` stays
null forever and the order never leaves that query. Every future sync click
re-included it, which also dragged `start = min(scheduled_date)` back to
that old date, widening the Motive API date-range call every single time
for no benefit — same problem applies to every D65 backfilled 2025 order,
none of which are excluded from this query either.

Added `orders.motive_synced_at timestamptz` (migration `20260818000003`) —
stamped whenever an order is *asked about*, independent of whether Motive
had data for it. The query now also excludes `motive_synced_at is not
null`, so an order that comes back unmatched drops out for good after one
attempt. No retry mechanism (a manual DB update is the only way back in) —
deliberately simple, matching the ask; a genuinely-equipped truck with one
day's log missing (device offline) that Motive backfills later wouldn't get
picked up automatically, but that's an accepted tradeoff, not an oversight.

Verified by stamping a real order's `motive_synced_at` directly and
confirming the query's row count dropped by exactly one, then reverting.
