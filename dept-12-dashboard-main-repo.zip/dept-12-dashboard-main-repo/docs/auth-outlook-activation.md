# Supabase Auth and delegated Outlook drafts

Both integrations are implemented behind independent, explicit feature flags.
They are **off by default** and the application makes no Supabase, Microsoft,
or SDK-CDN request while auth is disabled.

> **Hosted-cutover warning:** token verification is scaffolded, but a verified
> Supabase identity is not yet mapped to the dashboard's `app_users` row and
> existing section/database/date grants. Do not activate production Auth by
> flags alone. Implement and test that mapping first, then follow the combined
> dashboard + Rexius Bag Orders plan in
> [`supabase-server-port-plan.md`](supabase-server-port-plan.md).

## What is scaffolded

### Entire application

- The browser waits for a Supabase session before bootstrapping the dashboard.
- Signed-out users are redirected to the standalone login page.
- API calls carry the Supabase bearer token.
- Direct file links also work because the shared, chunked auth cookie is sent
  to the dashboard server.
- Every `/api/*` GET and POST is verified server-side through Supabase Auth
  before business logic runs.
- The bootstrap response exposes only the authenticated user's safe profile
  fields.
- Profile sign-out calls Supabase and returns to login.
- Static HTML/CSS/JS remains public so the client can load and redirect; all
  business data and mutations live behind authenticated API routes.

The login and dashboard use the same chunked cookie-backed Supabase storage.
Cookies are host-scoped rather than port-scoped, so the current localhost ports
8780 and 8770 can share the session. In production, serve both pages on the same
host or set `DEPT12_AUTH_COOKIE_DOMAIN` and the matching login config to the
shared parent domain. HTTPS makes the cookies `Secure` automatically.

### Outlook billing drafts

- Outlook authorization is delegated to the signed-in Microsoft user.
- The app requests `email offline_access Mail.ReadWrite` only when Outlook is
  connected, not for ordinary dashboard access.
- Billing sends that user's Microsoft provider access token to the server over
  the authenticated request.
- The server creates the draft with `POST /me/messages`, attaches the merged
  billing PDF, and returns the message `webLink` so Outlook on the web can open
  the exact draft.
- Attachments under 3 MB use the direct attachment endpoint. Files from 3 MB to
  150 MB use a resumable upload session in aligned chunks.
- The app never requests `Mail.Send`; a person reviews and sends the draft.

Supabase does not refresh Microsoft provider tokens. The scaffold therefore
reconnects Outlook when a usable provider token is absent. Before production,
decide whether periodic Microsoft re-consent is acceptable or add a secure
server-side refresh-token vault/broker. Never store provider refresh tokens in
the public database or expose the Microsoft client secret to browser code.

## Activation checklist

1. Create the hosted Supabase staging project and apply the existing migrations
   plus the restrictive runtime-role/RLS and Auth-identity-mapping migrations
   required by `supabase-server-port-plan.md`.
2. Register an application in Microsoft Entra ID.
3. Configure the Entra Web redirect URI as
   `https://YOUR_PROJECT_REF.supabase.co/auth/v1/callback`.
4. Enable Azure in Supabase Auth with the Entra client ID, client secret, and
   tenant URL.
5. Add the login and dashboard callback URLs to Supabase's redirect allow list.
6. Copy the public values into `login/supabase-config.js`; set its `enabled`
   flag to `true` only at activation time.
7. Export the server values shown in `.env.example` and set
   `DEPT12_AUTH_ENABLED=true`.
8. Test sign-in, sign-out, disabled/unmapped users, expired sessions, direct
   `/api/file/*` access, and every dashboard grant/RLS policy before making the
   hosted app available. Confirm the publishable key plus a user token cannot
   call business tables directly.
9. Add delegated `Mail.ReadWrite` to the Entra application, then set
   `DEPT12_OUTLOOK_ENABLED=true` and test a draft in a non-production mailbox.

## Feature flags

| Flag | Default | Effect |
|---|---:|---|
| `DEPT12_AUTH_ENABLED` | `false` | Protects all dashboard API routes with Supabase Auth. |
| `DEPT12_OUTLOOK_ENABLED` | `false` | Uses the signed-in user's Microsoft token for Graph drafts. Requires app auth. |

The Supabase service-role key and Microsoft client secret must remain
server-side. Neither is used by this browser scaffold.
