# Decision Log — Archive (D125–D213)

Older decisions preserved from the working log. Decisions D1–D124 are in [`decisions-archive.md`](decisions-archive.md); the newest active decisions and open items are in [`decisions.md`](decisions.md).

### D125 — Local test-login + per-section/date-range permissions (2026-08-19)

Nate: *"we need administrative lockdown controls. so we're going to build the
controls in, before we build the accounts."* Two account classes — admin
(unrestricted, manages other users) and restricted (read-only Scheduler only
until an admin grants more) — with per-user, per-section grants at a view/
edit level, plus a hard per-user date-range boundary on the Scheduler.

**Deliberately separate from the dormant Supabase Auth + Entra scaffold
(D110).** That one needs external service setup (a hosted Supabase project,
an Entra app registration) before anyone can sign in with it — a real lift,
parked indefinitely. Asked Nate whether "build the controls before the
accounts" meant standing up that scaffold first or something lighter; he
picked lighter: *"you can do a simple login just to test it... you don't
need to write a password you just type a username."* New, independent,
dependency-free (D24) local login — `app_users`/`app_user_grants`
(migration `20260819000001`) — seeded with his confirmed test roster: **Nate**
(admin), **Test1/Test2/Test3** (restricted), explicitly so he can verify a
grant to one doesn't leak to another. Off by default
(`DEPT12_LOCAL_AUTH_ENABLED`), same convention as every other integration
flag in this app.

**Scope boundary Nate explicitly accepted, asked directly rather than
assumed:** full per-section *data* isolation (rewriting `api_bootstrap` to
only send data for sections a user can see) is out of scope this phase — UI
hiding plus server-side edit-blocking is enough; a restricted user could in
theory still see raw JSON for a hidden section via dev tools network
inspection. The one deliberate exception is the Scheduler date window —
Nate was explicit that one is a **hard boundary, server-enforced**, so
`loads`/`schedule_notes` really are filtered out of the bootstrap read
(`_filter_scheduler_by_window`) for a restricted user with a window set, and
six mutation entry points (`api_schedule`, `api_load_carrier`,
`api_load_note`, `api_cell_color`, `api_cell_format`, `api_unschedule`) call
a shared `_enforce_view_window()` guard before touching a date outside it —
even when the caller otherwise has Scheduler edit rights.

**Database grants are per-grid, confirmed after flagging the cost.** Some
grid edits share one underlying table in a way the server can't resolve from
the path alone (Bagger Customers and Brokers are both `parties`, split only
by `is_customer`/`is_broker`). Asked Nate whether to collapse Database into
one permission or pay the resolver cost for real per-grid granularity — he
picked per-grid: *"i want each user only has exactly what they need to see
or edit."* `_database_sub_for_table`/`_record_entity_sub`/`_grid_sub`
(`server.py`) do one extra lookup per generic Database write, mirroring the
client's own `gridKey()`/`entityForGrid()` routing.

**Server-side enforcement is a single fail-closed table, not per-handler
checks.** The existing `ROUTES`/`route()` decorator (server.py) was already
dead code — 0 call sites — so there was no registry to hang authorization
on. New `API_PERMISSIONS` maps every mutating route to the `(section, sub)`
it needs `edit` on, checked once before the route-dispatch chain in
`do_POST`. A path NOT in the table defaults to **admin-only**, so a route
added later and forgotten here doesn't silently become an open door.
Structural endpoints (`/api/entity*`, `/api/field*`, `/api/grid/column*`),
`/api/category` (a global legend, not per-user data), and
`/api/sheets/push-driver-tabs` (writes the live mirror sheet 8 tablets read,
D111) are admin-only regardless of any grant — sensible defaults, Nate's
call to loosen later.

**Settings is gated like everything else — no special-casing.** Asked
whether a restricted user should always keep their own theme/shortcuts
(personal device prefs, not business data) or have Settings locked down
too; Nate: *"i think anyone whos not admin cant change their theme or
fonts... gate it and they can get access from an admin."* `SETTINGS_SUBS`
rides the same `section`/`sub` grant model as every NAV section — a
restricted user with zero grants sees no Settings tab at all, only the
always-available Sign Out (wired directly to `localLogout()`, bypassing the
now-gated Settings section entirely, since signing out has to work
regardless of what else is locked down).

**Client-side gates are UX fast-fails, not the real boundary** — `canView`/
`canEdit` (`01-core.js`) hide nav (`NAV`/`subsOf`/mobile nav menu) and toast
on the four/five real choke points already centralized by D118/D120/D121:
`startEdit`, `deleteSelection`, `commitCellOps`, `moveLoad` (gated on
`dispatch/sched` directly, not ambient `SEC`/`SUB`, since every call site is
Scheduler mechanics regardless of caller), and `queueDrawerSave` (gated by
the *open order's own kind* — `orders/int` or `orders/ext` — not ambient
section, since a drawer opened from the Scheduler still edits order data).
Toolbar action buttons (+Add customer, +Column, etc.) are **not**
individually hidden this pass — same graceful-degrade-to-toast pattern
already used for invoiced-load errors, not a gap that needs its own fix
unless Nate asks.

**Also folded in, unrelated:** Nate asked for the default (no saved
preference) theme to load light with a green accent instead of system/no-
accent — `PREFS.theme`/`PREFS.accent`'s fallback values changed
(`01-core.js`); an existing saved preference is untouched.

Verified live end-to-end with the real roster: Nate sees full nav and the
Admin tab; Test1 boots straight to read-only Scheduler with nothing else,
a double-click toasts "View-only" client-side; granting Test1 `orders/ext`
edit from the Admin panel took effect on next render — External Orders
appeared, a drawer field round-tripped to Postgres; Test2/Test3 stayed
untouched by that grant (the explicit isolation check Nate asked for); a
Scheduler date window was set, confirmed `loads` outside it dropped from
Test1's bootstrap response, and a direct `/api/schedule` call to a date
outside the window came back with the window error. Confirmed
`DEPT12_LOCAL_AUTH_ENABLED=false` (the shipped default) leaves the app
exactly as it behaved before this feature — no login gate, no `me` key in
bootstrap, ordinary Scheduler editing unaffected.

### D126 — Admin panel refinements: rolling date default, View/Edit toggles, collapsed rows, delete users, graying add buttons (2026-08-19)

A batch of Nate's follow-ups on the D125 Admin panel, the same day.

**Scheduler date range now has a real default instead of "unbounded until
set."** Nate: he wants restricted Scheduler visibility to default to 3 weeks
back / 1 week forward from today, not wide open until an admin manually
narrows it — matching the "restricted = minimal by default" spirit the rest
of D125 already followed for sections. New `_default_view_window()`
(`server.py`) computes `(today - 21d, today + 7d)` fresh on every check —
recomputed, not stored, so it actually rolls with the calendar rather than
freezing at whatever day the account was created. Applied wherever
`view_start`/`view_end` are both null: `_enforce_view_window` (writes) and
the bootstrap `loads`/`schedule_notes` filter (reads). An admin setting an
explicit range still overrides it outright; clearing the range reverts to
the rolling default rather than to "unbounded." The Admin panel's date
inputs prefill with the live default (via a new `default_view_start`/
`default_view_end` on `/api/admin/users`) so what's about to take effect is
visible before an admin types anything.

**Single-select grant control replaced with two independent toggles.**
Nate: "each of the controls to be a toggle view and then edit toggle for
each user." View and Edit are now separate checkboxes per (section, sub)
row instead of one three-option `<select>`. Interaction rules, enforced by
what each checkbox's change handler sends to `/api/admin/grants`:
unchecking View sends `revoke` (a grant can't be Edit without also being
View, so it has to take Edit down with it); checking Edit alone still works
even if View wasn't checked yet — the upsert creates the grant row outright,
and the next render shows View checked too, since "a grant row exists" *is*
the View signal. Unchecking Edit downgrades to view-only rather than
revoking — View stays on.

**Users collapse into spreadsheet-style rows.** Each restricted account is
now a `<details>` row (Nate: "each user collapsed in a spreadsheet style
row") — a one-line `<summary>` (username, a live view/edit count, whether
their Scheduler range is custom or default) that expands to the full grant
grid, matching the existing `summary.sec-h` collapsible convention (D104)
rather than inventing a new one. The delete button lives inside the
`<summary>` itself and needs its own `e.preventDefault()` in the click
handler — without it, clicking Delete also toggles the row open/closed
since the click bubbles to the native `<details>` activation behavior.

**Roster refreshes when the Admin tab is (re)entered**, not once-ever.
`ADMIN_ROSTER` (05-settings-nav-search.js) is invalidated specifically on
the nav click into `SUB === "admin"` (07-events.js), not on every `render()`
— a full-render-triggered refetch would spam `/api/admin/users` on every
click anywhere in Settings while the tab is open. This is what makes a
brand-new sign-in (auto-created by `/api/local-login`, D125) show up for an
admin without a page reload — visit Dispatch, come back to Admin, it's
there.

**Admins can delete a restricted user.** New `POST /api/admin/user/delete`,
admin-gated the same way as `/api/admin/grants`/`/api/admin/view-window`.
Refuses to delete an admin account (safety — this endpoint is for the
restricted test roster, not account recovery). Grants cascade-delete via the
existing FK; any live session for that user is dropped from the in-memory
`_local_sessions` map so a signed-in deleted user is logged out on their
next request rather than lingering until the process restarts. Confirmed
through the existing `confirmModal` pattern (matches D93's guarded
cancel/delete), same as every other destructive action in the app.

**"Add" buttons are grayed out (not hidden) for a view-only grant** — Nate
explicitly said hiding wasn't necessary, graying was fine. Reversal/
extension of D125's original call to leave toolbar buttons ungated: new
`applyEditLockUI()` (05-settings-nav-search.js, called once at the end of
`render()`) does a single generic DOM pass over known add-style controls
(`+ Add customer`, `+ Add location`, `+ Add truck`, `+ Row`, `+ Column`, the
rate-con drop zone, Internal Orders' bulk-add) rather than threading a
`canEdit` check into each button's template string — one choke point,
easier to keep in sync than 8+ scattered call sites. `+ New database`/`+ New
sheet` are grayed for ANY non-admin regardless of their edit grant, since
those stay admin-only structural actions server-side (D125) no matter what
section access looks like. New `.locked-view` CSS: `pointer-events:none` so
a non-button drop zone (no native `disabled`) is functionally inert, not
just dim.

Verified live end-to-end: default range showed `2026-07-29`–`2026-08-26`
against a `2026-08-19` clock; checking a row's Edit box created a
view+edit grant and checked View automatically; unchecking View revoked
both; deleting Test3 removed it from Postgres and the live list without a
reload; signing in as a fresh Test3 afterward and revisiting the Admin tab
showed it again with no manual refresh; a view-only grant on External
Customers rendered "+ Add customer" both `disabled` and visually grayed for
Test1. All test grants cleared afterward — roster back to Nate (admin) +
Test1/Test2/Test3 (restricted, no grants).

### D127 — Internal Freight tracker + department-traceable mileage/$ reporting (2026-08-19)

Grew out of a mileage-report request: Nate wanted internal mileage tracked
via Motive (per-truck-per-day ELD pulls), external's total derived by
subtraction so nothing has to be hand-typed on every external load — "we can
always get the total on external by subtracting internal from the total."
Investigating that surfaced a real gap: dept-to-dept moves with no customer
at all (e.g. "Bag Plant to Umatilla Yard") were getting typed into External
Orders with everything left blank, "cause it's not for a customer it's for
the department." Inspecting the real 2025-import data killed the obvious
fix (auto-detect "transfer" from blank customer/broker/solomon fields) —
some blank-customer external rows are genuine commercial loads that just
never got their PO/customer typed in (e.g. `"49 Weyer. Albany to Shelter
Products Medford (OPEN) OR471626"` — a real load/PO number sitting in the
free-text note, never entered into a structured field). Nate: "we cant auto
detect anything and legacy data is just that legacy data and isnt meant to
be perfect when we import." His call: **explicit flag only, going forward.**

That led to the bigger ask — a genuinely separate third Orders tracker
("Internal Freight") instead of bolting a flag onto External Orders, with
real per-department granularity so the numbers "trace... all the way back
to source": *"we haul for a lot of departments... it would be a hybrid of
the internal and external trackers."* Renames: the old "Internal Orders"
tab (bag-plant/dept 07 hauls) becomes **Bag Orders**; tab order is Bag
Orders → Internal Freight → External Orders.

**`orders.kind` stays a 2-value enum — no `'transfer'` kind.** Explore found
~19 call sites in `server.py` and ~9 in the client (billing eligibility,
`isExt()` and its callers, stop-sync, permission-scope resolution, chip
building, reports) branching on `kind`. Internal Freight orders stay
`kind='external'` (so `loads.kind`, copied from `orders.kind` at placement
time, needs no enum change either) with a new `is_transfer` boolean marking
them — the tracker itself is fully separate (own tab, own grid, own
lightweight add-flow via `/api/order/transfer`, own drawer
`openTransferOrder`) while scheduling/chip-placement/undo need zero changes.
Only the handful of places that assume "external ⇒ has a customer to bill"
needed an explicit `!is_transfer` guard: `_sync_simple_order_stops`/
`_sync_load_stops` (no pickup/delivery to sync), the External Orders grid
and its unplaced-count badge, and the Billing queue filter.

**Departments is a real table** (`departments`, its own migration,
`20260819000002_internal_freight_transfers.sql`), registered as a 5th
**builtin** Database entity (same `entities`/`fields` metadata pattern as
Fleet) rather than a `kind='custom'` entity — Explore confirmed
`fields.type='relation'` is an unimplemented placeholder (zero usages
anywhere), so every other *referenced* lookup in this app (`parties`,
`locations`, `trucks`) is a real table with a real FK, and Nate's own
framing ("making an internal dept database just like we have any other
backend") pointed the same direction. `orders.transfer_department_id`
references it (`on delete restrict`, guarded again in
`api_grid_row_delete`'s new `departments` branch so deleting a department
still in use on a transfer fails with a clear count, matching the existing
Bagger/Broker/Fleet/Pick-Drop delete-guard pattern).

**Transfers reuse D103's exact miles/$ fields** (`orders.miles`,
`motive_miles`, `miles_adjusted`, `internal_freight_amount`) instead of new
columns — same shape as a bag order (real one-way miles + a hand-entered $
transfer charge), just addressed to a department instead of a customer. The
D103 `orders_internal_freight_only` CHECK was relaxed to `kind='internal' or
is_transfer or (...all null...)`. A second constraint,
`orders_transfer_shape`, keeps the "clean tell" intact going forward: a
transfer can never carry a customer/broker/solomon # (that's what makes it
one), full stop — no future ambiguity like the legacy data's.

**Motive sync now covers both internal-flavored buckets** —
`api_motive_sync_miles`'s query broadened from `kind='internal'` to
`(kind='internal' or is_transfer)`, same per-truck-per-day mechanism,
writing to the same order columns. External stays untouched — its total is
whatever's left after subtracting the two internal-flavored buckets from a
truck's total ELD miles for the day, computed at report time, never synced
per-load.

**Three reports updated to fold the new bucket in, all using date-range
totals per Nate's explicit call** ("collapse to range totals... but i need
the raw data in a tab next to it so i can make a pivot table"):
- **Freight transfer report** (`_FREIGHT_SQL`) reshaped from the old
  truck+week buckets to truck+department totals for the picked range — a
  `union all` of bag-plant loads (department hardcoded `'07'`) and
  Internal Freight loads (real department name via
  `transfer_department_id`), both `delivered`/`closed` only.
- **Mileage report** (`_MILEAGE_SQL`, shipped earlier this session) extended
  from a 2-way internal/external split to 3-way: `internal` (bag orders, by
  customer), `transfer` (Internal Freight, by department — NOT folded into
  external anymore, which was the whole point of separating these out),
  `external` (one total, unchanged).
- **Full data dump** (`_DUMP_SQL`) gets one new derived column,
  `pivot_department` — `department` (the Solomon-derived `'07'`/`'12'` code,
  already populated for bag orders) coalesced with the new
  `transfer_department` — so the raw CSV is pivotable by customer, truck, OR
  department in one column, satisfying the "raw data to pivot myself" ask
  without a second raw-export report.

**A real UX bug found during live verification, fixed the same pattern
D122 already established for the carrier name→cost sequence:** picking a
department then immediately typing the route note (the natural fill-out
order for a new transfer) raced the generic `[data-of]` blur handler's full
`openOrder()` rebuild — the department save's round trip landed while the
note field was mid-keystroke, silently discarding what was typed, same
failure class as D122. Fix: the department `<select>` uses its own
`data-transferdept` save path (a new blur listener in `07-events.js`) that
patches just the drawer title (`refreshTransferHeader`, mirroring
`refreshCarrierSummary`) instead of doing a full-drawer rebuild, leaving
whatever the user is actively typing into the note field untouched.

Verified live end-to-end: created a Department ("Shop / Yard") via the new
Database tab; created a transfer, confirmed department→note fill-in no
longer drops the note; scheduled it onto a real truck via `/api/schedule`
and confirmed the chip renders "Shop / Yard — Internal Freight · Bag Plant
to Umatilla Yard # 23" (no blank customer, no false "NO ORDER #" badge);
confirmed it's absent from both the External Orders grid and the Billing
queue; ran all three reports and confirmed the transfer's $75/42.5mi landed
under "Shop / Yard" in the freight and mileage reports and under
`pivot_department` in the full dump; confirmed the Departments grid's
delete guard blocks removal while referenced (`"Can't delete — 1 transfer
order(s) reference this department."`) and succeeds once the referencing
order and load are gone. Test data cleaned up afterward.

**D127 follow-up (2026-08-19), same day, after Nate started using it live:**

- **"+ Add department" needed a real popup**, not the bare inline blank row
  a generic custom-entity `+ Row` leaves — Nate: "when i hit add department
  nothing pops up." New `addDepartmentModal()`/`api_add_department`, matching
  the Add customer/Add location/Add truck pattern exactly.
- **Renamed + reordered**: the Departments Database grid is now labeled
  "Internal Freight" (same name as the Orders tracker tab — Nate's explicit
  choice) and sits right after Bagger Customers, not after Fleet. `slug`
  stays `'departments'` (migration `20260819000003_departments_rename_reorder.sql`
  only touches `name`/`sort_order`, the renamable fields — same convention
  every other entity rename uses).
- **One static chip color for every Internal Freight transfer, regardless of
  department** — Nate: "all of them regardless of department will be in the
  same color." Stored on the entity itself, `entities.color`
  (`20260819000004_internal_freight_chip_color.sql`), not a per-row grid
  column — a per-department color would contradict "all the same color." A
  swatch (`<input type=color>`) in the Internal Freight grid's own toolbar
  edits it via `/api/entity/update` (admin-only, matches every other
  structural entity edit). `chipHtml`'s fill precedence gets a new top tier —
  `is_transfer` chips take this color unconditionally, same "purely X-driven,
  no fmt/category override" tier as internal's designation color, ahead of
  push color. The Google Sheets driver-tab push (`_chip_fill`) got the same
  branch, fed the color via one extra query in `_driver_week_payload` — "that
  decides the color fill for google sheets port over."
- **Copy button for Internal Freight** — `stageControls(o, on, true)` in
  `vInternalFreight()`; `api_copy_order` gained an early `is_transfer` branch
  that copies just the route identity (department + note), leaving
  miles/$/dates blank to refill, same "route identity carries over,
  per-instance details don't" split External's copy already uses for
  solomon/broker_load_no.
- **Drawer chip preview didn't live-update on the department `<select>`** —
  Nate: "when you select or change something in the side modal window it
  isnt live updating the chip preview." The generic `[data-of]` text-field
  live-preview (on the `input` event) doesn't cover `<select>`s, and the
  transfer department field deliberately uses its own `data-transferdept`
  path (not `data-of`) to avoid the D122/D127 full-rebuild race described
  above. Fix: a `change`-event branch that patches
  `order(oid).transfer_department_id`/`_name` and calls the *existing*
  `refreshDrawerChipPreview()`/`refreshTransferHeader()` instantly — no
  network round trip, so nothing races the real blur-triggered save.
- **A second real bug, unrelated to Internal Freight, caught in passing**:
  Nate — "when i create a bagger order and tab thru to select a customer...
  it says no customer but when i click it, it has the customer data in the
  dropdown... the chip doesnt display it and neither does the order
  tracker." Root cause: the tracker grid's `data-oedit` inline-select
  handler (D84 — deliberately patches the local order in place instead of
  calling `reload()`, so a full re-render doesn't destroy the `<select>`
  being tabbed through) patches the raw columns `/api/order/update` returns,
  but `customer_name`/`broker_name`/`transfer_department_name` are
  server-side JOINs, not real columns — so the display name silently stayed
  stale until a full bootstrap refetch. New `applyOrderFkDenorm(o, field,
  value)` (`02-chips-extract.js`) resolves the three known FK→name pairs
  from already-loaded `DB.parties`/`DB.departments` and is called from both
  patch sites (`07-events.js`'s `data-oedit` handler, `08-undo.js`'s
  `orderFieldSet` used by undo/redo) — fixes the same gap for Bag Orders'
  customer picker, External Orders' broker picker, AND Internal Freight's
  department picker at once, since all three ride the identical mechanism.
  The tracker handler also now calls `renderRail()` (an isolated DOM
  subtree, not the grid) so a chip already visible in the Staging rail
  updates immediately too, without the D84 regression a full `render()`
  would reintroduce.

Verified live against Nate's own real department data (already populated by
the time this landed): department rename/reorder confirmed in the Database
tab; Add-department modal confirmed; set the swatch to `#2e7d32` via
`/api/entity/update`, confirmed a staged transfer's rail chip picked up the
color; opened a real transfer's drawer, changed its department via the
`<select>` without blurring, confirmed both the drawer title and the chip
preview updated instantly pre-save, then confirmed the real save landed on
blur and reverted it back to its original department afterward; reproduced
the customer-picker staleness bug on a real blank-customer Bag Order,
confirmed the rail chip showed the correct name immediately after the fix
with no page reload, then reverted the test order back to blank.

**D127 follow-up #2, same day: per-department chip color, not one static
value.** Nate reversed his own earlier call within the hour, once he was
actually using it: "lets do the same color thing we have in fleet inside
the internal freight database... so i can have different ones by dept if i
wanted." Replaces the single `entities.color` swatch above with a real
per-row `departments.color` column (migration `20260819000005`, which drops
`entities.color` again) and a `color`-type `fields` row
(`storage='column:departments.color'`), same shape as Fleet's driver color
field — except Fleet's is a special case (color lives on `drivers`, reached
through the truck's current `driver_id` indirection, since a truck's row
context has no `ctx.drivers` slot) while departments' resolves directly
through its own row context, no indirection needed. `fieldCell`/
`fieldRawValue`'s `f.ui === "color"` branch now checks
`f.storage === "column:drivers.color"` for the Fleet special case, falling
through to a new generic column-backed color-chip renderer otherwise — same
`openSheetsPicker` UI, keyed `table|id|field` via a new
`data-colorchip-generic` attribute/handler instead of Fleet's driver-id one.
`transferChipColor(o)` now takes the order and resolves its OWN
department's color (`departmentById(o.transfer_department_id).color`) — a
department with no color set shows no fill, no fallback. Threaded through
the Sheets driver-tab push too: `_chip_fill` reads
`o["transfer_department_color"]`, joined per-order in
`_driver_week_payload` instead of the one-time global fetch this replaced.

Caught one bug during verification: `api_update_row`'s per-table allowed-
columns dict had `"departments": {"name", "sort_order"}` — missing `"color"`
entirely, so every color-chip save 500'd until added.

Verified live: color chips render on each department row (Fleet's exact
visual pattern); set "Bagger - 07" to `#76a5af` and "Specialty - 14" to
orange independently via the picker, confirmed only the clicked row's DB
value changed each time; staged a real transfer tagged to "Bagger - 07" and
confirmed its rail chip picked up `#76a5af` exactly.

**D127 follow-up #3, next session: copy/paste for department colors.** Nate:
"manually selecting each one making it the same is annoying." Right-click a
color chip → Copy color; right-click another → Paste color here, or (if rows
are multi-selected via the existing numbered-gutter row selector) Paste
color to N selected — one shot instead of re-opening the picker per row.
`COLORCLIP` (a single hex, `09-color.js`) plus three functions
(`copyChipColor`/`pasteChipColor`/`pasteChipColorToSelected`), wired into the
existing `contextmenu` dispatcher and reusing `gridCellSet`/`ROWSEL`/
`histPush` — no new selection or clipboard mechanism, all undoable including
the batch paste.

**Caught a real, already-live bug while verifying this**: `api_bootstrap`'s
`departments` query never selected the `color` column at all (only
`id, name, sort_order`) — so no matter what color anyone picked, every
department's chip silently rendered the `#888888` fallback everywhere
(Database grid, tracker, board, Sheets push) after the next reload. Nate had
already picked real colors for two departments before this was caught (live
verification found his real `#6aa84fd1`/`#ff9900` sitting correctly in
Postgres, invisible client-side). One-line fix; both showed correctly after.

Verified live: copy from "Bagger - 07" → paste onto "Yard 1 - 03", confirmed
in Postgres; multi-selected two more rows → "Paste color to 2 selected" →
confirmed both changed in one batch; Cmd+Z undid the batch paste (both back
to null) in one step. Test colors reverted afterward — only Nate's own two
real department colors remain set.

### D128 — Two-agent stress test of the whole D127 feature set, plus a wider adjacent-field save bug found live (2026-08-19)

Nate asked for two things in one message: get copy/paste working for chip
colors (done above, D127 follow-up #3) and "stress test all the new features
we've added... test each order type from start to finish multiple times."
Ran two parallel background agents against the live dev DB (a full `pg_dump`
backup was taken first, `scratchpad/dept12_backup_before_stresstest.sql`) —
one driving the actual browser UI through all three order types + the
Database grids, one hammering the API/DB layer directly via curl/psql with
edge cases and constraint-violation attempts. Both used `QATEST_`-prefixed
throwaway data and cleaned up after themselves (verified zero `QATEST_%`
rows left in any table); neither touched Nate's real data.

**Bugs found and fixed same-session:**

1. **The generic drawer blur handlers had the SAME adjacent-field save race
   as D122/D127's transfer-department fix — just not yet fixed there.**
   Confirmed live, twice, independently: typing in one text field then
   immediately clicking into an adjacent one (Notes → Miles on a Bag Order;
   Miles → Transfer $ on an Internal Freight transfer) silently dropped the
   FIRST field's edit — no error, it just reverted on the next read. Root
   cause: both the `[data-of]` and `[data-fr]` blur handlers
   (`07-events.js`) unconditionally call a full `openOrder(oid)` rebuild
   once their save round-trips, and that rebuild was landing WHILE the user
   was already mid-keystroke in the next field, same class of bug as the
   carrier name→cost race D122 originally fixed and the transfer department
   field was built to avoid from day one (see D127 above) — it just hadn't
   been generalized to the two handlers EVERY other drawer field rides.
   Fix: new `refreshOrderDrawerAfterSave(saveOid)` (`03-drawer-billing.js`)
   — checks `document.activeElement` when the save resolves; if focus is
   still on another editable drawer field (`[data-of]`, `[data-fr]`,
   `[data-frorder]`, `[data-transferdept]`, `input[data-cust]`,
   `[data-carrier]`), skip the full rebuild and just patch the chip preview
   + title (`refreshDrawerTitle`, generalized from the transfer-only
   `refreshTransferHeader` — all three drawer `<h2>`s now carry
   `id="dw-title"`); otherwise do the full `openOrder(oid)` rebuild as
   before. Both `[data-of]` and `[data-fr]` blur handlers now call this
   instead of the old unconditional `if (DRAWER_OID === saveOid)
   openOrder(saveOid)`. Verified live: typed Miles then immediately Transfer
   $ on a real transfer with no wait — both values landed in Postgres and on
   screen, previously only the second would have.

2. **Redo (Cmd+Shift+Z) never fired on Mac, full stop — pre-existing bug,
   unrelated to D127, surfaced by the stress test.** `01-core.js`'s
   `comboFromEvent()` always builds a modifier-combo string in
   `Ctrl, Alt, Shift, Meta` order, but the hardcoded Mac default for redo was
   written `"Meta+Shift+Z"` — backwards relative to what a real keypress
   actually produces (`"Shift+Meta+Z"`), so it could never match. Only the
   toolbar Redo button worked; the keyboard shortcut was silently dead for
   every Mac user since it shipped. Windows/Linux's `"Ctrl+Shift+Z"` was
   unaffected (Ctrl sorts before Shift already). One-line fix: the default
   literal now matches `comboFromEvent`'s actual canonical order. Verified
   live: undo → redo via keyboard now correctly restores a paste.

3. **`api_entity_update` still accepted a `color` field that no longer
   exists anywhere to write to** — leftover from the single-swatch design
   (D127 follow-up #2) superseded by per-department `departments.color`;
   `entities.color` was dropped in that same migration but `color` was never
   removed from `api_entity_update`'s allowed-fields set, so any call
   sending it 500'd (Postgres: `column "color" of relation "entities" does
   not exist`). No live UI path calls it that way anymore (confirmed via
   grep — the only surviving `entity/update` call site is the plain
   database-tab rename, which never sends `color`), but it was still a live
   trap for anything that did. Removed `color` from the allowed set.

4. **Copy color on an UNSET chip copied the visual `#888888` placeholder as
   if it were a real value** — found live while re-verifying fix #3's
   restart. `fieldCell`'s generic color-chip renderer shows `#888888` as a
   fallback when a row's color column is null (matching Fleet's own
   fallback), but the right-click "Copy color" handler trusted the chip's
   DOM *text*, not the row's real stored value — so copying an unset chip
   and pasting it elsewhere silently set a real, wrong `#888888` on the
   target instead of doing nothing. Fixed: the context-menu handler now
   resolves the actual value from the row's data (`rowArrFor(table)`), and
   "Copy color" simply doesn't appear on the menu at all when there's
   nothing real to copy.

**Reported, not fixed (flagged for Nate, not urgent enough to chase without
his input):**
- The `orders/xfer` local-auth permission bucket (a restricted user's
  edit-rights over Internal Freight transfers) was never exercised under
  actual local auth — doing so needs a server restart, which would have
  killed the parallel UI-testing agent's live session, so it was
  deliberately skipped this round. Everything else confirms the routes
  themselves resolve `"xfer"` correctly (via `_order_kind_sub`) when
  auth is off entirely (admin bypass); the actual deny-path for a
  restricted user is the untested part.
- Low-confidence, single occurrence, not reproduced a second time: clearing
  a delivered order's Delivered date inline didn't visibly unlock
  Cancel/Delete in the tracker until a full reload — could not rule out a
  mis-click; this is also consistent with the KNOWN, deliberate D84
  tradeoff that the tracker's inline-edit handler doesn't force a full
  re-render (to protect tab-through), so a delayed Actions-column refresh
  until the next natural render may simply be existing, accepted behavior
  rather than a bug — not chased further without a clean repro.
- Low severity, unusual precondition: an already-open drawer doesn't live-
  refresh if that same order's customer/broker is changed via the tracker
  grid's own dropdown while the drawer is open elsewhere — closing and
  reopening the drawer shows the correct value. Pre-existing architecture
  (drawer has no subscribe-to-external-changes mechanism), not something
  D127 introduced; noted for awareness, not fixed.

### D129 — Full code sweep: archived D97–D124, removed dead code, doc accuracy pass (2026-08-19)

Nate: "do a full code sweep remove dead code if there is any and then re
clean things up archive what we need to and optimize context/tokens...
make sure the md files are up to date and accurate."

**Archived D97–D124 into `docs/decisions-archive.md`**, following the exact
precedent D102 already set for D65–D96 (this file's own header literally
says "when a decision scrolls past ~5 back, move it to the archive," which
hadn't been followed since D102). `decisions.md` goes from 1488 lines to
585 — D125–D128 (today's local-auth + Internal Freight arc, still highly
active/referenced) are all that's left in the working log, plus Future/Open.
`decisions-archive.md`'s header now reads D1–D124. Nothing about this
touches any CLAUDE.md trap — traps that cite an archived D-number (D109,
D115, D118, D121, D122, D124, etc.) still resolve correctly, exactly as
D65–D96's traps already did before this.

**Dead code removed** (two passes: my own targeted checks plus a dedicated
Explore agent auditing every top-level function/global in `server.py` and
the whole `app/web/js/*.js` bundle as one namespace, the way it's actually
assembled):
- `ROUTES = {}` / `def route(method, path)` (`server.py`) — a decorator-
  based route table that was never actually used as a decorator anywhere;
  every real route is the long `if p == "/api/...":` chain in
  `do_GET`/`do_POST`. Zero callers, zero `@route` usages.
- `_next_internal_number(department, month_code)` (`server.py`) — an
  orphaned helper; `api_add_internal_order` reimplements the identical
  prefix/sequence lookup inline instead of calling it (it can't, quite —
  the real function needs to reserve a whole block of `n` sequential
  numbers in one call, this helper only ever returned one).
- `gridToolbar(grid)` (`06-modals-grids.js`) — the old `+Row`/`+Column`/
  `Delete selected` toolbar CLAUDE.md's D96 trap already says not to
  restore; the real toolbar (`04-views.js`) has fully replaced it, this
  was just never deleted.
- Three duplicate function pairs across `app/web/js/*.js`, each pair
  byte-identical (or functionally identical) logic defined twice —
  `party`/`partyById`, two separate `locById` definitions
  (`02-chips-extract.js` + `03-drawer-billing.js`), two separate `catById`
  definitions (`02-chips-extract.js` + `09-color.js`). Since every JS file
  is concatenated into one shared closure, the SECOND definition of each
  pair was silently shadowing/overriding the first at runtime the whole
  time — consolidated to one definition each, callers updated where the
  losing name was `partyById`.

**Doc accuracy fixes** (`README.md`, `CLAUDE.md`, `WORKTREE.md`):
- README's Layout table said "Four sections" directly above a table
  listing five (Dispatch/Orders/Billing/Database/Reports) — also still
  said the Database section's 5th grid was called "Departments," when it's
  been "Internal Freight" since D127 follow-up.
- Both README and CLAUDE.md's "two money paths" description still said
  the internal freight charge lives on `loads.internal_freight_amount`
  and is "aggregated weekly per truck" — stale since D103 moved it to
  `orders.internal_freight_amount`, and stale again since D127 reshaped
  that report to truck+department date-range totals, not weekly buckets.
- README's "Running things → The database" section only ever showed a
  throwaway `dept12_check` smoke-test DB seeded from just the FIRST
  migration — no instructions anywhere for actually building the real
  `dept12` dev DB through the full migration chain. Added that; kept the
  smoke-test snippet as a labeled secondary option.
- WORKTREE's "Current state" had grown into exactly the kind of
  migration-by-migration changelog CLAUDE.md's own house rule says not to
  paste there ("record decisions... don't paste changelogs") — collapsed
  ~25 lines of per-migration narration down to "migrations are sequential,
  latest is X, see decisions.md for why."
- CLAUDE.md had two separate traps describing the same drawer-rebuild-race
  bug from two different eras (D122's original carrier-specific writeup,
  D128's newer generalized one) — merged into one, keeping the one genuinely
  distinct nuance the older trap had (`carrierMap()` cache staleness) that
  the newer one didn't cover.

Verified: `ast.parse`/`node --check` clean after every removal; restarted
the server and smoke-tested Bagger Customers (exercises the surviving
`catById`) and Database → Internal Freight (exercises the surviving
`party`) live in the browser — Nate's real designation colors and
department colors both rendered correctly, confirming the consolidations
didn't silently break the behavior that used to come from the "losing"
duplicate.

### Future

- **Yearly rolling archive.** Internal + external orders should roll into
  per-year archives so each year starts with fresh tabs — but **rolling**, since
  work is pre-planned across the year boundary (mirrors the D53 rolling
  calendar). Needs a plan: what "archived" means (view filter vs. moved data),
  and how it interacts with the biller queue and the order lists.

### D130 — Internal Freight: separate "Load info" from the driver-pushed note (2026-08-19)

Nate, after seeing the transfer chip pushed to the real mirror sheet live:
*"lets make it to where the current notes/route info is titled 'load info'
and then have a different notes section below it for the notes that
actually get pushed to the driver tab... the load chip can stay the same,
but the notes that get to the driver actually serve a purpose."*

Before this, a transfer's single `notes` field did double duty: dashboard
chip title AND (via `_transfer_chip_text`) the first line pushed to the
driver's Sheets cell. New `orders.driver_note` column
(`20260819000006_transfer_driver_note.sql`) splits them: `notes` (now
labeled "Load info" in `openTransferOrder`) stays dispatcher-facing only —
drives the chip title, never pushed. `driver_note` (new "Driver tab note"
drawer section) is what's actually meant for the driver — `_transfer_chip_text`
now reads `driver_note` for line 1, department stays line 2. Rides the
existing generic `data-of` save path — no new JS plumbing needed. Two
explicit-column-list call sites needed the new field added by hand (the
`api_bootstrap`-style trap): `api_update_order`'s `allowed` set and
`_driver_week_payload`'s orders query (bootstrap's own `orders` select is
`o.*`, so that one didn't need a change).

Verified live end-to-end, twice, against the real mirror sheet (not a
mockup) — pushed a transfer chip before this fix (department bold on top,
route note below, matching D127's per-department color) and confirmed
exactly what a driver would see; then added a driver note, re-pushed, and
confirmed the cell switched to driver note + department while the sheet's
separate NOTES column still showed the untouched load info ("Bagger To
Umatilla 3"), proving the two fields save and push independently.

### D131 — Permanent admin History, individual revert, and point restore (2026-08-19)

Nate wanted the Sheets-style control concretely: show which user made each
edit, allow one action to be reverted, and allow the whole operational
dashboard to be restored to a selected point—but only after showing every
later action that will be overwritten. History and every reversal control are
admin-only; restricted users do not even get the toolbar button.

This is deliberately separate from D63/D96's 50-action browser closure stack.
Migration `20260819000007_admin_history.sql` adds immutable `audit_events` and
`audit_changes`. The server creates a request event with actor/scope/label and
sets a connection context; triggers on every current primary-key table capture
full before/after row versions, including cascades and composite keys. Direct
database scripts without request context get a connection-scoped System event,
so imports do not silently bypass the ledger. History is retained indefinitely.

The admin-only clock button is first in the formatting toolbar. Its independent
right panel pages backward through the full timeline, shows actor/time/scope,
changed fields, and status badges. `Revert action` applies one event's inverse;
`Restore to here` reverses every later operational event in newest-first order.
Both require a preview. The preview returns the current latest event sequence;
execution refuses a stale sequence if any action completed in the meantime.
Replay is one Postgres transaction with field-level conflict checks, and the
inverse mutations are captured as a new event—original evidence is never
deleted, so a reversal can itself be reversed.

Whole-dashboard restore intentionally preserves `app_users` and
`app_user_grants`; those remain visible and individually reversible without a
data restore risking the only admin account. Outlook drafts and live Google
Sheets pushes are recorded as irreversible external events and called out in
the overwrite preview.

Verified against a fresh isolated PostgreSQL cluster by applying the complete
migration chain, then exercising: update→revert, revert-the-revert, multi-row
customer+location create→delete→restore, point restore across later edits while
preserving an admin date-window change, and direct-SQL System capture. Browser
verification under local auth confirmed the admin-only toolbar button, paged
timeline, affected-data expansion, overwrite preview, security warning, and
the fixed-height scroll layout. A restricted Test1 session received HTTP 403
from `/api/history`.

### D132 — History: fix misattribution bug, cut point restore, gate the app behind sign-in (2026-08-19)

D131 was built by ChatGPT outside this session; Nate asked me to test what it
did and fix the UI. Live testing against his real local `dept12` DB (not a
fresh cluster) surfaced one real correctness bug and, from Nate using it
himself afterward, a design call:

**Bug — audit misattribution across requests.** `_history_create_event` sets
`dept12.history_event_id` on the Postgres session with `set_config(...,
false)` (session-scoped, not transaction-local). The per-thread connection
is pooled across requests (`ThreadingHTTPServer` + keep-alive), and the only
place the context was cleared was the `except` branch of `do_POST` — never
on success. So the NEXT request handled on that connection — anything that
doesn't call `_history_create_event` itself, e.g. `/api/local-login`
inserting a brand-new username — had its trigger-captured audit rows
silently folded into whatever event the *previous* request left set,
corrupting that event's `change_count`/`affected_tables` with unrelated
work. Fixed by moving the clear into `do_POST`'s `finally`, unconditional.
Verified: edited an order (event N), then logged in as a new username on the
same server — the new-user insert landed as its own clean "System · Direct
database change" event instead of attaching to event N.

**Cut: point-in-time "Restore to here."** Nate hit a case where it wouldn't
apply and asked whether to scrap it for a flatter "list of edits + who + undo
individual edits" model instead. Recommended cutting it: `Revert action`
(single event, conflict-checked) was the part that worked reliably in every
test; whole-dashboard restore was the most complex, fragile code path
(cascading `superseded_by_event_id` bookkeeping, protected-table carve-outs)
for something already achievable — just less conveniently — by reverting
events one at a time, each independently safety-checked. Removed
`mode`/"restore" branches from `_history_selected_events` (renamed
`_history_target_event`, single-event only), `api_history_preview`,
`api_history_revert`, and the client (`13-history.js`) — no "Restore to
here" button, no protected-table warning copy. Left the now-unused
`audit_events.superseded_by_event_id` column in place rather than a
follow-up migration to drop it — inert, not worth the churn.

**Sign-in gate now actually gates the app.** Nate found Staging visible
behind the sign-in card, then that the header/toolbar/nav were too, then
that hiding Staging alone left the login card off-center. Root cause for the
last one: `.body{grid-template-columns:minmax(0,1fr) var(--rail-w,276px)}`
reserves the second column whether or not `#rail-wrap` is visible — the
existing `.norail` class is how `render()` already collapses this for the
railless views, just not something `renderLoginGate()` was doing. Landed as
one `body.pre-auth` CSS class (`app.css`) hiding `header`/`.fmtbar`/
`.sections`/`.subs`/`#rail-wrap` together — the same five elements the
existing `@media print` rule already treats as one chrome unit — and
collapsing the grid to one column, toggled in `renderLoginGate()`/
`bootDashboard()`. Added the Rexius mark + "Dept 12 / Flatbed Trucking"
brand block (reusing the header's own `.brand`/`.brand-mark`/`.brand-copy`
markup) to the login card itself, since the real header is now hidden while
it's showing.

Verified live: fresh load hits a fully chrome-free, centered sign-in card;
login restores header/toolbar/Staging exactly as before; a reload while
already signed in skips the gate entirely with no leftover `pre-auth` state.

### D133 — History: persistent left sidebar, click-to-navigate chips, redo (2026-08-19)

Nate, after using the D131/D132 panel for real: drop the "Show affected
data" expand — show the changed data inline on the chip, always; clicking
a chip should jump to and highlight whatever it touched (Sheets-style);
the panel should stay open across navigation until he closes it, not
auto-close on every jump; and reverting a revert should read as **Redo**,
not a second confusingly-worded "Revert action".

**Persistent left sidebar, not an overlay.** `#history-panel` moved from a
`position:fixed` right-side overlay (z-index above `#drawer`, which is
exactly why it had to auto-close on jump — it would've hidden the drawer
it just opened) into a real column inside `#bodywrap`'s grid, first child
before `#main`. `.body.history-on` adds a `300px` track
(`.body.history-on.norail` for views with no Staging rail); the panel
itself is `display:none` outside `.on` so it claims no column width when
closed. `openHistoryPanel()`/`closeHistoryPanel()` toggle both the panel's
own `.on` and `#bodywrap`'s `.history-on` together. Because it now sits on
the opposite side from the drawer, a jump can leave it open without
covering the destination — so `closeHistoryPanel()` calls were dropped
from every jump target. Desktop-only for now, same as Staging
(`#rail-wrap`) — collapses at the existing `max-width:980px` breakpoint
rather than trying to make a 3-column layout work on a phone.

**Chips, not cards with a toggle.** `historyEventHtml` dropped the
`<details>/<summary>` — every change's table/operation/field diff renders
inline unconditionally. The whole chip is the click target
(`data-history-jump`) when `historyEventJump(e)` finds a live row to go to
(first non-DELETE change that resolves); Revert/Redo lives in its own
`.history-actions` row so a button click doesn't also fire the chip's
navigation (delegated handler checks the button selectors first, same
pattern as before).

**Redo is just relabeling.** Reverting a "Reverted: X" event already
worked mechanically (D132's revert is symmetric — it's just another
event with its own inverse), it only read wrong. `audit_events.reverts_
event_id` being set means *this* event **is** a revert, so its own
Revert-action button (and the preview modal's title/verb) now read
"Redo"/"Redo this action?" instead. No schema or endpoint change.

Verified live: reverted a department color change, chip read "Redo"
correctly; clicked Redo → confirmation modal said "Redo this action?" →
confirmed → color restored, toast "Redone · 1 change", panel never closed
through any of it. Clicked a chip while on Scheduler → jumped to Database
→ Internal Freight with the row still visible, panel still open on the
left the whole time. Closing the panel collapses the grid back to full
width immediately.

### D134 — History: collapse revert/redo chains into one chip, live refresh, toggle-close (2026-08-19)

Nate, immediately after D133 shipped: *"if u keep hitting it it changes
the event and adds 'reverted:' on top of the event over and over lol"* —
he wanted one button that flips between Revert/Redo, not a label that
grows a new "Reverted: " prefix and a new chip every time. Two smaller
asks landed the same round: the panel should refresh itself when changes
happen elsewhere (nice-to-have, not required), and clicking the History
toolbar icon again while the panel's open should close it (was open-only).

**The chain is real and stays real — only the display collapses.**
D131's append-only design is deliberate (never rewrite audit evidence), so
every Revert/Redo click still creates a brand-new `audit_events` row
server-side, exactly as before — toggling back and forth 10 times leaves
10 real rows. What changed is purely client-side: `historyGroupedEvents`
walks each event's `reverts_event_id`/`reverted_by_event_id` links, finds
the chain's root (the original, non-revert action) and its current tip
(the newest link — trivial to find since the server already returns events
newest-first, so the first member of any chain encountered while iterating
IS the tip), and renders **one chip per chain** instead of one per event.
Depth from root to tip determines state by parity — even = back to the
original data (chip reads "Revert action"), odd = currently reverted
(chip reads "Redo") — not `!!tip.reverts_event_id` (D133's approach),
which reads "Redo" for *any* revert-type event regardless of how many
times it's been toggled, exactly the bug Nate hit. The chip shows the
root's own label and field diff (the actual meaningful edit, not a
mechanical "reverted the revert of the revert" description); the button
targets the tip's id, since that's the event whose inverse needs applying
next.

**Live refresh** rides `reload()` — already called after essentially
every mutation in the app — with one added line: if the History panel is
open, reload it too. No polling, no websocket, just piggybacking on a
pattern already firing everywhere.

**Toggle-close** — the toolbar icon called `openHistoryPanel()`
unconditionally; now calls new `toggleHistoryPanel()` (checks
`historyPanelOpen()` first), matching how every other toggleable toolbar
control in the app already behaves.

Verified live: opened History, redid a department-color chip back to
"Revert action" — collapsed cleanly to one chip instead of stacking
"Reverted: Reverted:"; toggled the toolbar icon closed then open again;
edited an order's driver note from an open drawer while History stayed
open on the left, watched the new chip appear at the top automatically
with no manual refresh.

### D135 — History: collapse into days, drop non-actionable entries (2026-08-19)

Nate, after using D134's flat chip list for real: *"lets make it just
collapse into days and u can see the days with edits u can reverse and
thats that. the whole point was to make it to wher u could undo shit that
persists after u leave the session if u need to. so thats really the part
i care about."* He also noted live-refresh (D134) isn't actually updating
for him — explicitly deprioritized it ("thats fine i dont really care"),
so left as best-effort via the existing `reload()` hook rather than chased
further this round. He also flagged not knowing the retention window.

**Two changes, both in `historyGroupedEvents`/`renderHistoryPanel`
(13-history.js), no server/schema change.** First, a chain (D134's
root+tip) only survives into the list at all if there's something left to
act on — `!!(root.reversible && tip.change_count && !tip.reverted_by_
event_id)`. Non-actionable rows (an external-only push, a reversed
System no-op, anything with nothing to revert or redo) are dropped
outright — matches "days with edits u can reverse," not a general audit
browser. Second, `historyDayGroups` buckets the survivors by the *local
calendar day the root's original edit happened on* (not whenever it was
last toggled — undo should live with when the mistake was made, findable
regardless of how many times someone's redone it since) into collapsible
`<button>` headers ("Today · 14 edits", "Yesterday · 3 edits", …), each
expanding to the same chip list D134 already built. The newest day opens
automatically on a fresh load so the panel isn't a wall of collapsed
headers on first look; `HISTORY_OPEN_DAYS` persists per-day open/closed
state across live-refreshes so a background `reload()` doesn't yank shut
whatever the admin has open (only resets on Escape/manual close → reopen).

**Retention: there is none — everything is kept indefinitely.**
`audit_events`/`audit_changes` have no purge job, no TTL, no row cap; they
grow forever. That directly satisfies "persists after you leave the
session" (nothing to accidentally age out of), at the cost of unbounded
storage growth over time. Not a problem yet at this data volume; flagged
in Open — needs Nate below in case he wants a cap later (D133's Future
note guessed "~1 week" as his gut number, which would need an actual
purge job — not built, since D135 didn't ask for one).

Verified live: with today's dozen-plus test edits, panel now shows one
collapsed "Today · N edits" header instead of a flat wall of chips;
clicking it expands/collapses correctly; a non-actionable entry (already
fully round-tripped back to original state with nothing further to do)
no longer appears in the list at all.

### D136 — UI consistency pass: Reports export button colors (2026-08-19)

Nate asked for a sweep across the app for consistency — button placement,
zoom scaling, colors, calling out that Reports' export button colors
looked inconsistent. Checked three things:

1. **Year selector placement** — already consistent. `vOrders`/`vInternal`/
   `vInternalFreight` all build their toolbar identically:
   `<h2>Title</h2>` → `yearPicker()` → flex spacer → action buttons. No
   change needed.
2. **Zoom scaling of buttons/pills/text** — already correct for the main
   content area. `#main{zoom:ZOOM}` (11-toolbar.js) is a true CSS `zoom`,
   which scales layout + text together like a real page zoom, not a
   transform — verified live at 150%: status pills, "Stage →"/"Copy"
   buttons, table headers all scaled proportionally with no clipping.
   `#drawer`/`#modal`/`#history-panel` are intentionally NOT inside `#main`
   (they're fixed-position siblings), so they don't scale with content
   zoom — same as Google Sheets' own zoom doesn't scale its sidebars/
   dialogs. Left as is; flagged for Nate in case he specifically meant the
   drawer, since that's a real design call, not an obvious bug.
3. **Reports export button colors — real bug, fixed.** `vReports()`
   (`04-views.js`) built 5 cards' buttons with `r.k === "everything" ?
   " pri" : ""` — but no report key in the array is literally
   `"everything"` (`freight`/`mileage`/`customers`/`brokers`/`fleet`), so
   that condition was always false and every card button rendered plain
   while the "Export full data CSV" button above them was hardcoded
   `.btn pri`. Dead comparison, likely left over from an earlier version
   of the `reps` array. Fixed by dropping the dead conditional and the
   dump button's own `pri` — all 6 export buttons now render identically
   (plain `.btn`), matching that they're six independent, equally-weighted
   actions rather than one primary + five secondary. Verified live.

Grepped every other `? " pri" : ""` conditional in the client for the
same class of bug (comparing against a value that can never match) —
none found; the rest (driver-view picker, month tabs, sort button, prefs
buttons) all compare against real live state.

### D137 — Current Week and Driver Tabs: Staging visible, layout consistency, drag/drop (2026-08-19)

Nate: keep Staging on screen for Current Week and Driver Tabs (not just
Scheduler/the Orders trackers), size/position Current Week like the
Scheduler itself, line up button placement, and make sure drag-and-drop
between Staging and both views works in both directions.

**`RAIL_ON`** (`05-settings-nav-search.js`) gained `cw: 1, driver: 1` —
the one flag that already gates Staging's visibility + `renderRail()`
everywhere else, so this alone puts the rail on screen for both.

**Current Week** was already, structurally, "an editable window onto the
Scheduler" (D56) — same `data-key` cells, same `chipHtml()` chips — so
once the rail was on, drag/drop already worked with zero further changes
(verified live: chip carries `draggable="true"`/`data-oid`, cells carry
`data-key`, rail is visible). The remaining gap was "identical to the
Scheduler, not just close" (Nate's direct follow-up ask after the first
pass): its toolbar+grid were wrapped in a generic `.pad` (`padding:10px
14px`, plus a per-toolbar inline override dropping its own padding to
compensate) — same idea as every other tracker, but the Scheduler itself
is the one view that ISN'T `.pad`-wrapped at all (`vScheduler()`'s
toolbar and `#sched-wrap` are appended straight to `#main`). An initial
`grid-pad`-class patch got the height/scroll behavior right but still
left a real, visible difference: Current Week's toolbar sat flush left
(0px inset) while Scheduler's toolbar keeps the base `.toolbar{padding:7px
14px}` 14px inset — so column headers/dates didn't visually line up
between the two views. Fixed properly by giving `SUB==="cw"` its own
branch in `render()` — `main.insertAdjacentHTML("beforeend", vCurrentWeek())`
directly, no `.pad` div at all, byte-for-byte the same append pattern
`vScheduler()` uses — and dropping `vCurrentWeek()`'s toolbar's inline
padding override (now needs the same 14px the base rule already gives
Scheduler). Verified live: toolbar `padding` computes to `7px 14px` on
both views, column widths and the "DATE" header's left edge land at the
same x position in both.

**Driver Tabs was the real work.** `vDriverView()` used to render only
*occupied* slots (`if (!v) continue`) as hand-formatted plain `<div>`s —
no `data-key`, nothing draggable, so there was nothing for a drop to land
on and nothing to drag out. Rewritten to render all 15 slots (5 days × 3)
unconditionally; empty ones are a bare `.dv-cell[data-key]` (a real,
just-blank, drop target); occupied ones keep the exact same driver-facing
text (unchanged — this view's whole point is mirroring what the Sheet
tab shows) but the container itself now carries `data-key`/`draggable=
"true"`/`data-oid`/`data-from`, i.e. the same four attributes `chipHtml()`
puts on a real chip, just without the `.chip` class or its visual
styling — the dense text-table look stays exactly as it was, it's just
now also a valid drag source/target underneath.

That required broadening the shared drag/drop plumbing (`11-toolbar.js`,
`12-touch-boot.js`), which had hardcoded `td[data-key]`/`.chip[draggable=
true]` selectors assuming every drop target was a `<table><td>` and every
draggable was a real chip:
- dragstart: `.chip[draggable=true]` → `[draggable=true][data-oid]` — a
  strict superset (`chipHtml()` always sets `data-oid` on draggable
  chips), so no existing behavior changed, it just also now matches
  `.dv-cell`.
- dragover/dragleave/drop: `td[data-key]` → `[data-key]` (tag dropped).
  **`:not([data-field])` still matters and was kept everywhere it
  appeared** — Database/Sheet grid cells (`dcell`/`sheetCellHtml`/
  `dcellRow`) carry `data-key` too, in an unrelated `table-id-field` /
  `sheet-id-r|c` format, and always pair it with `data-field`; that's the
  one thing standing between "valid Scheduler-style drop target" and "a
  Database cell that happens to share the attribute name." Confirmed via
  grep that every non-scheduler `data-key` emitter in the client sets
  `data-field` alongside it — broadening the tag match doesn't risk
  turning a Database cell into an accidental drop target.

Verified live: Current Week shows the h2, fills the same height/scroll
as Scheduler, rail visible with the same chip/cell drag attributes as the
real board. Driver Tabs shows all 15 slots per truck (14 empty, 1
occupied in the test data) with correct `data-key`/`draggable`/`data-oid`/
`data-from` on the occupied one; clicking an occupied slot does not open
the drawer (unchanged — `.chip[data-oid]` is a separate, class-scoped
click delegator, so the broader `[data-oid]` used for drag doesn't leak
into click-to-open). Scheduler and Database grids re-verified working
with no console errors after the shared-selector changes.

### D138 — Driver Tabs: exact port of the real sheet, editable, click-to-open everywhere (2026-08-19)

Nate wanted Driver Tabs rebuilt as a genuine port of the real per-driver
Google Sheets tab rather than an approximation of it, with the notes
field actually editable, fixed-size cells (scroll instead of grow), and
— in a follow-up in the same round — the three Dispatch views (Scheduler,
Current Week, Driver Tabs) made consistently click-to-edit for load chips
across all of them, since a dispatch note is naturally Driver-Tabs-only
but everything else operates on the same underlying data.

**Checked the real mirror sheet directly** (not assumption) — a driver's
own tab is 6 columns, not the app's previous 4: DATE, the driver's own
name (the load column), NOTES, Pickup, Drop, Store Maps — matching
`_driver_week_payload`/`api_sheets_push_driver_tabs`'s own `B:G` layout
exactly (server.py). The app's old `vDriverView()` only had Date/Load/
Notes/Store, was missing Pickup/Drop as separate columns entirely, and
its "Load" text for a simple-route external order was just the header
line — no PICK:/DROP: address lines at all, unlike what the sheet
actually shows.

**Rebuilt to match column-for-column and byte-for-byte.** New client
helpers `fmtLocation`/`mapsViewLink` mirror server.py's `_fmt_location`/
`_maps_view_link` exactly (same string joins, same Google Maps search URL
construction) — kept deliberately parallel so the two stay in sync if
either changes. `driverExternalRouteText`/`driverInternalLoadText` now
produce the same text `_driver_chip_text`/`_internal_chip_text` push to
Sheets, including the PICK:/DROP: lines the app was missing. Pickup/Drop
became their own columns (`driverPickupDropLinks`), Store Maps stayed
internal-only, matching the server's own kind-based branching.

**Notes column is genuinely editable now** — a `<textarea class="dv-note">`
per slot, saving through `loadNoteSet`/`scheduleNote` (whichever the slot
already uses — same functions the Scheduler/Current Week chip's own note
editor calls, wired via a plain blur handler in `07-events.js`, not the
Scheduler's `EDITING`/keyboard grid system, which assumes a `<table>`
`<td>` structure `.dv`'s CSS-grid divs don't have). `o.notes`/the
customer location's note render above it as read-only context, matching
what the real push joins into that same cell server-side — editing here
only ever targets the one piece of that join that's a genuine
free-standing field (the per-placement dispatch note), not the whole
combined string.

**Fixed cell size, scrolls instead of growing** — `.dv-cell{max-height:
110px;overflow-y:auto}`, `.dv-note{min-height:34px;max-height:70px;
resize:none}`. Column widths were already fixed via `.dv`'s own
`grid-template-columns`; this was the missing per-cell height half.

**Click-to-open, made universal across all three Dispatch views.** The
existing chip-click delegator (`07-events.js`) was `.chip[data-oid]`
only — Driver Tabs' occupied load cells aren't `.chip` elements (kept the
dense text-table look, not chip styling), so clicking one did nothing.
Added `.dv-cell[data-oid]` as a second explicit match on the same
delegator — **not** broadened to a bare `[data-oid]`, because the
drawer's own carrier-name and pickup/delivery location-combo inputs also
carry `data-oid` for unrelated reasons, and a generic match would
re-trigger `openOrder` while typing inside a drawer that's already open
around them.

Verified live: driver tab for truck 39 (James) on a real external order
showed the exact multi-line PICK:/DROP: text plus working Pickup/Drop map
links (`https://www.google.com/maps/search/?api=1&query=...`, same
encoding as the server); typed a dispatch note on Jordan's occupied slot,
confirmed it landed in `loads.notes` in Postgres and immediately showed
up on the Scheduler's own chip (`✎ Fuel before leaving yard`) — same
row, same field, both views just render it differently; clicking that
same occupied cell opened the real order drawer, edited it there, closed
clean. No console errors across Scheduler/Current Week/Driver Tabs after
the change.

### D139 — Driver Tabs: same window as Current Week, not its own hardcoded one (2026-08-19)

Nate: *"it needs to display what current week is, and however many days
current week is. it needs to be linked together cause when i push it to
the google sheets it will write over everything."* Real risk, not just a
display nit — `vDriverView()` iterated its own hardcoded Monday-of-today
+ 5 days, completely unrelated to `CW_START`/`CW_DAYS` (Current Week's
actual configurable window, which is also exactly what
`/api/sheets/push-driver-tabs` pushes). An admin editing a dispatch note
on Driver Tabs could easily be looking at a day the next push wouldn't
even touch, or not realize a push overwrites a different range than
what's on screen.

Fixed by making Driver Tabs use the literal same state, not a synced
copy of it: `vDriverView()`'s day loop now calls `currentWeekDates()`
(the same helper `vCurrentWeek()` already uses) instead of its own
hardcoded range, and its toolbar renders the exact same `#cw-start`/
`#cw-days`/`data-cw-step` controls (plus the `#push-driver-tabs` button)
Current Week has — same element ids, so the existing generic handlers in
`07-events.js` (already id-matched, never scoped to a specific view) work
unmodified. Changing the window from either view changes both, because
there's only one `CW_START`/`CW_DAYS` regardless of which page rendered
the controls that touched it.

Removed `mondayOf()` (`02-chips-extract.js`) — its only caller was the
hardcoded loop this replaced; confirmed zero remaining references before
deleting.

Verified live: bumped Days Shown from 3 to 5 on Current Week, switched to
Driver Tabs — showed 5 days too, matching header controls, no reload
needed (both read the same globals). No console errors.

### D140 — Two notes per order, every kind: driver tab note vs. dispatcher note (2026-08-20)

Nate: *"we need two notes on every single order in that window, there
needs to be a driver tab note section and a note section for me if i need
it... so all three order types is what i mean by every order."* Before
this there were actually THREE overlapping note concepts in play —
`orders.notes` ("Load Info", dispatcher-only), `orders.driver_note`
(already existed as a real column, but only wired up for Internal Freight
transfers, D130), and `loads.notes` (a per-placement "dispatch note" — the
chip's ✎ icon, editable by right-click/typing-over-a-chip on any chip
across Scheduler/Current Week/Driver Tabs) — and `loads.notes` was
ALSO one of three things silently concatenated into the real pushed
Sheets NOTES column (`o.notes · customer_notes · load.notes`) for
internal/external orders, meaning "Load Info" was leaking into the
driver's tab despite the D130 comment claiming otherwise (that comment
was only ever true for transfers). Asked Nate what should happen to
`loads.notes` given the request was for exactly two notes, not three —
his call: retire it ("get rid of load notes cuz i dont know what it is").

Generalized the D130 transfer-only pattern to all three order kinds:
`orders.notes` ("Load Info") stays dispatcher-private, never pushed, and
now also drives the transfer chip's TITLE specifically (Nate flagged this
explicitly — don't break that). `orders.driver_note` ("Driver tab note")
is the one note that reaches the driver's Sheets tab, editable from the
Bag Orders/External Orders/Internal Freight drawers alike (`fld
("driver_note", ...)`, same section already built for transfers) and
from Driver Tabs' Notes column and Scheduler/Current Week's chip note
editor (both retargeted from `loads.notes` to `driver_note` via order id).
`chipHtml()` (`02-chips-extract.js`) no longer takes a `dispatchNote`
param — it reads `o.driver_note` directly, so the chip's ✎ badge is
always in sync with whatever wrote the field, from any of the three
editing surfaces.

Removed entirely: `loads.notes` reads/writes app-wide (`api_load_note`
and its route, `loadNoteSet`, the `loadNote` key in `cellContents()`),
though the `loads.notes` DB column itself is left in place (unused, not
dropped — a column is cheap to leave, a DROP COLUMN is not reversible).
Server's `_driver_week_payload` NOTES-column build now joins
`[driver_note, customer_notes]` instead of `[notes, customer_notes,
load.notes]` — `customer_notes` (location-level: forklift/gate
instructions) stays folded in since it's driver-relevant context, not
dispatcher shorthand.

New `driverNoteSet(oid, key, note)` (`08-undo.js`) replaces `loadNoteSet`
— writes through `/api/order/update` (already allowlists `driver_note`,
already permission-scoped per order kind via `_order_kind_sub`, so this
is MORE correctly gated than the old blanket-`dispatch/sched`-permissioned
`/api/load/note` was) and repaints only the affected chip via
`repaintCell`, never a full `render()` — a full rebuild here would race a
user tabbing between Driver Tabs' many note boxes, the same class of bug
D122/D128 fixed for drawer fields. `repaintCell` (`04-views.js`) was
extended with a second branch for Driver Tabs' un-nested chip markup
(no `.cell` child to find), so the same repaint call now correctly
updates both Scheduler/Current Week `<td>` cells and Driver Tabs' `.dv-
cell` divs.

Verified live: edited the driver tab note from all three surfaces
(Driver Tabs textarea, drawer field, typing directly over a Scheduler
chip) — each one instantly matched on the other two, plus the Scheduler
chip's own ✎ badge. Dry-ran `/api/sheets/push-driver-tabs` afterward with
no server error. No console errors anywhere in the flow.

### D141 — Driver Tabs load column is a real chip; Scheduler scroll position now survives a tab switch (2026-08-20)

Two more bugs from the same live pass. First: Nate — *"the load chips in
the driver tabs are not displaying like the load shouldnt be text it
should be the chip including color."* Driver Tabs' Load column
(`vDriverView`) rendered a hand-built plain-text block
(`driverExternalRouteText`/`driverInternalLoadText`, a byte-for-byte port
of the real push text) instead of the actual scheduler chip — no color,
no `.chip` styling, inconsistent with every other place a load renders in
the app. Deleted both functions and rendered `chipHtml(o, ...)` directly
inside the cell instead — same colored, click-to-open, drag-source chip
Scheduler/Current Week already show for the same load. The outer
`.dv-cell` keeps its own `data-key`/`draggable`/`data-oid`/`data-from`
(D137's drop-target/drag-source design, unchanged) with the real chip
nested inside it purely for display.

Also folded the Driver Tabs header into the same `.pad`-bypass Current
Week already used (D137 follow-up) — `render()`'s dispatcher (`05-
settings-nav-search.js`) now routes `SUB === "driver"` the same way as
`SUB === "cw"`, inserted straight into `#main` instead of wrapped in a
`.pad`. Before this the two toolbars looked different (Driver Tabs had
manual `border:0;background:none;padding:0 0 8px` overrides to avoid
double-padding inside `.pad`) even though both show the same First-day/
Days-shown/Update-Google-schedule controls. Now both toolbars are the
literal same markup shape and render pixel-identical; the truck-picker
row and `.dv` grid below get their own `padding:10px 14px 14px` wrapper
(`flex:1;overflow:auto`) standing in for what `.pad` used to provide.

Second: Nate — *"i encountered a bug when i switch from current week to
scheduler it resets scheduler view to july 1st."* Not a data bug — the
cached `schedNode` (D53's detached-while-hidden design) is reused, not
rebuilt, on a tab switch back to Scheduler, so `schedNeedsScroll`'s
scroll-to-today logic never re-fires. Turns out a detached-then-reattached
scrollable element loses its `scrollTop` in this browser — reattaching
`schedNode` after `main.innerHTML = ""` silently dropped the view back to
`scrollTop: 0`, which is the top of `SCHED_WIN`'s rolling window (one
month before today — July, since today is August). Fixed by saving
`schedNode.scrollTop` into a new `schedScrollTop` global right before
`main.innerHTML` clears it out of the DOM, and restoring it after
`main.appendChild(schedNode)` on any render that reuses the cached node
(the `schedNeedsScroll` branch, which only fires on a genuine fresh
build, is unaffected and still scrolls to today instead).

Verified live: switched Scheduler → Current Week → Scheduler — stayed on
today's row both times, no jump to July. Driver Tabs header now matches
Current Week's exactly (screenshot-compared bounding boxes: both toolbars
edge-to-edge, same padding, same background). Load chip in Driver Tabs
renders colored and click-to-open, matching the same load's Scheduler
chip exactly (this pass also exposed and fixed D140 above, since the two
bugs shared the same root file).

### D142 — Internal Freight column order, free-typed Fork field, typeable hex, unhid Store Map (2026-08-20)

Small polish batch, same live session as D140/D141:

- **Internal Freight tracker**: swapped the Department/Route-Note columns
  (Load Info now leads, Department follows — matches the drawer's own
  field order) and renamed "Route / Note" → "Load Info" for consistency
  with the drawer label. Purely a column-order/label change in
  `vInternalFreight()`; no data or save-path changes.
- **Transfer chip's blank-title fallback** changed from "(no route)" to
  "(no load info)" (`buildChip`, `02-chips-extract.js`) — matches the
  renamed field above; was stale copy from before Load Info existed as a
  named concept.
- **Bagger Customers' Fork field was a locked 3-option dropdown in the
  Add-customer modal** (`addCustomerModal`, `06-modals-grids.js`) — the
  live grid cell itself was already free-typed text (`fields` metadata
  already says `ui:'text'` for it), so this was only ever a bug in the
  modal's own hardcoded field list, not the metadata. Switched
  `mfield("forklift", ..., "select", {...})` to a plain `"text"` field —
  no server change needed, `api_add_customer` already stores it as a
  plain string, no enum.
- **Typeable hex code next to every native color swatch** (Nate: "also
  need a typeable hex code spot for the color editors") — added a paired
  `.hex-text` input, two-way synced with the native `<input type=color>`
  on every keystroke (`normalizeHex`/`hexInputValue`, `11-toolbar.js`), to
  the Sheets-style picker (`openSheetsPicker` — driver color chips,
  department color chips, fill/text-color toolbar) and the designation
  conditional-format rule editor (`condRuleRowHtml`, `06-modals-grids.js`
  — the Bagger Customers Time Window color rules). Border color
  (`openBorderMenu`) deliberately left alone — a different, tighter
  toolbar layout with no room for a second input, and not what was
  actually being pointed at (a border line color isn't really a "color
  editor" in the same sense as a chip/customer color). Save logic
  untouched everywhere — the typed text only ever writes into the
  existing native color input's `.value`, which every save handler
  already reads.
- **Bagger Customers' Store Map column was invisible, not deleted** —
  `locations.map_url` has been a real column all along (already in
  `api_bootstrap`'s locations select, already what Driver Tabs' "Store
  Maps" link reads via `locFor(...).map_url`), but had no `fields` row, so
  it never rendered as an editable grid column anywhere. New migration
  `20260820000001_bagger_store_map_field.sql` adds one (`ui:'text'`,
  appended after Notes) — falls through to the generic `dcell()` column
  render, which already linkifies a whole-value URL (D123), so a
  populated row shows a real clickable link with zero new rendering code.
  Verified the OTHER half of the ask — "make sure it shows up on the tabs
  in the correct spot... a true mirror of the google sheet" — was already
  true from D138: temporarily pointed Driver Tabs at a past date with a
  real internal load on a mapped customer (BI-MART #604, Sat 2026-05-02,
  Jon's tab) and confirmed the Store Maps link renders in the last column,
  matching the real sheet's layout exactly. No code change needed for
  that part — reverted the date back to today after confirming.

D142's Fork free-type fix only changed the UI (grid cell was already
text; the Add-customer modal's dropdown became text). Missed that the DB
itself still had `locations_forklift_check`, a CHECK constraint from the
initial schema locking the column to exactly `'NF'`/`'forklift'`/
`'spyder'` — typing anything else 500'd on save (Nate: "if i type over
the database for forklift it gives a toast error"). Migration
`20260820000002_forklift_free_text.sql` drops the constraint — it was
always a note field in practice, not a real enum, and now the schema
matches what the UI already promises. Verified live: typed "call ahead"
into a Fork cell, saved clean, no toast; reverted back to "NF", same.

### D143 — Marquee selection auto-scrolls when dragged to the edge (2026-08-20)

Nate: "need the databases to scroll if i select and go down or up off the
screen space." A drag-select marquee (`selStart`/`selMove`,
`10-select.js`) only ever updated on real `pointermove` events — dragging
to the bottom (or top) edge of a Database grid's scroll container and
holding the mouse there did nothing once the cursor stopped moving,
unlike Excel/Sheets' edge-auto-scroll. The selection system is shared
app-wide (D68 — same code drives Scheduler/Current Week marquees too),
so this fix isn't Database-specific even though that's the surface Nate
hit it on.

Added a timer that keeps running independent of new pointer events:
while a marquee drag is active (`MARQ.moved`) and the last known pointer
position is within `MARQ_SCROLL_EDGE` (28px) of the scroll container's
top or bottom edge (and there's more to scroll that direction), it
nudges `scrollTop` and re-runs `boxTds`/`setSel` against the new
(post-scroll) cell positions every tick. Deliberately a plain
`setInterval(16ms)`, not `requestAnimationFrame` — rAF callbacks are
paused outright by the browser the moment the tab/window isn't the
foreground one, which would silently kill mid-drag auto-scroll the
instant focus moved elsewhere; a timer keeps firing regardless (confirmed
this the hard way: an initial rAF-based version tested at literally 0
scroll under this session's own background-tab browser automation, while
switching to `setInterval` scrolled correctly under the exact same test).
Cleared in `endMarquee()`, which now also owns the `window blur` case
(was a separate inline `killMarquee()+MARQ=null`, missing the timer
teardown — folded into calling `endMarquee()` directly, confirmed it
doesn't change blur's existing selection-preserving behavior since
`setSel([])` only clears `SELSET`, never `SEL`, when `SELSET` is already
empty).

Vertical only, matching what was actually asked — the same pattern
extends to horizontal edges later if that's ever needed. Verified via
dispatched pointer events (drag start → hold at bottom edge → scrollTop
climbed and the multi-cell highlight grew with it → pointerup stopped it
instantly with no further drift; then the same for the top edge after
scrolling back down first). No console errors.

Same-turn follow-up, Nate: "it also needs to scroll if im dragging a
cell value" — the fill handle (D118, Excel-style drag-to-fill) is a
second, separate drag mechanism (`FILL`, not `MARQ`) with the identical
gap. Factored the shared edge-detection math out into `edgeAutoScroll
(wrap, x, y)` so both drags call the same function instead of duplicating
it, then wired it into the fill handle the same way: `FILL.lastX/lastY`
tracked on every real pointermove, a `setInterval` re-running
`fillHandleUpdate` (the box-and-paint logic, itself factored out of
`fillHandleMove` so both the live pointer handler and the scroll tick
call it) whenever the pointer sits near the wrap's edge. Also added a
`cancelFillHandle()` on window blur — the fill handle had no blur
handling at all before (a stray `setInterval` would have leaked forever
if focus left mid-drag); cancels rather than commits, matching the
marquee's blur behavior, since an interrupted drag shouldn't silently
write whatever was highlighted at the moment of interruption.

Verified live the same way as the marquee, PLUS an end-to-end value
check: grabbed a City cell's fill handle, dragged to the bottom edge and
held — scrollTop climbed, the `.fill-target` count grew across the
newly-revealed rows, released, and the real cities got overwritten with
the source cell's value exactly as a fill should (confirmed live in
Postgres, then immediately undone via the app's own Undo — this was
real customer data, not scratch — confirmed every city was back to its
original value in the DB afterward). No console errors.

### D144 — Managed dropdown options on any built-in text field (2026-08-20)

Nate, right after the D142 forklift fix landed: "now that we fixed the
forklift thing i need to be able to make something a dropdown cause i do
want the forklift thing to be a dropdown menu i just have no way to edit
or control that yet. or assign new ones or change the dropdown labels
etc." D142 made Fork free-typed (the DB enum was the actual bug that
turn), but free-typed was never the end state Nate wanted — he wants a
dropdown, just one HE controls the option list of, not a hardcoded
3-value enum baked into the schema.

Turned out `fields.type`/`fields.options` (jsonb) already existed on
every built-in field — mirrors the custom-column select type from D85 —
and `api_field_update` already allowlisted both for any non-locked field.
The entire gap was client-side: nothing ever rendered a built-in field as
a `<select>` even when `type='select'`, and there was no UI to set
`type`/`options` on a built-in field at all (only custom columns had
`columnModal`'s Type+options form).

Closed both gaps:
- `fieldCell()`'s generic column-backed branch (`04-views.js`) now checks
  `f.type === "select"` and renders `selectFieldCell(...)` instead of
  `dcell(...)` — a `<select>` riding `data-rowtable`/`data-rowid`/
  `data-rowfield`, the SAME existing generic "save one row field to
  `/api/row`" change handler Fleet's equipment picker and the designation
  select already use (07-events.js) — no new save path, no new endpoint.
  The row's current value is always injected into the option list even
  if it's since fallen off the configured set (an old free-typed value,
  or a since-renamed/removed option) — turning a field into a dropdown
  must never silently hide what's already there.
- New `fieldOptionsModal(field)` (`06-modals-grids.js`) — one comma-
  separated "Dropdown options" input, same convention `columnModal`/
  `customFieldModal` already use for a custom column's options (not a
  repeatable-row builder — matching the existing pattern beat inventing a
  fancier one). Blank options reverts the field to plain `type:'text'`,
  so this one control both makes and unmakes a dropdown. Reached via a
  new "Dropdown options…" item on the field right-click menu (D85's
  existing `th[data-fieldid]` context menu, alongside "Conditional
  formatting…"), gated to plain generic column-backed fields only — not
  offered on `ui:'designation'`/`'equipment'`/`'truckdriver'`/`'color'`
  (already their own managed-dropdown-equivalent systems), not on
  json-storage custom fields (already get Type+options through their own
  add-field modal), and not on a `locked` field (server already refuses
  to retype one).

Verified live: right-clicked Fork → Dropdown options… → typed "NF,
forklift, spyder, call ahead" → Save. Every row's Fork cell became a
real `<select>` with all four options and the correct one pre-selected
(including the existing free-typed "call ahead" value, proving the
inject-current-value guard works). Changed one row's value via the
dropdown, confirmed the new value landed in Postgres, reverted it back
directly in the DB afterward. No console errors.

### D145 — Dropdown options as one row each, not comma-separated; conditional-format modal was clipping its own opacity slider (2026-08-20)

Two fast follow-ups on the same live pass. First, Nate on D144's
comma-separated options input: "right click select is cool but each
option needs to be its own thing it cant be mushed in one line separated
by comma, like we have to make it a fill outable entity." Rebuilt
`fieldOptionsModal` (`06-modals-grids.js`) as one row per option — a text
input plus a `×` remove button, a "+ Add option" button appends a new
blank row and focuses it — instead of one comma-separated text field.
Not a new UI pattern: reuses `condRuleRowHtml`'s existing repeatable-row
convention (same `.colmgr-row` class conditional-format rules already
use) rather than inventing a second way to manage a list in this app.
Save now reads every `[data-optval]` input under `#field-options-rows`
instead of splitting one string. `columnModal`/`customFieldModal` (custom
grid columns' own options editor) still use the older comma-separated
input — untouched, out of scope for this ask, though the same rebuild
would apply there if that's ever raised too.

Second, Nate noticed in passing: "the opacty slider on the conditional
formatting window bleeds over the edge." Real layout bug, not new — a
conditional-format rule row packs six controls onto one flex line (op
select, value input, color swatch, D142's hex-text box, the opacity
slider + its output, delete button), and the modal's default width
(460px) was never wide enough for that even before D142's hex-text
addition made it worse. Fixed with a `wide-modal` class on `#modal`
(same pattern the route editor's existing `route-modal` class already
uses to widen itself to 920px) bumping the card to 640px, added only by
`condFmtFieldModal`. `openModal()` now clears `wide-modal` alongside
`route-modal` on every open, so it can't leak onto an unrelated modal
opened afterward.

Verified live: Fork's dropdown-options modal now shows NF/forklift/
spyder/call ahead as four separate rows; added a "side door" row, deleted
"call ahead", saved — Postgres showed exactly `["NF","forklift","spyder",
"side door"]`. Conditional formatting's modal now shows all four rules
with the full opacity slider and percentage visible inside the card;
reopened Add Customer right after and confirmed it's back to the normal
460px width (wide-modal didn't leak). Reverted the test option-list
change back to the original three afterward. No console errors.

### D146 — Renaming a dropdown option migrates existing rows, not just the label list (2026-08-20)

Nate: "when i update the dropdowns they need to update the in the
database." D144/D145 let Nate manage a field's option LIST, but editing
an existing option's text only ever touched `fields.options` — every row
already holding the old text (119 of 272 Bagger Customers said plain
"forklift") was left exactly as it was, silently falling off the new
option list (still shown via the existing "inject the current value even
if it's not in the configured options" guard, D144) instead of actually
becoming the new text like a rename implies.

New `/api/field/rename-option` (`api_field_rename_option`, `app/server.py`)
does a straight `update <table> set <col>=%s where <col>=%s`, resolving
table/column from the field's own `storage` (validated against the same
small real-table allowlist `fieldCell`'s select branch already trusts,
plus an identifier-shape regex on the column — defense in depth, since
`storage` is trusted metadata, not client input, but cheap to check
anyway). No `API_PERMISSIONS` entry needed — structural field routes
(the whole `/api/field*`/`/api/entity*` family) are deliberately absent
from that table already, which fails closed to admin-only by the existing
D125 default, not a gap specific to this route.

Client-side, each option row already carries `data-optorig` (added in
D145 to build the row markup) — the save handler now diffs each row's
`data-optorig` against its current value: unchanged rows are ignored,
a genuinely NEW row (added via "+ Add option") has no `data-optorig` so
it can never look like a rename, and an in-place edit becomes a `{from,
to}` rename call to the new endpoint, run after `fieldMetaSet` saves the
option list itself. Wired into `histPush` both ways — undo reverses both
the option list AND every migrated row back to the old text, not just
the metadata. A `reload()` follows any rename so the grid actually shows
the migrated values instead of a stale in-memory copy (a plain
`fieldMetaSet` alone, with no rename, still skips this — cheaper, and
correct, since nothing in the underlying rows changed).

Caught mid-verification: the server-side half 404'd on the first live
test — editing `app/server.py` needs a server restart to take effect
(the standing trap in `CLAUDE.md`), and this session's server had been
running since before this route was added. Restarted it, confirmed the
same rename call returned 200 next time.

Verified live: renamed Fork's "forklift" option to "Forklift Required" —
confirmed in Postgres that all 119 rows previously reading exactly
"forklift" (not the differently-cased "Forklift" stray value, correctly
untouched) now read "Forklift Required", and the grid showed the new
text immediately without a manual refresh. Reverted both the row data and
the option list back to the original afterward. No console errors on the
successful run.

### D147 — Driver Tabs drag/drop needed a full reload to show; note placeholder was overly specific (2026-08-20)

Nate: "currently when you drag an order in the driver tabs the ui doesnt
update unless you refresh the page." Real bug in `repaintCell()`'s
Driver-Tabs branch (added D140/D141): it only patched the Load cell's
`innerHTML`, and only when that cell already had `dataset.oid` set — so
two of the three real cases silently did nothing — dropping onto a
previously-EMPTY slot (no `data-oid` to match the guard) and dragging a
load OUT of a slot (the cell still had its stale `data-oid` since nothing
ever cleared it, but `CELLS[key]` was already deleted, so the "if there's
an order" check inside failed too, leaving the old chip on screen). Only
the third case — dropping onto a slot that already held a DIFFERENT
order — happened to work, since it never falls back to the DOM's stale
`data-oid`, but that's rarely how a drag between two Driver Tabs slots
plays out.

Fixed properly rather than patching around the guard: factored the
Load/Notes/Pickup/Drop/Store-Maps cell markup out of `vDriverView()`'s
render loop into `dvSlotCellsHtml(key)`, and added `repaintDvSlot(key)`
that rebuilds all 5 sibling cells from that same function and swaps them
in via `replaceWith` — matching the initial render byte-for-byte instead
of a narrower ad-hoc patch that only ever handled the Load cell. All 5
cells needed rebuilding, not just Load — Notes/Pickup/Drop/Store Maps
all depend on which order (if any) currently occupies the slot.
`repaintCell()`'s `.dv-cell` branch now just calls `repaintDvSlot(key)`
unconditionally instead of the old inline oid-gated patch.

Same-turn, Nate: "it makes the note box say 'driver tab note' which is
unneccasary. it doesnt need to change from note until i start typing."
The `NOTES` column header already says what the field is — the empty-
state placeholder repeating "Driver tab note" was redundant. Changed to
plain "Note" (`dvSlotCellsHtml`).

Verified live: real HTML5 drag-and-drop simulated (`DragEvent` +
`DataTransfer`, not just direct API calls, so the actual `dragstart`/
`dragover`/`drop` handlers in `11-toolbar.js` ran) — moved BI-MART #607
from Thu slot 3 to Fri slot 2 within Wayne's Driver Tabs; both the source
(cleared) and destination (chip + Store Maps link appeared) updated
instantly with no reload, confirmed via `/api/schedule` returning 200 in
the network log. Moved it back afterward. Empty note box now shows
"Note". No console errors.

### D148 — Order-tracker Customer/Broker pickers are type-ahead now, not a giant plain `<select>` (2026-08-20)

Nate: "workflow wise the order trackers dropdowns need to be more
sensitive to typing like the autofill for example if im typing in the
customer box 607 then the stores with 607 need to populate." Bag Orders'
Customer column and External Orders' Broker/Customer column were both a
native `<select>` listing the FULL party list (272+ Bagger Customers) —
a native select's type-to-jump only matches text a typed key STARTS
with, so typing "607" could never land on "BI-MART #607" (the match has
to begin with what's typed, and nothing here starts with a customer
number). D42's Pickup/Drop combo (`locCombo`/`renderLocSuggest`/
`handleLocPick`, `03-drawer-billing.js`) already solved exactly this
problem for locations — substring-anywhere search, click-to-pick,
positioned-under-input suggestion panel — so this reuses that same UI
(`.loccombo`/`.loc-suggest` CSS, same event-listener wiring pattern in
`07-events.js`) rather than building a second combo widget from scratch.

New `partyCombo`/`renderPartySuggest`/`handlePartyPick`/`partySubsetFor`
(`03-drawer-billing.js`) — searches `DB.parties` filtered to `is_customer`
or `is_broker` depending on which field the combo is wired to, substring
match on name only (unlike locations, a party has no address/city/phone
to also search). Deliberately has NO "+ Create" option, unlike
`locCombo` — a brand-new customer/broker already has its own "+ Add
customer" modal per grid, and letting a fast typo in a tracker cell
silently spawn a second, duplicate party record is a real risk a
location doesn't share (a location has no separate identity to collide
with). Wired into the existing `data-loccombo` input/focus/click
listeners as sibling `data-partycombo` branches rather than duplicating
three near-identical listeners.

Replaced both call sites: Bag Orders' Customer column (`vInternal`,
dropped the now-dead `custs` variable it replaces) and External Orders'
Broker/Customer column (`vOrders`, dropped the now-dead `brokers`
variable). The disabled-when-cancelled behavior the old `<select>` had
carries over via a new `disabled` param on `partyCombo`.

Verified live: typed "607" into a blank Bag Orders customer cell —
"BI-MART #607" was the only suggestion, clicked it, saved, Time Window
resolved correctly from the newly-set customer (confirms
`applyOrderFkDenorm` still fires through the new save path). Reverted
the test row back to blank in Postgres afterward. External Orders'
Broker/Customer column confirmed showing the same search-as-you-type
combo. No console errors.

### D149 — Arrow keys and Tab now drive the loc/party suggestion panels (2026-08-20)

Nate, mid-turn on D148: "can we make the arrow keys interact with the
dropdown lists and search functions as well as the cells in the entire
app, like up and down arrow should be able to scroll lists if ur
searching or if ur typing in customers etc." — then, right after: "if a
user is in the middle of an autofill and they hit tab the menu should
close with the best match being the selection thats how all the
autofills should work." Global search (`#gsearch`) already had this
(`GS_SEL`/`ArrowUp`/`ArrowDown`/`Enter`, `07-events.js`); the loc-suggest/
party-suggest panels D42/D148 use had none — click was the only way in.

`renderLocSuggest`/`renderPartySuggest` now both call a shared
`markFirstLocOpt(panel)` so the best (first) match starts highlighted the
instant results appear — Tab has something to commit even if the user
never touches an arrow key. A new `keydown` listener scoped to
`[data-loccombo],[data-partycombo]` (`07-events.js`) moves the `.on`
highlight on ArrowUp/ArrowDown (wrapping, `scrollIntoView` for overflow),
activates the highlighted option on Enter (`preventDefault`, matches
Enter-to-edit elsewhere), and on Tab activates it too — deliberately
WITHOUT `preventDefault`, so focus still advances to the next field
exactly like an ordinary Tab; the pick just rides along first. One
`activateLocOpt(opt)` dispatcher branches on `data-partypick` vs.
`data-locpick`/`data-loccreate` so both combo types share the same
listener instead of two near-duplicate ones.

Scheduler cell arrow-key movement was already working (`move()`,
`06-modals-grids.js`, existing `scrollIntoView({block:'nearest'})` on
every move) — checked live via dispatched keydown events before writing
any code, confirmed already correct, no changes made there.

Verified live: typing "Trade" into External Orders' Broker/Customer combo
surfaced "Tradewinds Brokerage" pre-highlighted; a single dispatched
ArrowDown moved the highlight to "TRADEWINDS BROKERAGE,INC." cleanly (one
event in, one state change out — confirmed precisely via direct
`KeyboardEvent` dispatch, since the browser-automation tool's own
synthetic key-press occasionally double-fires and isn't reliable for
this kind of single-step assertion); Tab immediately after committed
that highlighted option and saved it. Reverted the test row afterward.

### D150 — External Orders: dropped the redundant "Drop rate con" button (2026-08-20)

Nate: "the button that says drop rate con -> new order, that can go away
completely and can be the new order button thats currently sitting next
to it cause i already have a drag box for inputting rate cons with OCR."
The button (`#new-ratecon`) just opened the same hidden file picker
(`#file-ratecon`) the real `#rc-drop` drag-and-drop zone right below it
already opens on a tap (`12-touch-boot.js`) — genuinely redundant, not
just visually similar. Removed the button and its now-dead click handler;
"+ New Order" is now the toolbar's one action button, promoted to
`btn pri` (primary) since it's no longer sharing visual weight with a
second button.

### D151 — Smart date-range inputs: slashes and Tab are interchangeable, year inferred if you skip it (2026-08-20)

Nate, across two follow-up messages: "the date ranges need to accept
better date inputs as well like i should be able to type 8 tab 22 and
then it just goes" and then, more precisely: "all the date ranges that
you can type into should be seamless i can type 08/22/2026 or... 8 tab 22
tab 2026... make it easier to work with tabs and slashes being the same
thing inside the dates." A native `<input type=date>` has NO JS-visible
way to move its own internal month/day/year segment cursor — there's no
browser API for it — so "/" can never act as Tab (or Tab as "/") inside
one; the only way to deliver "tabs and slashes being the same thing" was
to stop using native date inputs for these fields and own the typing
entirely.

Built a masked text-input module (`10-select.js`) scoped to `[data-
smartdate]`, applied to the fields that are genuinely date RANGES —
Reports' From/To (`data-repfrom`/`data-repto`) and Current Week/Driver
Tabs' "First day drivers see" (`#cw-start`, shared by both views since
D139) — not every single date column app-wide (the per-order Ordered/
Delivered tracker columns and the admin per-user view-window stayed
native `type=date`, not named in either message and a wider blast radius
to convert). Segment state (month/day/year, index 0-2) lives in a
WeakMap, not in the DOM — digits fill the active segment and auto-advance
once it's full (2 digits for month/day, 4 for year, so "08222026" typed
straight through with no separators works too); "/" always advances one
segment and never leaves the field; Tab is context-sensitive — on the
month segment it just advances to day (a bare month isn't a usable date
yet), from day or year onward it commits immediately and does NOT
`preventDefault`, so focus actually leaves like an ordinary Tab. That's
the whole "8 tab 22 [tab away] and it just goes" flow: a missing year is
inferred from the field's own last real value, or today's real year if
it never had one.

Two bugs caught during live verification, not just written and assumed
correct:
1. **Redundant "/" skipped the day segment.** Typing "08" auto-advances
   past month; the very next "/" (typed as the natural month/day
   separator in "08/22/2026") advanced AGAIN, landing on year with day
   still empty — reproduced live (`mid: "08//202026"`) before a
   `justAdvanced` flag was added so an explicit "/" right after an
   auto-advance is absorbed instead of double-advancing.
2. **Commit briefly used a flat "how many digits total" guess** (concat
   all three segments, split 2/2/4) instead of trusting the actual
   tracked segments — which cannot tell a single-digit month from a
   two-digit one once a year is also present ("07202026" is genuinely
   ambiguous read as a flat digit run). Rewrote `smartDateCommit` to
   build the ISO straight from `s.seg[0]`/`s.seg[1]`/`s.seg[2]` — the
   segments already know which digits are which as they're typed, so
   there's nothing left to guess.

Also: `.value` on these inputs is ALWAYS the pretty `MM/DD/YYYY` display,
both while typing and at rest after a commit — the real ISO date lives in
`data-last-iso` instead. First version left the raw ISO sitting in
`.value` after commit (caught live: the Reports From box showed literal
"2026-07-01" instead of "07/01/2026" once you tabbed off it) — fixed by
reformatting on commit and moving every downstream reader (`#cw-start`'s
change handler, the Reports export click handler) from `.value` to
`.dataset.lastIso`.

Verified live via precise dispatched `KeyboardEvent`s (not the browser-
automation tool's own key-press simulation, which occasionally misfires
for exact single-step assertions like this): "8" → "22" → Tab produced
`2026-08-22` with the year correctly inferred from the field's prior
value; typing the fully slashed "08/22/2026" character-by-character now
progresses cleanly (`08` → `08/2` → `08/22` → `08/22/2026`, no more
double-slash glitch) and commits to the same ISO date; a bare digit
string "08202026" (no separators at all) also committed correctly;
backspacing the Reports field down to nothing correctly cleared both
`.value` and `data-last-iso`. Confirmed Current Week and Driver Tabs
(sharing the same `#cw-start`) both show `08/20/2026` after reverting.
No console errors.

### D152 — Smart date input rolled out to every remaining date field (2026-08-20)

Nate: "can we just put the same date things in the order trackers as we
have in the reports that looks clean. same thing with the scheduler
ranges and jump to day etc. anywhere you put a date in should behave and
look like the report one you just put in." D151 only covered the actual
range fields (Reports From/To, Current Week/Driver Tabs); this pass
converts everything left: the order trackers' Ordered/Delivered columns
(all three: Bag Orders, Internal Freight, External Orders — new shared
`dateOeditCell(oid, field, isoVal, disabled)` helper, `04-views.js`),
Scheduler's jump-to-day (`#jump`), the admin per-user Scheduler view
window (`data-admin-window`), and every drawer's Ordered/Delivered field
(`fld()`'s `type:"date"` branch, `03-drawer-billing.js` — one shared
helper covers all three drawer variants at once).

Two consumer paths needed a matching fix, not just the render-side markup
swap, since different date fields save through different mechanisms:
- **Order-tracker `data-oedit` fields** save on the existing generic
  `change` listener (07-events.js), which read `e.target.value` directly
  — now checks `dataset.smartdate` first and reads `dataset.lastIso`
  instead, matching the pattern already used for `#cw-start` and the
  Reports click handler.
- **Admin view-window** (read on Save-button click) and **`#jump`**
  (read on Go-button click) — same one-line swap from `.value` to
  `.dataset.lastIso`, no listener involved either way.

**Drawer `[data-of]` fields save on `blur`, not `change` — and that
broke in an interesting way, caught only by actually checking Postgres,
not just the on-screen display.** `smartDateCommit()` already dispatched
a synthetic `change` event (matches how `#cw-start`/`data-oedit` expect
to hear about a finished edit), but nothing dispatched `blur`. A
Tab-triggered commit runs entirely inside a `keydown` handler — a
*dispatched* keydown event never triggers the browser's native focus
traversal the way a real keystroke does, so no real `blur` ever followed
it, and the drawer's blur-driven save silently never ran. Verified live
end-to-end (not just visually): typed a delivery date into a real order's
drawer, watched `.value` update to "08/14/2026" correctly on screen, then
checked Postgres directly — `delivered_at` was still null, and there was
no `/api/order/update` call in the network log at all. Fixed by having
`smartDateCommit()` also dispatch a synthetic `blur`.

That first fix then broke IN A DIFFERENT WAY that only showed up by
re-testing the exact same live scenario again: the pre-edit tracking
fields (`data-undo-prev`/`data-undo-prev-iso`, captured on focus so the
blur handler can tell "did anything actually change") were being synced
to the NEW value *before* dispatching the synthetic events — so by the
time the blur listener ran, it compared the new value against itself and
saw no change, and skipped the save it was supposed to make. Fixed by
reordering: dispatch first (the listener reads the still-stale, correct
"previous" markers while `dispatchEvent` is synchronously running it),
sync the markers only after — so a genuine SECOND blur later (the real
one the browser fires once focus actually leaves, moments after the
synthetic one) correctly sees no change and no-ops instead of firing a
redundant duplicate save.

Verified live, end-to-end, against Postgres directly each time (not just
the on-screen value) after both fixes: order-tracker Ordered/Delivered
cells across all three trackers show `MM/DD/YYYY`; a drawer delivery date
typed as "8 Tab 14 Tab" now genuinely lands in `orders.delivered_at` as
`2026-08-14`, confirmed via direct SQL query, with exactly one
`/api/order/update` call in the network log (no duplicate). Reverted
every test edit back to its original value afterward — some of this
testing landed on real order rows, not scratch data. No console errors.

### D153 — Order-tracker status pills were overflowing their fixed 64×20 box (2026-08-20)

Nate: "the status indicators in the order trackers are still bleeding
over the pills if you zoom out." Measured directly (not guessed): the
longer status words — "Scheduled"/"Delivered"/"Cancelled" — need ~66px
of natural width at 9px mono font with the pill's `letter-spacing:.06em`,
but the fixed pill box (D100: "every status/action is exactly 64×20,"
a deliberate hard constraint) only has ~54px of content room inside its
padding and border. That's a real, pre-existing overflow at 100% zoom
too — just marginal enough (a couple px) to go unnoticed there; the
app's own `zoom` CSS property scales the whole subtree together, so the
SAME proportional overflow persists at any zoom level, but at 50%/75%
it wraps the text onto a second line that has nowhere to go but bleed
out of the pill's now much-smaller box, which is what actually reads as
"bleeding" — an already-present bug made visually obvious by scale, not
introduced by scale.

Left the 64×20 box exactly as-is (that dimension is Nate's own explicit
rule, D100) and fixed the TEXT to fit it instead: `.stage-actions>.pill`
drops to 8px font / `.03em` letter-spacing (still fully legible, verified
at 200% zoom), and the box itself gained `max-width`/`max-height` +
`flex-shrink:0` so flex sizing can no longer force it to grow past
64×20 regardless of content length, as a hard backstop on top of the
text fix. `overflow:hidden` added too, so even a future longer status
word clips instead of visually breaking the row.

Verified live at 50%, 75%, and 200% zoom via both `getBoundingClientRect()`
(confirms the box's actual rendered size never exceeds 64×20-at-that-
zoom) and a screenshot at 200% (confirms "SCHEDULED"/"DELIVERED" read
cleanly, not just technically non-overflowing). No console errors.

### D154 — Sync mileage/delivery dates moved to the Orders sub-tab bar (2026-08-20)

Nate: "i think sync delivery dates and sync mileage should be tool bar
level functions cause they are app wide across all three types of
orders. mileage only effects internal stuff, yes, but delivery dates is
all of them. thats the only way the app knows to make the 'delivered'
status is if it reads a load chip in the past and that function runs."
Checked `api_sync_delivery_dates` first rather than assuming — it
already covers every order kind server-side (D34: "there's no reason an
external order's delivered_at shouldn't sync the same way" — a straight
`update orders ... from load_orders/loads`, no `kind` filter at all).
The actual gap was purely where the BUTTON lived: Bag Orders had both
Sync mileage and Sync delivery dates, Internal Freight had only Sync
mileage, and **External Orders had neither** — meaning an admin working
only External Orders had no way to trigger the sync that sets its own
`delivered_at` at all, exactly the gap Nate described.

Moved both buttons out of each tracker's own page-level toolbar and onto
the `#subs` bar (the persistent sub-tab row — Bag Orders / Internal
Freight / External Orders — that's visible no matter which one is
selected), gated to `SEC === "orders"` so they don't show up on
unrelated sections. Same element ids (`#motive-sync`/`#sync-btn`), so
the existing click handlers needed no changes at all — this was purely a
render-location move, not new plumbing.

Verified live: both buttons now show on all three Orders sub-tabs,
including External Orders where neither existed before; clicked "Sync
delivery dates" from External Orders specifically — toast confirmed
"Synced 5 delivery date(s)", one clean `/api/sync-delivery-dates` call in
the network log. This one wasn't test data to revert — it's the real
sync doing its real job. No console errors.

### D155 — "Full data dump" is now "Export entire app": every order column, not just the money-path ones (2026-08-20)

Nate: "the full data dump report two things 1 the button to export needs
to just say export csv like the rest of them, and instead of calling it
full data dump call it export entire app and make it export all data in
every single section like literally all data the app has in a massive
csv... so i would use it to sort by pivot tables in excel to do
analysis... i would need literally every piece of info exported all the
loads all of it." Renamed the card ("Export entire app") and button
("Export CSV," matching every other report card instead of its own
"Export full data CSV") — one-line changes.

For "literally every piece of info": kept the existing grain (one row
per order, its most recent load joined in — the natural pivot-table row
unit; mashing unrelated master-data tables like `categories`/
`grid_columns` into the same row wouldn't pivot meaningfully) but
roughly tripled the column count on `_DUMP_SQL` (`app/server.py`) with
everything that was missing: `notes` (Load Info) and `driver_note`,
`billed_at`/`tarp`/`route_mode`/`motive_miles`/`miles_adjusted`, the
load's own `status`/`slot`/`pushed_at`, carrier info (`is_carrier`/
carrier name/cost), full customer AND broker contact details (phone, AP
email, manager, Rexius customer #, not just the name), full pickup/
delivery addresses (street, state, zip, phone — was city-only), the
internal customer's own location detail (forklift, timing window,
standard miles, city/state), driver color, and a per-order document
count split by type (rate con / POD / invoice) via a new lateral
subquery. `_csv()` derives the header row from whatever columns the
query returns, so no separate header-list needed updating.

Verified live: restarted the server (Python change), clicked Export CSV
on the renamed card — `GET /api/report/dump` returned 200 with 159 rows
and a ~70-column header (up from ~25). Spot-checked the raw CSV directly
(not just that it didn't error): an internal order's row carries the
correct customer location detail (forklift/timing window/standard
miles), an external order's row carries broker + full pickup/delivery
address detail. No console errors.

### D156 — Sub-tab bar height unified across sections (2026-08-20)

Nate: "i also want you to make the sub-tab bar to be universially the same
size across the app and i believe it should be the size it is in the
database section." Measured both live: Orders' `#subs` rendered at
34.2px, Database's at 35.75px, despite sharing the exact same `.subs`/
`.sub-tab` markup and CSS. Root cause: `.subs` is a flex row with the
browser default `align-items: stretch`, and Database's row also contains
the "+" add-sheet/add-database buttons (`.sub-tab.addsheet`, font-size
15px + fatter padding) — that taller sibling stretched the whole row,
and every plain `.sub-tab` in it, to match. Orders' row has no such
sibling, so it rendered at the shorter natural height.

Fix (`app/web/app.css`): gave `.subs` an explicit `height:36px` +
`align-items:center` (was implicit/stretch), and `.sub-tab` an explicit
`height:100%;box-sizing:border-box` (was implicit content-box height from
padding+font alone). Now every section's bar is pinned to the same 36px
regardless of what its tallest child would otherwise want, and the
oversized addsheet button just centers within that fixed row instead of
setting it.

Verified live: measured `#subs`/`.sub-tab` `getBoundingClientRect().height`
across Orders/Database/Dispatch/Billing/Reports — all render at 36px now
(35px per individual tab, same everywhere). Screenshotted Database and
Orders (with its Sync mileage/Sync delivery dates buttons, D154) — nothing
clipped or misaligned.

### D157 — Bag Orders: order # is type-overable, bulk-add takes a starting number, grid stays sorted live (2026-08-20)

Nate: "i think in the bag order tracker we make order numbers type
overable like they are in the external, but we keep the add orders
function button and change it to like let me add orders in bulk starting
at a specific number, and the page should auto sort by the order number
so its always sorted and live updated as i edit order numbers. so this
way i can bulk import a bunch of orders but i can also handle the off
season better by typing in the orders manually during that time cause
its functionally better for the off season in particular to be type
over." This is a deliberate loosening of the old "internal order numbers
are never hand-typed" rule — CLAUDE.md's domain notes updated to match.

**Type-over.** The Order # cell (`app/web/js/04-views.js`, `vInternal()`)
was plain read-only text; changed to the same `data-oedit`/
`data-field="solomon_order_no"` input External Orders already uses,
disabled when the row is cancelled (matching PAL/dates/notes' existing
`dead` guard). Saves through the existing generic `data-oedit` change
handler in `07-events.js` — no server allowlist change needed, since
`solomon_order_no` was already writable through `/api/order/update` for
external orders.

**Bulk-add takes a starting number.** `bulkInternalModal()`
(`app/web/js/06-modals-grids.js`) gained a "Starting #" field between
Year and Count, prefilled via a new `nextInternalOrderStart(code)`
helper (`01-core.js`) that scans the in-memory `orders()` for the
current max under that MMYY prefix — same default the server used to
compute on its own — but it's a plain editable input, so Nate can
override it to start anywhere (off-season manual entry, importing a
range that doesn't continue from the last block). `api_add_internal_order`
(`app/server.py`) now takes an optional `start`; when present it's used
verbatim instead of querying for the current max. The single quick-add
"+ Add one" button doesn't send `start`, so it keeps the old
always-continue-from-max behavior unchanged.

**Live sort, without breaking tab-through.** The grid was already sorted
by `solomon_order_no` on every `render()` — the gap was that editing a
field via `data-oedit` deliberately does NOT call `render()` (D84: a full
rebuild on blur destroys the very input you just tabbed into). A naive
fix (re-render after every order-# edit) would reintroduce exactly that
bug for the field immediately to the right (PAL). Fixed instead with
`resortInternalTrackerRow(oid)`: on a `solomon_order_no` edit, if the
row still belongs in the currently-viewed month/year group, move its
existing `<tr>` DOM node directly to its new sorted position
(`tbody.insertBefore`/`appendChild`) instead of rebuilding the table —
moving an already-attached node doesn't blur whatever's focused inside
it. If the new number parses into a *different* month/year (rare —
usually a typo), lightweight repositioning isn't possible since the row
may need to leave the visible group entirely, so it falls back to a full
`render()` in that case only.

Verified live: typed a new number into a reserved blank row's cell via a
dispatched `change` event — confirmed via direct `psql` query that
`orders.solomon_order_no` actually updated (not just the DOM), and the
row's `<tr>` moved to its correct sorted position in the table without a
page reload. Ran the bulk-add modal with a deliberately arbitrary
starting number (500, count 2) — got `07-0826-0500`/`07-0826-0501`
inserted and correctly sorted to the bottom; confirmed via `psql`, then
deleted the test rows. Reloaded fresh afterward and confirmed the tracker
still renders in correct sorted order end to end.

### D158 — Internal Freight: "+ Add order" now bulk-creates, "+ Add one" moved to the bottom (2026-08-20)

Nate: "can we change the internal freight thing from add transfer to add
order and also let me do the plus one at the bottom and add more than one
at a time with the button like insert 10 or 12 or whatever thats how the
button should behave, and then a a single one at the bottom like the bag
order one." Brings Internal Freight's add-flow in line with Bag Orders'
existing two-button pattern (D51/D157): a top bulk button and a bottom
one-at-a-time button, instead of a single button that always created and
opened exactly one row.

The top toolbar button was renamed "+ Add transfer" → "+ Add order"
(`id="xfer-bulk"`, `vInternalFreight()` in `app/web/js/04-views.js`) and now
opens a small new modal, `bulkTransferModal()` (`06-modals-grids.js`) — just
a "How many orders" count, since transfers have no number to reserve
(never Solomon-numbered, never invoiced, D127) unlike Bag Orders' fuller
month/year/start modal. A new bottom button, `id="xfer-add"` ("+ Add one"),
keeps the old single-add-and-open-its-drawer behavior.

Server (`api_add_transfer_order`, `app/server.py`) gained an optional
`count` (default 1, clamped to 500 like every other bulk-create in this
app) and now always returns `{created, orders}` instead of a bare row, so
both call sites share one endpoint: the bottom quick-add reads
`r.orders[0]` and opens its drawer; the bulk modal just reads `r.created`
for the toast. Updated the two other places that still referenced the old
`#new-transfer` id (the click-delegator's id allowlist in `07-events.js`
and `applyEditLockUI`'s locked-button list in `05-settings-nav-search.js`)
to the new `#xfer-add`/`#xfer-bulk` ids — a locked (view-only) user would
otherwise have kept a live, un-disabled add button.

Verified live: renamed button confirmed on screen; bulk-added 3 via the
modal (toast "3 orders added", row count 3→6); quick-added 1 more via the
bottom button (opened its drawer immediately, toast "New transfer — fill
it in", row count 6→7); deleted all 4 test rows by `created_at` (kept the
2 pre-existing blank rows) and reloaded fresh — tracker back to its
original 5 rows.

### D159 — Order trackers: numbered-gutter multi-select replaces per-row and drawer Cancel/Delete (2026-08-20)

Nate: "i also think i need to be able to delete more than one order at a
time, or cancel more than one, so we need a way to be able to select
orders. and do that. i dont want to create new ui so im wondering what
you suggest." Recommended reusing the Database grids' existing numbered-
gutter row selector (D50/D94: click a row number to select, Shift for a
range, ⌘/Ctrl to toggle one, header cell selects/clears all) instead of
inventing a new selection mechanism — same interaction Nate already knows
from Bagger Customers etc., just applied to the three order trackers
(Bag Orders "int", Internal Freight "xfer", External Orders "ext" — each
its own `ROWSEL` key). He then asked to remove the now-redundant per-row
Cancel/Delete buttons and the drawer's own Cancel button, "since i can
delete or cancel by selecting in the order tracker."

**Selection engine reused as-is.** `handleRowSel`/`paintRowSel`/the
`data-selall` header handler (07-events.js, 06-modals-grids.js) are
already grid-key-generic — zero changes needed. Added a tracker-specific
gutter without the Database version's drag-reorder grip
(`trackerSelTh`/`trackerSelTd`, 06-modals-grids.js) since trackers have
their own real sort (order number or date), not a manual
`grid_row_orders` a drag would write to. `paintRowSel` extended to also
repaint two new bulk-action buttons per grid
(`data-orderdelrows`/`data-ordercancelrows`) alongside Database's existing
`data-delrows`, via `trackerBulkButtonsHtml(grid)`.

**Row-click-to-open conflict (D43).** The gutter `<td data-rowsel>` sits
inside the same `<tr data-roworder>` the whole-row-click-opens-drawer
handler already claims; had to add `[data-rowsel]` to that handler's
exclusion list (07-events.js) or every gutter click would open the drawer
instead of selecting.

**Bulk actions route through the real guarded order endpoints**, not a
generic row delete — `data-orderdelrows`/`data-ordercancelrows` handlers
(07-events.js) filter the selection through the exact same eligibility
checks the old per-row buttons used (`canCancelOrder`/`canDeleteOrder`),
silently skipping ineligible orders (delivered/billed) rather than
erroring, and say so in the confirm dialog ("1 selected order is locked
and will be skipped"). Confirmed live this actually matters: selected 3
Bag Orders rows including one delivered one — dialog correctly read
"Permanently delete 2 orders?... (1 selected order is locked and will be
skipped.)"

**Removed as redundant:** the per-row Cancel/Delete buttons
(`destructiveOrderControls`, the far-right Actions column — the column
itself is gone, tables narrowed accordingly) and the drawer's own Cancel
button (`schedBar`'s cancel span). `contextualDelete` (01-core.js, the
rebindable Delete-key shortcut, D97) updated to trigger
`[data-orderdelrows]` the same way it already falls back to Database's
`[data-delrows]`, so keyboard Delete still works with a tracker selection
active. Restore stays exactly where it was (`stageControls`, a positive
workflow action, never removed).

**A real bug caught mid-verification:** a test script meant to ctrl-click
two just-created disposable rows instead grabbed the last two rows of the
currently displayed (unfiltered by month) Bag Orders group, which turned
out to be `07-1026-0010`/`0011` — real rows, not the intended test data —
and deleted them for real. Caught immediately via the D131 audit log
(`audit_changes.before_data` had the full pre-delete row), restored both
verbatim from that snapshot, confirmed via `psql`. Investigating this also
surfaced 36 additional blank placeholder rows scattered across Jan/Sep/Oct
2026 in the real Bag Orders tracker, all timestamped inside earlier
testing windows this session — very likely leftover test data never
cleaned up, flagged to Nate for confirmation before touching further
(destructive, and the timestamps are circumstantial, not certain proof of
origin).

### D160 — Database grid row height increased so the selection ring stops overlapping colored cells (2026-08-20)

Nate: asked me to open Bagger Customers, select a row, and screenshot —
"you can see when you select one that the status indicator ui is off
slightly like its clipping the selection so we will need to fix that. im
okay with expanding row height to accommodate cause i dont want the
statuses to be smaller." Confirmed visually (zoomed screenshot): the Time
Window pill (a `<select>` rendered edge-to-edge in a padding:0 `.cell`
wrapper, `designationSelect`) filled the full 26px row height with ~1px
to spare, so the row-selection ring's inset box-shadow border (`tr.rowsel
td::after`, D94) landed directly across the pill's own top/bottom 2px,
reading as the pill getting cut off the instant its row was selected.
Growing the pill in lockstep with a taller row wouldn't have fixed
anything — an edge-to-edge fill has zero margin regardless of absolute
size, so the ring would still sit exactly on its border either way; the
actual fix needed real clearance between the pill and the cell edge.

Fix (`app/web/app.css`): `table.data td` height 26→32px (Database grids
only — order-tracker tables share the `.data` class but already carry
their own more-specific 34px override, unaffected). The two "fills its
cell edge-to-edge" patterns — a designation/managed-dropdown `<select>`
and a Fleet/generic color-chip `<button>`, both always rendered inside a
`<div class="cell" style="padding:0">` — are now pinned to their original
26px height and centered via `display:flex;align-items:center` on that
wrapper, instead of stretching to fill the new 32px row. Net effect: the
indicator itself is the exact same size as before (never shrunk, per
Nate's constraint), the row is taller, and the extra space is genuine
clearance the selection ring's border sits inside instead of on top of.
Scoped with `table.data:not(.order-tracker)` so it can't reach External
Orders' broker/customer type-ahead combo, which also happens to sit in a
`style="padding:0"` wrapper for an unrelated reason (full-width input) and
would have been wrongly turned into a flex row otherwise.

Verified live at 3x zoom: unselected rows' pill height and the selected
row's pill height now measure identical, with a clean band of the
selection tint above and below instead of the border cutting across it.
Confirmed the order-tracker broker/customer combo box is visually
unchanged.

### D161 — CSV exports get friendly headers instead of raw SQL column names (2026-08-20)

Nate: "i think we should code the variables to match teh headers idk if
they do in the app but if they did it would make the export easier to
read and more consistent." Confirmed: `_csv()` (`app/server.py`) was using
`rows[0].keys()` — the raw SQL alias — directly as the CSV header row, so
the "Export entire app" dump showed `solomon_order_no`, `pivot_department`,
`customer_rexius_no`, `iso_year`, etc. instead of anything resembling the
app's own labels. Confirmed with him: build the map for all 6 user-facing
reports (dump/freight/mileage/customers/brokers/fleet), and "if it has a
slash use an underscore" for any header that would otherwise read like one
(`po_number` → "PU_PO", matching External Orders' "PU/PO" column;
`customer_or_dept` → "Customer_Department") — a literal slash in a header
can read as a formula/path separator once the CSV lands in Excel.

Added `_REPORT_LABELS`, one raw-column → friendly-label dict per report,
reusing the app's own grid/drawer wording wherever a column has an
on-screen equivalent ("Order #", "PAL", "Load Info", "Transfer $", "Time
Window", ...) and a plain hand-written label for the ~15 dump-only
columns with no grid equivalent ("ISO Year", "Pivot Department", "Orders
On Load", ...). `_csv(rows, labels=None)` now maps `cols` through
`labels.get(c, c)` for the header row only — row data is untouched, still
keyed by the real column name. `build_report()` passes
`_REPORT_LABELS.get(name)` at both `_csv()` call sites (the direct
`PARAM_SQL` branch and the generic `REPORTS` branch), so the "everything"
combined report gets translated headers too, automatically.

Verified live: restarted the server (Python change), curled all 6
`/api/report/<name>` endpoints directly and parsed each CSV's header row.
Dump: exactly 71 columns, no raw snake_case leftovers anywhere in the
list (a missing/mistyped map entry would have shown up immediately as a
plain column name — the map was hand-transcribed from the SQL, so this
was the real check, not just eyeballing the dict). Freight/mileage/
customers/brokers/fleet: all 4-14 columns each translated correctly too.

### D162 — Scheduler toolbar gets its own "Update Google schedule" button (2026-08-20)

Nate: "i'd like the update google schedule button to also be on the
scheduler tab then we can kick the go to a date and today tab over to the
left to make room for it. it should be the only accent colored button in
that row." The push button (`id="push-driver-tabs"`, D98/D139) already
existed on Current Week and Driver Tabs, sharing one handler
(`07-events.js`) that reads only the module-level `CW_START`/`CW_DAYS`
rolling window — no dependency on any Current-Week-only DOM element — so
dropping the exact same button onto `vScheduler()`'s toolbar
(`04-views.js`) needed no new wiring, it was already generic.

Reordered the toolbar: the date-jump input, Go, and Today moved to sit
right after the `<h2>` (left side, before the flex spacer) instead of
being pushed flush right by it; "Update Google schedule" now takes that
right-aligned spot. Today lost its `.pri` (accent) class — Update Google
schedule is the only accent-colored button in the row now, per Nate's
ask.

Verified live: clicked Update Google schedule from the Scheduler tab —
got the real confirm dialog with the actual current push window (Thu Aug
20 – Wed Aug 26, 5 days), same dry-run preview Current Week produces;
cancelled without confirming. Clicked Today — jumped and scrolled
correctly to 08/20/2026, confirming the reorder didn't break the existing
handlers.

### D163 — Server launches with Google Sheets + local auth wired up by default (2026-08-20)

Nate: "i want it to launch with it wired up please, i also want it to
launch with the login screen as well til ur told otherwise." Earlier the
same session, I'd wired the real Sheets push by hand-passing
`DEPT12_SHEETS=google DEPT12_SHEETS_CREDS=… DEPT12_SHEETS_ID=15f12…` as a
one-off shell prefix when launching `python3 app/server.py` — real for
that process, but gone on the next plain restart. Nate wants both that
and local auth (`DEPT12_LOCAL_AUTH_ENABLED`) on by default going forward,
without having to remember a special launch incantation every time.

Added a hand-rolled `.env` loader (`_load_dotenv()`, `app/server.py`,
runs before any `os.environ.get()` call) — no `python-dotenv` dependency
(D24): KEY=VALUE per line, blank/`#` lines skipped, a real shell-exported
var always wins over the file (same precedence python-dotenv uses). `.env`
itself (repo root, already gitignored per the existing `.env.example`
convention) now carries `DEPT12_SHEETS`/`DEPT12_SHEETS_CREDS`/
`DEPT12_SHEETS_ID` (pointed at the real service-account key,
`secrets/dept-12-dash-b99870c4667e.json`, and the **mirror** sheet ID —
never the dispatcher's working sheet) plus `DEPT12_LOCAL_AUTH_ENABLED=true`.

Verified live: killed the server and relaunched with the plain
`python3 app/server.py` — no manual env vars at all — and got the local
sign-in screen immediately (confirming `.env` loaded) and a working Sheets
push later in the same session (confirming the Sheets creds loaded too).

### D164 — Scheduler/Current Week/Driver Tabs didn't reflect a push until some unrelated reload (2026-08-20)

Nate: "when i push to the sheets the scheduler needs to refresh the
colors and borders and whatever so i can see what was pushed i tested an
external chip ran the function and there was no update." Root cause: the
confirmed `push-driver-tabs` click handler (`07-events.js`) called the
write API and just toasted success — it never called `reload()`. The push
sets `loads.pushed_at` server-side, which is exactly the signal
`pushColorFor` (D85 Phase 2) uses to switch an external chip from its
pre-push fmt/category color to the truck's driver-color fill — but the
client's in-memory `DB.loads` still held the stale pre-push row until
something else happened to trigger a `reload()` (a section switch, an
unrelated edit). One line: wrapped the toast in
`return reload().then(function () { toast(...) })` inside the confirmed
branch.

Verified live as part of D165's push test below — after a real confirmed
push, the Scheduler/Current Week views updated their pushed loads'
appearance without any separate manual reload.

### D165 — Free-text Scheduler cells (no real load) were silently dropped from the Google Sheets push (2026-08-20)

Nate, across three messages narrowing down the same bug: "me writing text
in the scheduler the text is not getting pushed to the google sheet,"
then correcting himself once he found it — "its getting written to the
driver tab as a note rather than a load chip and thats wrong." Traced by
reading `_driver_week_payload` (`app/server.py`) start to finish: it only
ever queried `loads`, never `schedule_notes` — so a Scheduler cell holding
free text with no real load underneath (README: "an ad-hoc job, a shop
day, a reminder" — the same "cells hold either a load or free text"
behavior as the old sheet) produced a fully blank pushed row, `chip` and
`notes` both empty. Confirmed via the audit log this was exactly what
Nate had just done (`schedule_notes` INSERT, body "test", no matching
`loads` row at that truck/date/slot) — ruled out the other candidate
explanation (typing directly over an *existing* chip, which deliberately
sets `driver_note` per D130/D140 and is expected to land in the notes
column, not the chip) by checking the actual cell had no load at all.

Fix: query `schedule_notes` for the push's date range alongside `loads`,
keyed the same way (`truck_id`, `scheduled_date`, `slot`); when a slot has
no real load, fall back to its note's `body` as `row["chip"]` (not
`row["notes"]` — this text IS the cell's content, not an annotation on an
order) with the same fmt.fill-over-category-color precedence the
Scheduler UI itself already uses (`effFill`, `04-views.js`). Applies to
both driver tabs and the compact Current Week rows — they share this one
function.

Verified end-to-end against the real mirror sheet, not just the dry-run
payload: confirmed a real push, then read the live Google Sheet directly
(`GoogleSheetsSync.read_range`, same creds D163 wired up) — `'JON 33 BT'!
B2:D5` showed `test` in column C (chip) with column D (notes) blank,
exactly the intended shape. Also incidentally verified D164's reload fix
in the same pass: the Scheduler/Current Week views reflected the push
without a manual page reload.

### D166 — Change-history confirmation only fires after a 4-day grace period, not on every past-day edit (2026-08-21)

Nate: "can we make the change history warning popup only appear after 4 days
have passed? just cause shit happens ... i dont want to confirm an alert
every time i truck breaks down and i cant change the schedule til the
following day." The old rule (`08-undo.js`'s `historicalMoveMessage`,
`06-modals-grids.js`'s `deleteSelection`) compared a load's date straight
against `TODAY` — any edit touching yesterday or earlier prompted "Change
history," even for the routine one-day-late correction Nate actually does
all the time.

Fix: `histCutoff()` (`08-undo.js`) computes `TODAY` minus `HIST_GRACE_DAYS`
(4) instead of using `TODAY` directly; both call sites compare against that
cutoff. A move/clear touching a date within the last 4 days no longer
prompts at all; only a genuinely stale edit (5+ days back) still does. Same
single source of truth as before — no new call sites needed, just what
`TODAY` meant in the existing comparisons.

Verified via a Node-side reproduction of the exact extracted logic: 1 day
back → no prompt, exactly 4 days back → no prompt (inclusive), 5 days back
→ prompts with the original message. The Scheduler's other past-day
behavior (row add/remove structure locked past days, D100) is untouched —
that's a hard block, not this confirmation, and wasn't part of the ask.

### D167 — Help & FAQ moved off the Settings tab bar into the profile menu, as a popup (2026-08-21)

Nate: "i also want help and FAQ turned into a menu option on the profile
icon dropdown menu, then u can rewrite that and only make it pop up there."
`settingsHelp()`'s content (`05-settings-nav-search.js`) is unchanged —
still the same FAQ cards — but it's no longer a `SETTINGS_SUBS` tab. A new
`helpFaqModal()` (`06-modals-grids.js`) wraps that same content in a wide
`openModal()` popup; the profile dropdown (`01-core.js`'s `openProfileMenu`)
gained a `Help & FAQ` item between Account and Sign out, wired in
`07-events.js` (`data-profile="help"`). Verified live: click the avatar →
Help & FAQ → same FAQ content renders in a popup; Settings' sub-tab bar no
longer shows it.

### D168 — Time card calculator takes Help & FAQ's old spot on the Settings tab bar (2026-08-21)

Nate: "in its place on the settings bar i need a military time calculator
like a time card calc basically, i input two times in regular time and it
kicks out the military time equivalents for both times and then the total
hours." New `settingsTimeCalc()` (`05-settings-nav-search.js`), reached at
`SETTINGS_SUBS` key `timecalc` (label "Time Calc") — the same slot `help`
used to occupy. Two `<input type="time">` fields; deliberately no manual
time-parsing — a native time input's `.value` is already 24-hour `HH:MM`,
so "regular time in, military time out" is just stripping the colon
(`militaryLabel`). Total hours handles an overnight span (end time earlier
than start) by adding 24h and flags it with a note, shown both as `Xh Ym`
and decimal hours (payroll-friendly, e.g. "8.75 hrs"). Live-updates on
input via a `#tc-start,#tc-end` listener (`07-events.js`) calling
`renderTimeCalc()` — no submit button. Verified live: 07:30→16:15 gave
0730/1615/8h 45m (8.75 hrs); 22:00→06:00 gave 2200/0600/8h 0m plus the
overnight note.

### D169 — History retention capped at 14 days, purged by a background thread (2026-08-21)

Nate, closing the open question from D133/D135: "history shuts off after 14
days." This is a real delete, not just hiding old entries from the panel —
`_history_purge_old()` (`app/server.py`) removes `audit_events`/
`audit_changes` rows with `occurred_at` older than `HISTORY_RETENTION_DAYS`
(14). Deletes `audit_changes` first (`event_id` is `ON DELETE RESTRICT`),
then `audit_events`; a revert-chain link into a purged root just goes null
(`ON DELETE SET NULL` on `reverts_event_id`/`reverted_by_event_id`/
`superseded_by_event_id`) rather than blocking anything. Kept distinct from
D131's "never update/delete audit evidence" rule in both code comment and
`CLAUDE.md` — that rule is about not rewriting evidence during a revert, not
about how long evidence is kept at all.

Runs as a daemon thread (`_history_purge_loop`, started at the bottom of
`server.py` alongside `ThreadingHTTPServer(...).serve_forever()`) — sweeps
immediately on every server start, then every 24h for as long as the
process stays up. No new dependency (D24) — reuses the existing `threading`
import and the same thread-local `db()`/`q()` every request handler uses.

Verified live: inserted a fake `audit_events` row backdated 20 days plus a
matching `audit_changes` row, and a second one backdated 2 days, via direct
`psql`. Restarted the server. Confirmed via `psql` after: the 20-day row and
its `audit_changes` child were gone, the 2-day row survived untouched.

### D170 — Internal freight rate: a persisted $/mile + minimum, collapsible on the Orders toolbar (2026-08-21)

Nate: "why dont we have an adjustable rate thing in the bag orders tool bar
that changes the rate calc... only changes what it calculates that run not
what it was previously. i also need a minimum toggle, so if its under a
certain amount of mileage it charges the minimum... if its set to zero it
will input the mile rate" — then a run of quick corrections: persist it
(next to Sync mileage, not a separate spot), auto-run the calc when Sync
mileage runs (which made the manual "Calc freight $" button redundant —
"i dont want the calc freight button to exist," removed), shrink the
controls to match the sync buttons' height, label it "Internal rate,"
empty placeholders instead of a literal 0, and collapse the whole thing
behind a bare arrow, not a button pill ("i just want the arrow") — pointing
left when closed, right when open, Nate's explicit direction rather than
the usual disclosure-triangle convention.

**Storage.** New table `internal_freight_rate` (migration
`20260821000001_internal_freight_rate.sql`) — one settings row, `rate_per_
mile` + `minimum_charge`, always updated in place. Bootstrap-loaded as
`DB.internal_freight_rate`. Needed its own explicit `dept12_history_capture`
trigger — D131's install loop (`20260819000007_admin_history.sql`) only ran
once, over tables that existed at that migration's apply time, so any table
created after it needs the trigger added by hand (this is already called
out as a trap in `CLAUDE.md`).

**Formula.** `charge = greatest(miles * rate, minimum)` — no separate
mileage-cutoff field. A short haul's `miles * rate` naturally falls under
the minimum and the floor wins; `minimum = 0` means the floor never binds,
so it's always plain `miles * rate`, exactly matching Nate's own
description without a redundant extra setting.

**Scope.** Applies to both Bag Orders (`kind='internal'`) and Internal
Freight transfers (`is_transfer`) — the same pairing Motive sync already
uses (D127/D48) for the identical reason: both use the exact same `miles`/
`internal_freight_amount` columns. Not asked directly since the precedent
was already strong and reversible (one SQL filter), flagged here in case
Nate wants it Bag-Orders-only instead.

**Never overwrites a priced order.** `api_internal_freight_rate_calculate`
(`app/server.py`) only updates orders where `internal_freight_amount is
null` — an order already priced, by hand or by an earlier run under a
different rate, is untouched. This is what "only changes what it
calculates that run not what it was previously" means in practice: each
run only ever fills in the *currently* blank rows.

**Only runs via Sync mileage — no standalone trigger.** The `motive-sync`
click handler (`07-events.js`) chains straight into `internal-freight-rate/
calculate` after a successful sync, but only when `DB.internal_freight_rate.
rate_per_mile` is set — skipped quietly (not an error) when no rate is
configured yet, and never fires at all if the sync itself fails (verified
live: with Motive not configured in this dev environment, the sync's own
error toast fired and the network log showed no `/calculate` call
following it). `/api/internal-freight-rate/calculate` still exists as its
own endpoint (that's what the sync handler calls) — there's just no UI
control that calls it directly anymore.

**Permissions.** Both new routes (`/api/internal-freight-rate`, `/api/
internal-freight-rate/calculate`) are deliberately left out of
`API_PERMISSIONS` — same fail-closed, admin-only-by-omission precedent as
`/api/motive/sync-miles` and `/api/sync-delivery-dates` (a global setting +
a bulk cross-order mutation, not per-user data).

**UI.** Collapsed by default behind a bare `◂`/`▸` arrow (`.ifr-arrow` — no
border/background/padding-as-button, just a small clickable glyph;
`IFR_OPEN`, persisted per-device in `localStorage` like every other toolbar
UI preference — `WEEKEND_ON`, `PREFS`, etc.); expands to an "Internal rate
$/mi" label + the rate/min inputs, no button at all since there's nothing
left to manually trigger. `.rate-inp` sized to exactly match `.btn.sm`
(padding `2px 7px`, font-size `10.5px`) — verified live via
`getBoundingClientRect()`, both compute to 21.2px tall. Empty value +
`placeholder="0.00"` when unset, rather than a literal `0` sitting in the
field.

**Verified live end-to-end (before the manual Calc button was cut):** set
rate 2.75 / min 150 via the UI, confirmed in Postgres the row persisted
(survived a full server restart too); backed two orders with test miles
(30 and 120) via direct SQL, ran the calculate endpoint directly, got
"Filled 2 internal freight charge(s)," confirmed in Postgres: 30mi → $150
(floor won), 120mi → $330 (2.75×120), and a third already-priced order
(40.5mi, pre-existing $142.50 from before the rate was set) was untouched
by the run. Test data reverted after.

### D171 — One toolbar contract across every section (2026-08-21)

Nate, asked to build a UI style/redline doc, then to apply it: "make sure
the design is unified across the dashboard like page to page if buttons
persist they are in the same spots where it makes sense, thats the overall
polish im looking for." Checked the real code rather than guessing where it
drifted — three sections had each invented their own toolbar convention
independently in `04-views.js`, since nothing enforced a shared one:

- **Orders/Dispatch** (Scheduler, Current Week, Driver Tabs, Bag Orders,
  Internal Freight, External Orders) already agreed: title first, a
  flexible spacer, then secondary/bulk actions, then one primary action,
  rightmost.
- **Database**'s five built-in grids (`vBuiltin`) had **no title at all**
  and put the primary "+Add" button **first**, left-aligned — the opposite
  end of the bar from every other section.
- **Billing** had the title/alignment right but **no primary action** —
  three equal-weight buttons, nothing marked as the one that matters most.

Fix: one shared `toolbarHtml(title, {context, secondary, primary, plain})`
helper (`04-views.js`, right before `vScheduler`) that every `v*()` toolbar
now calls instead of hand-building its own string — the contract and the
consistency guarantee live in the same function, so a new section can't
drift the same way again. `plain` preserves the real, deliberate layout
difference between a sticky toolbar bar (Dispatch) and a borderless heading
row inside a scrolling `.pad` (Orders trackers, Database) — that distinction
is about page mechanics, not the button-order bug, so it stayed a caller
choice rather than being flattened away.

Database's title now reads `ent.name` — already the exact right string for
every grid, including "Internal Freight" for the renamed `departments`
entity (D127) — no new label mapping needed. Billing's "Mark done" becomes
the one `.btn.pri`, matching the redline doc's own call that it's the
actual conclusive action on that page.

**One nuance caught while wiring Database up:** `vBuiltin`'s sort button
already used `.btn.pri` (full green fill) to show "a custom sort is
active" — a status indicator, not a call to action. Left as `.pri` it would
have created a second primary-looking button next to the real "+Add",
violating the new contract's own point. Added `.btn.active` (`app.css`) —
outline + tint, not a fill — for exactly this "toggled on" case, and
repointed the sort button at it instead of `.pri`. Any future "this is
currently on" indicator should reach for `.active`, not `.pri`.

Verified live for every migrated section (Scheduler, Bagger Customers,
Fleet, Internal Freight/departments, Billing) — title present, one green
primary button rightmost everywhere, `.active` outline confirmed on the
sort button with a live sort applied and cleared back to default after.

The header lockup ("Dept 12 / Flatbed Trucking" next to the Rexius logo)
was floated as a possible tenth change in the same redline doc, but the
mockup was wrong — the square holds the real Rexius logo image, not an
empty box. Nate: keep the Rexius badge as-is. Declined, no code change.

### D172 — Design tokens: signal split into brand/focus/billed, plus a type/radius/elevation scale (2026-08-21)

Nate: "i want you to finish the whole thing" — the redline doc's remaining
token-level recommendations (03, 01, 02, 04, 08), applied for real.

**Signal split (redline 03).** `--signal`/`--signal-soft` renamed to
`--brand`/`--brand-soft` everywhere (the personalizable accent — primary
buttons, active nav/tab state, links, toggle-on indicators), with two new
fixed tokens carved out for the ~30 call sites that were never really about
branding: `--focus`/`--focus-soft` (a fixed slate blue, `#2F5D8C`/`#5A92C9`
dark — every selection ring, drag-target, drop-zone hover, and input focus
state, so multi-cell selection reads the same regardless of which of the
12 accent colors someone's picked) and `--billed` (a fixed plum, `#6B4FA8`/
`#9F7FCC` dark — `.pill.billed` only). `PREFS.accent` (`01-core.js`) now
writes `--brand`/`--brand-soft`, not `--signal`; the two remaining inline
JS color refs (`04-views.js`'s cell-link, `05-settings-nav-search.js`'s
profile avatar) moved to `--brand` too.

Confirmed live why this mattered, not just in theory: `--good` (delivered/
on status) and the shipped default accent are the *identical* hex,
`#3F7D3A` — before this, a Primary button and a Delivered pill were
color-identical by default. Verified via computed styles after the split:
a cell-selection ring resolves to `#5A92C9` (`--focus`, dark mode) while
`.btn.pri` resolves to `#3F7D3A` (`--brand`, Nate's actual saved accent) —
two independent tokens, confirmed not entangled.

**Type scale (redline 01) and radius scale (redline 02).** Collapsed 17 ad
hoc `font-size` values (132 declarations) into 8 named steps
(`--fs-caption` 10px through `--fs-h1` 23px) and 11 ad hoc `border-radius`
values (78 declarations) into 3 (`--r-sm` 3px / `--r-md` 6px / `--r-lg`
10px) — each step's value is whichever size already had the most call
sites in its cluster, so this is a rename + merge of what was already
there, not a new design. Done as a scripted sweep (Python, not hand-edits —
too many declarations to do reliably by hand), but **not blind**: the
redline doc itself had flagged the real risk — the order-tracker status
pill (`table.order-tracker .stage-actions>.pill`, D100) is an 8px,
letter-spacing-tuned hard fit inside a fixed 64×20 box, and a naive global
"8px → 10px" replace would have silently reintroduced the exact overflow
bug D100 fixed. That rule, plus the header lockup (`.brand-copy b`/`span`
— Nate: leave it exactly as it reads today) were excluded by line number
before the sweep ran, then verified unchanged afterward via computed
styles (`8px`, `14px`/`8.5px` respectively — untouched).

**Elevation (redline 04).** Two reusable shadow tokens, `--e1` (subtle —
the Rexius logo box's own depth) and `--e2` (floating menus/dropdowns/
popovers — `#profile-menu`, `.font-menu`, `.swpick`, `.condfmt-pop`,
`.bordmenu`, `.palette`/`.ctxmenu`, `.gs-res`). The three heavy overlay
shadows — `.modal-card`, `#drawer`, `#navmenu` — stay their own literal
declarations on purpose: each needs a different offset direction (down for
a centered modal, left for a right-sliding drawer, right for a
left-sliding nav), so one shared value can't actually serve all three.
`.loc-suggest`'s lighter shadow and `.touch-ghost`'s drag-ghost shadow were
left alone too — both are deliberately a different visual weight than the
e2 popovers, not an oversight.

**Motion (redline 08).** One shared `transition: background-color, border-
color, color, box-shadow .15s ease-out` on the toggle/hover chrome
(`.btn`, `.hbtn`, `.pill`, `.chip`, `.sub-tab`, `.section-tab`, `.swatch`,
`td.rowgut`, `.nm-item`) — deliberately *not* applied to the selection-ring
family (`td.sel`, `td.over`, `tr.rowsel`, the marquee, fill-handle, etc.),
since those repaint per-cell during a fast drag-select and an eased
transition there would make multi-cell selection feel smeared instead of
instant. `prefers-reduced-motion` already zeroed all transitions/animations
app-wide before this (unchanged) — this rule doesn't need its own guard.

Verified live end to end: logged in, walked Scheduler, the order drawer,
Bag Orders tracker, Bagger Customers, a Sort-rows modal, the profile menu,
and Settings → Appearance — every token resolves correctly
(`getComputedStyle` spot-checks matched the declared values), no visual
regressions, and both protected exceptions (tracker pill, header lockup)
confirmed still exactly their original pixel values.

**The rest of the redline, same pass:**

- **Status pills (redline 06)** — the general `.pill` (drawer status strip,
  billing doc rows, Settings "Signed in"/"Connected") became dot + tinted
  outline instead of solid fill, using the same `--good`/`--warn`/`--bad`/
  `--billed` tokens. `table.order-tracker .stage-actions>.pill` — the D100
  fixed 64×20 box — was deliberately **not** touched: a 6px dot plus its
  gap would eat back into the exact room that fix already had to claw out
  of an 8px, tighter-letter-spacing font. It keeps its original solid-fill
  look via its own explicit override block (`gap:0`, dot suppressed via
  `::before{content:none}`), so both pill styles now coexist correctly by
  context — verified live: the tracker's "Delivered" pill is unchanged
  solid green, the same order's drawer status strip shows the new dot +
  outline "DELIVERED."
- **Toolbar icons (redline 05)** — a small hand-drawn inline-SVG set
  (`NAV_ICONS`/`icon()`, `01-core.js`, currentColor so an icon follows its
  button's own state for free) on Sync mileage (sync glyph), Sync delivery
  dates (calendar glyph), and Update Google schedule (sync glyph). Caught a
  real naming collision before shipping: `11-toolbar.js` (the cell
  formatting toolbar) already had its own unrelated `var ICONS` for
  Material Symbols path data: `var` redeclares the same binding, so
  whichever file's `ICONS` assignment ran last in the concatenated `app.js`
  silently won, and every new icon rendered as an empty `<span>`. Renamed
  mine to `NAV_ICONS` to resolve it — worth remembering before adding any
  other app-wide-sounding global, this file has ~30 of them.
- **Empty states (redline 07)**, exactly the three spots the redline named,
  via one shared `emptyStateHtml(text)` helper (`01-core.js`) — not a
  general pattern applied everywhere: the Staging rail (`renderRail`,
  distinguishes "nothing staged" from "no matches for a filter"), any
  built-in or custom Database grid with zero rows (`vBuiltin`), and
  Billing's unmatched-documents queue specifically when it's at zero
  (`vBilling` — previously that whole section just didn't render, so
  "queue is empty" and "the page hasn't loaded that section" looked
  identical). Verified live: an actually-empty Staging rail and an
  actually-zero unmatched queue both show the new icon + copy.

### D173 — Tab from a Database dropdown cell was jumping the browser's native tab order instead of the grid's own (2026-08-21)

Nate: "if i go into the database section and select a dropdown and hit tab
it has two selected cells at once, i can keep tabbing and itll move down
the dropdowns... the tab thru should continue to go through the sheet not
sticking through the dropdowns... like tabbing locks it to the dropdown
cells."

**Root cause.** The grid's keydown handler (`06-modals-grids.js`) had a
blanket guard — `if (e.target.tagName === "INPUT" || e.target.tagName ===
"SELECT") return;` — meant to keep app shortcuts from hijacking a real form
field elsewhere (a modal, the search box). But Database dropdown/combo
cells (`select.cell-i`) are real, always-live `<select>` elements sitting
directly inside a normal grid `<td>`, unlike a plain text cell (which only
gets a native `<textarea>` transiently, during `startEdit()`). Once one of
those was focused, every Tab hit that guard and returned — the app's own
`move()`-based cell navigation never ran, so the **browser's native tab
order** took over. Native tab order only ever visits focusable elements, so
it skipped every plain text cell and jumped straight to the next focusable
`.cell-i` — which in a Database grid is usually another dropdown, hence
"tabbing locks it to the dropdown cells." Meanwhile the app's own `SEL`
(and its `.sel` ring) stayed frozen on the *original* cell, since nothing
ever told it to move — so after one Tab press, one cell showed the app's
selection ring and a *different* cell showed the browser's native focus
ring, both drawn with the identical `var(--focus)` outline (D172), reading
as "two selected cells."

**Fix, two parts.** (1) The keydown handler now special-cases Tab when the
focused element is an INPUT/SELECT *and* sits inside a real `td[data-key]`
— `e.preventDefault()`, blur the stray native focus, then drive the exact
same `move()` every other cell uses. Real non-grid inputs (modals, drawer
fields, search) aren't inside a `td[data-key]` and still fall through to
the original guard, untouched. (2) That only reaches cells already wired
into the generic `data-key`/`data-table`/`data-id`/`data-field` system —
Bagger Customers' "Time Window" designation dropdown (`designationSelect()`,
D72) predates that convention (added later, D144/D145 for things like
Fork/equipment) and had never been retrofitted, so it sat outside the
whole system and was still broken after part 1. Gave it the same
attributes, matching `selectFieldCell()`'s existing pattern exactly — but
gated behind a new `gridMode` parameter, since `designationSelect()` is
also reused inside the order drawer's read-only customer-info panel
(`03-drawer-billing.js:195`), which isn't a real grid at all; the generic
`mousedown` handler that sets `SEL` isn't scoped to an actual grid
ancestor, so an ungated `data-key` there would've let a drawer click paint
a stray selection ring with nothing to Tab through. The drawer call site
passes no second argument (stays plain); the grid call site
(`fieldCell()`) passes `true`.

Verified live: clicking Fork (already `data-key`-wired) then Tab now blurs
to `document.body`, exactly one `td.sel` remains, on the correct next
cell. Clicking Time Window (previously broken) then Tab now behaves
identically — one selection ring, moves to Fork. Clicking the same
designation dropdown inside an order drawer confirms its `<td>` still has
no `data-key`, so the drawer path is unaffected.

### D174 — Days shown stepper's middle square finally matches the font-size stepper (2026-08-21)

Nate: "the font size selector with the + and - and the days shown selector
is not completely identical it should be, but it isnt. there is a
different in middle square background shade... id like it to be the same
as the font one for all three. i like that ui the best."

Both already used the exact same classes (`.fb-fs`/`.fb-fs-b`/
`.fb-fs-inp`) — the divergence wasn't a second, near-duplicate component,
it was a specificity bug. `.toolbar input,.toolbar select{background:
var(--paper);...}` (a generic rule for plain toolbar inputs like the date-
jump field) has higher specificity than a bare `.fb-fs-inp{background:
none}` (one class + one element beats one class), so any `.fb-fs-inp`
sitting inside a `.toolbar` — Current Week's and Driver Tabs' "Days shown"
stepper, both — silently got an unwanted `--paper` background. The font-
size stepper lives inside `.fmtbar`, not `.toolbar`, so it never hit that
rule and looked "right" the whole time; the other two looked "wrong."
Fixed by scoping the rule to `.fb-fs .fb-fs-inp` (two classes, beats
`.toolbar input`'s one-class-one-element regardless of which container
it's in) instead of bare `.fb-fs-inp`. One CSS change fixes both "Days
shown" instances since they share the exact same markup already. Verified
live: `getComputedStyle` on `#cw-days` now returns `background-color:
rgba(0,0,0,0)`, matching the font-size stepper's transparent box exactly.

### D175 — Scheduler row height / truck-column width, customizable with a live preview (2026-08-21)

Nate: "i'd like the day size to be customizable like cell height and width
in the scheduler it doesnt have to be click and draggable but i do need
the default height slightly adjusted cause right now its cutting load
chips off. if that was a setting the user could go into the settings and
adjust and inside the settings it pops up a window so you can see what ur
editing as u click it that would be perfect. like a plus and minus for
height and width and it shows a sample day with sample load chips so u can
see what ur doing."

**Immediate fix:** default row height 72px → 84px (`.slotrow`), the actual
"chips getting cut off" complaint — a chip with a full who/meta/flags/note
stack genuinely needs more than 64px of content room (72px row minus 8px
padding). Chip height stays `row height − 8px` at any size, not just the
default, so the relationship holds after customizing too.

**Customizable via two new PREFS,** `rowHeight` (56–160px, default 84) and
`colWidth` (100–320px, default 150), same per-device `localStorage`
mechanism as accent/font/density — `applyPrefs()` (`01-core.js`) sets
`--row-h`/`--col-w` on `:root`, and `.slotrow`/`.slotrow td`/`.slotrow
.chip` (`app.css`) all read from those instead of a hardcoded `72px`/
`64px`. The three real truck-column `<th>` emitters (`vScheduler` ×2 for
the truck + outside-carrier columns, `vCurrentWeek` ×1) switched their
inline `width:150px` to `width:var(--col-w,150px)`; the two JS-computed
*table* width formulas (`88 + cols * 150`) that size the outer `<table
style="width:...">` — a separate concern from the individual `<th>`
widths, since that total has to stay in sync with them — now read
`PREFS.colWidth` instead of the literal `150`, so the table's overall
width and its columns' individual widths never drift apart at a
non-default size. Clamped via a new small `clampInt(v, lo, hi, dflt)`
helper (`01-core.js`) so a corrupted/stray `localStorage` value can't
collapse the grid to something unusable — same reasoning as every other
numeric PREFS bound in this app.

**The live preview isn't a mockup.** `schedulerSizingHtml()`
(`05-settings-nav-search.js`, new "Scheduler sizing" card in Settings →
Appearance) renders two real sample chips (one plain, one filled/colored,
each with a full who/meta/flags/note stack — deliberately the exact
content that was getting cut off) inside real `.grid`/`.slotrow`/`.cell`
markup, sized by the same `--row-h`/`--col-w` custom properties the actual
Scheduler reads. A click on `+`/`−` calls `setPref()` → `applyPrefs()` →
the CSS variables update → the preview resizes live, for free — no
preview-specific sizing logic to keep in sync. The two steppers reuse the
exact `.fb-fs`/`.fb-fs-b`/`.fb-fs-inp` component D174 just fixed ("i like
that ui the best"), now a fourth consistent instance instead of a new one-
off control. Direct typed entry works too (a `change` listener on
`#pref-rowh-inp`/`#pref-colw-inp`, same pattern as `#cw-days`), not just
the buttons.

Verified live: default Scheduler now shows visibly taller rows with no
clipped chip content. In Settings, clicking `+` three times each moved Row
height 84→96 and Column width 150→170, with the preview chips growing to
match on every click; navigating to the real Scheduler confirmed the same
84/150 default (5 truck columns visible) and, after the change, wider/
taller cells with fewer columns fitting the viewport — the same numbers,
same visual result, both places.

### D176 — Internal load chips: order number on its own line, never split mid-string (2026-08-21)

Nate: "the load chips in the scheduler if we could get the order number
for the internal loads to be under the pallet count inside the app that'd
be cleaner i dont really want it to split the order number up."

Bag Orders chips previously joined pallet count and Solomon # into one
string — `"24 PAL · 07-0826-0105"` — rendered as a single `<span>` inside
`.meta`. With no `white-space:nowrap`, the browser's default line-breaking
treats a hyphen as a valid break opportunity, so a narrow chip could split
the order number itself mid-string (`"07-"` / `"0826-0105"`) — exactly
what Nate flagged.

Fix, scoped to `chipHtml()` (`02-chips-extract.js`) and only for
`o.kind === "internal" && !o.is_transfer`: PAL count and the Solomon #
render as two separate `<span>`s inside a `.meta.meta-2line` container
(`flex-direction:column`, unconditional — not a width-dependent wrap, so
the order number is reliably "under" the pallet count every time, not just
when the chip happens to run narrow), with `white-space:nowrap` on the
order-number span specifically so it can never split internally — if it
doesn't fit, it overflows/clips as a whole unit, never mid-hyphen.
External and Internal Freight transfer chips are untouched — they still
build a single joined `.meta` line the way `buildChip()` always has, since
this was specifically about the internal PAL/order-number pairing.

Verified live: Bag Orders chips (BRIGHTSIDE FLOWERS, BI-MART #607) now
render `<div class="meta meta-2line"><span>24 PAL</span><span
class="nowrap">07-0826-0105</span></div>` — confirmed via both computed
DOM inspection and a screenshot, order number fully intact on its own
line. External and transfer chips confirmed still using the original
single-line `.meta`, unaffected.

### D177 — Buttons unified to Title Case (2026-09-01)

Nate: "lets unify buttons and make them all capitalized first letter of
words, at least for primary action buttons."

Audited every static button label app-wide (`class="btn"`/`class="btn
pri"`/`class="btn sm"`/`class="pm-item"` — anything the user clicks as an
action, not just the primary-CTA floor Nate named). Most labels were
sentence-case only ("Add customer", "Mark done", "Delete selected"),
inconsistent with a smaller set that were already correct Title Case
("Continue", "+ New Order", "Connect Outlook"). Converted every multi-word
static label to Title Case (every word capitalized, per Nate's literal
phrasing — no smart-casing of short prepositions): `Add Customer/Location/
Truck/Department/Field/Orders/Column`, `Create Database`, `Reserve
Numbers`, `Save Route/Range`, `Return To Simple Route`, `Open In Tab`,
`Reopen For Billing`, `Edit Full Route…`, `Download Merged/Individually`,
`Open Outlook Draft`, `Mark Done/Complete`, `Draft Selected`, `Download
Selected (n)`, `Delete Selected (n)`, `Cancel Selected (n)`, `Update
Google Schedule`, `Reset All To Defaults`, `Reset To Default`, `Sign Out`,
`Load Older History`. Left single-word labels (`Save`, `Cancel`, `Close`,
`Delete`, `Reset`, `Restore`, `Today`, `Continue`) and already-Title-Case
ones untouched. Two help-text lines in Settings (`05-settings-nav-search.js`)
that quote a button name in `<b>` — "Add orders", "Delete selected" —
updated to match their button's new label so the docs stay literal quotes,
not stale ones.

Deliberately did NOT touch: modal `<h2>` headings (Nate asked about
buttons, not headings — "Add truck" the heading stays sentence-case even
though "Add Truck" the button below it changed), right-click context-menu
items (`09-color.js`'s `openMenu` — a different UI surface from `.btn`),
and prose sentences that merely mention an action in passing (e.g. "Use
Edit full route to review it." inside a `.note-bar`/toast — not a button
label itself).

Verified live: restarted the server, logged in, and spot-checked across
the surfaces these buttons live on — Scheduler toolbar ("Update Google
Schedule" with its sync icon), Database → Fleet ("+ Add Truck", "Delete
Selected"), Bag Orders tracker ("Add Orders", "Cancel Selected", "Delete
Selected"), and the profile menu ("Sign Out") — via screenshots and
`read_page`, all rendering the new Title Case labels correctly. `node
--check` on every edited file passed before the restart.

### D178 — Driver tab PO/PU# and Delivery# get their own columns (2026-09-10)

Nate: "im thinking about redesigning things so each number has its own
column inside the driver tabs, like PO PU and Delivery number... i think
you just put the numbers there instead of a google maps route and then we
move the google maps route to the H and I spots."

Driver tabs (one Google Sheets tab per driver, pushed by
`/api/sheets/push-driver-tabs`) had PO/PU# and Delivery# buried inline in
the load chip's PICK/DROP lines (`PICK: {po} | {address}`), while E/F held
the Pickup/Drop Google Maps links and G held the internal Store Map link.
Swapped: E now holds `po_number`, F holds `delivery_number` (plain text,
new `truck_rows()` fields in `_driver_week_payload`, `app/server.py`), and
the Pickup/Drop map links moved to H/I — both previously-unused columns
sitting inside the existing black-fill wall at column J, so no wall move
or column-shift of B–G was needed. G (Store Map, internal-only) is
untouched. `_driver_chip_text`'s PICK/DROP lines dropped the leading
number — chip now reads `PICK: {address}` / `DROP: {address}` only, since
the number has its own column. The push handler's clear range, write
range (`B2:I…`), and `_three_slot_grid_requests` wrap/font formatting call
all widened from column G to I to cover the two new columns. Scope is
Driver Tabs only — Current Week's compact chip is a shared per-truck grid,
not per-driver columns, so there's no room to split there and it's
unchanged.

Verified live: restarted the server, built 8 test external orders
(12-0926-9001–9008, one per driver) with real brokers (A-1 Freight
Systems, Alltran Logistics, Axiom Logistics, etc.) and real pickup/
delivery locations pulled from the existing Bi-Mart/garden-center location
list, scheduled one per truck for today, and pushed to the real mirror
sheet. Read back Wayne's tab (`WAYNE 31 BT!B2:I2`) directly via the Sheets
adapter and confirmed the live row: `E="PU-70001"`, `F="DL-80001"`,
`G=""` (no store map, external order), `H`/`I` carry the Pickup/Drop
hyperlinks, and the chip text (`C`) reads `PICK: BI-MART #601, 2030 RIVER
RD, EUGENE OR, 541-687-7600` with no leading `PU-70001 |` — confirming
both the column split and the chip cleanup landed correctly on the actual
sheet drivers read.

### D179 — Load# column, real single-tap map links, and readable Current Week spacing (2026-09-10)

Three follow-ups on D178 from the same conversation:

Nate: "also need another column for load #." Load# (`broker_load_no`) gets
its own driver-tab column, J — the ninth used column, sitting right after
D178's H/I map-link columns. Nate: "load number can be on the load chip as
well thats fine its not clutter," so unlike PO#/Delivery# it stays in the
chip's header line too (`{broker} - {solomon} - {load#}`) — J is additive,
not a move. `truck_rows()` gained `row["load_number"] = o.get("broker_load_no")`,
set for every order kind (not gated to external, since the field isn't
kind-specific), and the push handler's value row/ranges/`_three_slot_grid_requests`
call widened from I to J. J gets the same 164px column width as the other
narrow number/link columns so a freshly auto-provisioned tab (D112) doesn't
show Sheets' default width standing out.

Nate also asked me to reformat the sheet myself; a first pass added a
row-1 header-relabeling step (rewriting DATE/NOTES/PICKUP/DROP/etc. on
every push) but Nate fixed the headers by hand before that landed live, so
that step was pulled back out — push still only ever owns the C1
driver-name banner, same as before D178/D179; row-1 column labels are
Nate's own edit now, not something the app rewrites.

Nate: "also the google map links are not actually hyperlinking." The
formula itself (`=HYPERLINK(url,label)`, D112) was verified correct at the
API level — Sheets stored and evaluated it fine — but a plain
`=HYPERLINK()` cell needs a second tap (Sheets shows a hover/preview chip
on the first tap, requiring a follow-up tap on that chip to actually
navigate), which reads as broken on a driver's tablet. Switched Store
Map/Pickup/Drop (G/H/I) from formula strings pushed through the bulk
`values.update` write to real rich-text links — individual `updateCells`
requests per cell with `textFormatRuns[0].format.link.uri` set, the same
mechanism Sheets' own Insert > Link produces, which navigates on a single
tap. `_hyperlink_formula` is now dead code and was removed.

Nate: "on the current week tab... i need gaps on the external loads so
its broker/customer and a space and then the pick and space and drop. so
its readable." `_current_week_chip_text` moved from single `\n`-joined
lines to `\n\n` between every line (broker, PICK, DROP) — then a same-turn
follow-up ("cut the space between the pick and the drop... but keep the
space between customer/broker and the pick and drop") tightened it to a
blank line only after the broker/customer line, with PICK/DROP joined by
a single `\n` so both still fit the fixed-size Current Week cell.

Verified live at every step via the real Sheets API (not just code
review): read back `WAYNE 31 BT!G2:J2` after pushing and confirmed real
`hyperlink` fields (not `textFormatRuns`-only or formula text) pointing at
the correct Maps URLs for Pickup/Drop, `500001` landing in J, and
`Current Week!C2` reading `"A-1 FREIGHT SYSTEMS\n\nPICK: ...\nDROP: ..."`
— single blank line after the broker, tight PICK/DROP. One real miss
caught mid-verification: a browser-driven "Update Google Schedule" click
didn't actually fire the confirmed push (dry-run and live sheet still
showed stale spacing after clicking it), caught by re-checking the live
sheet instead of trusting the click succeeded — the retry went through
the authenticated fetch path directly and confirmed correct.

### D180 — Reverted the J/Load# column, reworked the chip header/PICK-DROP layout instead (2026-09-10)

Nate: "lets not do that, lets revert J back to what it was. lets just
change the driver tab format to be

    CUSTOMER/BROKER - Rexius Order: 12-xxxx-xxxx | Load: #####

    PICK:
    DROP:

and make the Rexius Order: in bold same with the Load: just like the pick
and drop. i think that would be clean and then have that be the C column."

Undid D179's J column entirely: `truck_rows()` no longer computes
`load_number`, the push handler's value row/ranges/`_three_slot_grid_requests`
call went back to ending at I, and the J-column-width request was removed.
The stale `500001`-style values D179 had already written into J on the 8
real driver tabs were cleared with a one-off script (rows 2 through the
14-day max, row 1 left alone since Nate owns header text) — otherwise
"reverted" would just mean "stopped updating," leaving old numbers sitting
there forever. Caught mid-cleanup: that script's tab filter (every tab
except "Current Week") accidentally also cleared column J on a real
non-driver informational tab, "FREIGHT CUST INFO" — checked its content
first before treating this as fine, confirmed the tab only ever uses
column A (customer info as one concatenated string per row) and J was
already blank there, so no real data was lost, but it's a reminder that
"every tab but X" is a looser filter than "every resolved driver tab."

In its place, `_driver_chip_text`'s external branch (C column) changed
shape: header is now `{broker} - Rexius Order: {solomon} | Load:
{load#}` (previously `{broker} - {solomon} - {load#}`, no labels), and
PICK/DROP dropped their blank-line separation from each other — one blank
line after the header, then PICK and DROP on consecutive lines, matching
the same tightened spacing Current Week's compact chip got earlier this
session. `_fmt_requests`' bold-label regex (`PICK:|DROP:|\b07-\d{4}-\d{4}\b`)
gained `Rexius Order:` and `Load:` so both render bold like PICK/DROP
already did — same text-format-runs mechanism, no new formatting code
path.

Verified live: dry-run confirmed the new chip text before pushing, then a
real push + a direct read of `WAYNE 31 BT!C2:J2` (formattedValue and
textFormatRuns, not just the code) confirmed the exact string
`"A-1 FREIGHT SYSTEMS - Rexius Order: 12-0926-9001 | Load: 500001\n\nPICK:
...\nDROP: ..."`, bold runs landing exactly on "Rexius Order:" (22–35) and
"Load:" (51–56) in addition to the existing PICK:/DROP: runs, and J
reading blank (no `rowData` at all for that range — fully cleared, not
just unwritten).

### D181 — Current Week chip gets the same Rexius Order/Load# header (2026-09-10)

Nate: "thats perfect lets also add the rexius order and load to the
curent week tabs as well."

`_current_week_chip_text`'s external branch had just the bare broker name
as its first line; changed to the same `{broker} - Rexius Order: {solomon}
| Load: {load#}` header D180 gave the driver tab chip. No separate
bolding work needed — Current Week chips already render through the same
`_fmt_requests` bold-label regex the driver tab does (`_three_slot_grid_requests`'s
per-row loop calls it with `current_sid`), so D180's regex extension
(`Rexius Order:`/`Load:`) covers this chip for free.

Verified live: dry-run confirmed the new header string, then a real push
+ direct read of `Current Week!C2` (formattedValue and textFormatRuns)
confirmed the header renders with "Rexius Order:" and "Load:" both bold
(runs at 22–35 and 51–56), same positions as the driver tab chip.

### D182 — Current Week chip drops the Rexius Order#, keeps Load# (2026-09-10)

Nate: "nah lets not do that lets get rid of the rexius order on the
current week tab lets just add the load. i know thats annoying." One
turn after D181 gave Current Week the same `{broker} - Rexius Order:
{solomon} | Load: {load#}` header the driver tab chip has — too much for
the fixed-size cell. Header is now `{broker} - Load: {load#}` only; the
Solomon order # stays exclusive to the driver tab's fuller chip (D180).

Verified live: dry-run confirmed the trimmed header, then a real push +
direct read of `Current Week!C2` confirmed `"A-1 FREIGHT SYSTEMS - Load:
500001"` with `Load:` still bold (run at 22–27).

### D183 — Driver tab PICK/DROP get their blank line back, Current Week stays tight (2026-09-10)

Nate: "inside the driver tabs lets have a space between the pick and
drop, but in teh current week we keep it together." The two chips had
drifted to the same tight PICK/DROP spacing (D180's driver-tab rework
copied Current Week's D179 tightening) — Nate wants them different: the
driver tab's fuller chip has room for a blank line between PICK and DROP,
Current Week's fixed-size cell doesn't. `_driver_chip_text`'s external
branch went back to `"\n\n".join([header, pick, drop])`;
`_current_week_chip_text` is untouched, still tight.

Verified live: dry-run confirmed both chip shapes at once (driver tab
blank-line-separated, Current Week tight), then a real push + direct read
of `WAYNE 31 BT!C2` confirmed the blank line between PICK and DROP landed
on the actual sheet.

### D184 — Days-shown stepper's divider lines finally match the font-size stepper (2026-09-10)

Nate: "the days shown counter lines between the bumbers and the + and -
arent the exact same as the one for the fonts in the tool bar." D174
already fixed a background/border mismatch between the two `.fb-fs`
steppers (Days-shown living in `.toolbar`, font-size living in `.fmtbar`),
but `.toolbar input,.toolbar select`'s `border-radius:var(--r-sm)` was
still leaking through onto `.fb-fs-inp`'s two divider borders
(border-left/border-right) — enough to round their corners just slightly
differently from the font-size stepper's perfectly square ones, which is
what read as "not the exact same" even after D174. Added explicit
`border-radius:0` to `.fb-fs .fb-fs-inp`.

Verified live: `getComputedStyle` on `#cw-days` (Current Week) and
`[data-fb="fs-inp"]` (format toolbar) now report identical `border-radius`
(`0px`), `border-left`, and `background` — confirmed via a screenshot too,
both steppers render visually identical.

### D185 — Driver Tabs dashboard view rebuilt to match the pushed sheet's real column layout (2026-09-10)

Nate: "i need whatever is in the google sheet to match the driver tabs in
the fashboard like the dashboard driver tabs section needs to be an exact
perfect port over so whatever i edit inside of the driver tabs on the
dash i can just directly push to the sheet and its perfect all of its in
the same spots."

`vDriverView()`'s `.dv` grid (D137/D147) was still Date/Load/Notes/
Pickup/Drop/Store Maps — the ORIGINAL B:G layout from before this
session's D178–D183 changes moved PO#/Delivery# into their own columns
and relocated the map links to H/I. The dashboard view never got updated
alongside those pushes, so it had drifted: it was missing PO#/Delivery#
entirely, and its Pickup/Drop columns sat where PO#/Delivery# now
actually live on the real sheet — editing "Pickup" in the dashboard had
no relationship to what column H actually holds anymore.

Rebuilt the grid to match `_driver_week_payload`'s real B:I column order
exactly: Date | Load | Notes | PO/PU# | Delivery# | Store Maps | Pickup |
Drop. `dvSlotCellsHtml()` now emits 7 sibling cells instead of 5 — two new
`.dv-field-inp` text inputs (`data-dvfield="po_number"` /
`"delivery_number"`, external orders only, matching the payload's own
external-only gate) slotted in at their real positions, with Store Maps/
Pickup/Drop reordered to come after them instead of before. New fields
save through a lightweight `orderPoDeliverySet(oid, field, value)`
(08-undo.js) — patches the in-memory order and stops, no repaint, since
neither field appears on any dashboard chip (D178 moved them off the chip
entirely) so there's nothing to visually refresh; mirrors `driverNoteSet`'s
shape but skips its `repaintCell` call for that reason. Wired via a new
blur handler in 07-events.js, same capture-phase pattern as the existing
Notes-column handler. `repaintDvSlot()`'s sibling-walk is fully generic
(no hardcoded count), so it needed no changes to handle 7 cells instead
of 5.

Also fixed in the same pass: D184 gave the Days-shown stepper's divider
lines the last bit of parity with the font-size stepper (`border-radius:0`
on `.fb-fs .fb-fs-inp` — `.toolbar input`'s border-radius was still
leaking through onto the two divider borders after D174's background/
border fix).

Verified live: a real `.click()`/native-setter-driven edit (not a
browser-automation mouse click — see note below) of Wayne's PO# field
persisted `PU-70001`→edited value→back to `PU-70001` in Postgres each
time, confirmed by direct `psql` queries; same for Delivery#. Confirmed
the column header row and populated cells render in the correct B:I
order via a live screenshot. One real tooling snag hit mid-verification:
the Browser pane's simulated mouse clicks intermittently failed to
register on this page (sub-tab navigation silently no-opped, an edited
input's blur never fired a save) while the exact same actions dispatched
via a real DOM `.click()`/native value-setter+`blur()` worked every time —
diagnosed by comparing click-vs-script behavior side by side rather than
assuming the new code was broken, confirmed as a Browser-pane
click-reliability quirk (this session had hit similar staleness/hidden-
pane issues before), not a bug in `orderPoDeliverySet` or the blur
handler.

### D186 — Bag Orders/Internal Freight mileage no longer resets scroll, Miles column widened (2026-09-10)

Nate: "when i input mileage it resets the view back to the front of the
tables and then the mileage column isnt wide enough to even see the
data."

Two separate bugs in the shared `milesCell`/`freightCell` machinery
(D48/D103, used by both Bag Orders and Internal Freight):

1. `freightValueSet` (08-undo.js) and the miles-reset button's click
   handler (07-events.js) both ended in `.then(reload)` — a full
   bootstrap refetch + `render()` that rebuilds the tracker's `.pad`
   scroll container from scratch, snapping it back to `scrollTop: 0` no
   matter how far down the list the edited row was. Same class of bug as
   D84/D122/D128/D140/D159 for other order-tracker/drawer fields, just
   never applied here. Fixed the same way: `freightValueSet` now patches
   the in-memory order from the returned row and calls a new
   `repaintFreightCell(oid, field)` (04-views.js) that swaps just that one
   `<td>` via `outerHTML`, leaving the rest of the table (and its scroll
   position) untouched. The reset-miles button got the identical
   treatment.
2. The Miles `<th>` was 120px in both trackers — enough for a bare
   number, not for one plus the "adj" pill + reset button that appear the
   moment a value is typed over (or the "ELD" pill when it's pre-filled
   from Motive), so the number itself got squeezed down small enough to
   read as missing. Widened to 150px in both `vInternal()` and
   `vInternalFreight()`, with each table's declared total pixel width
   bumped by the same +30 to keep the `table-layout:fixed` column sum
   correct (Bag Orders' sum matches its declared width exactly; Internal
   Freight's didn't already, pre-existing and unrelated to this fix — not
   touched further).

Verified live: scrolled Bag Orders' `.pad` container to `scrollTop: 800`
(41 rows, order 30 in the list), typed a mileage value on that row, and
confirmed `scrollTop` was still `800` after the save round-tripped —
compare to editing the very first row, whose scroll-into-view position is
near 0 regardless, which is what made an early manual test look like the
bug was still present until re-tested against a row that actually proves
the difference. Repeated for Internal Freight's Transfer-$ field.
Confirmed both tables' Miles `<th>` computed width is 150px live. Two
real orders picked up stray test values in the process (BRIGHTSIDE
FLOWERS momentarily got `miles=400.1`, a real is_transfer test row's
`miles=789.0` got briefly overwritten to `88.8`) — caught via direct
`psql` inspection before finishing and restored to their prior values
(the BRIGHTSIDE FLOWERS one back to blank, the transfer row back to its
original 789.0) rather than left as leftover noise in real tracker rows.

### D187 — Typing mileage by hand auto-calculates the transfer $ too (2026-09-10)

Nate: "i want it to auto calc based on mileage i type on an order too,
but still let me typeover the $ amount if i need to."

`api_internal_freight_rate_calculate` (D170) only ever ran as a Motive-sync
follow-up — typing miles directly into the Bag Orders/Internal Freight
tracker (or the drawer's own field, same endpoint) never touched
`internal_freight_amount`. `api_freight` (`app/server.py`) now applies the
exact same formula inline: after a miles update, if the order still has no
`internal_freight_amount` and a rate is configured, it fills
`round(greatest(miles * rate, minimum), 2)` in a follow-up update on the
same request. Guard is identical to the sync path's — never overwrites a
value that's already there, hand-typed or previously calculated — so
typing the $ amount directly still always wins, whether that happens
before or after a miles edit. Client's `freightValueSet` (08-undo.js) now
repaints both the miles and freight_amount cells after any save (not just
the field that was actually edited), since a miles save can now
side-effect the $ cell too; `repaintFreightCell` already no-ops safely if
a cell isn't on screen.

Verified live end-to-end against the real configured rate ($4.11/mi, $350
min): typed `95` into a blank order's Miles cell, confirmed both the DB
(`miles=95.0`, `internal_freight_amount=390.45`) and the live $ cell
(`390.45`) updated without a page reload. Then typed `999.00` directly
into that same order's $ cell, followed by a second
miles edit (`200`) — confirmed the $ cell stayed `999`, proving the
typeover guarantee holds regardless of edit order. One tooling snag: the
Browser pane being hidden intermittently breaks native `.focus()`/`.blur()`
method calls from firing real focus/blur DOM events (confirmed by adding
an isolated-world blur listener that never fired) — worked around by
dispatching synthetic `blur`/`focus`-flavored events directly via
`dispatchEvent`, which reaches the app's capture-phase listeners
regardless of window-focus state. Not a bug in the app; a repeat of the
same environment quirk hit earlier in this session (D185).

### D188 — Internal-rate toolbar spacing + a real box around its toggle arrow (2026-09-10)

Nate: "can i get some spacing added between the min $ box and the sync
mileage button so they arent touching? same amount of spacing between the
sync mileage and delivery date button would be great," then "i also
think a ui/box around the dropdown arrow for the interal freight rate and
minimum so i dont forget its there next time would be awesome... that way
i know theres a button."

The Min-$ input, Sync-mileage button, and Sync-delivery-dates button
(`internalFreightRateHtml()`/the Orders toolbar, `05-settings-nav-search.js`)
had inconsistent inline margins — 0 between Min-$ and Sync mileage, 6px
between Sync mileage and Sync delivery dates. Normalized both sync
buttons to `margin:6px 0 6px 8px`, giving an even 8px gap before each,
matching `.toolbar`'s own 8px flex-gap convention used everywhere else.

The IFR toggle arrow (`.ifr-arrow`, `#ifr-toggle`) was a bare borderless
glyph with no background — easy to read as decorative text rather than a
control. Gave it a real button box: 22×26px, `border:1px solid
var(--rule-2)`, `border-radius:var(--r-sm)`. First pass used
`background:var(--panel)`, which Nate flagged as brighter than its
surroundings — this toolbar is a `plain:true` one (Orders trackers sit in
the scrolling `.pad`, not a `.toolbar` bar), so the real ambient
background is `--paper`, one step darker than `--panel`; switched to
`background:var(--paper)` to actually match. Also switched from
padding+line-height centering (which read low/off-center for this glyph)
to `display:inline-flex;align-items:center;justify-content:center` on a
fixed-size box — deterministic centering instead of relying on font
metrics.

Verified live: `getBoundingClientRect` gaps for Min-$→Sync-mileage and
Sync-mileage→Sync-delivery-dates both measured exactly 8.0px. Toggle's
computed `backgroundColor` (`rgb(240,237,230)`) matches `--paper` exactly;
`display:flex`/`align-items:center`/`justify-content:center` confirmed on
the live element; a screenshot confirmed the glyph reads centered in a
visible, blended-but-outlined box.

### D189 — Rexius Bag Orders is part of the hosted dashboard cutover (2026-09-10)

Nate: "make sure this is a planned part of the dashboard port over when i go to
supabase" and asked for every connection and prerequisite before implementing
the server.

The portal will remain a separate web app/host, matching its temporary one-year
life, but it will launch as a required component of the same staged Supabase
cutover. It shares the dashboard's Postgres database, private `documents`
Storage bucket, ordinary Bag Orders, ordinary `delivery_receipt`/`pod` document
rows, and Fleet trucks. Umatilla is only the first visibility configuration;
there is no East-only table, bucket, or document lane.

The production topology is two persistent HTTPS Python services — dashboard and
Rexius Bag Orders — with browser clients talking only to their own same-origin
server. Privileged database, Storage, and mail credentials remain server-only.
The portal has no driver picker; an active truck number is required at
completion. A one-time shared tablet access code/device cookie protects the
queue without inventing driver accounts.

Activation is gated on: mapping Supabase Auth identities into existing
`app_users` permissions; preventing `anon`/`authenticated` browser roles from
direct business-table access; private Storage plus verified file migration;
bounded database connections/health checks; application-only Microsoft Graph
mail to `nathanl@rexius.com`; idempotent completion/email; staging acceptance;
and a backed-up, reversible cutover. The current delegated Outlook-draft adapter
cannot send the automatic completion email because it deliberately lacks
`Mail.Send`. The complete source of truth is
`docs/supabase-server-port-plan.md`.

### D190 — Full Supabase port audit: dashboard first, all integrations included (2026-09-10)

Nate: "review the current plan cause it needs to be up to date with everything
including the most recent feature commits" and then corrected the emphasis:
"i thought we were working on the supabase integration not the drivers order
thing."

Rebuilt `docs/supabase-server-port-plan.md` as the production port plan for the
whole dashboard. Rexius Bag Orders remains included, but only as one connected
component. The audit covered the 30 newest commits, all environment call sites,
the full migration chain, both servers, API route/permission families, login,
adapters, local Storage, and the live local Postgres schema.

New explicit gates cover: the Google driver-mirror push (including the final
D178–D185 column/layout behavior), Motive, delegated billing drafts, D170/D187
internal-freight calculation, 14-day History cleanup, all metadata/custom-grid
tables, reports, Pacific-time dates, external map/image links, pinned runtime
packaging, raw-Postgres-compatible hosting, TLS, Data API shutdown, separate
runtime roles, server-side read and write grants, API timeouts, backups for both
database and Storage, monitoring, and a schema-first/data-only migration rehearsal.

The audit also fixed safe local prerequisites without connecting a hosted
service: the dashboard bind host and both servers' database timezone are now
configurable; database connection strings are no longer printed in startup
errors/logs; authenticated API/document responses are marked no-store; the
Supabase Storage adapter now honors its bucket setting, URL-encodes filenames,
and sends the right MIME type; and the portal uses the order's actual
`delivery_location_id` instead of whichever customer location happened to be
oldest.

`driver_receipt_completions` was created after D131's one-time audit-trigger
sweep. Migration `20260910000002_driver_receipt_history.sql` gives it the same
history trigger as every other mutable table, and the portal clears the trigger's
connection-scoped context after each completion so one tablet submission cannot
be attributed to an earlier one.

One important reliability correction: completion email will use a hidden,
server-only durable outbox inserted in the same transaction as the signed POD.
There is still no pending-email UI or added driver step, but a process restart
can no longer silently lose the required final email. That outbox/Graph sender
remains a pre-hosting implementation gate, not code claimed complete here.

Verification used a brand-new isolated PostgreSQL 17 cluster, not the real
`dept12` database. Every migration applied in filename order and produced 32
base tables, 4 views, 20 policies, 42 application triggers, both required
extensions, and no missing durable-history trigger outside the four audit-log
tables. The dashboard then booted against that clean schema with a Pacific-time
session and no-store API headers; the reversible multi-stop workflow, local
Storage request encoding/MIME contract, and complete synthetic Bag Orders flow
also passed. No hosted project or real email was contacted.

## Open — needs Nate

**36 blank leftover rows in the real Bag Orders tracker.** Found while
verifying D159's bulk-delete: `07-0126-0001`–`0003`, `07-0826-0108`–`0110`,
`07-0926-0111`–`0130`, `07-1026-0002`–`0011` — all completely blank
(no customer, no dates, no PAL), all timestamped inside this session's own
testing windows (2026-08-20, 15:41–15:45). Strong circumstantial evidence
this is leftover test data from earlier verification, not anything Nate
entered, but not deleted yet — flagged to him in chat for confirmation
before touching real tracker rows.

**Does the order drawer/modals need to scale with app zoom?** (D136) They
currently don't — deliberate exclusion from `#main`'s zoom scope, matching
how dialogs/sidebars in comparable apps (Sheets) don't zoom with the
sheet. If Nate meant the drawer specifically when he said pills/buttons
should resize with zoom, that's a real (larger) layout change to scope,
not a one-line fix — flagging rather than guessing.

**Public broker list.** `legacy/invoicing-local/index.html:1467` reads the broker
directory from the TMS sheet over an unauthenticated `gviz/tq?tqx=out:csv`
endpoint. It returns 102 broker names with AP billing emails to anyone holding
the sheet ID — no credentials required. Works fine and nothing was changed, but
AP email addresses are a phishing target. Nate's call whether to lock the tab
down and move the fetch behind the Sheets API.

### D191 — Archive Bagger Customers and merge the duplicate Bi-Mart seeds (2026-09-10)

Nate: "lets add the archive functionality instead of delete for that database"
and clarified that the duplicate records are 601 and 602, not dependable visual
row numbers. Bagger Customers now use a nullable
`parties.customer_archived_at` timestamp from migration
`20260910000003_bagger_customer_archive.sql`. The active directory has
**Archive Selected** and **Show Archived**; the archive view uses the same
numbered gutter and **Restore Selected**. Permanent delete is rejected for this
grid. The controls reuse the shared toolbar, button, modal, and spreadsheet-row
selection patterns from `docs/design.md`, with one rightmost primary Add button
and no new component styling.

Archived customers are excluded from future Bag Order customer pickers, global
customer/location search, filename/customer matching, and customer-directory
export. Their party/location rows, old orders, documents, history, and any
broker/carrier role remain live. Existing Bag Orders are not canceled and still
flow to Rexius Bag Orders. Active and archived Bagger views preserve each
other's saved row ordering.

The confirmed duplicates were the sparse synthetic seeds `Bi-Mart 601`
(`11111111-1111-1111-1111-111111111103`) and `Bi-Mart 602`
(`11111111-1111-1111-1111-111111111104`). Their canonical imported records are
`BI-MART #601` (`a33e5fe4-1c1c-49aa-8d01-5ad4c2c1c4ed`) and `BI-MART #602`
(`c286fc30-a6f5-4cd1-9fab-693d73663cc0`). The one-off cleanup validates all
four exact identities, repoints order/invoice/load/location/image references to
the canonical records, and removes only the two duplicate parties and their two
duplicate locations in one transaction. Its default mode is a rollback-only dry
run; `--apply` is required to commit.

Verified archive/reorder/restore against `dept12_east_test` through both the API
and the rendered browser controls. The toolbar kept exactly one primary button,
the selection action stayed disabled until a gutter row was selected, the empty
archive view rendered correctly, and both state transitions appeared in durable
History. The existing rollback-only multi-stop regression also passed. Before
the real merge, a full custom-format database backup was written to
`/private/tmp/dept12-before-bimart-archive-20260910.dump` and the cleanup dry run
matched the expected references. The applied merge left 269 customer parties,
both canonical Bi-Mart records and their images, zero duplicate party/location
rows, and zero remaining references to the removed IDs.

### D192 — Extend archive/restore to External Customers and Internal Freight (2026-09-10)

Nate: "make this archive system work with the other two databases too cause its
better than deleting," then clarified that the two are **Internal Freight** and
**External Customers**. Pick/Drop List and Fleet therefore retain their guarded
delete behavior.

Migration `20260910000004_directory_archives.sql` adds the role-specific
`parties.broker_archived_at` and `departments.archived_at` timestamps plus active
row-order indexes. The existing Bagger-only implementation was generalized into
one archive configuration for the `bagger`, `external`, and `departments` grid
keys. Every directory uses the same Design.md-compliant toolbar, numbered-gutter
selection, confirmation modal, active/archive toggle, restore action, History
route, and view-specific saved ordering. There is still exactly one rightmost
primary Add button and no new CSS/component variant.

Archived External Customers are excluded from new broker pickers, document-name
matching, global directory search, and the broker export; another active role on
the same `parties` row remains usable. Archived Internal Freight departments are
excluded from blank/new transfer pickers. An existing order's archived broker or
department remains visible as its selected value, and all historical joins,
reports, documents, and History remain intact. The server rejects permanent row
deletion for all three archive-enabled directory grids.

### D193 — Click-and-drag range select on every numbered gutter (2026-09-10)

Nate: "i have a selection issue, i cant drag and select mroe than one order
in the orders tab i need that fixed."

The numbered gutter's `handleRowSel` (D50/D159) only ever handled `click` —
plain, Shift, and Cmd/Ctrl — never a mouse drag across multiple rows, on
Database grids or any of the three order trackers (they share the same
`[data-rowsel]`/`ROWSEL` engine). Added `rowSelStartDrag`/`rowSelDragTo`/
`rowSelEndDrag` (`06-modals-grids.js`) plus `mousedown`/`mousemove`/`mouseup`
listeners (`07-events.js`): a plain (no-modifier) mousedown on a gutter cell
arms a drag; moving into another gutter cell in the same grid extends the
selection live, using the identical range math Shift+click already does.
Shift/Cmd/Ctrl+mousedown deliberately don't arm a drag, so those existing
click-only behaviors are untouched. The trailing `click` event that always
fires after a real mouseup would otherwise collapse a dragged range back to
a single row (the exact click handler that runs on a plain click) — a new
`ROWSEL_SUPPRESS_CLICK` flag, set by `mouseup` only when a drag actually
moved between cells, tells the click delegator to skip its normal logic for
that one click. Also skips starting a drag when the mousedown lands on
Database's row-reorder grip (`.rowgrip`, a separate HTML5 drag) so the two
mousedown-driven gestures on that same gutter cell don't collide.

Verified live via dispatched `mousedown`/`mousemove`/`mouseup`/`click`
sequences (not a real trackpad drag) on Bag Orders: dragging from row 1
through row 5 selected exactly those 5 rows and the trailing click did not
collapse it. Re-confirmed a plain click still selects/toggles a single row
normally, and Shift+click still range-selects — neither regressed. On a
Database grid (Fleet), mousedown directly on `.rowgrip` selected zero rows,
confirming the reorder grip still gets first claim on that gesture.

Also fixed while getting the app running: this session's local Postgres
was missing migration `20260910000004_directory_archives.sql` (D192) —
`broker_archived_at`/`departments.archived_at` didn't exist yet, so the
bootstrap query 500'd. Applied it directly (`psql -d dept12 -h /tmp -f
supabase/migrations/20260910000004_directory_archives.sql`); no schema
change beyond what that file already specifies.

### D194 — Enter/Return accepts every popup's one obvious action (2026-09-10)

Nate: "can u go in and make sure that hitting enter or return on all the
popup windows accepts whatever changes are being made."

D98's Enter handler only recognized genuine confirmation dialogs by exact
button id (`#modal-confirm`/`#confirm-del`/`#confirm-customer-archive`) —
every add/edit popup (Add Customer, Add Location, Add Truck, Add
Department, Add Field, Create Database, Save Route, condfmt/field-options
Save, Reserve Numbers, bulk Add Orders, column Save) was deliberately left
alone under the old reasoning that "Enter belongs to the active input."
Broadened the same handler: when none of the known confirm ids are
present, it now falls back to the popup's `.modal-ft .btn.pri` — every one
of these popups has exactly one, per the toolbar contract's "exactly one
primary action" convention (D171), so there's never ambiguity about which
button Enter means. Also added `#history-confirm` (the durable-History
revert/redo modal) to the explicit id list — a real pre-existing gap, not
new. The sort/reorder modal's Save A→Z / Save Z→A pair is the one popup
with two `.btn.pri` buttons — the fallback only engages when there's
exactly one, so Enter still does nothing there rather than guessing which
direction. A `<textarea>` target is excluded on principle (multi-line
editing keeps Enter) even though no popup today actually has one.

Verified live: typed a truck number into Add Truck, pressed Enter with no
click at all, confirmed the modal closed and the truck was actually
created in Postgres (then removed it — it was a throwaway probe value,
not real fleet data).

### D195 — Staging a load no longer resets scroll, and bulk-stages a selection (2026-09-10)

Nate: "i found two bugs, if i hit stage on a load it brings me back to the
top of the page" and, same message thread, "also if i could bulk select
and hit stage on one of the selections and have it stage all of them that
would be great."

`STAGED` is a pure client array — never written to the server (D51) — but
its click handler still called a full `render()` on every click, rebuilding
the whole tracker and resetting its `.pad` scroll to the top, the same
class of bug D186 already fixed for mileage. Since nothing server-side
changes, the fix needed no round trip either: remove the just-staged
row's own `[data-stage]` button from the DOM directly and refresh the
(separate, self-contained) Staging rail — `renderRail()` only touches
`#rail`/`#stage-ct`, not the tracker.

While rewriting that handler, folded in the bulk-stage ask: it now reads
the clicked row's own tracker grid from its numbered-gutter sibling
(`[data-rowsel]`'s `grid|id` value) and checks whether that row is part of
the grid's current `ROWSEL` selection — if so, every selected order that's
still eligible (`canStageOrder`) gets staged, not just the one clicked,
mirroring the existing bulk Cancel/Delete convention of silently skipping
ineligible rows in a mixed selection rather than erroring. The selection
clears afterward, same as bulk Cancel/Delete.

Verified live: staged a single row at `scrollTop: 600` on Bag Orders,
confirmed scroll stayed at 600 and the button/rail both updated correctly.
Then drag-selected 3 rows (D193) and clicked Stage on one of them —
confirmed the staged count went from 1 to 4, all three rows' Stage
buttons disappeared, and the row selection cleared.

### D196 — Escape deselects (2026-09-10)

Nate: "id like to make it to where hitting escape deselects the
selection."

The main grid keydown handler (`06-modals-grids.js`) already used Escape
for a few narrow things (cancel an in-progress cell edit, clear a copy-
marquee highlight) but never touched the two actual selection concepts —
`SEL`/`SELSET` (a Scheduler/Database cell or marquee range, cleared via
the existing `clearMulti()`) and `ROWSEL` (a numbered-gutter row
selection, D159 — checked and cleared for every grid key at once, not
just whichever grid is currently visible, since it's cheap and simpler
than tracking "the active one"). Both are DOM-only patches
(`clearMulti()`/`paintRowSel()`) — no `render()`.

Verified live: selected a cell in the Scheduler (confirmed via
`td.sel`), pressed Escape, confirmed the selection ring was gone. Same
for a 3-row gutter selection on Bag Orders (drag-selected via D193,
Escape cleared it back to zero `.on` cells).

### D197 — Staging rail: collapsible, and reorderable by drag (2026-09-10)

Nate: "can we create a way to collapse and re open the staging bar? id
like to still be able to change the width of it but it would be nice,"
then in the same thread, "id also like to be able to re order the loads
in the staging area by clicking and dragging them."

**Collapse.** The rail's width was already user-resizable (D44,
`--rail-w` persisted to `localStorage["railW"]`, dragged via
`#rail-resize`), but had no show/hide toggle — only the per-view `RAIL_ON`
switch (D137, not user-facing) could hide it entirely. Added a small
`▸`/`◂` button in the rail header (`#rail-toggle`) that toggles a new
`rail-collapsed` class on `#bodywrap`, persisted separately
(`localStorage["railCollapsed"]`) from the width. Collapsing never touches
`--rail-w` — the CSS override (`.body.rail-collapsed:not(.norail){grid-
template-columns:minmax(0,1fr) 34px}`) replaces the column's *value*
without changing the variable, so expanding always comes back to exactly
the saved width. `:not(.norail)` defers to the existing per-view "no rail
at all" state if both are ever true at once. Collapsed state hides the
filter input, the chip list, and the resize handle, leaving just the
toggle button visible in a 34px strip.

**Reorder.** `STAGED` is a plain client array (never persisted, D51),
rendered in array order by `renderRail()` — there was no way to change
that order short of unstaging and restaging in a different sequence. The
generic load-drag system (`11-toolbar.js`, D137) already lets a staged
chip be dragged OUT (onto a Scheduler cell) but explicitly excluded a
STAGE-origin drag from doing anything when dropped back on the rail
itself (`rail && DRAG.from !== "STAGE"` — deliberately, since "moving into
staging you're already in" was a no-op). Added one more case ahead of
that: when a STAGE-origin drag is over/dropped on *another chip inside
`#rail`* (not just the rail container), it now calls a new
`reorderStagedRow(draggedId, targetId)` (`05-settings-nav-search.js`,
next to `renderRail`) — a plain array splice + `renderRail()`, no API
call, same insert-position convention `reorderGridRow` already uses
elsewhere (splice out, splice into the target's original index).

Verified live: toggled the rail closed (`grid-template-columns` narrowed
to `34px`, filter/list/resize-handle hidden) and back open (columns
restored to the exact pre-collapse width); dragged the resize handle
while expanded and confirmed it still resizes normally; reloaded the page
mid-collapsed and confirmed the collapsed state (and the correct `◂`
glyph) survived. Staged 3 real orders, dispatched a real `DragEvent`
sequence (`dragstart`/`dragover`/`drop`/`dragend` with a genuine
`DataTransfer`) moving the third chip onto the first, and confirmed the
rail's chip order changed from `[A, B, C]` to `[C, A, B]` — the same
splice semantics `reorderGridRow` already uses.

### D198 — Collapse toggle moved into the resize handle itself (2026-09-10)

Nate: "i dont think it should be the button you put i think it should be
an arrow thing in the middle of the bar that i drag to widen it, that way
the number of order counter in staging can be in the top right like it
was."

D197's collapse toggle was a separate button squeezed into `.rail-hd`,
crowding the "Staging"/count labels that live there. Removed it entirely
and merged its job into `#rail-resize` (the existing drag-to-resize
handle, D44) instead: a `▸`/`◂` arrow glyph sits centered in the handle
(flex-centered on the already full-height bar, so "the middle of the bar"
falls out for free), and the SAME element now does both jobs — drag it to
resize (unchanged), or click it with no drag to collapse/expand. Distinguishing
a click from a drag is a `moved` flag set only on `mousemove` between this
element's `mousedown` and the next `mouseup`; the trailing `click` event
checks it and skips toggling after a real drag. While collapsed, `mousedown`
deliberately doesn't arm the drag at all (nothing to resize at 34px) — only
the click handler runs, so a single click on the collapsed strip re-expands
it. `#rail-resize` itself no longer hides while collapsed (D197 had hidden
it along with the search box and chip list) since it's now the only way
back to expanded. `.rail-hd` is untouched — the "Staging"/count layout is
exactly what it was before D197 ever touched it.

Verified live (at real desktop width — the Browser pane defaults to 550px,
narrow enough to trip the existing "staging is desktop-only" mobile
breakpoint that hides `#rail-wrap` entirely, which the first pass of
testing didn't account for): a plain click on the handle collapsed
(`1060px 340px` → `1366px 34px` grid columns, search box hidden, arrow
`▸`→`◂`) and a second click expanded back to the exact original column
widths; a real drag (`mousedown`+multiple `mousemove`+`mouseup`) resized
normally and the trailing `click` correctly did NOT toggle collapse
(`localStorage["railW"]` updated to the new width, rail stayed expanded).

### D199 — Staging collapse: a dedicated `<>` icon, left of the header label (2026-09-10)

Nate, rejecting D198: "i dont like that look either... the collapsable
arrow for the staging could be like a `<>` icon or something that lives
on the staging area at the top to the left of 'staging' header." (He also
floated a bigger idea in the same message — collapsing the whole app's
nav to icon-only, mobile-style, with a reference screenshot — noted below
as a separate, unscoped proposal, not built.)

Third design for the same toggle in as many turns: back to a header
button (like D197), but positioned *before* `.rail-hd`'s "Staging" label
instead of after the count, and styled as a literal `<>` glyph instead of
a triangle. `#rail-resize` goes back to being purely D44's original drag
handle — no click behavior, no arrow child (D198's merged design is
fully reverted). `.rail-hd` switched from `justify-content:space-between`
(which would have spread three children — icon, label, count — evenly
across the row instead of grouping icon+label together on the left) to a
plain flex row with `gap`, plus `margin-left:auto` on the count
specifically so it alone pins to the right edge — the icon+"Staging"
pairing and the right-aligned count both come out matching the original
header layout modulo the new icon. `#rail-toggle` stays visible while
collapsed (only `.rail-search`/`.rail-body`/`#rail-resize` hide) since
it's still the only way back to expanded.

Verified live (at a real 1400px width, not the Browser pane's narrow
550px default that trips the mobile-only rail breakpoint — same lesson
from D198): the count's right edge sits within 15px of the header's right
edge before and after collapsing; a click collapses (`980px 420px` →
`1366px 34px` grid columns) with the toggle still visible/clickable in
the collapsed strip; a second click restores the exact pre-collapse
column widths; the plain resize handle, now independent of collapse
again, drags to a new width and persists it (`localStorage["railW"]`)
exactly as it did before D197 ever touched this area.

**Open — needs Nate:** the bigger proposal ("what if we made the app fold
like the mobile version and unified it with something like this
design") — an icon-only collapsed state for the main nav with hover
tooltips, per his reference screenshot (a 3-panel "Animal Care" sidebar
mockup: full labeled sidebar / collapsed icon rail / collapsed rail with
a flyout tooltip on hover). This is a real redesign of the app's main
hamburger/section nav, not a small toggle — scoping it (which nav, what
triggers the fold, whether flyout tooltips apply here) needs Nate's
answer before it's built.

### D200 — Hamburger nav made universal, Orders/Database controls relocated (2026-09-10)

Nate: *"lets build it out, i want the menu to open the bigger tabs and
then have the smaller tabs per section underneath the bigger ones so i
can nav anywhere from anywhere in the app which currently doesnt exist.
plus that gives us more room on the dash since we dont need those
persistent tab bars. where we have to be careful is the order section
because those tabs actually have buttons and functionality so we need to
move that somewhere that fits the ui."* Then, clarifying Database: *"i
think maybe leaving the database as is with its layout and just letting
me navigate but having database be like opening a spreadsheet would be
good and then i can double click to rename from the nav menu as well
under the database section like draw a line that separates it from the
other sections in the nav menu."*

Answers the "Open" item from D199 above — resolves it as "make the
hamburger menu (D60, previously mobile-only) the only navigation," not
the icon-rail-with-hover-tooltip visual from the screenshot (that's a
separate ask, addressed by D201 below). `.sections`/`.subs` are hidden
permanently (`display:none!important`, kept defined rather than deleted —
still real CSS other things reference) rather than removed from the DOM.

`openNavMenu()` was rebuilt to read `subsOf(sec)` instead of the static
`NAV[i].subs` — a real pre-existing bug fix, since `subsOf` is what
already resolves Database's dynamic entity/sheet list and this nav had
never used it. Investigating what else lived in the retired `.subs` bar
(per Nate's own caution about Orders) turned up a bigger hidden problem
than Orders: Database's `.sub-tab`s hosted double-click rename, right-click
delete, and the "+ New Database"/"+ New Sheet" buttons — all of which
needed a new home, not just Orders' IFR-rate arrow and Sync mileage/Sync
delivery dates buttons.

Fix: `ordersToolbarExtras()` (05-settings-nav-search.js) produces the
IFR-rate + Sync buttons; each order tracker's own `toolbarHtml()` call
now includes it as `secondary` (ahead of that tracker's own bulk
buttons, so the one `.pri` stays rightmost per the D171 toolbar
contract) — Bag Orders, Internal Freight, and External Orders all pick
it up instead of just Orders in general. Database's rename/delete/add
moved onto the nav item itself: `inlineRename()` gained a 4th `onCancel`
parameter (default `render`, preserving its 3 existing call sites) so a
nav item's Escape/no-change-blur can call a nav-specific refresh instead
of the page `render()`, which never touches the nav's own DOM. A plain
click on a Database sheet/custom-entity item is delayed 250ms
(`dataset.pendingNav`) so a real double-click (which fires two clicks
before `dblclick`) can cancel it and trigger rename instead — every other
nav item keeps instant navigation. Rename applies to any sheet or entity,
built-in included (matching the retired tab bar's actual behavior, not
just custom ones); delete stays custom-only. A `.nm-div` divider
separates Database's real entities from its custom sheets, matching the
old `.sub-div`.

Superseded same-session by D201 — Nate rejected the overlay/slide-out
presentation before this ever got its own live verification pass; see
D201 for the shipped design. Kept as its own entry per this session's
own precedent (D197→D198→D199) of never silently folding a rejected
revision into the one that replaced it.

### D201 — Persistent collapsible sidebar, replacing the D200 overlay (2026-09-10)

Nate, immediately after D200: *"i want it to be rediesgned to be more
like the thing i sent you [the D199 reference screenshot], and it needs
to be persistent so i can toggle the open and close but if i choose to
keep it open it looks like it matches the ui... if we need icons for the
bigger sections we can do that to."* Then, mid-build: *"i will need a way
to navigate to each of the sub sections in collapsed mode though, u dont
need an icon necessarily but i need to have an expandable sub menu
underneath the icons to get there or something."* Then a run of smaller
corrections in the same thread: *"it should be > or < depending on the
nav state... whichever direction the toggle takes the nav is the one
that should be displayed, that goes for every collapsable menu in the
app"*; *"or up and down u can make up and down arrows too obviously"*;
*"if IFR means internal freight rate u can use the < and > logos instead
cause i dont like the little triangle thing that it currently uses"*;
*"definitely use a hamburger menu for the very top left toggle... lets
move the app toolbar so it starts without cutting into the nav menu"*;
finally *"just get rid of the < > thing on that nav bar cause its
redundant the hamburger is fine. and make the order count correct. and
make it slightly wider so that in collapse mode it fits the text or let
me drag it to whatever width i want"* and *"keep the little icon logos
next to the headers in expanded view."*

`#navmenu` (D200's `position:fixed` slide-out, opened/closed with a
scrim) is retired for `#sidenav` — a real grid column, same family as the
Staging rail and History panel (`.body`'s `grid-template-columns` now
carries `var(--nav-w,200px)` as its first column in all 6 combos), never
removed from the DOM. Collapsing swaps `#sidenav-body`'s entire content
between `navMenuHtml()` (full labeled list) and `navMenuCollapsedHtml()`
(one icon per top-level section) rather than just clipping text — Nate's
"expandable sub menu underneath the icons" needed a genuinely different
interaction, so collapsed mode is a single-open accordion
(`NAV_OPEN_SEC`): clicking a section icon reveals that section's real
subs directly beneath it, in the same narrow column (a hover flyout was
considered and rejected — he asked for "underneath the icons" — not to
the side). Expanded and collapsed items share one `.nm-subitem` class so
the rename/dblclick/delete handlers (07-events.js/09-color.js) match
either without duplicating logic.

Directional-arrow rule applied app-wide per Nate's explicit instruction:
an arrow shows the direction the *toggle* will move the panel, not the
panel's current state. Left-docked sidebar: N/A now (see below); right-
docked Staging rail (`#rail-toggle`, D199) switched from the static `<>`
to a computed single arrow — expanded shows `>` (collapsing shrinks it
rightward), collapsed shows `<` (expanding grows it back left). The
sidebar's own accordion arrows are vertical per his "up and down" note:
closed shows `↓` (expanding reveals subs below), open shows `↑`
(collapsing pulls them back up). The IFR-rate arrow (D170/D188) swapped
its "◂"/"▸" triangle glyphs for plain `<`/`>` on the same complaint,
keeping its existing open/closed mapping unchanged.

The toggle itself went through two designs before landing: first a
dedicated `#sidenav-toggle` arrow button (mirroring the rail's own D199
icon) — Nate then said this was redundant with the header's hamburger
and to drop it, so `#navtoggle` (the header hamburger, now the *only*
toggle) is a plain glyph that never changes, and `#sidenav-toggle` /
`.sidenav-hd` were removed entirely.

Two more fixes landed in the same pass: the section-level "total active
orders" badge (old `.section-tab .ct`, D51) was dropped from both nav
renders — shown next to the per-sub *unplaced* counts it doesn't
reconcile with (different metrics: total active vs. unplaced-in-
scheduler), it just read as a wrong number; the per-sub counts (the
actionable ones) are all that's left. And `navSecIcon(s.k)` (hand-drawn
SVGs, one per section: truck/box/invoice/grid/bar-chart, matching the
existing `NAV_ICONS` stroke style) now renders next to the section header
in *both* collapsed (icon rail) and expanded (`.nm-sec` label) modes,
not just collapsed.

Width: `--nav-w` moved off a static per-class value onto `<body>` as a
JS-driven inline custom property (`applyNavWidth()`, 12-touch-boot.js),
exactly mirroring `--rail-w` (D44) — a `#sidenav-resize` drag handle on
the sidebar's right edge persists the width to `localStorage["navW"]`
(expanded) or `["navCW"]` (collapsed) *separately*, so switching states
always restores that state's own saved width instead of carrying the
other one over. Collapsed defaults to 96px (not a bare 64px icon strip)
specifically so a wrapped label like "Internal Freight" has room in the
accordion; both states are draggable from there (56–200px collapsed,
160–360px expanded). The fmtbar row gained a `.fmtbar-navspacer` (reads
the same inherited `--nav-w`) so the toolbar's real content starts flush
with `main`, not the sidebar — Nate: "lets move the app toolbar so it
starts without cutting into the nav menu."

Verified live at a real 1400×900 width (not the Browser pane's narrow
550px default): sidebar renders open by default with no click needed
(unlike D200's overlay); collapsing via the header hamburger swaps to the
5-icon rail and the fmtbar spacer shrinks to match; clicking a collapsed
section icon expands its accordion with legible wrapped labels and
correct per-sub badges; clicking a sub-item inside the accordion
navigates and the accordion closes; a real drag on `#sidenav-resize`
(synthetic `mousedown`/`mousemove`/`mouseup`) resized to 140px and
persisted it to `localStorage["navCW"]`; double-click on the Departments
database item (labeled "Internal Freight" there, a real name collision
with the Orders tab of the same label — expected, not a bug) opened the
inline rename input, and Escape restored the label without navigating
away; no console errors on a fresh load.

**Next step (Nate, not yet built):** Database should NOT flatten into
individual nav items the way Orders/Dispatch/Billing/Reports do. Nate:
*"the database one giant sheet like it should be seprate from the other
nav menu it needs to be a section where u click it and it just opens the
database section with those tabs and everything like how it was. the tab
menu should still be active in the database section... it needs a soft
line separater in the nav menu which also means reports can jump it in
the order."* So: Database becomes a single sidebar entry; clicking it
opens the Database section with its OLD in-page tab bar (entities/sheets/
add-database/add-sheet) restored as the way to navigate within it,
instead of those living as sidebar sub-items; a soft divider sits in the
sidebar between it and the other sections, and Reports moves ahead of
Database in nav order (currently Dispatch/Orders/Billing/Database/
Reports) since the divider changes where Database sits. Explicitly
deferred by Nate ("u dont have to make this now just ensure its the next
step") — do this before any other nav work.

### D202 — Database restored as one separated workspace in the sidebar (2026-09-11)

Completed D201's explicitly deferred next step before doing any other nav work.
Database no longer expands into entity/sheet rows in either sidebar state.
`navMenuHtml()` and `navMenuCollapsedHtml()` now render one direct Database
destination after a soft `.nm-section-div`; Reports moved ahead of it, leaving
the primary flow as Dispatch → Orders → Billing → Reports → Database. In the
collapsed rail, the Database icon navigates directly and never opens an
accordion.

The Database page again owns its spreadsheet navigation. `databaseTabsHtml()`
renders the dynamic entity and sheet list inside `#main`, using the established
`.sub-tab` component plus separate Add Database and Add Sheet controls. The old
tab behaviors therefore stay in their natural location: click navigates,
double-click renames, and right-click offers deletion only for custom databases
and sheets. The temporary D200/D201 sidebar rename/delete handlers and their
250ms click delay were removed. The Database sidebar entry returns to the last
active Database tab for the current browser session instead of resetting the
workspace to its first table.

This remains a presentation-only change: no endpoint, schema, migration,
permission, or Supabase-port behavior changed. The production port baseline was
advanced to D202 so the final hosted dashboard includes this accepted navigation
structure.

Verified against the isolated `dept12_east_test` database in both expanded and
collapsed sidebar modes: Database opened from the direct icon, the in-page tabs
switched between built-in grids, double-click entered rename and Escape restored
the original name without a write, and re-clicking Database preserved the active
External Customers tab. JavaScript syntax checks and whitespace validation also
passed.

### D203 — Collapsed Orders icon shows one reconciled order count (2026-09-11)

Nate: *"in collapse mode is there a way to have a total order count by the box
icon? i think it would be clean"*

Added one badge to the collapsed Orders icon only. Its value is the sum of the
visible Bag Orders, Internal Freight, and External Orders unplaced counts—the
same numbers shown when the Orders accordion opens. This deliberately does not
restore D51's old all-active section total, which D201 removed because it used a
different metric and appeared inconsistent beside the actionable subsection
counts. Restricted users sum only the order destinations they can view, and the
badge stays hidden when the total is zero. Expanded navigation remains unchanged.

Verified in the isolated `dept12_east_test` dashboard: collapsed Orders showed
4, and opening its accordion showed Bag Orders 2 + Internal Freight 1 + External
Orders 1. The badge remained visually separate from the arrow and the browser
reported no errors.

### D204 — Collapsed rail gains subsection-cycle arrows and matching separators (2026-09-11)

Nate: *"i think we put arrows in that space below the hamburger menu and the
icons in collapse mode that let you cycle through subsection for the section
you're in that way you dont have to click the drop down"*; then: *"also the
split between database that line ui there should be the same one used for the
arrow to icon split to maintain consistency"*.

The otherwise-empty `.fmtbar-navspacer` directly beneath the hamburger now
hosts compact `<` and `>` buttons only while the sidebar is collapsed. They
cycle backward/forward through `subsOf(SEC)`, wrap at both ends, and therefore
respect the same permission-filtered and dynamic subsection list as the sidebar
and Database tab strip. Tooltips and accessible names identify the actual
destination before each click. Both controls disable when the current section
has fewer than two visible destinations; the expanded sidebar remains unchanged.

For a consistent rail hierarchy, the spacer's collapsed-mode `::after`
divider—the separator between the arrow controls and the section icons—shares
the same 1px `--rule-2` treatment and physical side inset as `.nm-section-div`
above Database. No additional divider style or color was introduced.

### D205 — Plain compact rail controls and a fixed-open formatting toolbar (2026-09-11)

Nate: *"i think we get rid of the button aesthetic on the internal freight and
staging collapse menu and just have the < > icons alone, i think we remove the
collapsability of the toolbar and solidfy the ui more and we add that internal
rate collapse bar in the top right of the tool bar"*; then: *"i also dont think
the nav arrows should have button design im okay with just the arrows being
there and making them smaller so i can move that menu as far to the left as
possible"*.

All three horizontal disclosure/cycle control families now share one quiet
treatment: plain angle glyphs with no border, fill, radius, or hover block. The
collapsed navigation cycler uses 16px hit columns and the Staging toggle uses a
14px column; Internal Rate uses the same bare-glyph language. Their existing
direction contract is unchanged: each glyph points where clicking it will move.

The collapsed sidebar's minimum draggable width dropped from 56px to 44px while
retaining its 96px default and independent saved width. At that minimum, the two
16px cycler glyphs plus their gap and inset fit without forcing the rail wider.
The line below them uses the exact same 1px `--rule-2` rule and physical side
inset as the Database divider.

The cell-formatting toolbar is now permanently open. Its collapse/expand button,
`FMTBAR_OPEN`, `localStorage.fmtbarOpen`, collapsed rendering branch, and
collapsed CSS treatment were removed. On Orders pages, the Internal Rate toggle
and its expanded rate/minimum inputs now sit at the far-right edge of this global
toolbar. The three order trackers retain Sync mileage and Sync delivery dates in
their page-specific action toolbar, without a duplicate Internal Rate control.
Non-Orders pages do not render Internal Rate in the global toolbar.

This is a shell/UI refinement only: no endpoint, schema, migration, permission,
rate calculation, or Supabase-port behavior changed. The production feature
baseline advances to D205.

Verified live against the isolated `dept12_east_test` dashboard at both the
96px default and 44px minimum collapsed widths: the plain cycler remained
usable, its divider aligned with Database, the Orders count remained attached
to the box icon, and expanding the sidebar hid the cycler. Bag Orders showed
Internal Rate only in the global toolbar and retained both sync actions in its
page toolbar; the rate fields expanded in place, and the plain Staging arrow
collapsed/reopened its rail. The assembled client passed JavaScript syntax and
whitespace checks, and the browser reported no errors.

### D206 — The hamburger and header respect the sidebar shell boundary (2026-09-11)

Nate: *"i think the nav menu like the hamburger part pf the nav menu should be
in the nav menu's ui not in the header, the header with thes search bar should
begin when the nav menu stops does that make sense?"*

The top row now mirrors the two rows below it. A dedicated `.nav-head` cell owns
the hamburger and reads the same `--nav-w` as `#sidenav` and
`.fmtbar-navspacer`; the real `<header>` begins immediately after that cell and
contains only the Rexius lockup, search, connection status, and profile. When
the sidebar is resized or collapsed, all three boundaries move together without
duplicate JavaScript sizing logic.

`.nav-head` shares the sidebar's panel background and right rule, making the
left navigation one continuous visual column from the top of the app to the
bottom. The app header keeps its existing height and bottom rule, but no longer
runs behind or across navigation. Print and pre-auth hiding were updated to hide
the entire `.header-row`, so the new nav-owned top cell cannot remain visible by
itself.

This is shell structure and presentation only. Navigation behavior, persisted
widths, permissions, APIs, schema, migrations, and the Supabase production port
remain unchanged; its feature baseline advances to D206.

### D207 — Collapsed section icons navigate; their arrows only disclose (2026-09-11)

Nate: *"since we have those arrows the user needs to be able to click the icon
and open up that secion in collapse mode or click the dropdown arrow in the
section to directly navigate to that section"*.

The collapsed rail no longer makes the icon and vertical arrow one large shared
button. Each section now has two independent targets: clicking its icon opens
the section immediately at its current visible subsection, or its first
permission-visible subsection when entering from elsewhere; clicking the plain
`↓`/`↑` arrow only expands or collapses that section's subsection choices. A
subsection choice still navigates directly, and the top `<`/`>` cycler still
moves between subsections once the user is inside the section.

The active and hover backgrounds live on a shared `.nm-crow` wrapper so the
split hit targets still read as one compact section unit. Database remains the
intentional exception: it has no sidebar subsection dropdown and its single
icon continues to open the in-page Database workspace directly.

This changes only collapsed navigation interaction and markup. Permissions,
counts, expanded navigation, APIs, schema, migrations, and Supabase behavior are
unchanged; the production feature baseline advances to D207.

Verified live against `dept12_east_test` at the 44px collapsed minimum and at
160px/220px expanded widths. The nav-owned hamburger cell, formatting-toolbar
spacer, sidebar, and main header/content boundary remained aligned through
collapse and a real resize drag. With the subsection list closed, clicking the
Orders box opened Bag Orders without expanding the list; clicking the separate
down arrow then exposed all three Orders destinations without navigating; the
top next arrow moved from Bag Orders to Internal Freight while preserving the
open dropdown. Accessible labels reflected each action and the browser reported
no errors.

### D208 — Narrow screens use a touch navigation drawer (2026-09-11)

Nate: *"then you need to redesign how it works on mobile just make sure it does
work on mobile u can do whatever u need to do to ensure thats the case im okay
if the app reads device i know right now it used to read aspect ratio but
whatever u gotta do to make itw ork with a touch screen is good w me"*

At 980px and below, the desktop navigation column now becomes a full-label
off-canvas drawer beneath the 52px top row. The hamburger opens it, and choosing
a destination, tapping the backdrop, pressing `Escape`, or returning to a wide
viewport closes it. This temporary `MOBILE_NAV_OPEN` state never overwrites the
user's persisted desktop expanded/collapsed preference. The hamburger exposes
the drawer state through its accessible label and `aria-expanded`; the
backdrop is removed from keyboard order while closed.

The narrow body is one column. Desktop-only Staging and History rails and their
resizers are hidden, while the fixed formatting toolbar scrolls horizontally
instead of wrapping. The rail selector is deliberately scoped to direct body
children so the order drawer—also an `aside`—continues to work on mobile. Form
controls use 16px text to prevent focus zoom. Available width chooses the
layout; `pointer:coarse` separately provides larger touch targets on hardware
such as wide landscape tablets. No user-agent or device-name sniffing was
introduced.

This is client shell behavior only. APIs, data, permissions, schema,
migrations, email, and the Supabase production port remain unchanged; the
production feature baseline advances to D208.

### D209 — Bare arrow keys cycle navigation only when the workspace is idle (2026-09-11)

Nate: *"i'd also like keyboard shortcuts for the arrows, maybe hitting arrow
keys when nothing is selected triggers the nav arrows? as long as escape is
what gets u out of selections i dont think that will conflict w anything."*
Nate also noted: *"the hamburger menu isnt centered in its little square"*.

Bare Left/Right now calls the same wrapped subsection cycler as the plain
toolbar glyphs. The shortcut is intentionally conservative: it does nothing
while editing, while a cell/range/row is selected, while a form control or
contenteditable element has focus, while a drawer/menu/modal is open, when a
modifier is held, or when the same key combination has a configured shortcut.
That preserves existing spreadsheet arrow navigation and makes `Escape` the
clear handoff from selection mode back to section cycling.

The nav-owned hamburger cell now centers its only control horizontally and
vertically at expanded, collapsed, and narrow-screen widths. This corrects the
visual offset without adding button chrome or changing the shared sidebar,
toolbar, and content boundary.

This changes navigation input and alignment only. APIs, permissions, stored
data, schema, migrations, and Supabase behavior are unchanged; the production
feature baseline advances to D209.

### D210 — The formatting toolbar matches the lighter app shell (2026-09-11)

Nate: *"i dont want the tool bar to be as dark as it is, it doesnt match the
rest of the app."*

The global cell-formatting toolbar now uses `--panel`, the same warm surface as
the header and navigation shell, instead of the darker `--panel-2` treatment
used by table headers and tab bars. Individual controls keep their borders, and
hover feedback moves to `--panel-2` so the toolbar remains readable and
interactive without presenting as a heavy horizontal band. The change follows
the existing light/dark theme tokens and requires no theme-specific literals.

This is presentation only. Toolbar behavior, navigation, APIs, permissions,
data, schema, migrations, and Supabase behavior are unchanged; the production
feature baseline advances to D210.

### D211 — Order trackers use a joined workflow control and dedicated Open column (2026-09-11)

All three trackers place a dedicated Open column after the numbered selection
gutter, making it the only order-drawer target inside editable tracker tables.
The adjacent fixed-width workflow control keeps Status, Copy, and optional
Stage/Restore segments vertically aligned; the final segment folds away when it
is unavailable. Copy is available across all three trackers. This was a
presentation and click-target change only; order state and APIs were unchanged.

### D212 — Staging filter focus matches global Search (2026-09-11)

The staging rail's Filter Staged Loads input now uses the same focus treatment
as the header Search input: its existing border changes to `--focus` instead of
adding a separate outer outline. Filtering, search, keyboard behavior, APIs,
data, schema, and Supabase behavior are unchanged.

### D213 — Typography, navigation, and selection use one visual system (2026-09-11)

Nate asked for a dashboard-wide unification pass after noticing inconsistent
font sizes and square-looking navigation states, then clarified that selection
and the Scheduler's current-day marker should match the chosen accent. He also
preferred the smaller Orders sync-button treatment for every action in that
toolbar.

All static interface font sizes now use the existing eight-step type tokens;
the protected Dept 12 header lockup remains unchanged, as do user-selected
per-cell font sizes and font-picker previews. Interface copy continues to use
`--font`, while compact labels, counts, statuses, and tabular values use
`--mono`. Tracker, general, and History status labels now share caption sizing,
weight, spacing, and the large-radius capsule language.

Sidebar section labels use the mono caption treatment, destinations use the
compact body size, and selected destination surfaces use `--r-lg`. All `.ct`
order counts share one capsule base instead of separate expanded/collapsed
font sizes and shapes. The Orders toolbar now applies `.btn.sm` to Sync
Mileage, Sync Delivery Dates, Cancel Selected, Delete Selected, and New/Add
Orders, with Title Case labels throughout. Its action row remains single-line
and scrolls horizontally if space is unusually narrow instead of orphaning the
primary action on a second row.

`--focus` and `--focus-soft` now alias `--brand` and `--brand-soft`. Existing
selection, field-focus, drag/drop, and Today-marker selectors keep their
semantic focus-token names, but automatically follow the user's accent. Billed,
delivered, warning, and cancelled colors remain separate lifecycle semantics.

This is presentation only. Navigation behavior, order actions, filtering,
data, APIs, schema, permissions, migrations, and Supabase behavior are
unchanged; the production feature baseline advances to D213.
