# Future TMS — Google Apps Script

## What This Is
A Google Apps Script bound to the **"future TMS"** Google Sheet used for Rexius trucking load scheduling and dispatch. It manages driver load assignments, syncs schedules to a read-only mirror spreadsheet for drivers, and connects order trackers with customer data.

- **Script ID:** `1CpJeAMukE5rseJwV13FfDfqX1eEkzWAjKW3NogqcbTGZAjSZePGP09ke`
- **Sheet ID:** `1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4`
- **Mirror Sheet ID:** `15f12Q0Nz4NFNUwbtQ7NgE7eCwSfqx3ai0VJAeZjtKJs` (read-only copy drivers see)
- **Owner:** nathanl@rexius.com
- **Runtime:** V8 (see appsscript.json)
- **Status:** Test environment, not yet live

## Deployment
- Managed via **clasp** (Google's CLI for Apps Script)
- GitHub Actions auto-deploys on push to `main` — runs `clasp push --force`
- Clasp credentials stored as `CLASPRC_JSON` GitHub secret (Rexius Google account)
- Repo: `NateTooNice/SHEETS-TMS-APPSCRIPT` (private)

## Sheet Tabs & Layout

### SCHEDULER
The main scheduling grid.
- **A:C** — "LOADS" staging area (unassigned load chips waiting to be placed)
- **D** — DATE column (3 rows per business day: 1 visible + 2 hidden with white font)
- **E onward** — Driver columns (one per driver, chips placed here = assigned)
- Row 1 = headers, data starts at row 2
- Thick black top border on each visible date row separates days

### Current Week
5-day view copied from SCHEDULER, mirrored to the driver-facing spreadsheet.
- **A** — Color legend (Green=Early Store, Yellow=Anytime, Dark Yellow=Early EAST, Brown=Anytime EAST)
- **B** — Date
- **C onward** — Driver columns (same order as SCHEDULER E onward)
- Row 1 = headers with driver names
- Rows 2-16 = data (5 days × 3 rows each), row 17+ preserved during refresh

### External Order Tracker
Orders from outside brokers/carriers.
- **A** = Order #
- **B** = Load #
- **C** = Broker/Customer (dropdown)
- **D** = PU/PO
- **E** = Delivery #
- **F** = Notes (appointment info, tarp requirements, etc.) — piped to driver tab col D
- **G** = Pickup Address (dropdown)
- **H** = Delivery Address (dropdown)
- **I** = Driver Load Chip (formatted text block with pick/drop details)
- **J** = Dispatch Load Chip (condensed version: "P: location | city\nD: location | city")
- **K** = Pickup Google Maps link
- **L** = Delivery Google Maps link
- Row 1 = headers, data starts at row 2

### Internal Order Tracker
Monthly repeating columns for internal (Rexius) orders.
- Grouped by month (JAN–JUL) with color-coded month headers, then **OFF SZN** (AX–BD) for Aug–Dec orders
- Each 7-column block repeats: Order #, PAL, Customer, Order Date, [Early/Any or blank], Delivery Date, LOAD CHIP
- **Chip columns** (the LOAD CHIP column for each block): G, N, U, AB, AI, AP, AW, BD
- **Order # is always 6 columns left** of the chip column (G→A, N→H, BD→AX, etc.)
- Delivery Date is always 1 column left of the chip column (synced by `syncDeliveryDates`)
- Row 1 = month headers, row 2 = column labels, data starts at row 3
- `syncDeliveryDates` matches by **order number** (substring match in scheduler cells), not chip text

### Bagger Customers
Customer directory for bag product deliveries.
- **A** = Customer name
- **B** = Address
- **C** = City
- **D** = State
- **E** = Forklift type (NF, Forklift, Spyder)
- **F** = Early/Anytime/Umatilla designation
- **G** = Notes
- **H** = LOAD CHIPS (formatted chip text)
- **I** = Phone
- **J** = Manager Name
- **N (col 14)** = Map URL (used by `findStoreMapUrlFromChip` for STORE MAP links in driver tabs)
- Row 1 = headers, data starts at row 2

### Outside Customer List
Broker/carrier directory with AP billing info.
- **A** = Customer/Broker name
- **B** = Notes
- **C** = AP Email
- Not directly referenced by current script code

### Pick/Drop List
Company address directory used for dropdown data validation in other sheets.
- **A** = App? (appointment required indicator)
- **B** = Company Name
- **C** = Address
- **D** = City
- **E** = State
- **F** = Phone Number
- **G** = Dropdown List (concatenated string: "Company, Address, City State, Phone")
- Not directly referenced by current script code, but feeds dropdowns in External Order Tracker

### FLEET/DRIVERS (tab partially visible)
Driver/fleet info — not referenced by current script code.

## How the Script Works

### Menu Structure (created in `onOpen`)
1. **Formatting Tools** — EOY schedule generation, date borders, clear date ranges
2. **Navigation** — Jump to top/bottom of External Order Tracker or Scheduler
3. **Update Schedules** — Sync delivery dates, update Current Week, update driver tabs, manual mirror push
4. **Assign Loads** — Copy selected loads to scheduler, send all staged loads to today

### Key Workflows

**Load Assignment Flow:**
1. User selects load chip cells on any sheet
2. "Assign Load" (`copySelectionToScheduler`) places them in first open A:C slots on SCHEDULER
3. "Send loads to today" (`assignLoadsForToday`) shifts all staged A:C chips to start at today's date row
4. User manually drags chips from A:C into driver columns (E onward)

**Schedule Sync Flow:**
1. "Update Current Week" (`updateCurrentWeek`) copies next 5 business days from SCHEDULER into Current Week tab, then mirrors to driver spreadsheet
2. "Update Driver Tabs" (`runDriverUpdate`) builds per-driver sheets in the mirror with:
   - Dates from Current Week col B
   - Load chips with formatting
   - Pickup/Drop info pulled from External Order Tracker (matched by chip key)
   - STORE MAP links pulled from Bagger Customers (matched by customer name)
3. "Sync Delivery Dates" (`syncDeliveryDates`) writes delivery dates back into Internal Order Tracker by matching chip text in the scheduler grid to chip columns

**Chip Key Matching:**
- `extractExternalKeyFromChip(chipText)` parses chip text by splitting on " - " and checking parts against the External Order Map
- `findStoreMapUrlFromChip(chipText)` does case-insensitive substring matching against Bagger Customer names

### Mirror Spreadsheet
- ID: `15f12Q0Nz4NFNUwbtQ7NgE7eCwSfqx3ai0VJAeZjtKJs`
- Contains a "Current Week" sheet (copy of the main sheet's Current Week tab)
- Contains per-driver sheets (named after driver, e.g. "WAYNE 31 BT") with their assigned loads, pickup/drop details, and store map links
- Rebuilt on each update (existing sheet deleted, new copy placed at position 1)

## Constants (top of Code.js)
All hardcoded values are now extracted as named constants:
```
// IDs
MIRROR_SHEET_ID          = '15f12Q0Nz4NFNUwbtQ7NgE7eCwSfqx3ai0VJAeZjtKJs'

// Sheet names
SHEET_SCHEDULER, SHEET_CURRENT_WEEK, SHEET_EXT_TRACKER, SHEET_INT_TRACKER, SHEET_BAGGER

// Scheduler layout
LOAD_CHIP_RANGE          = 'A2:C7'
SCHED_DATE_COL           = 4    // D
SCHED_DATE_START_ROW     = 2
SCHED_LOAD_START_COL     = 1    // A
SCHED_LOAD_NUM_COLS      = 3    // A:C
SCHED_GRID_START_COL     = 5    // E

// External Order Tracker columns
EXT_NOTES_COL            = 6    // F
EXT_DRIVER_COL           = 9    // I
EXT_PICKUP_COL           = 11   // K
EXT_DROP_COL             = 12   // L

// Internal Order Tracker
INT_TRACKER_CHIP_COLS    = ['G','N','U','AB','AI','AP','AW','BD']

// Bagger Customers
BAGGER_MAP_URL_COL       = 14   // N

// Current Week
CW_PRESERVE_ROW          = 20

// Border walls — black-fill boundaries so drivers can't scroll into empty space
// UPDATE THESE if you add more drivers or change the layout
CW_WALL_ROW              = 20   // Current Week: black fill from this row down
CW_WALL_COL              = 16   // Current Week: black fill from this column right (P) — room for ~4 more drivers
DT_WALL_ROW              = 20   // Driver tabs: black fill from this row down
DT_WALL_COL              = 10   // Driver tabs: black fill from this column right (J)

// Driver tab columns (mirror)
DRIVER_DATE_COL          = 2    // B
DRIVER_CHIP_COL          = 3    // C
DRIVER_NOTES_COL         = 4    // D
DRIVER_PICKUP_COL        = 5    // E
DRIVER_DROP_COL          = 6    // F
DRIVER_STORE_COL         = 7    // G
```

## Utility Functions
- `log(fn, msg)` — logs to Cloud Logging with function prefix
- `normalizeDate(d)` — strips time component from a Date
- `getSheetOrAlert(ss, name)` — gets sheet by name with user alert on null
- `pushSheetToMirror(sourceSheet, sheetName)` — safe copy-then-delete mirror push
- `applyBlackWalls(sheet, wallRow, wallCol)` — fills black from wallRow down and wallCol right, prevents driver doomscrolling
- `getDriverHeaders(sched)` — reads driver names and columns from SCHEDULER row 1
- `findOutsideCarriersCol(sched)` — finds the Outside Carriers column position

## Fleet Management Menu
Drivers are managed via the "Fleet Management" menu:
- **Add Driver** — inserts column in SCHEDULER (before Outside Carriers) and Current Week, creates mirror tab
- **Rename / Swap Truck** — renames a driver's header across all sheets and mirror tab
- **Swap Trucks Between Drivers** — swaps truck numbers between two drivers atomically
- **Remove Driver** — hides (not deletes) column and mirror tab, preserving data

## Fleet
- Currently 7 drivers: Wayne 31 BT, Jon 33 BT, Jordan 63/80 F, Larry 72 F, James 39 F, Joe 162 CV, Brian 62 F
- Plus: 63 F, 135 BT, Outside Carriers columns on SCHEDULER
- Building toward 10+ drivers — code is optimized for that scale (batched writes, cached mirror ref)
