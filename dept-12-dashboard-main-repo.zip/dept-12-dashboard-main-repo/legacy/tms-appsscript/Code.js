const MIRROR_SHEET_ID = '15f12Q0Nz4NFNUwbtQ7NgE7eCwSfqx3ai0VJAeZjtKJs';

// ============================
// SHEET NAMES
// ============================
const SHEET_SCHEDULER    = 'SCHEDULER';
const SHEET_CURRENT_WEEK = 'Current Week';
const SHEET_EXT_TRACKER  = 'External Order Tracker';
const SHEET_INT_TRACKER  = 'Internal Order Tracker';
const SHEET_BAGGER       = 'Bagger Customers';

// ============================
// SCHEDULER LAYOUT
// ============================
const LOAD_CHIP_RANGE      = 'A2:C7';
const SCHED_DATE_COL       = 4; // D
const SCHED_DATE_START_ROW = 2;
const SCHED_LOAD_START_COL = 1; // A
const SCHED_LOAD_NUM_COLS  = 3; // A:C
const SCHED_GRID_START_COL = SCHED_DATE_COL + 1; // E

// ============================
// EXTERNAL ORDER TRACKER COLUMNS
// ============================
const EXT_NOTES_COL  = 6;  // F - Notes (appointment info, tarp, etc.)
const EXT_DRIVER_COL = 9;  // I - Driver Load Chip
const EXT_PICKUP_COL = 11; // K - Pickup rich text
const EXT_DROP_COL   = 12; // L - Drop rich text

// ============================
// INTERNAL ORDER TRACKER
// ============================
const INT_TRACKER_CHIP_COLS = ['G','N','U','AB','AI','AP','AW','BD'];
const INT_TRACKER_ORDER_OFFSET = 6; // Order # column is 6 cols left of LOAD CHIP

// ============================
// BAGGER CUSTOMERS
// ============================
const BAGGER_MAP_URL_COL = 14; // N - Store map URL

// ============================
// CURRENT WEEK LAYOUT
// ============================
const CW_PRESERVE_ROW = 20; // Rows below this are not cleared during refresh (6 days × 3 rows + header)

// ============================
// BORDER WALLS — black-fill boundaries so drivers can't scroll into empty space
// Update these if you add more drivers or change the layout
// ============================
const CW_WALL_ROW  = 20; // Current Week: black fill starts at this row
const CW_WALL_COL  = 16; // Current Week: black fill starts at this column (P)
const DT_WALL_ROW  = 20; // Driver tabs: black fill starts at this row
const DT_WALL_COL  = 10; // Driver tabs: black fill starts at this column (J)

// ============================
// DRIVER TAB COLUMNS (mirror spreadsheet)
// ============================
const DRIVER_DATE_COL   = 2; // B
const DRIVER_CHIP_COL   = 3; // C
const DRIVER_NOTES_COL  = 4; // D
const DRIVER_PICKUP_COL = 5; // E
const DRIVER_DROP_COL   = 6; // F
const DRIVER_STORE_COL  = 7; // G

function log(fn, msg) {
  console.log('[' + fn + '] ' + msg);
}

function normalizeDate(d) {
  const n = new Date(d);
  n.setHours(0, 0, 0, 0);
  return n;
}

function getSheetOrAlert(ss, name) {
  const sheet = ss.getSheetByName(name);
  if (!sheet) SpreadsheetApp.getUi().alert('Sheet "' + name + '" not found.');
  return sheet;
}

/**
 * Safely copies a sheet to the mirror spreadsheet, replacing any existing sheet
 * with the same name. Copies first, then deletes old — so drivers never lose
 * their view if something fails mid-operation.
 */
function applyBlackWalls(sheet, wallRow, wallCol) {
  const maxRows = sheet.getMaxRows();
  const maxCols = sheet.getMaxColumns();

  // Paint the wall row black
  sheet.getRange(wallRow, 1, 1, wallCol).setBackground('#000000').clearContent();
  // Paint the wall column black
  sheet.getRange(1, wallCol, wallRow, 1).setBackground('#000000').clearContent();

  // Delete everything past the wall
  if (maxRows > wallRow) {
    sheet.deleteRows(wallRow + 1, maxRows - wallRow);
  }
  if (maxCols > wallCol) {
    sheet.deleteColumns(wallCol + 1, maxCols - wallCol);
  }
}

function pushSheetToMirror(sourceSheet, sheetName) {
  log('pushSheetToMirror', 'Pushing "' + sheetName + '" to mirror');
  const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  const existing = destSS.getSheetByName(sheetName);

  try {
    const newSheet = sourceSheet.copyTo(destSS);
    newSheet.setName(sheetName + '_temp');

    if (existing) destSS.deleteSheet(existing);

    newSheet.setName(sheetName);
    destSS.setActiveSheet(newSheet);
    destSS.moveActiveSheet(1);
  } catch (e) {
    SpreadsheetApp.getUi().alert('Failed to update mirror sheet “' + sheetName + '”: ' + e.message);
  }
}

/**
 * Adds custom menus when the spreadsheet opens.
 */
function onOpen() {
  const ui = SpreadsheetApp.getUi();
  
  ui.createMenu('🔧 Formatting Tools')
    .addItem('EOY Update Schedule', 'generateBusinessDaysForYear')
    .addItem('Refresh Date Borders', 'applyDateBordersManually')
    .addItem('Clear Scheduler Date Range', 'clearSchedulerDateRange')
    .addToUi();

  ui.createMenu('🧭 Navigation')
    .addItem('Top External Order', 'goToTopExternalOrder')
    .addItem('Bottom External Order', 'goToFirstOpenExternalOrder')
    .addItem('Top Scheduler', 'goToTopScheduler')
    .addItem('Bottom Scheduler', 'goToTodayInScheduler')
    .addToUi();
  
  ui.createMenu('🚚 Update Schedules')
    .addItem('Publish to Drivers (Full Week)', 'publishFullWeek')
    .addItem('Publish to Drivers (Partial)', 'publishPartialWeek')
    .addItem('Push & Update Mirror', 'pushAndUpdateMirror')
    .addToUi();

  ui.createMenu('📅 Assign Loads')
    .addItem('Assign Load', 'copySelectionToScheduler')
    .addToUi();

  ui.createMenu('🚛 Fleet Settings')
    .addItem('Add Driver', 'addDriver')
    .addItem('Rename / Swap Truck', 'renameDriver')
    .addItem('Sync Delivery Dates', 'syncDeliveryDates')
    .addItem('Manual Update Current Week', 'manualUpdateCurrentWeek')
    .addItem('Manual Update Driver Tabs', 'runDriverUpdate')
    .addItem('Manual Push Mirror', 'pushCurrentWeekToMirror')
    .addToUi();
}

/**
 * Prompts for a year, then builds that year’s business-day schedule on SCHEDULER:
 * each business day is written in three rows (date + 2 “hidden” rows with white text).
 *
 * ✅ UPDATED: dates now write to column D (SCHED_DATE_COL)
 */
function generateBusinessDaysForYear() {
  const ui   = SpreadsheetApp.getUi();
  const resp = ui.prompt(
    'Generate Business-Day Schedule',
    'Enter the year (e.g. 2025):',
    ui.ButtonSet.OK_CANCEL
  );
  if (resp.getSelectedButton() !== ui.Button.OK) return;

  const year = parseInt(resp.getResponseText().trim(), 10);
  if (isNaN(year) || year < 1900 || year > 9999) {
    ui.alert('Please enter a valid 4-digit year.');
    return;
  }

  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sheet) return;

  // 1) Clear old dates & reset font color in DATE column
  const maxRows   = sheet.getMaxRows();
  const dateRange = sheet.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, maxRows - 1, 1);
  dateRange.clearContent();
  dateRange.setFontColor(null);

  // 2) Loop through every day of the chosen year
  const startDate = new Date(year, 0, 1);
  const endDate   = new Date(year, 11, 31);
  let writeRow    = SCHED_DATE_START_ROW;

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const dow = d.getDay(); // 0=Sun,6=Sat
    if (dow > 0 && dow <= 6) {  // Mon–Sat
      // write date + two hidden rows
      for (let i = 0; i < 3; i++) {
        const cell = sheet.getRange(writeRow + i, SCHED_DATE_COL)
          .setValue(new Date(d))
          .setNumberFormat('m/d/yy - ddd');
        if (i > 0) cell.setFontColor('white');
      }
      writeRow += 3;
    }
  }

  ui.alert(`Built ${year} schedule with Mon-Sat (3 rows per date).`);
}

/**  
 * Applies the thickest possible black TOP border across columns D→last column
 * on each “visible” date row in SCHEDULER (non-white font date rows).
 *
 * ✅ UPDATED: date column is D
 * ✅ UPDATED: greys empty load slots across A2:C7
 */
function applyDateBordersManually() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < SCHED_DATE_START_ROW) return;

  const dateRange  = sheet.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, lastRow - 1, 1);
  const dates      = dateRange.getValues().flat();
  const fontColors = dateRange.getFontColors().flat();

  for (let i = 0; i < dates.length; i++) {
    const d  = dates[i];
    const fc = (fontColors[i] || '').toLowerCase();
    if (d instanceof Date && fc !== '#ffffff') {
      const row = i + SCHED_DATE_START_ROW;
      // border across D → lastCol
      sheet.getRange(row, SCHED_DATE_COL, 1, lastCol - SCHED_DATE_COL + 1)
        .setBorder(
          /* top */ true, /* left */ false, /* bottom */ false, /* right */ false,
          /* vertical */ false, /* horizontal */ false,
          'black', SpreadsheetApp.BorderStyle.SOLID_THICK
        );
    }
  }

}

/**
 * Assigns whatever cells you SELECT (supports cmd+click multi-range)
 * directly into SCHEDULER, filling the first open spot starting at A2,
 * scanning row-major across A→B→C then next row.
 *
 * ✅ UPDATED: destination is A:C (since dates are now in D)
 * ✅ Preserves formatting (background, font color, weight)
 * ✅ Does NOT overwrite existing values in Scheduler
 */
function copySelectionToScheduler() {
  const ss  = SpreadsheetApp.getActiveSpreadsheet();
  const src = ss.getActiveSheet();

  const rangeList = src.getActiveRangeList();
  const ranges = rangeList ? rangeList.getRanges() : [src.getActiveRange()];

  // Pull selected cells row-major, preserve formatting
  const items = [];
  ranges.forEach(range => {
    const v2d  = range.getValues();
    const bg2d = range.getBackgrounds();
    const fc2d = range.getFontColors();
    const fw2d = range.getFontWeights();
    v2d.forEach((row, i) => {
      row.forEach((v, j) => {
        if (v === '' || v === null) return;
        items.push({ v, bg: bg2d[i][j], fc: fc2d[i][j], fw: fw2d[i][j] });
      });
    });
  });

  if (items.length === 0) {
    SpreadsheetApp.getUi().alert('No loads selected to assign.');
    return;
  }

  const sched = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sched) return;

  // Check for duplicates against everything already on the SCHEDULER
  const schedLastRow = sched.getLastRow();
  const schedLastCol = sched.getLastColumn();
  const existingVals = new Set();

  if (schedLastRow >= 2 && schedLastCol >= 1) {
    const allData = sched.getRange(2, 1, schedLastRow - 1, schedLastCol).getDisplayValues();
    allData.forEach(row => {
      row.forEach(cell => {
        const v = (cell || '').toString().trim();
        if (v) existingVals.add(v);
      });
    });
  }

  const dupes = [];
  const uniqueItems = items.filter(item => {
    const val = (item.v || '').toString().trim();
    if (existingVals.has(val)) {
      dupes.push(val);
      return false;
    }
    existingVals.add(val);
    return true;
  });

  if (dupes.length > 0) {
    SpreadsheetApp.getUi().alert('Skipped ' + dupes.length + ' duplicate load(s):\n' + dupes.join('\n'));
  }

  if (uniqueItems.length === 0) return;

  // Find today's row in the date column
  const today = normalizeDate(new Date());
  const dateVals = sched.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, schedLastRow - 1, 1).getValues().flat();

  let startRow = 2;
  for (let i = 0; i < dateVals.length; i++) {
    if (dateVals[i] instanceof Date && normalizeDate(dateVals[i]).getTime() === today.getTime()) {
      startRow = i + SCHED_DATE_START_ROW;
      break;
    }
  }

  const lastRow  = Math.max(schedLastRow, startRow);
  const numRows  = Math.max(1, lastRow - startRow + 1);

  // Read A:C grid from today's row downward
  const destRange = sched.getRange(startRow, SCHED_LOAD_START_COL, numRows, SCHED_LOAD_NUM_COLS);
  const destVals  = destRange.getValues();
  const destBgs   = destRange.getBackgrounds();
  const destFcs   = destRange.getFontColors();
  const destFws   = destRange.getFontWeights();

  // Fill in first open spots row-major
  let idx = 0;
  for (let r = 0; r < destVals.length && idx < uniqueItems.length; r++) {
    for (let c = 0; c < SCHED_LOAD_NUM_COLS && idx < uniqueItems.length; c++) {
      if (destVals[r][c]) continue;
      destVals[r][c] = uniqueItems[idx].v;
      destBgs[r][c]  = uniqueItems[idx].bg;
      destFcs[r][c]  = uniqueItems[idx].fc;
      destFws[r][c]  = uniqueItems[idx].fw;
      idx++;
    }
  }

  // Write back what we filled
  destRange
    .setValues(destVals)
    .setBackgrounds(destBgs)
    .setFontColors(destFcs)
    .setFontWeights(destFws)
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle')
    .setWrap(true);

  // If more loads remain, append rows and keep filling
  const remaining = uniqueItems.slice(idx);
  if (remaining.length > 0) {
    const rowsNeeded = Math.ceil(remaining.length / SCHED_LOAD_NUM_COLS);

    const currentMaxRows = sched.getMaxRows();
    const neededMaxRows  = lastRow + rowsNeeded;
    if (neededMaxRows > currentMaxRows) {
      sched.insertRowsAfter(currentMaxRows, neededMaxRows - currentMaxRows);
    }

    const newVals = Array.from({ length: rowsNeeded }, () => Array(SCHED_LOAD_NUM_COLS).fill(''));
    const newBgs  = Array.from({ length: rowsNeeded }, () => Array(SCHED_LOAD_NUM_COLS).fill('#ffffff'));
    const newFcs  = Array.from({ length: rowsNeeded }, () => Array(SCHED_LOAD_NUM_COLS).fill('#000000'));
    const newFws  = Array.from({ length: rowsNeeded }, () => Array(SCHED_LOAD_NUM_COLS).fill('normal'));

    let k = 0;
    for (let r = 0; r < rowsNeeded; r++) {
      for (let c = 0; c < SCHED_LOAD_NUM_COLS; c++) {
        if (k >= remaining.length) break;
        newVals[r][c] = remaining[k].v;
        newBgs[r][c]  = remaining[k].bg;
        newFcs[r][c]  = remaining[k].fc;
        newFws[r][c]  = remaining[k].fw;
        k++;
      }
    }

    const appendStartRow = lastRow + 1;
    const appendRange = sched.getRange(appendStartRow, SCHED_LOAD_START_COL, rowsNeeded, SCHED_LOAD_NUM_COLS);
    appendRange
      .setValues(newVals)
      .setBackgrounds(newBgs)
      .setFontColors(newFcs)
      .setFontWeights(newFws)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle')
      .setWrap(true);
  }
}

/**
 * Jumps the view to the first empty cell in column A of the
 * "External Order Tracker" sheet (starting at A2).
 */
function goToFirstOpenExternalOrder() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_EXT_TRACKER);
  if (!sheet) return;
  ss.setActiveSheet(sheet);

  const values  = sheet.getRange('A2:A').getValues().flat();
  let targetRow = values.findIndex(v => v === '' || v === null) + 2;
  if (targetRow < 2) targetRow = sheet.getLastRow() + 1;

  sheet.getRange(targetRow, 1).activate();
}

/**
 * Jumps the view to cell A2 of the
 * "External Order Tracker" sheet.
 */
function goToTopExternalOrder() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_EXT_TRACKER);
  if (!sheet) return;
  ss.setActiveSheet(sheet);
  sheet.getRange('A2').activate();
}

/**
 * Jumps the view to today’s date in the DATE column (now D) of the SCHEDULER sheet.
 */
function goToTodayInScheduler() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sheet) return;

  const today = normalizeDate(new Date());

  const lastRow = sheet.getLastRow();
  if (lastRow < SCHED_DATE_START_ROW) {
    SpreadsheetApp.getUi().alert('No dates found in Scheduler.');
    return;
  }

  const vals = sheet.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, lastRow - 1, 1).getValues();

  for (let i = 0; i < vals.length; i++) {
    const cellVal = vals[i][0];
    if (cellVal instanceof Date) {
      const d = normalizeDate(cellVal);
      if (d.getTime() === today.getTime()) {
        const row = i + SCHED_DATE_START_ROW;
        sheet.activate();
        sheet.getRange(row, SCHED_DATE_COL).activate();
        return;
      }
    }
  }
  SpreadsheetApp.getUi().alert('Today\'s date not found in Scheduler date column.');
}

/**
 * Jumps the view to cell A2 of the "SCHEDULER" sheet.
 */
function goToTopScheduler() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sheet) return;
  ss.setActiveSheet(sheet);
  sheet.getRange('A2').activate();
}

/**
 * Syncs delivery dates back into the Internal Order Tracker.
 *
 * ✅ UPDATED for new Scheduler layout:
 * - Dates live in column D
 * - Chips we want to map live in columns E→end (to the right of the date column)
 */
function syncDeliveryDates() {
  const ss      = SpreadsheetApp.getActiveSpreadsheet();
  const tracker = getSheetOrAlert(ss, SHEET_INT_TRACKER);
  if (!tracker) return;
  const sched = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sched) return;

  log('syncDeliveryDates', 'Starting');

  const sLastRow = sched.getLastRow();
  const sLastCol = sched.getLastColumn();
  if (sLastRow < SCHED_DATE_START_ROW || sLastCol < SCHED_GRID_START_COL) return;

  // Build a map: for each cell in the scheduler driver grid,
  // extract any order number and map it to the date from column D
  const schedDates = sched.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, sLastRow - 1, 1).getValues().flat();
  const gridWidth = sLastCol - SCHED_GRID_START_COL + 1;
  const schedGrid = sched.getRange(SCHED_DATE_START_ROW, SCHED_GRID_START_COL, sLastRow - 1, gridWidth).getDisplayValues();

  // Map order numbers found anywhere in scheduler cells to their date
  const orderDateMap = new Map();
  schedGrid.forEach((row, rIdx) => {
    const date = schedDates[rIdx];
    if (!date) return;
    row.forEach(cellText => {
      const text = (cellText || '').toString().trim();
      if (!text) return;
      // Extract order numbers matching patterns like 07-0226-0005 or 12-0426-0001
      const orderMatches = text.match(/\d{2}-\d{4}-\d{4}/g);
      if (orderMatches) {
        orderMatches.forEach(orderNum => {
          if (!orderDateMap.has(orderNum)) orderDateMap.set(orderNum, date);
        });
      }
    });
  });

  const chipCols = INT_TRACKER_CHIP_COLS;
  const tLastRow = tracker.getLastRow();

  chipCols.forEach(colLetter => {
    const chipColIndex = tracker.getRange(colLetter + '3').getColumn();
    const dateCol = chipColIndex - 1;
    const orderCol = chipColIndex - INT_TRACKER_ORDER_OFFSET;
    const numRows = tLastRow - 2;
    if (numRows <= 0) return;

    const orderNums = tracker.getRange(3, orderCol, numRows, 1).getDisplayValues().flat();
    const existing = tracker.getRange(3, dateCol, numRows, 1).getValues().flat();

    const outDates = orderNums.map((orderNum, i) => {
      if (existing[i]) return [existing[i]];
      const key = (orderNum || '').toString().trim();
      if (!key) return [''];
      return [orderDateMap.get(key) || ''];
    });

    tracker.getRange(3, dateCol, numRows, 1)
      .setValues(outDates)
      .setNumberFormat('m/d/yy - ddd')
      .setHorizontalAlignment('center')
      .setFontWeight('bold');
  });

  log('syncDeliveryDates', 'Matched ' + orderDateMap.size + ' order numbers');
  SpreadsheetApp.getUi().alert('Delivery dates synced. Found ' + orderDateMap.size + ' scheduled orders.');
}

/**
 * Copies up to 5 business-day blocks (date + 2 hidden rows) from SCHEDULER
 * into 'Current Week', preserving formatting.
 *
 * ✅ UPDATED:
 * - Scheduler date column is D (used to find visible dates)
 * - Copy source block from D→end
 * - Paste into Current Week starting at column B (so CW layout stays the same)
 */
function updateCurrentWeek(options) {
  const startDay = (options && options.startDay !== undefined) ? options.startDay : 0;
  const clearFirst = (options && options.clear !== undefined) ? options.clear : true;

  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sched = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sched) return 0;
  const cw = getSheetOrAlert(ss, SHEET_CURRENT_WEEK);
  if (!cw) return 0;

  const schedLastCol = sched.getLastColumn();
  const srcWidth = schedLastCol - SCHED_DATE_COL + 1;

  if (clearFirst) {
    const clearRows = CW_PRESERVE_ROW - 2;
    cw.getRange(2, 2, clearRows, srcWidth).clear();
  }

  // Find this week's Monday
  const today = normalizeDate(new Date());
  const todayDow = today.getDay(); // 0=Sun, 1=Mon, ..., 5=Fri
  const monday = new Date(today);
  monday.setDate(monday.getDate() - (todayDow === 0 ? 6 : todayDow - 1));

  // Build array of this week's 6 potential days (Mon-Sat)
  const weekDates = [];
  for (let d = 0; d < 6; d++) {
    const date = new Date(monday);
    date.setDate(date.getDate() + d);
    weekDates.push(normalizeDate(date));
  }

  const sLastRow = sched.getLastRow();
  const schedDateRange = sched.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, sLastRow - 1, 1);
  const dates = schedDateRange.getValues().flat();
  const fontColors = schedDateRange.getFontColors().flat();

  // Build a map of date → scheduler row index (first visible row for each date)
  const dateRowMap = new Map();
  for (let i = 0; i < dates.length; i++) {
    const d = dates[i];
    const fc = (fontColors[i] || '').toLowerCase();
    if (d instanceof Date && fc !== '#ffffff') {
      const dt = normalizeDate(d);
      const key = dt.getTime();
      if (!dateRowMap.has(key)) dateRowMap.set(key, i + SCHED_DATE_START_ROW);
    }
  }

  // Copy Mon-Fri into fixed positions
  // Mon=rows 2-4, Tue=rows 5-7, Wed=rows 8-10, Thu=rows 11-13, Fri=rows 14-16
  let copiedDays = 0;
  for (let d = startDay; d < 5; d++) {
    const schedRow = dateRowMap.get(weekDates[d].getTime());
    if (!schedRow) continue;

    const cwRow = 2 + (d * 3);
    const src = sched.getRange(schedRow, SCHED_DATE_COL, 3, srcWidth);
    const dst = cw.getRange(cwRow, 2, 3, srcWidth);
    src.copyTo(dst, { contentsOnly: false });
    copiedDays++;
  }

  // Saturday (rows 17-19): only copy if there's data in the driver grid
  const satRow = dateRowMap.get(weekDates[5].getTime());
  const satCwRow = 17;
  if (satRow) {
    const satGrid = sched.getRange(satRow, SCHED_GRID_START_COL, 3,
      schedLastCol - SCHED_GRID_START_COL + 1).getValues();
    const hasSatData = satGrid.some(row => row.some(cell => cell !== '' && cell !== null));

    if (hasSatData) {
      const src = sched.getRange(satRow, SCHED_DATE_COL, 3, srcWidth);
      const dst = cw.getRange(satCwRow, 2, 3, srcWidth);
      src.copyTo(dst, { contentsOnly: false });
      copiedDays++;
    } else {
      cw.getRange(satCwRow, 2, 3, srcWidth).clear().setBackground('#000000');
    }
  } else {
    cw.getRange(satCwRow, 2, 3, srcWidth).clear().setBackground('#000000');
  }

  return copiedDays;
}

function publishFullWeek() {
  log('publishFullWeek', 'Starting');
  const days = updateCurrentWeek({ startDay: 0, clear: true });
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cw = ss.getSheetByName(SHEET_CURRENT_WEEK);
  if (cw) {
    applyBlackWalls(cw, CW_WALL_ROW, CW_WALL_COL);
    pushSheetToMirror(cw, SHEET_CURRENT_WEEK);
  }
  const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  updateDriverTabs(destSS);
  SpreadsheetApp.flush();
  boldDriverTabLabels(destSS);
  SpreadsheetApp.getUi().alert('Full week published (' + days + ' days).');
  log('publishFullWeek', 'Complete');
}

function publishPartialWeek() {
  log('publishPartialWeek', 'Starting');
  const today = new Date();
  const dow = today.getDay(); // 1=Mon ... 5=Fri
  const dayIndex = (dow === 0 ? 4 : dow - 1); // convert to 0=Mon ... 4=Fri
  const daysRemaining = 5 - dayIndex;

  if (daysRemaining < 3) {
    log('publishPartialWeek', 'Less than 3 days remaining, running full publish');
    publishFullWeek();
    return;
  }

  const days = updateCurrentWeek({ startDay: dayIndex, clear: false });
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cw = ss.getSheetByName(SHEET_CURRENT_WEEK);
  if (cw) {
    applyBlackWalls(cw, CW_WALL_ROW, CW_WALL_COL);
    pushSheetToMirror(cw, SHEET_CURRENT_WEEK);
  }
  const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  updateDriverTabs(destSS);
  SpreadsheetApp.flush();
  boldDriverTabLabels(destSS);
  SpreadsheetApp.getUi().alert('Partial update published (' + days + ' days from ' + ['Monday','Tuesday','Wednesday','Thursday','Friday'][dayIndex] + '). Earlier days unchanged.');
  log('publishPartialWeek', 'Complete');
}

function pushAndUpdateMirror() {
  log('pushAndUpdateMirror', 'Starting');
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cw = getSheetOrAlert(ss, SHEET_CURRENT_WEEK);
  if (!cw) return;
  applyBlackWalls(cw, CW_WALL_ROW, CW_WALL_COL);
  pushSheetToMirror(cw, SHEET_CURRENT_WEEK);
  const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  updateDriverTabs(destSS);
  SpreadsheetApp.flush();
  boldDriverTabLabels(destSS);
  SpreadsheetApp.getUi().alert('Mirror pushed and driver tabs updated.');
  log('pushAndUpdateMirror', 'Complete');
}

function runDriverUpdate() {
  log('runDriverUpdate', 'Starting driver update');
  const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  updateDriverTabs(destSS);
  SpreadsheetApp.flush();
  boldDriverTabLabels(destSS);
}

function boldDriverTabLabels(destSS) {
  const srcSS = SpreadsheetApp.getActiveSpreadsheet();
  const cw = srcSS.getSheetByName(SHEET_CURRENT_WEEK);
  if (!cw) return;

  if (!destSS) destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
  const lastCol = cw.getLastColumn();
  const driverNames = cw.getRange(1, 3, 1, lastCol - 2).getValues()[0];

  driverNames.forEach((driver) => {
    const name = (driver || '').toString().trim();
    if (!name) return;

    const driverSheet = destSS.getSheetByName(name);
    if (!driverSheet) return;

    const sheetLastRow = driverSheet.getLastRow();
    if (sheetLastRow < 2) return;
    const sheetNumRows = sheetLastRow - 1;

    const range = driverSheet.getRange(2, DRIVER_CHIP_COL, sheetNumRows, 1);
    const richVals = range.getRichTextValues();

    const newRich = richVals.map(row => {
      const rv = row[0];
      if (!rv || !rv.getText()) return row;
      const text = rv.getText();

      let builder = rv.copy();
      const boldStyle = SpreadsheetApp.newTextStyle().setBold(true).build();

      ['Pick: ', 'Drop: '].forEach(prefix => {
        const idx = text.indexOf(prefix);
        if (idx !== -1) {
          builder = builder.setTextStyle(idx, idx + prefix.length, boldStyle);
        }
      });

      return [builder.build()];
    });

    range.setRichTextValues(newRich);
  });
}




/**
 * Updates each driver’s sheet in the mirror document by pulling
 * dates (col B) and load-chip info (col C) from the “Current Week”.
 *
 * (No change needed unless you also changed Current Week’s layout.)
 */
function updateDriverTabs(destSS) {
  log('updateDriverTabs', 'Starting');
  const srcSS = SpreadsheetApp.getActiveSpreadsheet();
  const cw = getSheetOrAlert(srcSS, SHEET_CURRENT_WEEK);
  if (!cw) return;

  if (!destSS) destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);

  // ========= External Order Tracker =========
  const ext = getSheetOrAlert(srcSS, SHEET_EXT_TRACKER);
  if (!ext) return;

  const extLastRow = ext.getLastRow();
  if (extLastRow < 2) return;

  const extNumRows = extLastRow - 1;

  const extKeys = ext.getRange(2, 1, extNumRows, 1).getDisplayValues().flat();

  const extDriverRange = ext.getRange(2, EXT_DRIVER_COL, extNumRows, 1);
  const extDriverVals = extDriverRange.getValues().flat();
  const extDriverBgs = extDriverRange.getBackgrounds().flat();
  const extDriverFontCols = extDriverRange.getFontColors().flat();
  const extDriverFontWts = extDriverRange.getFontWeights().flat();
  const extDriverNumFormats = extDriverRange.getNumberFormats().flat();

  const extPuRich = ext.getRange(2, EXT_PICKUP_COL, extNumRows, 1).getRichTextValues().flat();
  const extDrRich = ext.getRange(2, EXT_DROP_COL, extNumRows, 1).getRichTextValues().flat();
  const extNotes = ext.getRange(2, EXT_NOTES_COL, extNumRows, 1).getValues().flat();

  const extMap = new Map();
  for (let i = 0; i < extKeys.length; i++) {
    const key = (extKeys[i] || '').toString().trim();
    if (!key) continue;

    extMap.set(key, {
      driverVal: extDriverVals[i],
      driverBg: extDriverBgs[i],
      driverFontCol: extDriverFontCols[i],
      driverFontWt: extDriverFontWts[i],
      driverNumFormat: extDriverNumFormats[i],
      pu: extPuRich[i],
      dr: extDrRich[i],
      notes: (extNotes[i] || '').toString()
    });
  }

  // ========= Bagger Customers lookup =========
  const bagger = srcSS.getSheetByName(SHEET_BAGGER);
  const baggerMap = new Map();

  if (bagger) {
    const baggerLastRow = bagger.getLastRow();
    if (baggerLastRow >= 2) {
      const baggerNumRows = baggerLastRow - 1;

      const baggerKeys = bagger.getRange(2, 1, baggerNumRows, 1).getDisplayValues().flat();
      const baggerRich = bagger.getRange(2, BAGGER_MAP_URL_COL, baggerNumRows, 1).getRichTextValues().flat();
      const baggerVals = bagger.getRange(2, BAGGER_MAP_URL_COL, baggerNumRows, 1).getDisplayValues().flat();

      for (let i = 0; i < baggerKeys.length; i++) {
        const key = (baggerKeys[i] || '').toString().trim();
        if (!key) continue;

        let url = '';
        const rich = baggerRich[i];
        if (rich && rich.getLinkUrl && rich.getLinkUrl()) {
          url = rich.getLinkUrl();
        } else {
          url = (baggerVals[i] || '').toString().trim();
        }

        if (url) {
          baggerMap.set(key.toLowerCase(), url);
        }
      }
    }
  }

  // ========= Current Week basics =========
  const lastCol = cw.getLastColumn();
  const lastRow = cw.getLastRow();
  const numRows = lastRow - 1;
  if (numRows <= 0) return;

  // If Saturday has no data, wall moves up to row 17 on driver tabs
  const hasSaturday = numRows >= 16;
  const driverWallRow = hasSaturday ? DT_WALL_ROW : 17;

  const dateRange = cw.getRange(2, 2, numRows, 1);
  const dateVals = dateRange.getValues();
  const dateFontCols = dateRange.getFontColors();
  const dateFontWts = dateRange.getFontWeights();
  const dateNumFormats = dateRange.getNumberFormats();

  const driverNames = cw.getRange(1, 3, 1, lastCol - 2).getValues()[0];

  function extractExternalKeyFromChip(chipText) {
    const text = (chipText || '').toString().trim();
    if (!text) return '';

    // Try order number pattern first (e.g., 12-0426-0001)
    const orderMatch = text.match(/\d{2}-\d{4}-\d{4}/);
    if (orderMatch && extMap.has(orderMatch[0])) return orderMatch[0];

    // Try plain numeric keys (e.g., 1845574)
    const numMatch = text.match(/\b\d{5,}\b/);
    if (numMatch && extMap.has(numMatch[0])) return numMatch[0];

    // Fallback: split on " - " and check parts against the map
    const firstLine = text.split('\n')[0].trim();
    if (!firstLine) return '';
    const parts = firstLine.split(' - ').map(s => (s || '').trim()).filter(Boolean);
    for (const part of parts) {
      if (extMap.has(part)) return part;
    }

    return '';
  }

  function findStoreMapUrlFromChip(chipText) {
    const text = (chipText || '').toString().toLowerCase();
    if (!text) return '';

    for (const [storeKey, url] of baggerMap.entries()) {
      if (storeKey && text.includes(storeKey)) return url;
    }

    return '';
  }

  driverNames.forEach((driver, idx) => {
    const name = (driver || '').toString().trim();
    if (!name) return;

    const driverSheet = destSS.getSheetByName(name);
    if (!driverSheet) return;

    driverSheet.setFrozenRows(1);

    driverSheet.getRange(2, DRIVER_DATE_COL, numRows, 5).clearContent().clearFormat();
    driverSheet.getRange(2, DRIVER_STORE_COL, numRows, 1).clearContent();

    const chipCol = DRIVER_CHIP_COL + idx;
    const chipRange = cw.getRange(2, chipCol, numRows, 1);

    const chipVals = chipRange.getValues();
    const chipBgs = chipRange.getBackgrounds();
    const chipFontCols = chipRange.getFontColors();
    const chipFontWts = chipRange.getFontWeights();
    const chipNumFormats = chipRange.getNumberFormats();

    driverSheet.getRange(2, DRIVER_DATE_COL, numRows, 1)
      .setValues(dateVals)
      .setFontColors(dateFontCols)
      .setFontWeights(dateFontWts)
      .setNumberFormats(dateNumFormats)
      .setFontSize(13)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('top')
      .setWrap(true);

    const outVals = chipVals.map(r => [r[0]]);
    const outBgs = chipBgs.map(r => [r[0]]);
    const outFontCols = chipFontCols.map(r => [r[0]]);
    const outFontWts = chipFontWts.map(r => [r[0]]);
    const outNumFormats = chipNumFormats.map(r => [r[0]]);

    driverSheet.getRange(2, DRIVER_PICKUP_COL, numRows, 2).clearContent();

    const emptyRich = SpreadsheetApp.newRichTextValue().setText('').build();
    const puRichArr = Array.from({ length: numRows }, () => [emptyRich]);
    const drRichArr = Array.from({ length: numRows }, () => [emptyRich]);
    const storeRichArr = Array.from({ length: numRows }, () => [emptyRich]);
    const notesArr = Array.from({ length: numRows }, () => ['']);

    for (let r = 0; r < numRows; r++) {
      const chipText = chipVals[r][0];

      const key = extractExternalKeyFromChip(chipText);
      if (key) {
        const hit = extMap.get(key);
        if (hit) {
          outVals[r][0] = hit.driverVal || '';
          outBgs[r][0] = hit.driverBg || '#ffffff';
          outFontCols[r][0] = hit.driverFontCol || '#000000';
          outFontWts[r][0] = hit.driverFontWt || 'normal';
          outNumFormats[r][0] = hit.driverNumFormat || '@';

          if (hit.pu && hit.pu.getText && hit.pu.getText()) {
            puRichArr[r][0] = hit.pu;
          }
          if (hit.dr && hit.dr.getText && hit.dr.getText()) {
            drRichArr[r][0] = hit.dr;
          }
          if (hit.notes) {
            notesArr[r][0] = hit.notes;
          }
        }
      }

      const storeUrl = findStoreMapUrlFromChip(outVals[r][0] || chipText);
      if (storeUrl) {
        storeRichArr[r][0] = SpreadsheetApp.newRichTextValue()
          .setText('STORE MAP')
          .setLinkUrl(storeUrl)
          .build();
      }
    }

    driverSheet.getRange(2, DRIVER_CHIP_COL, numRows, 1)
      .setValues(outVals)
      .setBackgrounds(outBgs)
      .setFontColors(outFontCols)
      .setFontWeights(outFontWts)
      .setNumberFormats(outNumFormats)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('top')
      .setWrap(true);

    driverSheet.getRange(2, DRIVER_NOTES_COL, numRows, 1)
      .setValues(notesArr)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('top')
      .setWrap(true);

    driverSheet.getRange(2, DRIVER_PICKUP_COL, numRows, 1).setRichTextValues(puRichArr);
    driverSheet.getRange(2, DRIVER_DROP_COL, numRows, 1).setRichTextValues(drRichArr);
    driverSheet.getRange(2, DRIVER_STORE_COL, numRows, 1).setRichTextValues(storeRichArr);

    driverSheet.getRange(2, DRIVER_PICKUP_COL, numRows, 3)
      .setHorizontalAlignment('center')
      .setVerticalAlignment('top')
      .setWrap(true);

    applyBlackWalls(driverSheet, driverWallRow, DT_WALL_COL);
  });

 
}


/**
 * Prompts for a date range and clears Scheduler “assignment grid” cells for those dates.
 *
 * ✅ UPDATED: dates are in D, so we clear columns to the right of D.
 * Keeps your original width of 13 columns (old C→O) but shifted right: now E→Q.
 */
function clearSchedulerDateRange() {
  const ui = SpreadsheetApp.getUi();
  const resp = ui.prompt(
    'Clear Scheduler Data',
    'Enter date range (MM/DD/YYYY - MM/DD/YYYY):',
    ui.ButtonSet.OK_CANCEL
  );
  if (resp.getSelectedButton() !== ui.Button.OK) return;

  const input = resp.getResponseText();
  const parts = input.split(/\s*-\s*/);
  const startText = parts[0].trim();
  const endText = parts[1] ? parts[1].trim() : startText;

  const startDate = normalizeDate(new Date(startText));
  const endDate   = normalizeDate(new Date(endText));

  if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
    ui.alert('Invalid date format. Please use MM/DD/YYYY.');
    return;
  }

  if (startDate > endDate) {
    ui.alert('Start date must be before or equal to end date.');
    return;
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sheet) return;

  const lastRow = sheet.getLastRow();
  const dates = sheet.getRange(SCHED_DATE_START_ROW, SCHED_DATE_COL, lastRow - 1, 1).getValues().flat();

  const clearStartCol = SCHED_DATE_COL + 1;
  const clearWidth    = sheet.getLastColumn() - clearStartCol + 1;
  if (clearWidth < 1) return;

  for (let i = 0; i < dates.length; i++) {
    const cellVal = dates[i];
    if (cellVal instanceof Date) {
      const d = normalizeDate(cellVal);
      if (d >= startDate && d <= endDate) {
        const row = i + SCHED_DATE_START_ROW;
        sheet.getRange(row, clearStartCol, 1, clearWidth).clearContent().clearFormat();
      }
    }
  }

  applyDateBordersManually();
  ui.alert(`Cleared data from ${startText} to ${endText}.`);
}


function pushCurrentWeekToMirror() {
  const srcSS = SpreadsheetApp.getActiveSpreadsheet();
  const cw = getSheetOrAlert(srcSS, SHEET_CURRENT_WEEK);
  if (!cw) return;

  pushSheetToMirror(cw, SHEET_CURRENT_WEEK);
}

function manualUpdateCurrentWeek() {
  const days = updateCurrentWeek({ startDay: 0, clear: true });
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const cw = ss.getSheetByName(SHEET_CURRENT_WEEK);
  if (cw) pushSheetToMirror(cw, SHEET_CURRENT_WEEK);
  SpreadsheetApp.getUi().alert('Current Week updated (' + days + ' days). Driver tabs NOT updated.');
}

// ============================
// FLEET MANAGEMENT
// ============================

function getDriverHeaders(sched) {
  const lastCol = sched.getLastColumn();
  if (lastCol < SCHED_GRID_START_COL) return [];
  const headers = sched.getRange(1, SCHED_GRID_START_COL, 1, lastCol - SCHED_GRID_START_COL + 1).getValues()[0];
  const drivers = [];
  for (let i = 0; i < headers.length; i++) {
    const name = (headers[i] || '').toString().trim();
    if (!name) continue;
    drivers.push({ name, col: SCHED_GRID_START_COL + i });
  }
  return drivers;
}

function findOutsideCarriersCol(sched) {
  const drivers = getDriverHeaders(sched);
  for (const d of drivers) {
    if (d.name.toLowerCase().includes('outside carrier')) return d.col;
  }
  return null;
}

function addDriver() {
  const ui = SpreadsheetApp.getUi();
  const nameResp = ui.prompt('Add Driver', 'Enter driver name (e.g. MIKE):', ui.ButtonSet.OK_CANCEL);
  if (nameResp.getSelectedButton() !== ui.Button.OK) return;
  const driverName = nameResp.getResponseText().trim().toUpperCase();
  if (!driverName) { ui.alert('Driver name cannot be empty.'); return; }

  const truckResp = ui.prompt('Add Driver', 'Enter truck number and type (e.g. 45 F):', ui.ButtonSet.OK_CANCEL);
  if (truckResp.getSelectedButton() !== ui.Button.OK) return;
  const truckInfo = truckResp.getResponseText().trim().toUpperCase();
  if (!truckInfo) { ui.alert('Truck info cannot be empty.'); return; }

  const header = driverName + ' ' + truckInfo;
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sched = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sched) return;
  const cw = getSheetOrAlert(ss, SHEET_CURRENT_WEEK);
  if (!cw) return;

  log('addDriver', 'Adding driver: ' + header);

  const ocCol = findOutsideCarriersCol(sched);
  const insertCol = ocCol || (sched.getLastColumn() + 1);

  sched.insertColumnBefore(insertCol);
  sched.getRange(1, insertCol).setValue(header);

  if (insertCol > SCHED_GRID_START_COL) {
    const srcCol = insertCol - 1;
    const maxRows = sched.getMaxRows();
    const srcRange = sched.getRange(2, srcCol, maxRows - 1, 1);
    const dstRange = sched.getRange(2, insertCol, maxRows - 1, 1);
    srcRange.copyTo(dstRange, SpreadsheetApp.CopyPasteType.PASTE_FORMAT, false);
    dstRange.clearContent();
  }

  const cwLastCol = cw.getLastColumn();
  const cwHeaders = cw.getRange(1, 1, 1, cwLastCol).getValues()[0];
  let cwInsertCol = cwLastCol + 1;
  for (let i = cwHeaders.length - 1; i >= 0; i--) {
    const h = (cwHeaders[i] || '').toString().trim().toLowerCase();
    if (h.includes('outside carrier')) { cwInsertCol = i + 1; break; }
  }
  cw.insertColumnBefore(cwInsertCol);
  cw.getRange(1, cwInsertCol).setValue(header);

  try {
    const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
    const existing = destSS.getSheetByName(header);
    if (!existing) {
      const allSheets = destSS.getSheets();
      const templateTab = allSheets.find(s => {
        const n = s.getName().toLowerCase();
        return n !== 'current week' && !s.isSheetHidden();
      });

      if (templateTab) {
        const newTab = templateTab.copyTo(destSS);
        newTab.setName(header);
        newTab.getRange(1, DRIVER_CHIP_COL).setValue(header);
        const tabLastRow = newTab.getLastRow();
        if (tabLastRow > 1) {
          newTab.getRange(2, DRIVER_DATE_COL, tabLastRow - 1, 6).clearContent();
        }
        newTab.setFrozenRows(1);
      } else {
        const newTab = destSS.insertSheet(header);
        newTab.getRange(1, 1, 1, 7).setValues([['', 'Date', header, '', 'Pickup', 'Drop', 'Store Map']]);
        newTab.setFrozenRows(1);
      }
      log('addDriver', 'Created mirror tab: ' + header);
    }
  } catch (e) {
    log('addDriver', 'Warning: could not create mirror tab: ' + e.message);
  }

  ui.alert('Added driver "' + header + '" successfully.');
  log('addDriver', 'Complete');
}

function renameDriver() {
  const ui = SpreadsheetApp.getUi();
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sched = getSheetOrAlert(ss, SHEET_SCHEDULER);
  if (!sched) return;

  const drivers = getDriverHeaders(sched).filter(d => !d.name.toLowerCase().includes('outside carrier'));
  if (drivers.length === 0) { ui.alert('No drivers found.'); return; }

  const list = drivers.map((d, i) => (i + 1) + '. ' + d.name).join('\n');
  const pickResp = ui.prompt('Rename / Swap Truck',
    'Select a driver by number:\n' + list, ui.ButtonSet.OK_CANCEL);
  if (pickResp.getSelectedButton() !== ui.Button.OK) return;
  const idx = parseInt(pickResp.getResponseText().trim(), 10) - 1;
  if (isNaN(idx) || idx < 0 || idx >= drivers.length) { ui.alert('Invalid selection.'); return; }

  const oldName = drivers[idx].name;
  const col = drivers[idx].col;

  const newResp = ui.prompt('Rename / Swap Truck',
    'Current: ' + oldName + '\nEnter new name and truck (e.g. JORDAN 80 F):', ui.ButtonSet.OK_CANCEL);
  if (newResp.getSelectedButton() !== ui.Button.OK) return;
  const newName = newResp.getResponseText().trim().toUpperCase();
  if (!newName) { ui.alert('Name cannot be empty.'); return; }

  log('renameDriver', oldName + ' -> ' + newName);

  sched.getRange(1, col).setValue(newName);

  const cw = ss.getSheetByName(SHEET_CURRENT_WEEK);
  if (cw) {
    const cwLastCol = cw.getLastColumn();
    const cwHeaders = cw.getRange(1, 1, 1, cwLastCol).getValues()[0];
    for (let i = 0; i < cwHeaders.length; i++) {
      if ((cwHeaders[i] || '').toString().trim() === oldName) {
        cw.getRange(1, i + 1).setValue(newName);
        break;
      }
    }
  }

  try {
    const destSS = SpreadsheetApp.openById(MIRROR_SHEET_ID);
    const mirrorTab = destSS.getSheetByName(oldName);
    if (mirrorTab) mirrorTab.setName(newName);
  } catch (e) {
    log('renameDriver', 'Warning: could not rename mirror tab: ' + e.message);
  }

  ui.alert('Renamed "' + oldName + '" to "' + newName + '".');
}

