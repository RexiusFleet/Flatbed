// SETUP (do once before deploying):
// 1. Extensions → Apps Script
// 2. Left sidebar → Services (+) → add "Drive API" (v2) — needed for OCR
// 3. Deploy → New deployment → Web app → Execute as: Me → Access: Anyone in org

const ACTIVE_FOLDER_ID  = '1SlKLmMBxu7kfUpJ3Bqn_CjfzPB6Gt0Us';
const ARCHIVE_FOLDER_ID = '1L2VnN0IUW6s5DyPeTpNVhOubewkpl7DK';
const BROKER_SHEET_ID   = '1KlPQrxbXjDssy3Y5QrU75FoaGpeCmTmQhUC-m0p1mJ4';

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getLoads() {
  const activeFolder = DriveApp.getFolderById(ACTIVE_FOLDER_ID);
  const subfolders   = activeFolder.getFolders();
  const loads        = [];

  while (subfolders.hasNext()) {
    const folder = subfolders.next();
    const files  = folder.getFiles();
    const fileData = { rateCon: undefined, invoice: undefined, pod: undefined };

    while (files.hasNext()) {
      const file  = files.next();
      const lower = file.getName().toLowerCase();
      const info  = { id: file.getId(), name: file.getName() };
      if      (lower.includes('ratecon')) fileData.rateCon = info;
      else if (lower.includes('invoice')) fileData.invoice = info;
      else if (lower.includes('pod'))     fileData.pod     = info;
    }

    loads.push({
      folderId : folder.getId(),
      name     : folder.getName(),
      files    : fileData,
      created  : folder.getDateCreated().getTime()
    });
  }

  loads.sort((a, b) => b.created - a.created);
  return loads;
}

function getBrokers() {
  const sheet   = SpreadsheetApp.openById(BROKER_SHEET_ID)
                    .getSheetByName('outside customer list');
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  return sheet.getRange(2, 1, lastRow - 1, 1)
    .getValues()
    .map(row => String(row[0]).trim())
    .filter(v => v);
}

function getArchive() {
  const archiveFolder = DriveApp.getFolderById(ARCHIVE_FOLDER_ID);
  const subfolders    = archiveFolder.getFolders();
  const loads         = [];

  while (subfolders.hasNext()) {
    const folder   = subfolders.next();
    const files    = [];
    const fileIter = folder.getFiles();
    while (fileIter.hasNext()) {
      const file = fileIter.next();
      files.push({ name: file.getName(), url: file.getUrl() });
    }
    loads.push({
      name    : folder.getName(),
      url     : folder.getUrl(),
      files   : files,
      created : folder.getDateCreated().getTime()
    });
  }

  loads.sort((a, b) => b.created - a.created);
  return loads;
}

function createLoad(rateConBase64, loadName) {
  const activeFolder = DriveApp.getFolderById(ACTIVE_FOLDER_ID);
  const loadFolder   = activeFolder.createFolder(loadName);
  const bytes        = Utilities.base64Decode(rateConBase64);
  const blob         = Utilities.newBlob(bytes, 'application/pdf', loadName + '_ratecon.pdf');
  const file         = loadFolder.createFile(blob);
  return { folderId: loadFolder.getId(), name: loadName, rcFileId: file.getId() };
}

// type: keyword used to find and trash existing file of same role (e.g. 'invoice', 'pod', 'ratecon')
// fileName: full base name for the saved file (without .pdf)
function saveFileToLoad(folderId, base64Data, type, fileName) {
  const folder   = DriveApp.getFolderById(folderId);
  const existing = folder.getFiles();

  while (existing.hasNext()) {
    const f = existing.next();
    if (f.getName().toLowerCase().includes(type.toLowerCase())) f.setTrashed(true);
  }

  const bytes = Utilities.base64Decode(base64Data);
  const blob  = Utilities.newBlob(bytes, 'application/pdf', fileName + '.pdf');
  const file  = folder.createFile(blob);
  return { fileId: file.getId(), name: file.getName() };
}

function deleteLoad(folderId) {
  DriveApp.getFolderById(folderId).setTrashed(true);
  return true;
}

function getFileBase64(fileId) {
  return Utilities.base64Encode(DriveApp.getFileById(fileId).getBlob().getBytes());
}

function extractTextFromPdf(base64Data) {
  const bytes   = Utilities.base64Decode(base64Data);
  const pdfBlob = Utilities.newBlob(bytes, 'application/pdf', 'ocr_temp.pdf');

  let docId;
  try {
    const result = Drive.Files.insert(
      { title: 'ocr_' + Date.now(), mimeType: MimeType.GOOGLE_DOCS },
      pdfBlob,
      { ocr: true, ocrLanguage: 'en' }
    );
    docId = result.id;
    return DocumentApp.openById(docId).getBody().getText();
  } finally {
    try { if (docId) DriveApp.getFileById(docId).setTrashed(true); } catch (e) {}
  }
}

// attachmentName: full base name for the email attachment PDF (without .pdf)
// Archive only — no email. Used by the client-side Download flow.
function archiveLoad(folderId, mergedBase64, attachmentName) {
  const bytes  = Utilities.base64Decode(mergedBase64);
  const blob   = Utilities.newBlob(bytes, 'application/pdf', attachmentName + '.pdf');
  const folder = DriveApp.getFolderById(folderId);
  folder.createFile(blob);
  const activeFolder  = DriveApp.getFolderById(ACTIVE_FOLDER_ID);
  const archiveFolder = DriveApp.getFolderById(ARCHIVE_FOLDER_ID);
  archiveFolder.addFolder(folder);
  activeFolder.removeFolder(folder);
  return true;
}

function emailAndArchive(folderId, mergedBase64, attachmentName) {
  const bytes  = Utilities.base64Decode(mergedBase64);
  const blob   = Utilities.newBlob(bytes, 'application/pdf', attachmentName + '.pdf');
  const email  = 'nathanl@rexius.com';

  MailApp.sendEmail(email, 'Invoice Package: ' + attachmentName, '', { attachments: [blob] });

  const folder        = DriveApp.getFolderById(folderId);
  const activeFolder  = DriveApp.getFolderById(ACTIVE_FOLDER_ID);
  const archiveFolder = DriveApp.getFolderById(ARCHIVE_FOLDER_ID);

  archiveFolder.addFolder(folder);
  activeFolder.removeFolder(folder);

  return true;
}
