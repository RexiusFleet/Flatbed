@echo off
REM ============================================================
REM  Nate's Flatbed Billing - local launcher (Windows)
REM  Double-click this file to start the app.
REM  It serves this folder on localhost so Chrome can save
REM  finished invoice packages straight into your archive folder.
REM ============================================================
cd /d "%~dp0"
echo Starting Nate's Flatbed Billing...
echo Leave this black window OPEN while you work. Close it to quit.
echo.
start "" "http://localhost:8765/index.html"
python server.py 2>nul || py server.py
pause
