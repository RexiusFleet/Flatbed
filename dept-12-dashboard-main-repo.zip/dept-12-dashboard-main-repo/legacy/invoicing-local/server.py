import http.server, json, os, sys, tempfile, base64, re, time

PORT = 8765
# Bind to loopback only. Binding to '' would expose this directory listing and the
# /create-draft endpoint (which creates Outlook drafts in your mailbox) to anyone
# on the office network.
HOST = '127.0.0.1'
BASE = os.path.dirname(os.path.abspath(__file__))

try:
    import win32com.client, pywintypes
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

# Transient COM errors that mean "Outlook is busy, try again" — NOT real failures.
# These show up when drafts are created rapidly (e.g. a 20-file mass batch):
#   0x80010001 RPC_E_CALL_REJECTED          — Outlook rejected the call (busy)
#   0x8001010A RPC_E_SERVERCALL_RETRYLATER  — message filter says retry later
#   0x80080005 CO_E_SERVER_EXEC_FAILURE     — Outlook still launching
RETRY_HRESULTS = {-2147418111, -2147417846, -2146959355}

# Full, self-contained email body incl. the signature. We build this ourselves
# instead of pulling Outlook's default signature via GetInspector — it's specific
# to this program (your normal Outlook signature is untouched) and much faster.
EMAIL_BODY = """\
<html><body style="font-family:'Segoe UI',Arial,sans-serif;font-size:14px;color:#222222;">
<p style="margin:0 0 12px 0;">Hello,</p>
<p style="margin:0 0 12px 0;">Please see the attached invoice.</p>
<p style="margin:0 0 12px 0;">
  <em style="font-size:11px;color:#555555;">This email was sent automatically, feel free to respond with questions and concerns.</em>
</p>
<p style="margin:0 0 18px 0;">Thank you,</p>
<div style="font-size:13px;color:#222222;line-height:1.15;">
  <span style="font-weight:bold;">Nathan Lee</span> | Rexius Flatbed Trucking<br>
  MC# 194041<br>
  Office: 541-342-1835<br>
  Direct: 458-298-0680
</div>
</body></html>
"""

def _is_retryable(e):
    hr = e.args[0] if getattr(e, 'args', None) else None
    return hr in RETRY_HRESULTS

def _construct_mail(to, subject, pdf_path):
    """Build the draft fully but DO NOT save it. Safe to retry wholesale because
    nothing is persisted to the Drafts folder until .Save() is called."""
    outlook = win32com.client.Dispatch('Outlook.Application')
    mail    = outlook.CreateItem(0)   # 0 = olMailItem
    mail.Subject = subject

    # Resolve the recipient against the address book so it doesn't show the red X.
    # Best-effort: on locked-down Outlook this can be blocked, so fall back to To.
    if to:
        resolved_ok = False
        try:
            for addr in re.split(r'[;,]\s*', to.strip()):
                if addr:
                    rcp = mail.Recipients.Add(addr)
                    try: rcp.Resolve()
                    except Exception: pass
            try: mail.Recipients.ResolveAll()
            except Exception: pass
            resolved_ok = True
        except Exception:
            resolved_ok = False
        if not resolved_ok:
            try: mail.To = to
            except Exception: pass

    # Use our own baked-in body + signature (no GetInspector = much faster)
    mail.HTMLBody = EMAIL_BODY

    mail.Attachments.Add(pdf_path)    # Outlook copies the bytes on attach
    return mail

def create_draft(to, subject, pdf_path):
    """Create one Outlook draft, retrying transient 'Outlook is busy' rejections.

    The build and the save are retried separately on purpose:
      • _construct_mail can be retried wholesale (nothing saved yet → no duplicates)
      • .Save() is retried on the SAME mail object, so a rejected-but-actually-saved
        call just re-saves the same item instead of creating a second draft."""
    mail = None
    for i in range(5):
        try:
            mail = _construct_mail(to, subject, pdf_path); break
        except pywintypes.com_error as e:
            if _is_retryable(e) and i < 4: time.sleep(0.05 * (i + 1)); continue
            raise

    for i in range(6):
        try:
            mail.Save(); return        # saves to Drafts, no window opens
        except pywintypes.com_error as e:
            if _is_retryable(e) and i < 5: time.sleep(0.05 * (i + 1)); continue
            raise

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=BASE, **kw)

    def do_POST(self):
        if self.path == '/create-draft':
            if not HAS_WIN32:
                self._err('pywin32 not installed — run: pip install pywin32 --user')
                return
            try:
                n    = int(self.headers.get('Content-Length', 0))
                data = json.loads(self.rfile.read(n))

                to       = data['to']
                subject  = data['subject']
                body     = data.get('body', '')
                pdf_b64  = data['pdfB64']
                filename = data['filename']

                # Write PDF to a temp file named correctly so Outlook shows the right
                # filename. basename() strips any path the client sent so the write
                # can never escape the temp directory.
                safe_name = os.path.basename(filename) or 'invoice.pdf'
                pdf_bytes = base64.b64decode(pdf_b64)
                pdf_path  = os.path.join(tempfile.gettempdir(), safe_name)
                with open(pdf_path, 'wb') as f:
                    f.write(pdf_bytes)

                try:
                    create_draft(to, subject, pdf_path)
                finally:
                    try: os.remove(pdf_path)
                    except: pass

                self._ok({'ok': True})
            except Exception as e:
                self._err(str(e))
        else:
            self.send_response(404); self.end_headers()

    def _ok(self, obj):
        body = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header('Content-Type',   'application/json')
        self.send_header('Content-Length', len(body))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers(); self.wfile.write(body)

    def _err(self, msg):
        body = json.dumps({'error': msg}).encode()
        self.send_response(500)
        self.send_header('Content-Type',   'application/json')
        self.send_header('Content-Length', len(body))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers(); self.wfile.write(body)

    def log_message(self, *_): pass

if __name__ == '__main__':
    os.chdir(BASE)
    if not HAS_WIN32:
        print('WARNING: pywin32 not found. Outlook drafts will not work.')
        print('Fix: pip install pywin32 --user\n')
    print(f'Flatbed Billing  →  http://localhost:{PORT}/index.html')
    print('Leave this window open while you work.\n')
    with http.server.HTTPServer((HOST, PORT), Handler) as s:
        s.serve_forever()
